package com.ghostie.pet

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters

/** The four tabs of the phone's calendar form: Event, Birthday, Anniversary, Countdown. */
enum class EventKind(val label: String, val icon: String) {
    EVENT("Event", "📅"), BIRTHDAY("Birthday", "🎂"), ANNIVERSARY("Anniversary", "💍"), COUNTDOWN("Countdown", "⏳");

    companion object {
        fun parse(s: String): EventKind? = values().firstOrNull { it.name.equals(s, true) || it.label.equals(s, true) }
    }
}

sealed class Command {
    object Organize : Command()
    object Help : Command()
    /**
     * [startMillis] is local time. For all-day events only the date matters.
     * [repeat] is "", DAILY, WEEKLY, MONTHLY or YEARLY. [remind] is minutes before the start.
     * [explicit] is true when the user named the category themselves.
     */
    data class Event(
        val title: String, val startMillis: Long, val kind: EventKind = EventKind.EVENT, val allDay: Boolean = false,
        val repeat: String = "", val durationMin: Int = 60, val remind: List<Int> = listOf(10),
        val description: String = "", val explicit: Boolean = false
    ) : Command()
    data class MakeKind(val kind: EventKind) : Command()
    object Undo : Command()
    data class Note(val text: String) : Command()
    object ShowNotes : Command()
    object ClearNotes : Command()
    data class TodoAdd(val text: String) : Command()
    object TodoList : Command()
    data class TodoDone(val n: Int) : Command()
    data class Flashlight(val on: Boolean?) : Command()
    data class Quick(val kind: String) : Command()
    data class Calculate(val expr: String) : Command()
    data class RemindIn(val text: String, val minutes: Int) : Command()
    data class Trick(val kind: String) : Command()
    data class Study(val focus: Int?, val brk: Int?, val subject: String? = null) : Command()
    object Plan : Command()
    data class Food(val items: List<WantedItem>) : Command()
    object FoodStop : Command()
    data class Suggestions(val on: Boolean) : Command()
    object ForgetHabits : Command()
    object StudyStop : Command()
    object StudyLog : Command()
    /** "When I say X, do/say Y" (exact phrase) or "remember X means Y" (word substitution, stored as word:Y). */
    data class Teach(val phrase: String, val meaning: String) : Command()
    data class Forget(val phrase: String) : Command()
    object ForgetAll : Command()
    object Learned : Command()
    data class Timer(val seconds: Int) : Command()
    data class Alarm(val hour: Int, val minute: Int, val label: String = "") : Command()
    data class Call(val target: String) : Command()
    data class OpenApp(val name: String) : Command()
    data class OpenFile(val query: String) : Command()
    data class ShowDocs(val subject: String) : Command()
    data class Watch(val group: String) : Command()
    /** Recognised verb but something is missing; message tells the user what. */
    data class Incomplete(val message: String) : Command()
}

/** Turns chat text into a Command. Pure Kotlin so it can be tested without a phone. */
object Commands {
    const val HELP = "I can do these 💜\n" +
        "• organize documents – sorts your WhatsApp files by subject\n" +
        "• show documents of computer science\n" +
        "• add event maths exam tomorrow 10am  (also: add birthday Tikki on 19 October, anniversary, countdown to exams on 5 Dec; add \"every week\", \"for 2 hours\", \"all day\", \"remind me 30 minutes before\")\n" +
        "• make it a birthday – fixes the category of the last event, and I'll remember\n" +
        "• when I say study mode, set timer 25 minutes – teach me your own phrases\n" +
        "• remember cs means computer science\n" +
        "• what have you learned / forget study mode / forget everything\n" +
        "• watch group CSE 3A – I'll remind you the day before any submission or event registration deadline posted there\n" +
        "• Share a group's exported chat (or one message) from WhatsApp to Ghostie to catch up on deadlines\n" +
        "• call Mom  /  call 9876543210\n" +
        "• timer 10 minutes\n" +
        "• alarm 6:30 am\n" +
        "• open WhatsApp\n" +
        "• note buy milk  /  show notes  /  clear notes\n" +
        "• todo finish lab record  /  my todos  /  done 2\n" +
        "• remind me to drink water in 20 minutes\n" +
        "• flashlight on / off\n" +
        "• calculate 12*(3+4)  /  flip a coin  /  roll a dice\n" +
        "• what time is it  /  what's the date  /  battery\n" +
        "• plan my week  /  study dbms 45  (I learn your routines and suggest things; say \"stop suggestions\" to pause them)\n" +
        "• study mode  /  study 45 (focus minutes)  /  stop studying  /  study log\n" +
        "• cheapest chicken biryani  /  compare paneer pizza and garlic bread  (I check Zomato, Swiggy and brand apps and tell you the cheapest with delivery fees - I never order)\n" +
        "• open file <name>  /  open the DBMS pdf  (I find it on your phone and open it)\n" +
        "• dance  /  wave  /  yawn  /  do a flip  (tricks!)"

    private val I = RegexOption.IGNORE_CASE
    private data class TimeHit(val hour: Int, val minute: Int, val range: IntRange)

    fun parse(raw: String, now: LocalDateTime = LocalDateTime.now()): Command? {
        val t = raw.trim()
        if (t.isEmpty()) return null

        if (Regex("^(?:forget|reset|clear)\\s+(?:my\\s+)?(?:habits|routines)$", I).matches(t)) return Command.ForgetHabits
        if (Regex("^(?:stop|cancel)\\s+(?:the\\s+)?(?:price\\s*check|food(?:\\s+check)?|comparing|comparison)$", I).matches(t)) return Command.FoodStop
        FoodCompare.parse(t)?.let { return Command.Food(it) }
        if (Regex("^(help|commands|what can you do\\??|what do you do\\??)$", I).matches(t)) return Command.Help

        if (Regex("^(?:what (?:have|did) you (?:learn(?:ed|t)?)(?: about me)?|what do you know about me|show (?:what you )?learn(?:ed|ing)|my habits|show (?:my )?habits)\\??$", I).matches(t)) return Command.Learned
        if (Regex("^(?:forget everything(?: you (?:learned|learnt|know))?|reset (?:your )?(?:learning|memory)|clear (?:your )?memory)$", I).matches(t)) return Command.ForgetAll
        Regex("^forget\\s+(?:the\\s+)?(?:phrase\\s+)?[\"“']?(.+?)[\"”']?$", I).find(t)?.let { return Command.Forget(it.groupValues[1].trim()) }
        Regex("^(?:when|if|whenever) i (?:say|type|ask|tell you)\\s+[\"“']?(.+?)[\"”']?\\s*(?:,|then|->|=>|:)?\\s*(?:you\\s+)?(?:should\\s+|please\\s+)?(say|reply|respond|answer|do|run|set|open|call|add|timer|alarm)\\s+(.+)$", I).find(t)?.let { m ->
            val verb = m.groupValues[2].lowercase()
            val rest = m.groupValues[3].trim()
            val meaning = when (verb) {
                "say", "reply", "respond", "answer" -> "say:" + rest.trim('"', '“', '”')
                "do", "run" -> rest
                else -> "$verb $rest"
            }
            return Command.Teach(m.groupValues[1].trim(), meaning)
        }
        Regex("^remember\\s+(?:that\\s+)?[\"“']?(.+?)[\"”']?\\s+(?:means|stands for|is short for|=)\\s+[\"“']?(.+?)[\"”']?$", I).find(t)?.let {
            return Command.Teach(it.groupValues[1].trim(), "word:" + it.groupValues[2].trim())
        }
        if (Regex("^(?:please\\s+)?(undo|undo that|undo it|remove it|delete it|delete that|delete that event|cancel that event)\\s*[.!]?\\s*(?:↩️?)?$", I).containsMatchIn(t)) return Command.Undo
        Regex("^(?:please\\s+)?(?:make|change|turn|set)\\s+(?:it|that|this)\\s+(?:into\\s+|to\\s+|as\\s+|a\\s+|an\\s+|the\\s+)*(event|birthday|bday|anniversary|countdown)\\b", I).find(t)?.let {
            val w = it.groupValues[1].lowercase()
            return Command.MakeKind(if (w == "bday") EventKind.BIRTHDAY else EventKind.parse(w) ?: EventKind.EVENT)
        }

        Regex("^(?:please\\s+)?(?:take a note|note down|note|jot down|jot|save a note|remember to)[:\\s]+(.+)$", I).find(t)?.let { return Command.Note(it.groupValues[1].trim()) }
        if (Regex("^(?:show |list |read |open )?(?:my )?notes$", I).matches(t)) return Command.ShowNotes
        if (Regex("^(?:clear|delete|erase) (?:all )?(?:my )?notes$", I).matches(t)) return Command.ClearNotes
        Regex("^(?:add\\s+(?:a\\s+)?(?:todo|to-do|task)|todo|to-do|new task|add task)[:\\s]+(.+)$", I).find(t)?.let { return Command.TodoAdd(it.groupValues[1].trim()) }
        if (Regex("^(?:show |list |what(?:'s| is) (?:on )?)?(?:my )?(?:todos?|to-dos?|to do list|todo list|tasks)\\??$", I).matches(t)) return Command.TodoList
        Regex("^(?:done|finish(?:ed)?|complete(?:d)?|tick|check off|remove task)\\s+(?:todo\\s+|task\\s+)?(\\d+)$", I).find(t)?.let { return Command.TodoDone(it.groupValues[1].toInt()) }
        Regex("^(?:turn\\s+|switch\\s+)?(?:(on|off)\\s+)?(?:the\\s+)?(?:flash ?light|torch)(?:\\s+(on|off))?$", I).find(t)?.let {
            val w = it.groupValues[1].ifEmpty { it.groupValues[2] }.lowercase()
            return Command.Flashlight(if (w == "on") true else if (w == "off") false else null)
        }
        if (Regex("^(?:flip a coin|toss a coin|coin flip|heads or tails\\??)$", I).matches(t)) return Command.Quick("coin")
        if (Regex("^(?:roll (?:a )?(?:dice|die)|roll dice|dice)$", I).matches(t)) return Command.Quick("dice")
        if (Regex("^(?:what(?:'s| is)? the time|what time is it\\??|time now|current time)$", I).matches(t)) return Command.Quick("time")
        if (Regex("^(?:what(?:'s| is)? (?:the )?(?:date|day)(?: today)?\\??|today'?s date|what day is it\\??)$", I).matches(t)) return Command.Quick("date")
        if (Regex("^(?:battery|battery level|how(?:'s| is) (?:my )?battery\\??|what(?:'s| is) my battery\\??)$", I).matches(t)) return Command.Quick("battery")
        Regex("^(?:calc(?:ulate)?|what(?:'s| is)|compute)\\s+([-+*/x×÷().%^\\d\\s,]+?)\\??$", I).find(t)?.let {
            val e = it.groupValues[1]
            if (e.any { c -> c.isDigit() } && e.any { c -> c in "+-*/x×÷%^" }) return Command.Calculate(e)
        }
        Regex("^remind me (?:to |about )?(.+?)\\s+in\\s+(\\d+)\\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?|h|m)$", I).find(t)?.let {
            val n = it.groupValues[2].toInt()
            val u = it.groupValues[3].lowercase()
            val mins = if (u.startsWith("h")) n * 60 else if (u.startsWith("s")) 1 else n
            return Command.RemindIn(it.groupValues[1].trim(), mins.coerceAtLeast(1))
        }
        if (Regex("^(?:plan|schedule)\\s+(?:my\\s+)?(?:day|week|days|study|studies)$|^(?:make|give)\\s+(?:me\\s+)?a\\s+(?:study\\s+)?plan$|^what should i (?:do|study)(?: today| now| next)?\\??$|^plan$", I).matches(t)) return Command.Plan
        if (Regex("^(?:stop|no more|turn off)\\s+(?:the\\s+)?suggest(?:ions?|ing)(?:\\s+please)?$", I).matches(t)) return Command.Suggestions(false)
        if (Regex("^(?:start|turn on|enable)\\s+(?:the\\s+)?suggest(?:ions?|ing)$", I).matches(t)) return Command.Suggestions(true)
        Regex("^(?:start\\s+|begin\\s+)?(?:studying|study|focus\\s+on)\\s+(?!mode\\b|log\\b|tips?\\b|stats\\b|time\\b|streak\\b|report\\b|hard\\b|now\\b|more\\b|plan\\b|group\\b|session\\b|for\\b|with\\b|\\d)([A-Za-z][A-Za-z+&.\\s]{0,28}?)(?:\\s+(?:for\\s+)?(\\d{1,3})\\s*(?:min(?:ute)?s?)?)?(?:\\s+(?:with\\s+)?(\\d{1,2})\\s*(?:min(?:ute)?s?\\s*)?breaks?)?$", I).find(t)?.let {
            return Command.Study(it.groupValues[2].toIntOrNull()?.coerceIn(5, 180), it.groupValues[3].toIntOrNull()?.coerceIn(1, 60), it.groupValues[1].trim().replaceFirstChar { c -> c.uppercase() })
        }
        if (Regex("^(?:stop|end|quit|cancel)\\s+(?:the\\s+)?(?:studying|study(?: mode)?|focus(?: mode)?|pomodoro)$", I).matches(t)) return Command.StudyStop
        if (Regex("^(?:study|focus)\\s+(?:log|stats|time|streak|report)$|^how (?:much|long) (?:did i|have i) (?:study|studied|focus(?:ed)?)\\??(?: today)?$", I).matches(t)) return Command.StudyLog
        Regex("^(?:start\\s+|begin\\s+)?(?:studying|study(?: mode)?|focus(?: mode)?|pomodoro)(?:\\s+(?:for\\s+)?(\\d{1,3})\\s*(?:min(?:ute)?s?)?)?(?:\\s+(?:with\\s+)?(\\d{1,2})\\s*(?:min(?:ute)?s?\\s*)?breaks?)?$", I).find(t)?.let {
            val f = it.groupValues[1].toIntOrNull()
            val b = it.groupValues[2].toIntOrNull()
            return Command.Study(f?.coerceIn(5, 180), b?.coerceIn(1, 60))
        }
        Regex("^(?:do a |do |show me a |play )?(dance|wave|yawn|shiver|flip|backflip|jump|trick)(?: for me| please)?$", I).find(t)?.let {
            return Command.Trick(it.groupValues[1].lowercase().replace("backflip", "flip").replace("jump", "flip"))
        }

        if (Regex("\\b(organi[sz]e|sort|arrange|clean ?up|group)\\b.*\\b(docs?|documents?|files?|pdfs?|notes)\\b", I).containsMatchIn(t)) {
            return Command.Organize
        }

        val call = Regex("^(?:please\\s+)?(?:call|dial|phone|ring)\\s+(?:up\\s+)?(.+?)(?:\\s+(?:please|now))?$", I).find(t)
        if (call != null) {
            val who = call.groupValues[1].trim()
            if (Regex("^(?:me|it|us|them|back later|a day)\\b", I).containsMatchIn(who)) return null // "call me Anay", "call it a day"
            return if (who.isNotEmpty()) Command.Call(who) else Command.Incomplete("Who should I call? Try: call Mom")
        }

        val watch = Regex("^(?:please\\s+)?(?:watch|monitor|track)\\s+(?:(?:the\\s+)?group\\s+(.+)|(.+?)\\s+group)$", I).find(t)
        if (watch != null) {
            val name = (watch.groupValues[1].ifEmpty { watch.groupValues[2] }).trim().trim('"', '\'')
            return if (name.isNotEmpty()) Command.Watch(name) else Command.Incomplete("Which group? Try: watch group CSE 3A")
        }

        val show = Regex(
            "\\b(?:give|show|list|find|get|send|see|display)\\b.*?\\b(?:docs?|documents?|files?|notes|pdfs?)\\b\\s*(?:belonging to|related to|of|for|in|from|on|about|under)?\\s*(.*)$", I
        ).find(t)
        if (show != null) {
            val subject = show.groupValues[1].replace(Regex("^(?:the|my)\\s+", I), "").trim()
            return if (subject.isNotEmpty()) Command.ShowDocs(subject)
            else Command.Incomplete("Which subject? Try: show documents of computer science")
        }

        val hasDate = findDate(t, now.toLocalDate()) != null
        if (Regex("\\btimer\\b", I).containsMatchIn(t) || (Regex("\\bcountdown\\b", I).containsMatchIn(t) && !hasDate)) {
            val secs = durationSeconds(t)
            return if (secs > 0) Command.Timer(secs) else Command.Incomplete("For how long? Try: timer 10 minutes")
        }

        if (Regex("\\balarm\\b", I).containsMatchIn(t)) {
            val hit = findTime(t)
            val label = Regex("\\b(?:with\\s+)?(?:title|label|name|called|named)\\s+(.+?)(?=\\s+(?:at|for|in|on|tomorrow|today)\\b|$)", I).find(t)?.groupValues?.get(1)?.trim().orEmpty()
            return if (hit != null) Command.Alarm(hit.hour, hit.minute, label) else Command.Incomplete("What time? Try: alarm 6:30 am")
        }

        val ev = Regex(
            "^(?:please\\s+)?(?:add|create|set|make|schedule|new|put|save)\\s+(?:an?\\s+|the\\s+|my\\s+)?(?:new\\s+)?(?:all[- ]day\\s+)?(event|reminder|meeting|class|exam|appointment|birthday|b'?day|anniversary|countdown)\\b(.*)$",
            I
        ).find(t)
        if (ev != null) return parseEvent(ev.groupValues[1].lowercase(), (if (Regex("all[- ]day", I).containsMatchIn(t.substringBefore(ev.groupValues[1]))) " all day " else "") + ev.groupValues[2], now)

        // "Tikki's birthday on 19 October", "countdown to exams 5 dec" (need a date so normal chat isn't hijacked)
        val bare = Regex("^(.+?)\\s+(birthday|b'?day|anniversary)\\b(.*)$", I).find(t)
        if (bare != null && findDate(t, now.toLocalDate()) != null) return parseEvent(bare.groupValues[2].lowercase(), bare.groupValues[1] + " " + bare.groupValues[3], now)
        val cd = Regex("^(?:countdown|days? (?:left )?(?:to|until|till|for))\\s+(?:to\\s+|for\\s+)?(.+)$", I).find(t)
        if (cd != null && findDate(t, now.toLocalDate()) != null) return parseEvent("countdown", cd.groupValues[1], now)

        // "open file maths notes", "open the DBMS pdf", "open lab record.docx"
        val of1 = Regex("^(?:please\\s+)?(?:open|show me|pull up|view)\\s+(?:the\\s+|my\\s+)?(?:file|document|doc|pdf|ppt|notes?)\\s+(.+)$", I).find(t)
        if (of1 != null) return Command.OpenFile(of1.groupValues[1].trim())
        val of2 = Regex("^(?:please\\s+)?(?:open|show me|pull up|view)\\s+(.+?\\.(?:pdf|docx?|pptx?|xlsx?|csv|txt|png|jpe?g|mp4|zip))$", I).find(t)
        if (of2 != null) return Command.OpenFile(of2.groupValues[1].trim())
        val of3 = Regex("^(?:please\\s+)?(?:open|show me|pull up|view)\\s+(?:the\\s+|my\\s+)?(.+?\\s(?:file|pdf|ppt|pptx|document|doc|docx|notes|record|assignment|slides))$", I).find(t)
        if (of3 != null) return Command.OpenFile(of3.groupValues[1].trim())

        val open = Regex("^(?:please\\s+)?(?:open|launch|start)\\s+(?:the\\s+)?(.+?)(?:\\s+app)?\\s*$", I).find(t)
        if (open != null) return Command.OpenApp(open.groupValues[1].trim())

        return null
    }

    private fun yearlyDefaults(kind: EventKind) = when (kind) {
        EventKind.BIRTHDAY -> listOf(-540, 900)
        EventKind.ANNIVERSARY -> listOf(-540, 900, 10620)
        EventKind.COUNTDOWN -> listOf(-540, 900, 10620)
        EventKind.EVENT -> listOf(10)
    }

    /** Applies a category's defaults (all-day, yearly repeat, reminders, title style). Used for "make it a birthday". */
    fun withKind(e: Command.Event, kind: EventKind): Command.Event {
        val base = baseTitle(e.title)
        return when (kind) {
            EventKind.EVENT -> e.copy(title = base, kind = kind, allDay = false, repeat = "", remind = listOf(10), durationMin = 60)
            EventKind.BIRTHDAY -> e.copy(title = possessive(base) + " Birthday", kind = kind, allDay = true, repeat = "YEARLY", remind = yearlyDefaults(kind))
            EventKind.ANNIVERSARY -> e.copy(title = (if (base.contains("anniversary", true)) base else "$base Anniversary"), kind = kind, allDay = true, repeat = "YEARLY", remind = yearlyDefaults(kind))
            EventKind.COUNTDOWN -> e.copy(title = "⏳ $base", kind = kind, allDay = true, repeat = "", remind = yearlyDefaults(kind))
        }
    }

    private fun possessive(name: String) = if (name.endsWith("s", true)) "$name'" else "$name's"

    /** The bare subject: "Tikki's Birthday" -> "Tikki". */
    fun baseTitle(title: String): String = title.replace("⏳", "")
        .replace(Regex("[''’]s?\\s+(birthday|anniversary)\\b", I), "")
        .replace(Regex("\\b(birthday|bday|anniversary|countdown)\\b", I), "")
        .replace(Regex("\\s+"), " ").trim().ifEmpty { title }

    private fun titleCase(s: String) = s.split(' ').joinToString(" ") { w -> if (w in setOf("and", "of", "the", "&")) w else w.replaceFirstChar { it.uppercase() } }

    private fun parseEvent(type: String, rest: String, now: LocalDateTime): Command {
        var s = rest
        s = s.replace(Regex("\\b(?:in|on|to|into|at)\\s+(?:my\\s+|the\\s+)?(?:calendar|calender|caly|cal)\\b", I), " ")
        val today = now.toLocalDate()

        // Options from the calendar form: repeat, length, all day, reminder, description.
        var repeat = ""
        Regex("\\b(?:repeat(?:s|ing)?\\s+)?(?:every\\s+(day|week|month|year)|(daily|weekly|monthly|yearly|annually))\\b", I).find(s)?.let { m ->
            val w = (m.groupValues[1].ifEmpty { m.groupValues[2] }).lowercase()
            repeat = when { w.startsWith("d") -> "DAILY"; w.startsWith("w") -> "WEEKLY"; w.startsWith("m") -> "MONTHLY"; else -> "YEARLY" }
            s = s.removeRange(m.range)
        }
        var duration = 60
        Regex("\\bfor\\s+(\\d+(?:\\.\\d+)?)\\s*(hours?|hrs?|h|minutes?|mins?)\\b", I).find(s)?.let { m ->
            val v = m.groupValues[1].toDouble()
            duration = (if (m.groupValues[2].lowercase().startsWith("h")) v * 60 else v).toInt().coerceIn(5, 24 * 60)
            s = s.removeRange(m.range)
        }
        var remind: List<Int>? = null
        Regex("\\b(?:remind(?:er)?(?:\\s+me)?\\s+)?(\\d+)\\s*(minutes?|mins?|hours?|hrs?|days?)\\s+(?:before|earlier|prior)\\b", I).find(s)?.let { m ->
            val v = m.groupValues[1].toInt()
            val u = m.groupValues[2].lowercase()
            remind = listOf(when { u.startsWith("h") -> v * 60; u.startsWith("d") -> v * 1440; else -> v })
            s = s.removeRange(m.range)
        }
        var allDay = false
        Regex("\\ball[- ]?day\\b", I).find(s)?.let { allDay = true; s = s.removeRange(it.range) }
        var description = ""
        Regex("\\b(?:with\\s+)?(?:description|notes?)\\s*[:\\-]?\\s+(.+)$", I).find(s)?.let { m ->
            description = m.groupValues[1].trim()
            s = s.removeRange(m.range)
        }

        // Category: from the verb ("add birthday ...") or from a word in the sentence ("add event birthday tikki ...").
        var kind = when {
            type.startsWith("b") -> EventKind.BIRTHDAY
            type == "anniversary" -> EventKind.ANNIVERSARY
            type == "countdown" -> EventKind.COUNTDOWN
            else -> EventKind.EVENT
        }
        var explicit = kind != EventKind.EVENT
        Regex("\\b(birthday|b'?day|anniversary|countdown)\\b", I).find(s)?.let { m ->
            val w = m.groupValues[1].lowercase()
            kind = when { w.startsWith("b") -> EventKind.BIRTHDAY; w == "anniversary" -> EventKind.ANNIVERSARY; else -> EventKind.COUNTDOWN }
            explicit = true
            s = s.removeRange(m.range)
        }

        val dateHit = findDate(s, today)
        val timeHit = if (kind == EventKind.EVENT || !allDay) findTime(s) else null
        val removals = mutableListOf<IntRange>()
        dateHit?.let { removals.add(it.second) }
        timeHit?.let { removals.add(it.range) }
        for (r in removals.sortedByDescending { it.first }) s = s.removeRange(r)

        for (i in 0..2) {
            s = s.replace(Regex("^[\\s,:;\\-]*(?:title|name|called|named|for|of|about|to|on)\\b[\\s,:;\\-]*", I), " ")
        }
        s = s.replace(Regex("[\\s,:;\\-]*\\b(?:at|on|for|by|called|named|about|of|to|in)\\s*$", I), " ")
            .replace(Regex("[,;]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        var title = when {
            kind != EventKind.EVENT -> titleCase(s.replace(Regex("[''’]s?$", I), "").trim())
            type == "event" || type == "reminder" -> s
            s.isEmpty() -> type
            else -> "$type $s"
        }
        if (kind == EventKind.EVENT) title = title.replaceFirstChar { it.uppercase() }
        if (title.isEmpty()) return Command.Incomplete(
            when (kind) {
                EventKind.BIRTHDAY -> "Whose birthday? Try: add birthday Tikki on 19 October"
                EventKind.ANNIVERSARY -> "Whose anniversary? Try: add anniversary Mom and Dad on 5 June"
                EventKind.COUNTDOWN -> "Counting down to what? Try: countdown to exams on 5 December"
                else -> "What's the event? Try: add event maths exam tomorrow 10am"
            }
        )

        var date = dateHit?.first
        val yearlyKind = kind == EventKind.BIRTHDAY || kind == EventKind.ANNIVERSARY
        if (date == null) {
            if (kind == EventKind.EVENT && timeHit != null) date = today
            else return Command.Incomplete(
                when (kind) {
                    EventKind.BIRTHDAY -> "When is $title's birthday? Try: add birthday $title on 19 October"
                    EventKind.ANNIVERSARY -> "When is the anniversary? Try: add anniversary $title on 5 June"
                    EventKind.COUNTDOWN -> "What date are we counting down to? Try: countdown to $title on 5 December"
                    else -> "When is \"$title\"? Try: add event $title tomorrow 5pm"
                }
            )
        }
        val wholeDay = allDay || kind != EventKind.EVENT
        val h = timeHit?.hour ?: 9
        val m = timeHit?.minute ?: 0
        var dt = LocalDateTime.of(date, java.time.LocalTime.of(if (wholeDay) 0 else h, if (wholeDay) 0 else m))
        if (!wholeDay && dateHit == null && dt.isBefore(now)) dt = dt.plusDays(1)
        val start = dt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

        val base = Command.Event(title, start, kind, wholeDay, repeat, duration, remind ?: listOf(10), description, explicit)
        if (kind == EventKind.EVENT) return base.copy(allDay = wholeDay, remind = remind ?: if (wholeDay) listOf(-540) else listOf(10))
        val styled = withKind(base.copy(title = title), kind)
        return styled.copy(repeat = if (repeat.isNotEmpty()) repeat else styled.repeat, remind = remind ?: styled.remind, description = description, durationMin = duration, explicit = explicit)
    }

    private fun durationSeconds(t: String): Int {
        val total = Regex("(\\d+(?:\\.\\d+)?)\\s*(hours?|hrs?|h|minutes?|mins?|m|seconds?|secs?|s)\\b", I)
            .findAll(t).sumOf { m ->
                val v = m.groupValues[1].toDouble()
                val u = m.groupValues[2].lowercase()
                when {
                    u.startsWith("h") -> v * 3600
                    u.startsWith("m") -> v * 60
                    else -> v
                }
            }
        return total.toInt()
    }

    private fun findTime(s: String): TimeHit? {
        Regex("\\b(?:at\\s+)?(\\d{1,2})(?::(\\d{2}))?\\s*([ap])\\.?m\\b\\.?", I).find(s)?.let { m ->
            var h = m.groupValues[1].toInt()
            val mi = m.groupValues[2].ifEmpty { "0" }.toInt()
            val pm = m.groupValues[3].equals("p", true)
            if (h in 1..12 && mi < 60) {
                if (h == 12) h = 0
                if (pm) h += 12
                return TimeHit(h, mi, m.range)
            }
        }
        Regex("\\b(?:at\\s+)?(\\d{1,2}):(\\d{2})\\b", I).find(s)?.let { m ->
            val h = m.groupValues[1].toInt()
            val mi = m.groupValues[2].toInt()
            if (h < 24 && mi < 60) return TimeHit(h, mi, m.range)
        }
        Regex("\\bat\\s+(\\d{1,2})\\b", I).find(s)?.let { m ->
            var h = m.groupValues[1].toInt()
            if (h in 1..6) h += 12 // "at 5" almost always means 5 pm
            if (h < 24) return TimeHit(h, 0, m.range)
        }
        return null
    }

    private const val MONTHS = "jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|june?|july?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?"
    private val MONTH_KEYS = listOf("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec")

    /** day/month (and optional year) -> the next such date; a past date without a year means next year. */
    private fun resolve(day: Int, month: Int, year: Int?, today: LocalDate): LocalDate? = try {
        if (year != null) LocalDate.of(if (year < 100) 2000 + year else year, month, day)
        else {
            val d = LocalDate.of(today.year, month, day)
            if (d.isBefore(today)) d.plusYears(1) else d
        }
    } catch (e: Exception) {
        null
    }

    private fun findDate(s: String, today: LocalDate): Pair<LocalDate, IntRange>? {
        Regex("\\b(\\d{1,2})\\s*(?:st|nd|rd|th)?\\s*(?:of\\s+)?($MONTHS)\\b\\.?(?:[,\\s]+(\\d{4}))?", I).find(s)?.let { m ->
            val mo = MONTH_KEYS.indexOf(m.groupValues[2].lowercase().take(3)) + 1
            resolve(m.groupValues[1].toInt(), mo, m.groupValues[3].toIntOrNull(), today)?.let { return it to m.range }
        }
        Regex("\\b($MONTHS)\\b\\.?\\s+(\\d{1,2})\\s*(?:st|nd|rd|th)?\\b(?:[,\\s]+(\\d{4}))?", I).find(s)?.let { m ->
            val mo = MONTH_KEYS.indexOf(m.groupValues[1].lowercase().take(3)) + 1
            resolve(m.groupValues[2].toInt(), mo, m.groupValues[3].toIntOrNull(), today)?.let { return it to m.range }
        }
        Regex("\\b(\\d{1,2})[/.-](\\d{1,2})(?:[/.-](\\d{2,4}))?\\b").find(s)?.let { m ->
            resolve(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toIntOrNull(), today)?.let { return it to m.range }
        }
        Regex("\\bin\\s+(\\d{1,3})\\s*(days?|weeks?)\\b", I).find(s)?.let { m ->
            val n = m.groupValues[1].toLong() * (if (m.groupValues[2].lowercase().startsWith("w")) 7 else 1)
            return today.plusDays(n) to m.range
        }
        Regex("\\bday after tomorrow\\b", I).find(s)?.let { return today.plusDays(2) to it.range }
        Regex("\\btomorrow\\b", I).find(s)?.let { return today.plusDays(1) to it.range }
        Regex("\\btoday\\b", I).find(s)?.let { return today to it.range }
        Regex("\\b(?:next\\s+|on\\s+)?(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\\b", I).find(s)?.let {
            val dow = DayOfWeek.valueOf(it.groupValues[1].uppercase())
            return today.with(TemporalAdjusters.next(dow)) to it.range
        }
        return null
    }
}
