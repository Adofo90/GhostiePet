package com.ghostie.pet

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.time.LocalDateTime

/** The alarm time has come (also after a snooze): hand over to the ring service. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getLongExtra("id", -1L)
        val snooze = intent.getBooleanExtra("snooze", false)
        ActivityLog.add(ctx, "Alarm", "Alarm broadcast received (id $id${if (snooze) ", snooze" else ""})")
        val a = AlarmStore.all(ctx).firstOrNull { it.id == id }
        if (a == null && id != AlarmStore.TEST_ID) return
        if (!snooze && a != null) {
            if (!a.enabled) return
            if (!AlarmStore.claim(ctx, a)) { ActivityLog.add(ctx, "Alarm", "Already rang this minute"); return }
            AlarmStore.rang(ctx, id)
        }
        AlarmRingService.fire(ctx, id)
    }
}

/** Rings with the alarm sound and vibration until dismissed or snoozed (gives up after 3 minutes). */
class AlarmRingService : Service() {
    companion object {
        const val START = "com.ghostie.pet.ALARM_START"
        const val DISMISS = "com.ghostie.pet.ALARM_DISMISS"
        const val SNOOZE = "com.ghostie.pet.ALARM_SNOOZE"
        const val CHANNEL = "ghostie_alarm"
        const val NID = 4242
        const val SNOOZE_MIN = 10

        /** Starts the ring; logs why if the phone refuses. */
        fun fire(ctx: Context, id: Long) {
            try {
                ctx.startForegroundService(Intent(ctx, AlarmRingService::class.java).setAction(START).putExtra("id", id))
                ActivityLog.add(ctx, "Alarm", "Ring started")
            } catch (e: Exception) {
                ActivityLog.add(ctx, "Alarm", "Couldn't start the ring: ${e.javaClass.simpleName} ${e.message?.take(80)}")
                // last resort: a loud notification with a full-screen screen
                try {
                    val nm = ctx.getSystemService(NotificationManager::class.java)
                    nm.createNotificationChannel(NotificationChannel(CHANNEL, "Ghostie alarms", NotificationManager.IMPORTANCE_HIGH))
                    val full = PendingIntent.getActivity(ctx, 1, Intent(ctx, AlarmRingActivity::class.java).putExtra("id", id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                    nm.notify(NID, Notification.Builder(ctx, CHANNEL).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("⏰ Alarm").setContentText("Tap to dismiss")
                        .setCategory(Notification.CATEGORY_ALARM).setFullScreenIntent(full, true).setContentIntent(full).build())
                } catch (e2: Exception) { }
            }
        }
    }

    private var tone: Ringtone? = null
    private val handler = Handler(Looper.getMainLooper())
    private var alarmId = -1L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            DISMISS -> { stopRinging(); return START_NOT_STICKY }
            SNOOZE -> {
                val id = intent.getLongExtra("id", alarmId)
                stopRinging()
                snoozeAt(this, id, SNOOZE_MIN)
                return START_NOT_STICKY
            }
        }
        alarmId = intent?.getLongExtra("id", -1L) ?: -1L
        val a = AlarmStore.all(this).firstOrNull { it.id == alarmId }
        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL, "Ghostie alarms", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        nm.createNotificationChannel(ch)
        val title = "⏰ " + (a?.let { AlarmStore.timeText(it) } ?: "Alarm")
        val body = a?.label?.ifBlank { null } ?: "Time to get up!"
        val full = PendingIntent.getActivity(
            this, 1, Intent(this, AlarmRingActivity::class.java).putExtra("id", alarmId).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        fun act(action: String, code: Int) = PendingIntent.getService(
            this, code, Intent(this, AlarmRingService::class.java).setAction(action).putExtra("id", alarmId),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title).setContentText(body)
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .setFullScreenIntent(full, true)
            .setContentIntent(full)
            .addAction(Notification.Action.Builder(null, "Snooze $SNOOZE_MIN min", act(SNOOZE, 2)).build())
            .addAction(Notification.Action.Builder(null, "Dismiss", act(DISMISS, 3)).build())
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(NID, n)
        } catch (e: Exception) {
            ActivityLog.add(this, "Alarm", "startForeground failed: ${e.javaClass.simpleName} ${e.message?.take(80)}")
            try { startForeground(NID, n) } catch (e2: Exception) { }
        }
        ActivityLog.add(this, "Alarm", "Ringing now")
        startNoise()
        handler.postDelayed({ stopRinging() }, 3 * 60_000L)
        try { startActivity(Intent(this, AlarmRingActivity::class.java).putExtra("id", alarmId).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
        return START_NOT_STICKY
    }

    private fun startNoise() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            tone = RingtoneManager.getRingtone(this, uri)?.also {
                it.audioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                it.isLooping = true
                it.play()
            }
        } catch (e: Exception) { }
        try {
            val v = getSystemService(Vibrator::class.java)
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 400), 0))
        } catch (e: Exception) { }
    }

    private fun stopRinging() {
        handler.removeCallbacksAndMessages(null)
        try { tone?.stop() } catch (e: Exception) { }
        tone = null
        try { getSystemService(Vibrator::class.java).cancel() } catch (e: Exception) { }
        sendBroadcast(Intent("com.ghostie.pet.ALARM_CLOSED").setPackage(packageName))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { stopRinging(); super.onDestroy() }
}

private fun snoozeAt(ctx: Context, id: Long, minutes: Int) {
    try {
        val at = System.currentTimeMillis() + minutes * 60_000L
        val pi = PendingIntent.getBroadcast(
            ctx, 900_000 + (id % 1000).toInt(),
            Intent(ctx, AlarmReceiver::class.java).setAction(AlarmStore.RING).putExtra("id", id).putExtra("snooze", true),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val show = PendingIntent.getActivity(ctx, 1, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        ctx.getSystemService(android.app.AlarmManager::class.java).setAlarmClock(android.app.AlarmManager.AlarmClockInfo(at, show), pi)
    } catch (e: Exception) { }
}

/** Full-screen alarm: big time, Snooze and Dismiss. */
class AlarmRingActivity : Activity() {
    private val closed = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { finish() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true); setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val id = intent.getLongExtra("id", -1L)
        val a = AlarmStore.all(this).firstOrNull { it.id == id }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#14101F")); setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        fun tv(t: String, sp: Float, c: String, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = sp; setTextColor(Color.parseColor(c)); gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
        root.addView(tv("👻⏰", 54f, "#FFFFFF"))
        root.addView(tv(a?.let { AlarmStore.timeText(it) } ?: "%02d:%02d".format(LocalDateTime.now().hour, LocalDateTime.now().minute), 64f, "#FFFFFF", true))
        root.addView(tv(a?.label?.ifBlank { null } ?: "Time to get up!", 20f, "#D9CFFF"))
        fun btn(t: String, fill: String, textc: String, action: String) = Button(this).apply {
            text = t; textSize = 20f; setTextColor(Color.parseColor(textc)); isAllCaps = false
            background = GradientDrawable().apply { cornerRadius = dp(28).toFloat(); setColor(Color.parseColor(fill)) }
            setOnClickListener {
                startService(Intent(this@AlarmRingActivity, AlarmRingService::class.java).setAction(action).putExtra("id", id))
                finish()
            }
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(64)).apply { topMargin = dp(18) }
        }
        root.addView(btn("Snooze ${AlarmRingService.SNOOZE_MIN} min", "#3A3060", "#FFFFFF", AlarmRingService.SNOOZE).also { (it.layoutParams as LinearLayout.LayoutParams).topMargin = dp(48) })
        root.addView(btn("Dismiss", "#B89CFF", "#14101F", AlarmRingService.DISMISS))
        setContentView(root)
        registerReceiver(closed, android.content.IntentFilter("com.ghostie.pet.ALARM_CLOSED"), Context.RECEIVER_NOT_EXPORTED)
    }

    override fun onDestroy() { try { unregisterReceiver(closed) } catch (e: Exception) { }; super.onDestroy() }
}
