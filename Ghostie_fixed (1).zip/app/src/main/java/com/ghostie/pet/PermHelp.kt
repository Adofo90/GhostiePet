package com.ghostie.pet

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

/** Opens the right settings screens, with fallbacks for phones (Xiaomi / Poco HyperOS) that ignore the standard ones. */
object PermHelp {
    private fun appInfo(a: Activity) = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.packageName}"))

    private fun tryStart(a: Activity, i: Intent): Boolean = try { a.startActivity(i); true } catch (e: Exception) { false }

    /** "Display over other apps". */
    fun openOverlay(a: Activity) {
        if (tryStart(a, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${a.packageName}")))) return
        // Xiaomi permission editor
        val x = Intent("miui.intent.action.APP_PERM_EDITOR").setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
            .putExtra("extra_pkgname", a.packageName)
        if (tryStart(a, x)) return
        if (tryStart(a, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))) return
        tryStart(a, appInfo(a))
        Toast.makeText(a, "Open Other permissions > Display pop-up windows / Display over other apps", Toast.LENGTH_LONG).show()
    }

    /** Accessibility screen with this app's service highlighted where the phone supports it. */
    fun openAccessibility(a: Activity, serviceClass: String) {
        val comp = ComponentName(a.packageName, "${a.packageName}.$serviceClass").flattenToString()
        val i = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        val args = Bundle().apply { putString("preference_key", comp) }
        i.putExtra(":settings:fragment_args_key", comp)
        i.putExtra(":settings:show_fragment_args", args)
        if (!tryStart(a, i)) tryStart(a, appInfo(a))
    }

    /** Notification access screen, opening this app's own page when possible. */
    fun openListener(a: Activity, serviceClass: String) {
        val comp = ComponentName(a.packageName, "${a.packageName}.$serviceClass")
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            if (tryStart(a, Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS).putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, comp.flattenToString()))) return
        }
        if (!tryStart(a, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))) tryStart(a, appInfo(a))
    }

    /** So alarms can wake the phone: Xiaomi "Autostart" first, then the battery-optimisation list, then App info. */
    fun openBackgroundRun(a: Activity) {
        val x = Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"))
        if (tryStart(a, x)) return
        if (tryStart(a, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))) return
        tryStart(a, appInfo(a))
    }

    const val HELP = "If the Ghostie switch is greyed out or turns itself off:\n\n" +
        "1. Phone Settings > Apps > Manage apps > Ghostie > ⋮ (top right) > \"Allow restricted settings\" (confirm with your PIN/fingerprint).\n" +
        "2. Open Accessibility again > Downloaded apps (or Installed apps) > Ghostie... > switch ON > Allow.\n" +
        "3. On Poco/Xiaomi also open Ghostie's App info > Other permissions and allow \"Display pop-up windows while running in the background\" and \"Display over other apps\".\n" +
        "4. If it still turns itself off, restart the phone once and try again."
}
