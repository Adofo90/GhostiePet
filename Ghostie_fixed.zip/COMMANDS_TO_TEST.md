# Ghostie: commands to test

How to read this: **Recognised** means my automatic check (run on a computer, not on your phone) turned the phrase into the right command. It does not mean it works on the phone: mark that yourself after testing. **Add variation** means the phrase was not recognised and I suggest adding it.

Things you can type in the chat box or say by voice. Day words work as `today`, `tomorrow`, `monday`... Times work as `7 pm`, `7:30`, `19:00`.

## Documents
| Phrase | Recognised? | Notes |
|---|---|---|
| `organize documents` | ✓ recognised | |
| `organise my files` | ✓ recognised | |
| `sort my whatsapp files` | ✓ recognised | |
| `show documents of computer science` | ✓ recognised | |
| `show my maths files` | ✗ add variation | Ghostie asks for more detail. Add: `show my <subject> files` / `maths files` (now: Incomplete) |
| `open file maths notes` | ✓ recognised | |
| `open the DBMS pdf` | ✓ recognised | |

## Calendar
| Phrase | Recognised? | Notes |
|---|---|---|
| `add event maths exam tomorrow 10am` | ✓ recognised | |
| `add birthday Tikki on 19 October` | ✓ recognised | |
| `add anniversary 5 december` | ✗ add variation | Needs a name (works as `add anniversary Sam 5 december`). Add: ask "whose anniversary?" instead of failing (now: Incomplete) |
| `countdown to exams on 5 Dec` | ✓ recognised | |
| `add meeting every week friday 4pm` | ✓ recognised | |
| `schedule dentist tomorrow at 5pm` | ✗ add variation | Add: `schedule ...` as another word for `add event ...` (now: none) |
| `make it a birthday` | ✓ recognised | |
| `undo` | ✓ recognised | |

## Timer
| Phrase | Recognised? | Notes |
|---|---|---|
| `timer 10 minutes` | ✓ recognised | |
| `set a timer for 5 min` | ✓ recognised | |
| `timer 30 seconds` | ✓ recognised | |
| `start a 1 hour timer` | ✓ recognised | |

## Alarm
| Phrase | Recognised? | Notes |
|---|---|---|
| `alarm 6:30 am` | ✓ recognised | |
| `set an alarm for 7 am` | ✓ recognised | |
| `wake me up at 6` | ✗ add variation | Add: `wake me up at <time>` as an alarm phrase (now: none) |
| `alarm 7 weekdays` | ✓ recognised | |
| `alarm gym 5:30 pm` | ✓ recognised | |
| `my alarms` | ✓ recognised | |
| `show alarms` | ✓ recognised | |
| `turn off alarm 6:30` | ✓ recognised | |
| `delete alarm 7 am` | ✓ recognised | |

## Reminders
| Phrase | Recognised? | Notes |
|---|---|---|
| `remind me to drink water in 20 minutes` | ✓ recognised | |
| `remind me in 2 hours to call mom` | ✗ add variation | Add: time before the task (`remind me in 2 hours to ...`); `remind me to ... in 2 hours` works (now: none) |
| `remind me to submit record at 7 pm` | ✓ recognised | |
| `add reminder for 7 as AI assignment` | ✓ recognised | |
| `remind me tomorrow at 8 am to study` | ✗ add variation | Add: day and time before the task (`remind me tomorrow at 8 am to ...`) (now: none) |
| `remind me to buy milk` | ✓ recognised | |
| `my reminders` | ✓ recognised | |
| `cancel all reminders` | ✓ recognised | |
| `cancel reminder buy milk` | ✓ recognised | |

## Calls
| Phrase | Recognised? | Notes |
|---|---|---|
| `call Mom` | ✓ recognised | |
| `call 9876543210` | ✓ recognised | |
| `phone dad` | ✓ recognised | |

## Apps
| Phrase | Recognised? | Notes |
|---|---|---|
| `open WhatsApp` | ✓ recognised | |
| `launch instagram` | ✓ recognised | |

## Notes
| Phrase | Recognised? | Notes |
|---|---|---|
| `note buy milk` | ✓ recognised | |
| `take a note: lab at 3` | ✓ recognised | |
| `show notes` | ✓ recognised | |
| `my notes` | ✓ recognised | |
| `clear notes` | ✓ recognised | |

## Todos
| Phrase | Recognised? | Notes |
|---|---|---|
| `todo finish lab record` | ✓ recognised | |
| `add todo call bank` | ✓ recognised | |
| `my todos` | ✓ recognised | |
| `show my to-do list` | ✗ add variation | Add: `to-do list` / `to do list` spellings (`my todos` works) (now: none) |
| `done 2` | ✓ recognised | |

## Pack list
| Phrase | Recognised? | Notes |
|---|---|---|
| `pack list` | ✓ recognised | |
| `add charger to pack list` | ✓ recognised | |
| `new trip` | ✓ recognised | |
| `I'm going for 5 days` | ✓ recognised | |
| `trip for 2 weeks` | ✓ recognised | |

## Tools
| Phrase | Recognised? | Notes |
|---|---|---|
| `flashlight on` | ✓ recognised | |
| `turn off the torch` | ✓ recognised | |
| `calculate 12*(3+4)` | ✓ recognised | |
| `what is 15% of 200` | ✗ add variation | Add: percentage questions (`calculate 15% of 200` may work; test it) (now: none) |
| `flip a coin` | ✓ recognised | |
| `roll a dice` | ✓ recognised | |
| `what time is it` | ✓ recognised | |
| `what's the date` | ✓ recognised | |
| `battery` | ✓ recognised | |

## Tricks
| Phrase | Recognised? | Notes |
|---|---|---|
| `dance` | ✓ recognised | |
| `wave` | ✓ recognised | |
| `yawn` | ✓ recognised | |
| `shiver` | ✓ recognised | |
| `do a flip` | ✓ recognised | |

## Study
| Phrase | Recognised? | Notes |
|---|---|---|
| `study mode` | ✓ recognised | |
| `study 45` | ✓ recognised | |
| `study dbms 45` | ✓ recognised | |
| `stop studying` | ✓ recognised | |
| `study log` | ✓ recognised | |
| `plan my week` | ✓ recognised | |
| `I study at 7pm` | ✓ recognised | |
| `study times 6am and 9pm` | ✓ recognised | |
| `clear study time` | ✓ recognised | |
| `stop suggestions` | ✓ recognised | |
| `forget my habits` | ✓ recognised | |

## Attendance
| Phrase | Recognised? | Notes |
|---|---|---|
| `attendance` | ✓ recognised | |
| `my attendance in maths` | ✓ recognised | |
| `present in maths` | ✓ recognised | |
| `absent in maths` | ✓ recognised | |
| `I attended maths` | ✗ add variation | Add: `I attended <subject>` (`present in maths` works) (now: none) |
| `I bunked physics` | ✓ recognised | |
| `am i short on attendance` | ✓ recognised | |
| `which subjects have low attendance` | ✓ recognised | |

## Timetable
| Phrase | Recognised? | Notes |
|---|---|---|
| `today's timetable` | ✓ recognised | |
| `what are today's classes` | ✓ recognised | |
| `tomorrow's classes` | ✓ recognised | |
| `classes on friday` | ✓ recognised | |
| `do I have class tomorrow` | ✓ recognised | |
| `my timetable this week` | ✓ recognised | |
| `next class` | ✓ recognised | |
| `when is my next lecture` | ✓ recognised | |

## Bunk
| Phrase | Recognised? | Notes |
|---|---|---|
| `can I bunk maths` | ✓ recognised | |
| `can I bunk today` | ✓ recognised | |
| `can I skip tomorrow` | ✓ recognised | |
| `is it safe to bunk on friday` | ✓ recognised | |
| `which subjects can I bunk` | ✓ recognised | |
| `bunk status` | ✓ recognised | |
| `how many classes can I bunk in maths` | ✓ recognised | |

## Class changes
| Phrase | Recognised? | Notes |
|---|---|---|
| `maths class today is cancelled` | ✓ recognised | |
| `no classes tomorrow` | ✓ recognised | |
| `dbms taken instead of physics today` | ✓ recognised | |
| `physics replaced by chemistry tomorrow` | ✓ recognised | |
| `ai moved to 2pm tomorrow` | ✓ recognised | |
| `extra class of maths tomorrow at 4pm` | ✓ recognised | |
| `holiday on friday` | ✓ recognised | |
| `physics lab postponed to monday 10am` | ✓ recognised | |
| `undo class change` | ✓ recognised | |
| `reset tomorrow's timetable` | ✓ recognised | |
| `clear all class changes` | ✓ recognised | |

## Exams
| Phrase | Recognised? | Notes |
|---|---|---|
| `exams` | ✓ recognised | |
| `exam maths 20 dec` | ✓ recognised | |
| `study today` | ✓ recognised | |
| `done topic limits` | ✓ recognised | |

## Flashcards
| Phrase | Recognised? | Notes |
|---|---|---|
| `card What is a deadlock = circular wait` | ✓ recognised | |
| `quiz me` | ✓ recognised | |

## Groups
| Phrase | Recognised? | Notes |
|---|---|---|
| `watch group CSE 3A` | ✓ recognised | |
| `watch this group` | ✓ recognised | |
| `watch the open group` | ✓ recognised | |
| `what did I miss` | ✓ recognised | |
| `catch me up` | ✓ recognised | |

## Spending
| Phrase | Recognised? | Notes |
|---|---|---|
| `spent 120 on lunch` | ✓ recognised | |
| `paid 50 for auto` | ✓ recognised | |
| `my spending` | ✓ recognised | |
| `how much did I spend` | ✓ recognised | |

## Split
| Phrase | Recognised? | Notes |
|---|---|---|
| `split 600 lunch with Riya and Sam` | ✓ recognised | |
| `Riya paid me back 200` | ✓ recognised | |
| `I paid Sam 150` | ✓ recognised | |
| `I owe Riya 100` | ✓ recognised | |
| `settle up with Riya` | ✓ recognised | |
| `who owes me` | ✓ recognised | |

## Projects
| Phrase | Recognised? | Notes |
|---|---|---|
| `projects` | ✓ recognised | |
| `overdue tasks` | ✓ recognised | |

## Weekly
| Phrase | Recognised? | Notes |
|---|---|---|
| `weekly summary` | ✓ recognised | |
| `week summary` | ✓ recognised | |

## Food
| Phrase | Recognised? | Notes |
|---|---|---|
| `cheapest chicken biryani` | ✓ recognised | |
| `compare paneer pizza and garlic bread` | ✓ recognised | |
| `stop price check` | ✓ recognised | |
| `show last price check result` | ✓ recognised | |

## Teaching
| Phrase | Recognised? | Notes |
|---|---|---|
| `when I say study mode, set timer 25 minutes` | ✓ recognised | |
| `remember cs means computer science` | ✓ recognised | |
| `what have you learned` | ✓ recognised | |
| `forget study mode` | ✓ recognised | |
| `forget everything` | ✓ recognised | |

## Personality
| Phrase | Recognised? | Notes |
|---|---|---|
| `change tone` | ✓ recognised | |
| `be sassy` | ✓ recognised | |
| `be dark romance` | ✓ recognised | |
| `what do personalities do` | ✓ recognised | |

## Help
| Phrase | Recognised? | Notes |
|---|---|---|
| `help` | ✓ recognised | |
| `what can you do` | ✓ recognised | |

## Chat features that are not simple commands (test by talking)
| What | Try |
|---|---|
| Chat export | `export` or `export chat` |
| Private memories | `private code` in the "Find anything" search bar |
| Forget crush notes | `forget my crush`, `forget all private memories` |
| What Ghostie remembers | `what do you remember about my crush` |
| Personal talk | `I have a crush on Riya`, `he is my ex`, `my girlfriend keeps ignoring me`, `I'm in a situationship`, `we're long distance`, `I feel lonely`, `my parents pressure me`, `I have no confidence`, `my friends and I had a fight`, `I'm so anxious`, `I'm so angry` |
| Always on listening | Settings > Look & feel > Listening > Always on. Say `Ghostie, what's the time` (or your own name) |
| Group chats | `watch group CSE 3A` then send a test message in that group |
| Class changes from groups | A watched group says `Maths class cancelled tomorrow`; Ghostie offers Apply / Ignore |

Checked: 156 phrases, 147 recognised, 9 to add.
