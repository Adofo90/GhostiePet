# Ghostie: feature and test list

Status key: [built] in the app / [untested] not yet tried on a phone / [planned] not built yet

## Existing features (all [built], to be tested together at the end)
- Floating ghost, edge handle, dragging, sleep at night, bin to remove
- One-tap chat (build 49) [untested]
- Chat box: AI/local chat, voice in and out, chat history, themes/glass
- Commands: alarms, events/calendar, calls, reminders, habits
- Alarms (setAlarmClock, backup ring, "Ring reliably" help) [untested: ring in Recommended battery mode, same-day ring]
- Study mode: focus timer, app blocking, DND, Stop
- Timetable, attendance notifications, "Attendance to fill" card [untested]
- Deadline reminders with Done [untested]
- Group reminders (WhatsApp notifications + open-chat reading)
- Food price check: Zomato, Swiggy, Domino's, Popeyes, EatSure [untested after builds 46-48]
- Documents: WhatsApp file organizer by file name (12 subject categories + 2 fallback categories, editable keywords)
- Backup and restore
- Summon (also during calls) [untested]
- Sliding underline bottom bar (build 49) [untested]
- Privacy Shield for payment/banking apps (build 49) [untested]

## Added in build 50 (all [built], [untested on a phone])
1. Alarm in the phone's Clock app: "alarm 7 am" / Add alarm now go to the Clock app (switch in Alarms card to go back to Ghostie's ringer). Test: say "alarm 6:30 am weekdays", check it appears in Clock and rings. "my alarms" opens the Clock app. Old Ghostie alarms are still listed.
2. Chat reader for Instagram, Telegram, Discord: switches in Group reminders. Needs Notification access and "Read open chats" accessibility (the accessibility service list now includes these apps; if the switch is greyed out, re-enable it). Test: send yourself "submit assignment by 20 November" in each app.
3. Call notes: Phone call recorder file -> Android speech recognizer -> reminders/notes -> recording deleted. Needs Android 13+, File access, Microphone, and the phone's own call recording turned on. Test: record a short call saying a deadline; recording is kept if it can't be read. Biggest risk: whether your phone's recognizer accepts audio from a file.
4. File organizer reads inside files: PDF, docx, pptx (8 slides), txt, csv. "Read inside files" switch in Documents card (on by default; strong content evidence of 4+ keywords overrides the file name, unless you taught Ghostie that file before). Scanned (image) PDFs are not readable.
5. Spending: bank/UPI SMS and payment-app notifications (GPay, PhonePe, Paytm, bank apps), manual "spent 120 on lunch", monthly budget, safe-to-spend per day, alerts at 80% and 100%. Test: allow SMS access, tap "Scan last 30 days of texts", set a budget, say "my spending".
6. Subject database: file-name keywords for 10 subjects + 2 fallback categories already existed (editable in Documents). Now also used on file contents. Not added: course-specific lists beyond these.

## Added in build 51 (all [built], [untested on a phone])
7. Subject tick-boxes (Documents card): 56 subjects in 7 groups (Computer & AI incl. C, C++, Java, Python, DSA, DAA, DBMS, OS, CN, COA, AI, ML, Deep Learning; Maths & Science; Electrical & Electronics; Mechanical; Civil; Chemical; Humanities & Management). Only ticked subjects are organized; files matching none are left alone. Switch for exam papers/timetables and assignments/labs, "My own subjects" (Subject: keyword, keyword), "Reset subjects". Test: tick two subjects, tap Organize now, check unticked-subject files are skipped and the result says how many were left alone. Subject names and keywords come from the course lists of a few Indian engineering colleges plus common curricula; keywords are guesses, so tell me which subjects misfire.
8. Trip pack list (More tab): 44 usual items in 7 groups, tick off, Add item, long-press to remove, "New trip (untick all)", "Reset list to defaults". Chat: "pack list", "what should I pack", "add charger to pack list", "new trip". Test: tick items, restart the app (ticks persist), add and remove items, then reset.

## Still planned / not built
- Profession-based onboarding and per-profession animations
- Keyword database for more course types
- UI polish beyond build 49 (typography, cards, light/dark refinement)
