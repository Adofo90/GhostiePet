# Ghostie: features and test list

Marks: [✓] works perfectly, [−] half working (note says what), [✗] not tested yet. Everything below is built; I can only compile and logic-test, so only your testing changes a mark.

## Core
- [✗] Animated switches (five styles, hand-drawn): Boo ghost on "Sleep at night", Haunted Hill day/night glass on "Glass look", Ectoplasm blob on Privacy Shield's "Hide Ghostie in protected apps", Wisp flame on each alarm's switch, Check-ins and Sunday summary, Poltergeist spring on both Study mode switches. Other switches stay plain. Check they flip, look right, and keep their setting
- [✓] Floating ghost: edge handle, drag, sleep at night, drag to bin
- [✓] One-tap chat (tap the small edge ghost) with a smooth open animation. Option in Look & feel: open the chat box directly (default) or let the big ghost come first (opened the big ghost first; now tapping the small ghost opens the chat box directly: retest)
- [✗] Personal talk, Crush: say you have a crush; Ghostie asks friendly questions (name, a girl or a boy, how you met), each question only once, keeps he/she consistent, gives simple advice when asked. Remembers name and a few notes on the phone only. Delete with "forget my crush"
- [✗] Personal talk, Other relationships: Ghostie notices what the person is to you and switches its questions: ex ("he is my ex", "my ex Rohan"), partner ("my girlfriend keeps ignoring me"), situationship / talking stage, long distance, one-sided ("she doesn't like me back"), friend you have feelings for. Each has its own questions; the he/she wording follows what you said
- [✗] Personal talk, Unsure check: "do I have a crush?" / "does she like me?" runs a short yes/no check
- [✗] Personal talk, Friends: fights, being left out, jealousy
- [✗] Personal talk, Family: pressure, comparison, marks and career
- [✗] Personal talk, Confidence: self-doubt, shyness, "not good enough"
- [✗] Personal talk, Lonely / homesick
- [✗] Personal talk, Break-up
- [✗] Personal talk, Anxiety and anger
- [✗] Personal talk, Secrets and unwanted violent thoughts: answered on the phone only (not sent to AI, not saved, not learned, not logged)
- [✗] Private memories: type `private code` in the "Find anything" search bar once to create a code; later typing that code there opens the saved memories (view, delete, change code)
- [✗] Chat export: type `export` (or `export chat`) in the chat box. Everything said since you started chatting, including private/personal turns (marked private/local/AI/command), is written to a text file and the share sheet opens so you can send it. It is held in memory only until you export, then cleared; nothing is sent anywhere by Ghostie
- [✗] Listening modes (Look & feel, "Listening"): Mic button + hold ghost (default), Mic button only, Hold ghost only, Always on (keeps listening; outside the chat box it only reacts when you start with "Ghostie ..."; uses more battery, Android may stop it) Always on waits for the pet name (default Ghostie; change it in Look & feel > "Name for Always on"); close mishearings like "ghosty" are accepted, and the Activity log notes when speech was heard without the name
- [✓] Chat box: AI/local chat, voice in and out, history, themes (replies felt repetitive; added many more topics, question types and topic memory: retest)
- [✗] No-repeat replies: private-talk questions don't repeat until a topic's list is used up; "didn't understand" lines rotate through a bigger pool
- [✓] Sliding underline bottom bar
- [−] Privacy Shield: Ghostie hides while a payment/banking app is open (editable list, bank guessing, usage access) (Google Pay is fine; Paytm and BharatPe refuse to run next to Ghostie; user is looking for alternatives)
- [✓] Summon button in the notification (also during calls)
- [✗] Backup and restore (not needed yet)
- [✓] Pull the big ghost into the left/right screen edge: it hides (no bin, no quiet time); tap the small edge ghost to bring it back (only a quick sideways flick into the edge hides it; sliding up/down along the edge just moves it)
- [−] Icons: "Use simple symbols instead of emoji" switch in Look & feel (app screens, dialogs, bottom bar and chat) (some places showed only an arrow because their emoji had no symbol; now every icon gets a symbol: retest)

## Alarms
- [✗] Alarm labels: after picking a time you can type a label (e.g. Gym); tap an alarm's text to change its label later. Chat: `alarm 7 called gym`
- [✓] Ghostie's own alarms (rings itself, survives restarts). Card: Add alarm, per-alarm switch, Test ring. Chat: `alarm 6:30 am`, `alarm 7 weekdays`, `alarm 7`, `my alarms`, `turn off alarm 6:30`, `delete alarm called gym`
- [✓] Waiting reminders: chat reminders that haven't rung yet are listed in the "Waiting reminders" card with Remove / Remove all. Reminders that already rang are kept under "Already rang" with Remove / Clear all old. Chat: `my reminders`, `cancel reminders`, `cancel reminder drink water`
- [✗] More ways to set a reminder that rings at a clock time: `add reminder for 7 as AI assignment`, `reminder AI assignment 7 o'clock`, `add assignment reminder at 7:00`, `remind me to submit it at 7 pm`, `kal 8 baje reminder gym`. A plain "7" means the next 7 o'clock still ahead (7 pm in the afternoon). `Aaj reminder for assignment` or just `add reminder` asks what is missing, then your next message answers. Reminders with a calendar date ("add reminder maths exam on 25 Nov") still go to the calendar
- [✓] Timer: `timer 10 minutes`; reminders: `remind me to drink water in 20 minutes` (seconds work too, e.g. `in 15 seconds`)

## Study and college
- [✗] Timetable grid with a subject list under it (look-alike names such as Maths / Mathematics or a typo are flagged so you can merge them; the list feeds attendance with no duplicates; each subject has Remove and Merge into...); fill by hand or **from a photo** (📷 From a photo: reads a printed timetable with days down the side or across the top, shows what it found, replaces only after you confirm). Photo reading uses Google ML Kit via Play Services (the reader downloads once, so the first scan needs internet)
- [✗] Working Saturdays: some colleges meet only on certain Saturdays (1st & 3rd, 2nd & 4th, or alternate) with their own timetable and period times. Timetable card → Working Saturdays → Add Saturday timetable. Attendance asks on those Saturdays only. A photo with rows like "2nd Saturday" / "4th Saturday" is imported as Saturday timetables (same period times; edit them afterwards)
- [✗] Subject changes follow into attendance: renaming or removing a subject in the timetable asks whether to move its attendance, keep it, or delete it
- [✗] Remove a subject from attendance: Remove on any attendance row stops tracking it (it stays in the timetable); a Not tracked list has Track again. A slot like MAT/ESC asks which subject it was when you answer Present/Absent
- [✗] Attendance: "Did you attend?" after each class, bunk calculator, "Attendance to fill" card. Chat: `attendance`, `can I bunk maths`, `present in maths`, `absent in maths`
- [✗] See your timetable in chat: `today's timetable`, `what are today's classes`, `tomorrow's classes`, `classes on friday`, `my timetable this week`, `next class`, `which class is now`, `do I have class tomorrow`
- [✗] More ways to check bunking: `can I bunk today` / `tomorrow` / `on friday` (whole-day check, subject by subject), `which subjects can I bunk` / `bunk status` (all subjects, safest first), `how many classes can I bunk in maths`, `low attendance` / `am I short on attendance`
- [✗] One-day class changes: tell Ghostie in chat `maths class today is cancelled`, `no classes tomorrow`, `dbms taken instead of physics today`, `another subject was taken instead of maths` (it asks which), `ai moved to 2pm tomorrow`, `extra class of maths tomorrow at 4pm`. Then `today's timetable`, the bunk check, "Did you attend?" and the 15-minute heads-up follow the change (cancelled classes show as ❌ and aren't counted; a replacement counts for the new subject; the day is marked "changed"). Your normal timetable is not touched. `undo class change`, `reset tomorrow's timetable` or `clear all class changes` put it back. When a watched class group says a class is cancelled or rescheduled, Ghostie offers "Apply class change / Ignore" for the subjects in your timetable
- [✗] Today's plan: `what's today's plan`, `how's the day looking`, `what do I have today`, `my day` show today's classes (with cancelled ones), reminders still to come, open to-dos and exams in the next 7 days; Dark romance words the intro in its own voice
- [✗] Heads-up 15 min before a class when that subject's attendance is at risk (switch in Weekly summary card)
- [✗] Study mode: focus timer, app blocking, Do Not Disturb. Chat: `study mode`, `study 45`, `study dbms 45`, `stop studying`, `study log`, `plan my week`
- [✗] **My study time**: tell Ghostie when you usually study; at that time it notifies everything due tomorrow (group submissions, event registrations, project tasks, exams). Card: My study time (add several times, "Show what's due tomorrow"). Chat: `I study at 7pm`, `study times 6am and 9pm`, `study time`, `clear study time`
- [✗] Exams and syllabus topics: `exams`, `exam maths 20 dec`, `study today`, `done topic limits`
- [✗] Weekly summary: Sunday 6 pm notification (study time, attendance, spending, what's due). Chat: `weekly summary`, `how was my week`
- [✗] Flashcards with spaced repetition: `card What is a deadlock = circular wait`, `quiz me`. "Review now" is a full-screen flip-card screen: tap the card to see the answer, then Again / Got it / Easy; progress bar; filter by subject; "Practice all cards" when none are due; a "missed ones" round at the end
- [✗] Flashcards from notes or a question paper (PDF, docx, pptx, txt): finds MCQs (with answer keys) and numericals, shows a tick-list of the cards found (untick bad ones, tap ✎ to fix wording, pick the subject, then add)
- [✗] Flashcards from notes (no questions in the file): Ghostie says "This looks like notes" and offers definition cards ("Explain: term", "What is X?") with 3 examples to check before adding. Numbered points and lettered headings are no longer counted as "questions with no answer". Cards are only as good as the notes, and PDF text sometimes splits words ("perfor m"), so check a few
- [✗] My cards (Flashcards > "My cards"): all cards grouped by subject, search, tick boxes (tick all per subject), edit a card (✎), move ticked cards to another subject, delete ticked cards (asks first)
- [✗] Group project tracker: tasks with owner, due date, optional WhatsApp number; overdue/due-soon status; one-tap reminder to teammates (WhatsApp or share sheet); share status. Chat: `projects`, `overdue tasks`
- [✗] Placement prep: 119 built-in questions (aptitude, reasoning, verbal, C, data structures, OS, DBMS, networks, HR) plus your own; Practice 5, interview question, results by topic, optional 7 pm "Question of the day" notification
- [✗] `what did I miss` / `catch me up`: digest of class groups

## Deadlines and groups
- [✗] Group reminders from WhatsApp notifications and open-chat reading, with Done
- [✗] Instagram, Telegram, Discord chat reader (switches in Group reminders)
- [✗] Share an exported chat or one message to Ghostie to catch up on deadlines
- [✗] `watch group CSE 3A`, and `watch this group` / `watch the open group` / `watch the group I'm in` watches the WhatsApp group that is open (needs Open-chat reading on; works if the group was open in the last 15 minutes)
- [✗] Call notes: call recording file → Android speech recognizer → reminders/notes → recording deleted (needs Android 13+, your phone's call recording on)

## Documents
- [✗] WhatsApp file organizer: sorts by file name, then chat name, then the text inside the file (PDF, docx, pptx, txt, csv; scanned PDFs not readable). Originals are never touched
- [✗] Subject tick-boxes: 56 subjects in 7 groups; only ticked ones are organized; own subjects; reset
- [✗] Combine subjects (🔗 Combine subjects button): pick 2 or more subjects (e.g. Artificial Intelligence + Machine Learning), name the result (suggests AIML); files about any of them go into one folder. The combined row snaps in with a small animation; tap it to split apart. Members get unticked when combined
- [✗] Browse sorted files shows folders by subject (tap a folder to open it, file counts shown); tap a file to move it, drag to the bin
- [✗] Chat: `organize documents`, `show documents of computer science`, `open file maths notes`, `open the DBMS pdf`

## Money
- [−] Spending from bank/UPI SMS and payment-app notifications, manual entry, monthly budget, safe-to-spend per day, alerts at 80% and 100%. Shows where the money went (category totals, % and bars); "See what I spent on" opens a month view, tap a category to list each payment, ◀ Earlier / Later ▶ for other months. Bill reminders, due notices, sales/offers ("Rs 3000 OFF") and payment requests are ignored; a message needs a clear payment word (debited, paid, spent...) or bank details (a/c, card, UPI...) to count (not counted as spending); tap a payment in the month view to remove a wrong one. Every payment now shows where it came from (text sender such as VM-KOTAKB, or the payment app). Old entries have no sender: tap one and choose "Find the text" to look it up in your inbox, or run "Scan last 30 days of texts" once to fill senders in. Chat: `spent 120 on lunch`, `my spending`, `where did my money go` (Google Pay works, month breakdown and sender lookup work; Paytm/BharatPe refuse to open with Ghostie installed)
- [✗] Split expenses: who owes whom, WhatsApp reminder, paid back/part/clear. Chat: `split 600 lunch with Ravi and Meena`, `Ravi paid me back 200`, `I paid Ravi 100`, `I owe Meena 75`, `settle Ravi`, `who owes me`
- [✗] Food price check (Zomato, Swiggy, Domino's, Popeyes, EatSure; never orders): `cheapest chicken biryani`, `compare paneer pizza and garlic bread`, `show last food result`, `stop price check`

## More tab
- [✗] Trip pack list: tell Ghostie how long you're going (`I'm going for 5 days`, `trip for 2 weeks`, or the Trip length button): clothes counts (shirts, underwear, socks, pants, nightwear, masks) follow the days, tap a number to change it. 44 default items, tick, add, remove, new trip, reset. Chat: `pack list`, `add charger to pack list`, `new trip`
- [✗] Notes and to-dos: `note buy milk`, `show notes`, `clear notes`, `todo finish lab record`, `my todos`, `done 2`

## Everyday commands
- [✗] Stored events: every event Ghostie added has a Remove button (also deletes its calendar entry); Clear past events (list only) and Remove all; past group deadlines are counted with Show / Clear all past (records only, calendar untouched)
- [✗] Calendar: `add event maths exam tomorrow 10am`, `add birthday Tikki on 19 October`, `countdown to exams 5 dec`, extras (`every week`, `for 2 hours`, `all day`, `remind me 30 minutes before`), `make it a birthday`, `undo`
- [✗] Calls and apps: `call Mom`, `call 9876543210`, `open WhatsApp`
- [✗] Tools: `flashlight on/off`, `calculate 12*(3+4)`, `flip a coin`, `roll a dice`, `what time is it`, `what's the date`, `battery`
- [✗] Tricks: `dance`, `wave`, `yawn`, `shiver`, `do a flip`
- [✗] Teaching: `when I say study mode, set timer 25 minutes`, `remember cs means computer science`, `what have you learned`, `forget study mode`, `forget everything`, `stop suggestions`, `start suggestions`
- [✗] Personalities (Look & feel, or in chat: `change tone`, `be sassy`, `be dark romance`, `what do personalities do`): Classic, Sweet, Playful, Sassy, Coach and Dark romance (gothic, moonlit, poetic; always gentle, never possessive). They change how Ghostie talks: greetings, check-ins, thank-yous, good-nights, study and deadline nudges and the tone of AI replies. Personal talk, advice and most other replies are the same in every personality. They don't change what it understands; Dark romance also has its own "didn't understand" lines (never the same line twice in a row)
- [✗] Payment pause (Paytm / BharatPe show "Suspicious App Detected: Ghostie" while any Accessibility service is on): Setup button "Pause screen reading" or chat `pause screen reading` / `payment mode` switches off Read open chats and Food price reader; Android won't let apps turn Accessibility back on, so re-enable via "Turn reading back on" / `turn screen reading on` (opens Accessibility settings). Notification reading is unaffected. Test: pause, then open Paytm and pay
- [✗] `help` shows the command list. Anything unrecognised goes to the AI chat (if a key is set) or a friendly local reply

## Known risks to watch while testing
- The first photo scan needs internet to download the reader. Photo timetable and flashcards-from-file depend on how clean the photo/file is; check the preview before accepting
- Call notes depend on whether your phone's recognizer accepts audio from a file
- Bank/payment package names and subject keywords are from public lists and memory; tell me any that misfire
- Poco/HyperOS may block alarms or overlays unless Autostart and battery "No restrictions" are set

## Planned / not built
- iPhone (iOS) version: not possible as a port of this app (iOS doesn't allow floating overlays or reading other apps' notifications); options are a separate iOS companion app (reminders, attendance, timetable, chat) or a home-screen widget plus Shortcuts
- Profession-based onboarding and per-profession animations
- More course-specific keyword lists
- Further UI polish
- Chat: more situations as they turn up in testing (latest: "what's happening", "check WhatsApp" opens the app, reactions like "it's interesting")
- Home screen of feature tiles (icon grid). Tapping a tile opens that feature as a tall popup sheet (full screen for heavy ones like timetable, spending, placement practice). Plan: about 8-10 tiles (Study, Timetable, Attendance, Deadlines, Documents, Money, Projects, Placement, More, Setup), badges for overdue/unmarked items, consistent flat icons instead of mixed emoji, daily features kept one tap away, permissions kept in one Setup area, bottom bar reduced to Home / Chat / Setup. Risks to check when built: extra tap per feature, nested dialogs inside sheets, back gesture, keyboard covering fields, refresh after edits. Fallback: keep the tabs and add the tile home screen on top
- Per-personality replies for every situation: reply lines kept in text files (one per personality, Classic as fallback), added in small batches of about 8-12 lines per situation and tested batch by batch. Sensitive topics (break-up, anxiety, anger, secrets/intrusive thoughts): whether they change per personality is pending your decision; until then they stay the same in every personality

