# Ghostie: features and test list

Status: [x] = you tested it and it works, [ ] = not tested on a phone yet. Everything below is built; nothing has been run on a phone by me, only compiled and logic-tested.

## Core
- [ ] Floating ghost: edge handle, drag, sleep at night, drag to bin
- [ ] One-tap chat (tap the ghost or edge handle) with a smooth open animation
- [ ] Chat box: AI/local chat, voice in and out, history, themes
- [ ] Sliding underline bottom bar
- [ ] Privacy Shield: Ghostie hides while a payment/banking app is open (editable list, bank guessing, usage access)
- [ ] Summon button in the notification (also during calls)
- [ ] Backup and restore

## Alarms
- [ ] Ghostie's own alarms (rings itself, survives restarts). Card: Add alarm, per-alarm switch, Test ring. Chat: `alarm 6:30 am`, `alarm 7 weekdays`, `alarm 7`, `my alarms`, `turn off alarm 6:30`, `delete alarm called gym`
- [ ] Timer: `timer 10 minutes`; reminders: `remind me to drink water in 20 minutes`

## Study and college
- [ ] Timetable grid; fill by hand or **from a photo** (📷 From a photo: reads a printed timetable with days down the side or across the top, shows what it found, replaces only after you confirm). Photo reading uses Google ML Kit via Play Services (the reader downloads once, so the first scan needs internet)
- [ ] Attendance: "Did you attend?" after each class, bunk calculator, "Attendance to fill" card. Chat: `attendance`, `can I bunk maths`, `present in maths`, `absent in maths`, `today's classes`
- [ ] Heads-up 15 min before a class when that subject's attendance is at risk (switch in Weekly summary card)
- [ ] Study mode: focus timer, app blocking, Do Not Disturb. Chat: `study mode`, `study 45`, `study dbms 45`, `stop studying`, `study log`, `plan my week`
- [ ] **My study time**: tell Ghostie when you usually study; at that time it notifies everything due tomorrow (group submissions, event registrations, project tasks, exams). Card: My study time (add several times, "Show what's due tomorrow"). Chat: `I study at 7pm`, `study times 6am and 9pm`, `study time`, `clear study time`
- [ ] Exams and syllabus topics: `exams`, `exam maths 20 dec`, `study today`, `done topic limits`
- [ ] Weekly summary: Sunday 6 pm notification (study time, attendance, spending, what's due). Chat: `weekly summary`, `how was my week`
- [ ] Flashcards with spaced repetition: `card What is a deadlock = circular wait`, `quiz me`
- [ ] Flashcards from notes or a question paper (PDF, docx, pptx, txt): finds MCQs (with answer keys) and numericals, you pick the subject and add them
- [ ] Group project tracker: tasks with owner, due date, optional WhatsApp number; overdue/due-soon status; one-tap reminder to teammates (WhatsApp or share sheet); share status. Chat: `projects`, `overdue tasks`
- [ ] Placement prep: 119 built-in questions (aptitude, reasoning, verbal, C, data structures, OS, DBMS, networks, HR) plus your own; Practice 5, interview question, results by topic, optional 7 pm "Question of the day" notification
- [ ] `what did I miss` / `catch me up`: digest of class groups

## Deadlines and groups
- [ ] Group reminders from WhatsApp notifications and open-chat reading, with Done
- [ ] Instagram, Telegram, Discord chat reader (switches in Group reminders)
- [ ] Share an exported chat or one message to Ghostie to catch up on deadlines
- [ ] `watch group CSE 3A`
- [ ] Call notes: call recording file → Android speech recognizer → reminders/notes → recording deleted (needs Android 13+, your phone's call recording on)

## Documents
- [ ] WhatsApp file organizer: sorts by file name, then chat name, then the text inside the file (PDF, docx, pptx, txt, csv; scanned PDFs not readable). Originals are never touched
- [ ] Subject tick-boxes: 56 subjects in 7 groups; only ticked ones are organized; own subjects; reset
- [ ] Combine subjects (🔗 Combine subjects button): pick 2 or more subjects (e.g. Artificial Intelligence + Machine Learning), name the result (suggests AIML); files about any of them go into one folder. The combined row snaps in with a small animation; tap it to split apart. Members get unticked when combined
- [ ] Chat: `organize documents`, `show documents of computer science`, `open file maths notes`, `open the DBMS pdf`

## Money
- [ ] Spending from bank/UPI SMS and payment-app notifications, manual entry, monthly budget, safe-to-spend per day, alerts at 80% and 100%. Shows where the money went (category totals, % and bars); "See what I spent on" opens a month view, tap a category to list each payment, ◀ Earlier / Later ▶ for other months. Chat: `spent 120 on lunch`, `my spending`, `where did my money go`
- [ ] Split expenses: who owes whom, WhatsApp reminder, paid back/part/clear. Chat: `split 600 lunch with Ravi and Meena`, `Ravi paid me back 200`, `I paid Ravi 100`, `I owe Meena 75`, `settle Ravi`, `who owes me`
- [ ] Food price check (Zomato, Swiggy, Domino's, Popeyes, EatSure; never orders): `cheapest chicken biryani`, `compare paneer pizza and garlic bread`, `show last food result`, `stop price check`

## More tab
- [ ] Trip pack list: 44 default items, tick, add, remove, new trip, reset. Chat: `pack list`, `add charger to pack list`, `new trip`
- [ ] Notes and to-dos: `note buy milk`, `show notes`, `clear notes`, `todo finish lab record`, `my todos`, `done 2`

## Everyday commands
- [ ] Calendar: `add event maths exam tomorrow 10am`, `add birthday Tikki on 19 October`, `countdown to exams 5 dec`, extras (`every week`, `for 2 hours`, `all day`, `remind me 30 minutes before`), `make it a birthday`, `undo`
- [ ] Calls and apps: `call Mom`, `call 9876543210`, `open WhatsApp`
- [ ] Tools: `flashlight on/off`, `calculate 12*(3+4)`, `flip a coin`, `roll a dice`, `what time is it`, `what's the date`, `battery`
- [ ] Tricks: `dance`, `wave`, `yawn`, `shiver`, `do a flip`
- [ ] Teaching: `when I say study mode, set timer 25 minutes`, `remember cs means computer science`, `what have you learned`, `forget study mode`, `forget everything`, `stop suggestions`, `start suggestions`
- [ ] `help` shows the command list. Anything unrecognised goes to the AI chat (if a key is set) or a friendly local reply

## Known risks to watch while testing
- The first photo scan needs internet to download the reader. Photo timetable and flashcards-from-file depend on how clean the photo/file is; check the preview before accepting
- Call notes depend on whether your phone's recognizer accepts audio from a file
- Bank/payment package names and subject keywords are from public lists and memory; tell me any that misfire
- Poco/HyperOS may block alarms or overlays unless Autostart and battery "No restrictions" are set

## Planned / not built
- Profession-based onboarding and per-profession animations
- More course-specific keyword lists
- Further UI polish
- Home screen of feature tiles (icon grid). Tapping a tile opens that feature as a tall popup sheet (full screen for heavy ones like timetable, spending, placement practice). Plan: about 8-10 tiles (Study, Timetable, Attendance, Deadlines, Documents, Money, Projects, Placement, More, Setup), badges for overdue/unmarked items, consistent flat icons instead of mixed emoji, daily features kept one tap away, permissions kept in one Setup area, bottom bar reduced to Home / Chat / Setup. Risks to check when built: extra tap per feature, nested dialogs inside sheets, back gesture, keyboard covering fields, refresh after edits. Fallback: keep the tabs and add the tile home screen on top
