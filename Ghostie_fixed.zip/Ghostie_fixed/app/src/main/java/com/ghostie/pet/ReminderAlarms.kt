package com.ghostie.pet

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

/** Sets Ghostie's own alerts for each deadline, so the notification can carry Done / Snooze / bin buttons. */
object ReminderAlarms {
    const val SHOW = "com.ghostie.pet.REM_SHOW"
    const val DONE = "com.ghostie.pet.REM_DONE"
    const val SNOOZE = "com.ghostie.pet.REM_SNOOZE"
    const val TRASH = "com.ghostie.pet.REM_TRASH"
    const val QUICK = "com.ghostie.pet.REM_QUICK"
    const val CHANNEL = "ghostie_due"

    private fun pi(ctx: Context, action: String, eventId: Long, slot: Int, flags: Int = PendingIntent.FLAG_UPDATE_CURRENT): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, (eventId % 100000).toInt() * 10 + slot,
            Intent(ctx, ReminderReceiver::class.java).setAction(action).putExtra("id", eventId),
            PendingIntent.FLAG_IMMUTABLE or flags
        )

    fun scheduleAt(ctx: Context, eventId: Long, whenMs: Long, slot: Int) {
        if (whenMs <= System.currentTimeMillis()) return
        try {
            val am = ctx.getSystemService(AlarmManager::class.java)
            // Slot-specific request code, so each alert of one deadline stays separate. Approximate timing is fine for reminders.
            val p = PendingIntent.getBroadcast(
                ctx, (eventId % 100000).toInt() * 10 + slot,
                Intent(ctx, ReminderReceiver::class.java).setAction(SHOW).putExtra("id", eventId).putExtra("slot", slot),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, p)
        } catch (e: Exception) { }
    }

    /** "remind me to X in 20 minutes": a plain one-off notification. */
    // ---- quick reminders ("remind me to drink water in 20 minutes"): kept in a small list so they can be seen and removed ----
    private fun qprefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("ghostie_quick", Context.MODE_PRIVATE)
    private fun qPending(ctx: Context, text: String, whenMs: Long, flags: Int = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT): PendingIntent? =
        PendingIntent.getBroadcast(ctx, (text + whenMs).hashCode(), Intent(ctx, ReminderReceiver::class.java).setAction(QUICK).putExtra("text", text), flags)

    private fun parseQ(raw: String): List<Pair<Long, String>> = raw.lines().mapNotNull {
        val p = it.split('\t', limit = 2)
        val t = p.getOrNull(0)?.toLongOrNull()
        if (t != null && p.size == 2) t to p[1] else null
    }

    /** Reminders that have not rung yet, soonest first: pairs of (time, text). Ones that already rang move to [rangList]. */
    fun quickList(ctx: Context): List<Pair<Long, String>> {
        val now = System.currentTimeMillis()
        val all = parseQ(qprefs(ctx).getString("list", "") ?: "")
        val (future, past) = all.partition { it.first > now - 60_000L }
        if (past.isNotEmpty()) {
            val done = (past + parseQ(qprefs(ctx).getString("done", "") ?: "")).sortedByDescending { it.first }.take(30)
            qprefs(ctx).edit().putString("done", done.joinToString("\n") { it.first.toString() + "\t" + it.second })
                .putString("list", future.joinToString("\n") { it.first.toString() + "\t" + it.second }).apply()
        }
        return future.sortedBy { it.first }
    }

    /** Reminders that already rang, newest first (kept so they can be looked at and cleared). */
    fun rangList(ctx: Context): List<Pair<Long, String>> { quickList(ctx); return parseQ(qprefs(ctx).getString("done", "") ?: "").sortedByDescending { it.first } }
    fun removeRang(ctx: Context, whenMs: Long, text: String) {
        val keep = rangList(ctx).filterNot { it.first == whenMs && it.second == text }
        qprefs(ctx).edit().putString("done", keep.joinToString("\n") { it.first.toString() + "\t" + it.second }).apply()
    }
    fun clearRang(ctx: Context) { qprefs(ctx).edit().remove("done").apply() }
    private fun saveQuick(ctx: Context, list: List<Pair<Long, String>>) {
        qprefs(ctx).edit().putString("list", list.joinToString("\n") { it.first.toString() + "\t" + it.second }).apply()
    }

    /** Removes one reminder (and its alarm). */
    fun cancelQuick(ctx: Context, whenMs: Long, text: String) {
        try {
            val p = qPending(ctx, text, whenMs, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE)
            if (p != null) { ctx.getSystemService(AlarmManager::class.java).cancel(p); p.cancel() }
        } catch (e: Exception) { }
        saveQuick(ctx, quickList(ctx).filterNot { it.first == whenMs && it.second == text })
    }

    /** Removes every waiting quick reminder; returns how many. */
    fun cancelAllQuick(ctx: Context): Int {
        val all = quickList(ctx)
        all.forEach { cancelQuick(ctx, it.first, it.second) }
        return all.size
    }

    fun quick(ctx: Context, text: String, whenMs: Long) {
        try {
            val am = ctx.getSystemService(AlarmManager::class.java)
            val p = qPending(ctx, text, whenMs) ?: return
            saveQuick(ctx, quickList(ctx) + (whenMs to text))
            // short waits should ring on time; fall back to the normal (slightly late) alarm when exact ones aren't allowed
            if (whenMs - System.currentTimeMillis() < 10 * 60_000L) {
                try { am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, p); return } catch (e: SecurityException) { }
            }
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, p)
        } catch (e: Exception) { }
    }

    fun scheduleTimes(ctx: Context, e: LogEntry, times: List<LocalDateTime>) {
        times.take(5).forEachIndexed { i, t ->
            scheduleAt(ctx, e.eventId, t.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(), i)
        }
    }

    /** Slot used for the "last hour, still not done" call. */
    const val FINAL_SLOT = 5

    /** Rings like a call [SettingsStore.finalCallMin] minutes before the deadline if the task isn't marked done by then. */
    fun scheduleFinal(ctx: Context, e: LogEntry) {
        val s = SettingsStore(ctx)
        if (!s.finalCall || e.start <= 0L) return
        scheduleAt(ctx, e.eventId, e.start - s.finalCallMin * 60_000L, FINAL_SLOT)
    }

    /** After a reboot the exact times are gone, so use the usual ones: 9 am the day before and 8 am that morning. */
    fun rescheduleAll(ctx: Context) {
        val s = SettingsStore(ctx)
        for (e in s.logs()) {
            val d = ReminderLog.dueDate(e) ?: continue
            if (e.start <= System.currentTimeMillis()) continue
            val times = mutableListOf(LocalDateTime.of(d.minusDays(1), LocalTime.of(9, 0)))
            if (s.remindMorning) times.add(LocalDateTime.of(d, LocalTime.of(8, 0)))
            scheduleTimes(ctx, e, times.filter { it.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli() < e.start })
            scheduleFinal(ctx, e)
        }
    }

    fun cancelAll(ctx: Context, eventId: Long) {
        try {
            val am = ctx.getSystemService(AlarmManager::class.java)
            for (slot in 0..9) am.cancel(pi(ctx, SHOW, eventId, slot))
        } catch (e: Exception) { }
    }

    fun notify(ctx: Context, e: LogEntry) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Deadline reminders", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(ctx, 1, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val due = ReminderLog.dueDate(e)?.let { " (due $it)" } ?: ""
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ghost_pet)
            .setContentTitle(e.title)
            .setContentText("From ${e.group}$due")
            .setStyle(Notification.BigTextStyle().bigText("From ${e.group}$due" + (if (e.msg.isNotBlank()) "\n\u201C${e.msg}\u201D" else "")))
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Done ✅", pi(ctx, DONE, e.eventId, 7)).build())
            .addAction(Notification.Action.Builder(null, "Snooze 1h", pi(ctx, SNOOZE, e.eventId, 8)).build())
            .addAction(Notifier.summonAction(ctx))
            .build()
        nm.notify(("due" + e.eventId).hashCode(), n)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == ReminderAlarms.QUICK) {
            Notifier.post(ctx, "⏰ Ghostie reminder", intent.getStringExtra("text") ?: "Time!")
            return
        }
        val id = intent.getLongExtra("id", -1L)
        val s = SettingsStore(ctx)
        val e = s.logs().firstOrNull { it.eventId == id }
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val nid = ("due$id").hashCode()
        when (intent.action) {
            ReminderAlarms.SHOW -> if (e != null) {
                if (intent.getIntExtra("slot", -1) == ReminderAlarms.FINAL_SLOT) {
                    // Still on the list = not marked done. Ring like a call, once.
                    if (s.finalCall && e.start > System.currentTimeMillis()) {
                        val mins = ((e.start - System.currentTimeMillis()) / 60_000L).toInt().coerceAtLeast(1)
                        ActivityLog.add(ctx, "Call", "Final-hour call for ${ReminderLog.label(e)}")
                        CallAlerts.show(ctx, e.group, "⏰ ${ReminderLog.label(e)} is due in about $mins min and isn't marked done", e.msg, e.eventId)
                    }
                } else ReminderAlarms.notify(ctx, e)
            }
            ReminderAlarms.SNOOZE -> {
                nm.cancel(nid)
                if (e != null) { HabitStore.get(ctx).groupAct(e.group, 1); HabitStore.save(ctx) }
                if (e != null) ReminderAlarms.scheduleAt(ctx, id, System.currentTimeMillis() + 3_600_000L, 6)
            }
            ReminderAlarms.DONE, ReminderAlarms.TRASH -> {
                nm.cancel(nid)
                if (e != null) {
                    HabitStore.get(ctx).groupAct(e.group, if (intent.action == ReminderAlarms.TRASH) 2 else 0); HabitStore.save(ctx)
                    if (intent.action == ReminderAlarms.TRASH) {
                        LearnStore.get(ctx).block(e.group, ReminderLog.label(e))
                        LearnStore.save(ctx)
                    }
                    try { CalendarHelper.delete(ctx, id) } catch (x: Exception) { }
                    s.removeLog(id)
                    ReminderAlarms.cancelAll(ctx, id)
                    GhostieWidget.refresh(ctx)
                    ActivityLog.add(ctx, "Reminder", (if (intent.action == ReminderAlarms.TRASH) "Binned " else "Done: ") + ReminderLog.label(e))
                }
            }
        }
    }
}
