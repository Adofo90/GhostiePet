package com.ghostie.pet

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Ghostie's animated switches. style 0 Boo (ghost slides, wakes), 1 Haunted Hill (day/night through a glass),
 * 2 Ectoplasm (stretchy blob), 3 Wisp (flame orb with embers), 4 Poltergeist (springy knob that shakes the switch).
 */
class GhostSwitch(ctx: Context, private val style: Int) : View(ctx) {
    var checked = false
        private set
    var onChange: ((Boolean) -> Unit)? = null

    private var p = 0f      // knob position, 0 = off, 1 = on (style 4 overshoots)
    private var q = 0f      // trailing blob (style 2)
    private var burst = 1f  // 0..1 after each flip
    private var tick = 0f   // endless 0..1 loop while on (bobbing, embers)
    private var mover: ValueAnimator? = null
    private var tail: ValueAnimator? = null
    private var burstAnim: ValueAnimator? = null
    private var ticker: ValueAnimator? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val argb = ArgbEvaluator()
    private val d = ctx.resources.displayMetrics.density

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        isClickable = true
        isFocusable = true
        setOnClickListener { setChecked(!checked, true) }
    }

    private fun dp(v: Float) = v * d
    private fun mix(a: Int, b: Int, t: Float): Int = (argb.evaluate(t.coerceIn(0f, 1f), a, b) as Int)

    fun setCheckedInstant(v: Boolean) {
        checked = v
        p = if (v) 1f else 0f; q = p; burst = 1f
        updateTicker(); invalidate()
    }

    fun setChecked(v: Boolean, user: Boolean) {
        if (v == checked) return
        checked = v
        val target = if (v) 1f else 0f
        mover?.cancel(); tail?.cancel(); burstAnim?.cancel()
        mover = ValueAnimator.ofFloat(p, target).apply {
            duration = when (style) { 4 -> 650L; 3 -> 520L; 1 -> 600L; else -> 450L }
            interpolator = when (style) { 4 -> OvershootInterpolator(2.6f); 0 -> OvershootInterpolator(1.4f); else -> DecelerateInterpolator(1.6f) }
            addUpdateListener { p = it.animatedValue as Float; invalidate() }
            start()
        }
        if (style == 2) tail = ValueAnimator.ofFloat(q, target).apply {
            duration = 560L; startDelay = 110L; interpolator = DecelerateInterpolator(1.4f)
            addUpdateListener { q = it.animatedValue as Float; invalidate() }
            start()
        } else q = target
        burst = 0f
        burstAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700L; interpolator = LinearInterpolator()
            addUpdateListener { burst = it.animatedValue as Float; invalidate() }
            start()
        }
        updateTicker()
        if (user) { performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); onChange?.invoke(v) }
    }

    private fun updateTicker() {
        val need = checked && isAttachedToWindow && (style == 0 || style == 1 || style == 3)
        if (need && ticker == null) {
            ticker = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 1600L; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
                addUpdateListener { tick = it.animatedValue as Float; invalidate() }
                start()
            }
        } else if (!need) { ticker?.cancel(); ticker = null }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); updateTicker() }
    override fun onDetachedFromWindow() {
        mover?.cancel(); tail?.cancel(); burstAnim?.cancel(); ticker?.cancel(); ticker = null
        super.onDetachedFromWindow()
    }

    override fun onInitializeAccessibilityNodeInfo(info: AccessibilityNodeInfo?) {
        super.onInitializeAccessibilityNodeInfo(info)
        info?.className = "android.widget.Switch"
        info?.isCheckable = true
        info?.isChecked = checked
    }

    // ---------- drawing helpers ----------
    private fun drawFace(c: Canvas, cx: Float, cy: Float, s: Float, awake: Float, ink: Int) {
        paint.style = Paint.Style.FILL; paint.color = ink; paint.maskFilter = null; paint.shader = null
        val a = awake.coerceIn(0.1f, 1f)
        rect.set(cx - s * 0.27f, cy - s * 0.08f - s * 0.1f * a, cx - s * 0.13f, cy - s * 0.08f + s * 0.1f * a); c.drawOval(rect, paint)
        rect.set(cx + s * 0.13f, cy - s * 0.08f - s * 0.1f * a, cx + s * 0.27f, cy - s * 0.08f + s * 0.1f * a); c.drawOval(rect, paint)
        val m = 0.5f + 0.5f * a
        rect.set(cx - s * 0.08f * m, cy + s * 0.12f, cx + s * 0.08f * m, cy + s * 0.12f + s * 0.17f * m); c.drawOval(rect, paint)
    }

    private fun drawGhost(c: Canvas, cx: Float, cy: Float, s: Float, awake: Float, body: Int, ink: Int) {
        val l = cx - s / 2; val t = cy - s * 0.55f; val h = s * 1.1f
        path.reset()
        path.moveTo(l, t + h * 0.45f)
        path.cubicTo(l, t - h * 0.04f, l + s, t - h * 0.04f, l + s, t + h * 0.45f)
        path.lineTo(l + s, t + h)
        val seg = s / 3f
        for (i in 0 until 3) {
            val x0 = l + s - i * seg
            path.quadTo(x0 - seg / 2f, t + h * 0.76f, x0 - seg, t + h)
        }
        path.close()
        paint.style = Paint.Style.FILL; paint.color = body; paint.maskFilter = null; paint.shader = null
        c.drawPath(path, paint)
        drawFace(c, cx, cy, s, awake, ink)
    }

    private fun glow(c: Canvas, cx: Float, cy: Float, r: Float, color: Int, alpha: Float) {
        if (alpha <= 0.02f) return
        paint.style = Paint.Style.FILL; paint.shader = null
        paint.color = Color.argb((alpha * 255).toInt().coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))
        paint.maskFilter = BlurMaskFilter(dp(7f), BlurMaskFilter.Blur.NORMAL)
        c.drawCircle(cx, cy, r, paint)
        paint.maskFilter = null
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val pad = dp(4f)
        val tr = RectF(pad, pad, w - pad, h - pad)
        val trackH = tr.height(); val r = trackH / 2f - dp(2.5f)
        val cy = h / 2f
        val minX = tr.left + dp(2.5f) + r; val maxX = tr.right - dp(2.5f) - r
        fun kx(v: Float) = minX + v * (maxX - minX)
        val pc = p.coerceIn(0f, 1f)
        val corner = trackH / 2f
        when (style) {
            0 -> {
                if (pc > 0.02f) { paint.shader = null; paint.style = Paint.Style.FILL; paint.color = Color.argb((pc * 150).toInt(), 94, 242, 212); paint.maskFilter = BlurMaskFilter(dp(6f), BlurMaskFilter.Blur.NORMAL); canvas.drawRoundRect(tr, corner, corner, paint); paint.maskFilter = null }
                paint.style = Paint.Style.FILL; paint.shader = null; paint.color = mix(0xFF2B3145.toInt(), 0xFF1D9A8B.toInt(), pc)
                canvas.drawRoundRect(tr, corner, corner, paint)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(1.5f); paint.color = mix(0xFF3A4260.toInt(), 0xFF5EF2D4.toInt(), pc); canvas.drawRoundRect(tr, corner, corner, paint)
                if (pc > 0.3f) { val a = (0.5f + 0.5f * Math.sin(tick * 12.566).toFloat()) * pc; paint.style = Paint.Style.FILL; paint.color = Color.argb((a * 230).toInt().coerceIn(0, 255), 235, 255, 251); canvas.drawCircle(minX + dp(2f), cy - dp(4f), dp(1.6f) + a * dp(1f), paint) }
                if (pc < 0.4f) { paint.style = Paint.Style.FILL; paint.color = Color.argb(((0.4f - pc) * 400).toInt().coerceIn(0, 160), 150, 160, 190); paint.textSize = dp(10f); paint.isFakeBoldText = true; canvas.drawText("z z", maxX - dp(10f), cy - dp(4f), paint); paint.isFakeBoldText = false }
                val bob = if (checked) Math.sin(tick * 6.2832).toFloat() * dp(1.2f) else 0f
                drawGhost(canvas, kx(p), cy + bob, r * 1.95f, pc, Color.WHITE, 0xFF1B2030.toInt())
            }
            1 -> {
                canvas.save()
                path.reset(); path.addRoundRect(tr, corner, corner, Path.Direction.CW); canvas.clipPath(path)
                paint.style = Paint.Style.FILL; paint.shader = null; paint.maskFilter = null
                paint.color = mix(0xFF8FD0FF.toInt(), 0xFF141A44.toInt(), pc); canvas.drawRect(tr, paint)
                paint.color = Color.argb((pc * 255).toInt(), 255, 255, 255)
                for (i in 0 until 7) canvas.drawRect(tr.left + tr.width() * (0.08f + i * 0.13f), tr.top + tr.height() * (0.12f + (i * 37 % 5) * 0.1f), tr.left + tr.width() * (0.08f + i * 0.13f) + dp(1.3f), tr.top + tr.height() * (0.12f + (i * 37 % 5) * 0.1f) + dp(1.3f), paint)
                // hill
                paint.color = mix(0xFF5CA84C.toInt(), 0xFF1D3A4A.toInt(), pc)
                path.reset(); path.moveTo(tr.left, tr.bottom); path.lineTo(tr.left, tr.top + tr.height() * 0.72f); path.lineTo(tr.left + tr.width() * 0.3f, tr.top + tr.height() * 0.62f); path.lineTo(tr.left + tr.width() * 0.6f, tr.top + tr.height() * 0.68f); path.lineTo(tr.right, tr.top + tr.height() * 0.6f); path.lineTo(tr.right, tr.bottom); path.close(); canvas.drawPath(path, paint)
                // house
                val hx = tr.left + tr.width() * 0.6f; val hb = tr.bottom - dp(1f); val hw = dp(15f); val hh = dp(10f)
                paint.color = mix(0xFFD9A066.toInt(), 0xFF3A2D3F.toInt(), pc); canvas.drawRect(hx, hb - hh, hx + hw, hb, paint)
                paint.color = mix(0xFF4A56B8.toInt(), 0xFF2B3480.toInt(), pc); path.reset(); path.moveTo(hx - dp(2f), hb - hh); path.lineTo(hx + hw / 2, hb - hh - dp(6f)); path.lineTo(hx + hw + dp(2f), hb - hh); path.close(); canvas.drawPath(path, paint)
                paint.color = mix(0xFF8FD0FF.toInt(), 0xFFFFE9A1.toInt(), pc); canvas.drawRect(hx + hw * 0.55f, hb - hh * 0.8f, hx + hw * 0.85f, hb - hh * 0.4f, paint)
                if (pc > 0.5f) { val bobY = Math.sin(tick * 6.2832).toFloat() * dp(0.8f); paint.color = Color.argb(((pc - 0.5f) * 500).toInt().coerceIn(0, 255), 255, 255, 255); canvas.drawRect(hx + hw * 0.6f, hb - hh * 0.75f + bobY, hx + hw * 0.78f, hb - hh * 0.45f + bobY, paint) }
                // glass knob carrying sun or moon
                val gx = kx(p)
                paint.color = Color.argb(((1f - pc) * 255).toInt(), 255, 212, 94); canvas.drawCircle(gx, cy, r * 0.55f, paint)
                paint.color = Color.argb((pc * 255).toInt(), 243, 241, 216); canvas.drawCircle(gx, cy, r * 0.55f, paint)
                paint.color = Color.argb((pc * 120).toInt(), 160, 156, 120); canvas.drawCircle(gx - r * 0.18f, cy - r * 0.12f, r * 0.14f, paint)
                paint.color = Color.argb(46, 255, 255, 255); canvas.drawCircle(gx, cy, r, paint)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(1.4f); paint.color = Color.argb(190, 255, 255, 255); canvas.drawCircle(gx, cy, r, paint)
                canvas.restore()
                paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(2f); paint.color = mix(0xFFD9DBE6.toInt(), 0xFF3A3F66.toInt(), pc); canvas.drawRoundRect(tr, corner, corner, paint)
            }
            2 -> {
                paint.style = Paint.Style.FILL; paint.shader = null; paint.maskFilter = null; paint.color = 0xFF0B0D14.toInt(); canvas.drawRoundRect(tr, corner, corner, paint)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(1.5f); paint.color = mix(0xFF2A2F40.toInt(), 0xFF2E7F5A.toInt(), pc); canvas.drawRoundRect(tr, corner, corner, paint)
                val head = kx(p); val trail = kx(q.coerceIn(0f, 1f))
                val col = mix(0xFF6B7691.toInt(), 0xFF6DFFB6.toInt(), pc)
                glow(canvas, head, cy, r * 1.15f, 0xFF6DFFB6.toInt(), pc * 0.7f)
                paint.style = Paint.Style.FILL; paint.shader = null; paint.maskFilter = null; paint.color = col
                val lo = minOf(head, trail); val hi = maxOf(head, trail)
                if (hi - lo > 1f) { val stretch = (hi - lo) / (maxX - minX); val bh = r * (0.95f - 0.25f * stretch); rect.set(lo, cy - bh, hi, cy + bh); canvas.drawRoundRect(rect, bh, bh, paint) }
                canvas.drawCircle(head, cy, r, paint); canvas.drawCircle(trail, cy, r * (1f - 0.12f * Math.abs(p - q).coerceAtMost(1f)), paint)
                drawFace(canvas, head, cy, r * 1.9f, 0.3f + 0.7f * pc, 0xFF12202B.toInt())
            }
            3 -> {
                if (pc > 0.02f) { paint.shader = null; paint.style = Paint.Style.FILL; paint.color = Color.argb((pc * 140).toInt(), 255, 160, 60); paint.maskFilter = BlurMaskFilter(dp(6f), BlurMaskFilter.Blur.NORMAL); canvas.drawRoundRect(tr, corner, corner, paint); paint.maskFilter = null }
                paint.style = Paint.Style.FILL; paint.shader = null; paint.maskFilter = null; paint.color = mix(0xFF14141C.toInt(), 0xFF3A1B0A.toInt(), pc); canvas.drawRoundRect(tr, corner, corner, paint)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(1.5f); paint.color = mix(0xFF2A2733.toInt(), 0xFFB5621F.toInt(), pc); canvas.drawRoundRect(tr, corner, corner, paint)
                val ox = kx(p)
                canvas.save(); path.reset(); path.addRoundRect(tr, corner, corner, Path.Direction.CW); canvas.clipPath(path)
                if (checked || pc > 0.05f) for (i in 0 until 8) {
                    val t = (tick + i / 8f) % 1f
                    val ex = ox + Math.sin(i * 2.3 + t * 6.0).toFloat() * r * 0.8f
                    val ey = cy - r * 0.2f - t * trackH * 0.9f
                    val a = (1f - t) * pc
                    paint.style = Paint.Style.FILL; paint.shader = null; paint.maskFilter = null
                    paint.color = mix(0xFFFFE39A.toInt(), 0xFFFF9A3C.toInt(), t); paint.alpha = (a * 255).toInt().coerceIn(0, 255)
                    canvas.drawCircle(ex, ey, (1f - t) * dp(2f) + dp(0.6f), paint); paint.alpha = 255
                }
                canvas.restore()
                glow(canvas, ox, cy, r * 1.2f, 0xFFFFAA3C.toInt(), pc * 0.9f)
                val rr = r * (1f + 0.03f * Math.sin(tick * 37.7).toFloat() * pc)
                paint.style = Paint.Style.FILL; paint.maskFilter = null
                paint.shader = RadialGradient(ox - rr * 0.2f, cy - rr * 0.25f, rr * 1.3f,
                    intArrayOf(mix(0xFF8B8FA8.toInt(), 0xFFFFFBE0.toInt(), pc), mix(0xFF4A4D63.toInt(), 0xFFFFC15A.toInt(), pc), mix(0xFF4A4D63.toInt(), 0xFFFF7A1A.toInt(), pc)),
                    floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
                canvas.drawCircle(ox, cy, rr, paint); paint.shader = null
                if (pc > 0.4f) drawGhost(canvas, ox, cy + dp(0.5f), rr * 1.05f, pc, Color.argb((pc * 235).toInt(), 255, 246, 223), Color.argb((pc * 200).toInt(), 90, 50, 20))
            }
            else -> {
                canvas.save()
                val sh = if (burst < 1f) Math.sin(burst * 38.0).toFloat() * (1f - burst) * dp(1.6f) else 0f
                canvas.translate(sh, 0f); canvas.rotate(sh * 0.9f, w / 2f, cy)
                paint.style = Paint.Style.FILL; paint.shader = null; paint.maskFilter = null
                if (pc > 0.02f) { paint.color = Color.argb((pc * 150).toInt(), 167, 139, 255); paint.maskFilter = BlurMaskFilter(dp(6f), BlurMaskFilter.Blur.NORMAL); canvas.drawRoundRect(tr, corner, corner, paint); paint.maskFilter = null }
                paint.color = mix(0xFF272038.toInt(), 0xFF7D5CFF.toInt(), pc); canvas.drawRoundRect(tr, corner, corner, paint)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(1.5f); paint.color = mix(0xFF352B4C.toInt(), 0xFF43308A.toInt(), pc); canvas.drawRoundRect(tr, corner, corner, paint)
                val gx = kx(p)
                drawGhost(canvas, gx, cy, r * 1.95f, pc, Color.WHITE, 0xFF1B2030.toInt())
                if (burst < 1f) for (i in 0 until 6) {
                    val ang = i * 1.0472f + 0.4f
                    val dist = burst * r * 2.4f
                    val a = ((1f - burst) * 255).toInt().coerceIn(0, 255)
                    val bx = gx + Math.cos(ang.toDouble()).toFloat() * dist; val by = cy + Math.sin(ang.toDouble()).toFloat() * dist * 0.45f - burst * dp(3f)
                    drawGhost(canvas, bx, by, dp(6.5f), 1f, Color.argb(a, 255, 255, 255), Color.argb(a, 27, 32, 48))
                }
                canvas.restore()
            }
        }
    }
}
