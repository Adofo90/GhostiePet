package com.ghostie.pet

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var s: SettingsStore
    private lateinit var content: LinearLayout
    private lateinit var subjectsField: EditText
    private lateinit var groupsField: EditText
    private lateinit var keyField: EditText
    private lateinit var logBox: LinearLayout
    private lateinit var activityBox: LinearLayout
    private val refreshers = mutableListOf<() -> Unit>()

    // Palette
    private val bg = Color.parseColor("#170E2B")
    private val card = Color.parseColor("#241640")
    private val cardStroke = Color.parseColor("#3A2763")
    private val field = Color.parseColor("#1B1033")
    private val textMain = Color.parseColor("#F3ECFF")
    private val textSub = Color.parseColor("#B9A8D9")
    private val accent = Color.parseColor("#A978E8")
    private val good = Color.parseColor("#7BE0A4")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        s = SettingsStore(this)
        build()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onPause() {
        saveFields()
        super.onPause()
    }

    private fun refresh() {
        refreshers.forEach { it() }
        renderLog()
        renderActivity()
    }

    private fun saveFields() {
        s.subjects = subjectsField.text.toString()
        s.watchedGroups = groupsField.text.toString()
        s.key = keyField.text.toString().trim()
    }

    // ---- small UI toolkit -----------------------------------------------------------------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun rounded(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        if (bold) tv.setTypeface(tv.typeface, Typeface.BOLD)
        return tv
    }

    private fun match() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

    private fun card(title: String, subtitle: String? = null): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = rounded(card, 18, cardStroke)
        c.setPadding(dp(16), dp(14), dp(16), dp(16))
        c.addView(label(title, 17f, textMain, true))
        if (subtitle != null) {
            val sub = label(subtitle, 13f, textSub)
            sub.setPadding(0, dp(2), 0, dp(8))
            c.addView(sub)
        }
        val lp = match()
        lp.topMargin = dp(12)
        content.addView(c, lp)
        return c
    }

    private fun button(text: String, filled: Boolean = true, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 14f
        b.stateListAnimator = null
        b.minHeight = dp(44)
        b.minimumHeight = dp(44)
        styleButton(b, filled)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun styleButton(b: Button, filled: Boolean) {
        b.setTextColor(if (filled) Color.WHITE else accent)
        b.background = if (filled) rounded(accent, 12) else rounded(Color.TRANSPARENT, 12, accent)
    }

    private fun buttonRow(parent: LinearLayout, vararg buttons: Button) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (b in buttons) {
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), dp(4), dp(3), dp(4))
            row.addView(b, lp)
        }
        parent.addView(row, match())
    }

    private fun switchRow(parent: LinearLayout, text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val sw = SwitchCompat(this)
        sw.text = text
        sw.setTextColor(textMain)
        sw.isChecked = checked
        sw.setPadding(0, dp(6), 0, dp(6))
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        parent.addView(sw, match())
    }

    private fun spinnerRow(parent: LinearLayout, title: String, options: List<String>, values: List<Int>, current: Int, onPick: (Int) -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(label(title, 15f, textMain), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        sp.setSelection(values.indexOf(current).coerceAtLeast(0))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                onPick(values[position])
            }
        }
        row.addView(sp, LinearLayout.LayoutParams(dp(140), LinearLayout.LayoutParams.WRAP_CONTENT))
        parent.addView(row, match())
    }

    private fun textField(hint: String, value: String, multiline: Boolean, lines: Int = 1, password: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(value)
        e.setTextColor(textMain)
        e.setHintTextColor(textSub)
        e.textSize = 13f
        e.background = rounded(field, 12, cardStroke)
        e.setPadding(dp(12), dp(10), dp(12), dp(10))
        var type = InputType.TYPE_CLASS_TEXT
        if (multiline) {
            type = type or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            e.minLines = lines
            e.gravity = Gravity.TOP or Gravity.START
        }
        if (password) type = type or InputType.TYPE_TEXT_VARIATION_PASSWORD
        e.inputType = type
        return e
    }

    private fun fieldLp(): LinearLayout.LayoutParams {
        val lp = match()
        lp.topMargin = dp(6)
        return lp
    }

    // ---- permissions ----------------------------------------------------------------------

    private fun hasNotificationPermission() =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun hasCalendar() = CalendarHelper.hasPermission(this)
    private fun ensureCalendar(): Boolean {
        if (hasCalendar()) return true
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR), 3)
        toast("Allow Calendar, then tap again")
        return false
    }

    private fun hasAccessibility(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.startsWith("$packageName/") }
    }

    private fun hasContactsAndPhone() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED

    private fun hasListener() = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun askFileAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 2
            )
        }
    }

    private fun permRow(parent: LinearLayout, title: String, hint: String, isOn: () -> Boolean, request: () -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(6), 0, dp(6))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(label(title, 15f, textMain))
        col.addView(label(hint, 12f, textSub))
        val b = button("Allow") { request() }
        row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(b, LinearLayout.LayoutParams(dp(92), dp(40)))
        parent.addView(row, match())
        refreshers.add {
            if (isOn()) {
                b.text = "✓ On"
                b.setTextColor(good)
                b.background = rounded(Color.TRANSPARENT, 12, good)
            } else {
                b.text = "Allow"
                styleButton(b, true)
            }
        }
    }

    // ---- screen ---------------------------------------------------------------------------

    private fun petIntent(action: String? = null): Intent {
        val i = Intent(this, PetOverlayService::class.java)
        if (action != null) i.action = action
        return i
    }

    private fun startPet() {
        saveFields()
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            toast("Allow \"Display over other apps\", then tap Start again")
        } else {
            s.enabled = true
            startForegroundService(petIntent())
            toast("Ghostie is ready 👻")
        }
    }

    private fun pauseFor(minutes: Long, label: String) {
        s.quietUntil = System.currentTimeMillis() + minutes * 60_000L
        toast("Quiet for $label")
    }

    private fun build() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        scroll.isFillViewport = true
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(16), dp(16), dp(24))
        scroll.addView(content)
        setContentView(scroll)
        // Android 15 draws apps edge-to-edge, so keep content clear of the status/navigation bars.
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }

        // Header
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val ghost = ImageView(this)
        ghost.setImageResource(R.drawable.ghost_pet)
        ghost.scaleType = ImageView.ScaleType.FIT_CENTER
        header.addView(ghost, LinearLayout.LayoutParams(dp(64), dp(64)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(14), 0, 0, 0)
        titles.addView(label("Ghostie", 28f, textMain, true))
        titles.addView(label("Your tiny floating study buddy", 14f, textSub))
        header.addView(titles)
        content.addView(header, match())

        // Pet controls
        val pet = card("Pet")
        buttonRow(pet, button("Start") { startPet() }, button("Stop", false) { stopService(petIntent()); toast("Ghostie stopped") })
        buttonRow(
            pet,
            button("Summon now", false) { startForegroundService(petIntent(PetOverlayService.ACTION_SUMMON)) },
            button("Bring on screen", false) {
                s.resetPosition()
                startForegroundService(petIntent(PetOverlayService.ACTION_RESET))
            }
        )

        // Upcoming submissions (filled by renderLog)
        val upcoming = card("Upcoming deadlines", "Submissions and event registrations Ghostie spotted in your groups. Each one gets a calendar event with alerts (the day before, and optionally 2 days before and the morning of).")
        logBox = LinearLayout(this)
        logBox.orientation = LinearLayout.VERTICAL
        upcoming.addView(logBox, match())

        // Setup checklist
        val setup = card("Setup", "Switch on what you want to use. Green means ready.")
        permRow(setup, "Display over other apps", "Shows the floating ghost", { Settings.canDrawOverlays(this) }) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        permRow(setup, "Notifications", "Ghostie's own alerts", { hasNotificationPermission() }) {
            if (Build.VERSION.SDK_INT >= 33) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        permRow(setup, "File access", "To organize WhatsApp documents", { DocOrganizer.hasAccess(this) }) { askFileAccess() }
        permRow(setup, "Calendar", "To add events and reminders", { hasCalendar() }) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR), 3)
        }
        permRow(setup, "Contacts & calls", "So \"call Mom\" works (dials instantly)", { hasContactsAndPhone() }) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE), 4)
        }
        permRow(setup, "Notification access", "Reads new messages when WhatsApp is closed", { hasListener() }) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        permRow(setup, "Read open chats", "Catches messages while you have the group open", { hasAccessibility() }) {
            AlertDialog.Builder(this)
                .setTitle("Read open chats")
                .setMessage(
                    "Ghostie will only look at WhatsApp, and only act when one of your watched groups is on screen. Nothing leaves your phone.\n\n" +
                        "In the next screen open \"Installed apps\" (or \"Downloaded apps\"), choose \"Ghostie chat reader\" and switch it on.\n\n" +
                        "If Android says \"Restricted setting\": phone Settings > Apps > Ghostie > ⋮ (top right) > \"Allow restricted settings\", then try again."
                )
                .setPositiveButton("Continue") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // Group reminders
        val groups = card(
            "Group reminders",
            "Ghostie watches the groups you list - through notifications when WhatsApp is closed, and by reading the screen when the group is open. A submission or registration deadline becomes a calendar event with reminders."
        )
        switchRow(groups, "Watch groups", s.watchEnabled) { s.watchEnabled = it }
        switchRow(groups, "Also warn 2 days before", s.remind2d) { s.remind2d = it }
        switchRow(groups, "Nudge on the morning it is due", s.remindMorning) { s.remindMorning = it }
        val status = label("", 12f, textSub)
        status.setPadding(0, dp(4), 0, dp(4))
        groups.addView(status, match())
        refreshers.add {
            fun ago(k: String): String {
                val tm = ActivityLog.lastTime(this, k) ?: return "never"
                val mins = (System.currentTimeMillis() - tm) / 60_000L
                return if (mins < 1) "just now" else if (mins < 60) "$mins min ago" else if (mins < 1440) "${mins / 60} h ago" else "${mins / 1440} d ago"
            }
            status.text = "Last WhatsApp notification heard: ${ago("Notification")}\nLast open chat read: ${ago("Open chat")}"
        }
        groupsField = textField("Group names, one per line (e.g. CSE 3A)", s.watchedGroups, true, 3)
        groups.addView(groupsField, fieldLp())
        groups.addView(label("Only messages that arrive while this is on can be seen. Keep Ghostie's battery setting on \"Unrestricted\".", 12f, textSub).apply { setPadding(0, dp(6), 0, dp(4)) })
        val testField = textField("Try a message, e.g. Last date to register for Hackathon is 12 Nov", "", false)
        groups.addView(testField, fieldLp())
        buttonRow(groups, button("Test message", false) {
            val text = testField.text.toString()
            val sub = SubmissionParser.parse(text, LocalDate.now())
            val msg = if (sub == null) {
                "No submission date found in that message."
            } else {
                val now = LocalDateTime.now()
                val rs = SubmissionParser.reminderTimes(sub, now, s.remind2d, s.remindMorning)
                val fmt = DateTimeFormatter.ofPattern("EEE d MMM, h:mm a", Locale.ENGLISH)
                val kind = if (sub.kind == DeadlineKind.REGISTRATION) "Registration closes" else "Submission due"
                val alerts = if (rs.times.isEmpty()) "(no future alerts - it is due very soon)" else rs.times.joinToString("\n") { "• " + it.format(fmt) }
                "$kind: ${SubmissionParser.eventStart(sub).format(fmt)}\nAlerts:\n$alerts"
            }
            AlertDialog.Builder(this).setTitle("Ghostie would...").setMessage(msg).setPositiveButton("OK", null).show()
        })

        // Catch-up (works even when notifications are missed)
        val catchUp = card(
            "Manual catch-up (backup)",
            "Only needed for muted groups you never open, or if you skipped \"Read open chats\". To catch up: in the group tap ⋮ > More > Export chat > Without media, then choose \"Add Ghostie reminders\". You can also share a single message the same way."
        )
        buttonRow(catchUp, button("Scan a chat file…", false) {
            if (!ensureCalendar()) return@button
            val pick = Intent(Intent.ACTION_OPEN_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType("*/*")
                .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/plain", "application/zip"))
            startActivityForResult(pick, 77)
        })

        // Documents
        val docs = card(
            "Documents",
            "Copies WhatsApp documents into Documents/Ghostie/<Subject>, sorted by file name. Originals stay put. You can also tell the ghost: \"organize documents\"."
        )
        subjectsField = textField("Subject: keyword, keyword", s.subjects, true, 6)
        subjectsField.textSize = 12f
        docs.addView(subjectsField, fieldLp())
        docs.addView(label("One subject per line. Start a line with * for a fallback category. Clear everything to restore the defaults.", 12f, textSub).apply { setPadding(0, dp(6), 0, dp(4)) })
        buttonRow(docs, button("Organize now") {
            saveFields()
            if (!DocOrganizer.hasAccess(this)) {
                askFileAccess()
            } else {
                toast("Sorting...")
                Thread {
                    val text = try {
                        DocOrganizer.summary(DocOrganizer.organize(this))
                    } catch (e: Exception) {
                        "Something went wrong while organizing."
                    }
                    runOnUiThread { AlertDialog.Builder(this).setTitle("Documents").setMessage(text).setPositiveButton("OK", null).show() }
                }.start()
            }
        })

        docs.addView(label("Smart sorting also uses which chat a file came from and what is written inside PDFs, Word and PowerPoint files.", 12f, textSub).apply { setPadding(0, dp(2), 0, dp(4)) })
        switchRow(docs, "Sort new documents automatically", s.autoOrganize) { s.autoOrganize = it }

        // Companion settings
        val pref = card("Companion")
        switchRow(pref, "Enable pet", s.enabled) { s.enabled = it }
        switchRow(pref, "Check-ins", s.checkins) { s.checkins = it }
        switchRow(pref, "Always on top", s.alwaysTop) { s.alwaysTop = it }
        switchRow(pref, "Sound", s.sound) { s.sound = it }
        switchRow(pref, "Sleep at night (11 pm - 6 am)", s.sleepEnabled) { s.sleepEnabled = it }
        val sizeLabel = label("Ghost size: ${s.petDp}", 15f, textMain)
        sizeLabel.setPadding(0, dp(8), 0, 0)
        pref.addView(sizeLabel, match())
        val bar = SeekBar(this)
        bar.max = 144
        bar.progress = s.petDp - 56
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                sizeLabel.text = "Ghost size: ${value + 56}"
                if (fromUser) s.petDp = value + 56
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        pref.addView(bar, match())
        pref.addView(label("The ghost also hides during calls, in landscape and in Do Not Disturb.", 12f, textSub).apply { setPadding(0, dp(2), 0, dp(4)) })
        spinnerRow(pref, "Visit every", listOf("5 min", "10 min", "15 min", "30 min", "1 hour"), listOf(5, 10, 15, 30, 60), s.visitMinutes) { s.visitMinutes = it }
        spinnerRow(pref, "Water reminder", listOf("15 min", "30 min", "1 hour", "2 hours"), listOf(15, 30, 60, 120), s.waterMinutes) { s.waterMinutes = it }

        // Quiet time
        val quiet = card("Quiet time", "Pause visits and reminders from the ghost.")
        buttonRow(quiet, button("30 min", false) { pauseFor(30, "30 minutes") }, button("1 hour", false) { pauseFor(60, "1 hour") })
        buttonRow(
            quiet,
            button("Until tomorrow", false) {
                s.quietUntil = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                toast("Quiet until tomorrow")
            },
            button("Resume") {
                s.quietUntil = 0L
                toast("Ghostie resumed")
            }
        )

        // Activity log
        val act = card("Activity log", "What Ghostie has seen and done lately. Useful if a reminder did not appear.")
        activityBox = LinearLayout(this)
        activityBox.orientation = LinearLayout.VERTICAL
        act.addView(activityBox, match())
        buttonRow(
            act,
            button("Refresh", false) { renderActivity() },
            button("Copy", false) {
                val text = ActivityLog.read(this).take(40).joinToString("\n") { it.text() }
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Ghostie log", text))
                toast("Copied")
            },
            button("Clear", false) { ActivityLog.clear(this); renderActivity() }
        )

        // AI
        val ai = card("AI chat (optional)", "Needs your own OpenAI key. Without it, Ghostie still understands the commands above.")
        switchRow(ai, "Use AI for free chat", s.ai) { s.ai = it }
        keyField = textField("OpenAI API key", s.key, false, 1, true)
        ai.addView(keyField, fieldLp())
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != 77 || resultCode != RESULT_OK || uri == null) return
        toast("Scanning...")
        Thread {
            var group = "Chat"
            val msg = try {
                val (g, text) = ChatImporter.read(this, uri)
                group = g
                ChatImporter.describe(g, ChatImporter.importText(this, g, text))
            } catch (e: Exception) {
                "I couldn't read that file."
            }
            runOnUiThread {
                AlertDialog.Builder(this).setTitle(group).setMessage(msg).setPositiveButton("OK", null).show()
                renderLog()
            }
        }.start()
    }

    private fun renderActivity() {
        if (!::activityBox.isInitialized) return
        activityBox.removeAllViews()
        val lines = ActivityLog.read(this).take(15)
        if (lines.isEmpty()) {
            activityBox.addView(label("Nothing yet.", 13f, textSub))
            return
        }
        for (l in lines) activityBox.addView(label(l.text(), 12f, textSub).apply { setPadding(0, dp(2), 0, dp(2)) }, match())
    }

    private fun renderLog() {
        if (!::logBox.isInitialized) return
        logBox.removeAllViews()
        val items = ReminderLog.upcoming(s.logs()).take(10)
        if (items.isEmpty()) {
            logBox.addView(label("Nothing due. When someone posts a submission or registration deadline in a watched group, it appears here.", 13f, textSub))
            return
        }
        val warn = Color.parseColor("#FF8A7A")
        for (e in items) {
            val days = ReminderLog.daysLeft(e)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = rounded(field, 12, if (days <= 1) warn else cardStroke)
            row.setPadding(dp(12), dp(8), dp(8), dp(8))
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.addView(label((if (ReminderLog.isRegistration(e)) "📝 Registration: " else "📌 ") + ReminderLog.label(e), 14f, textMain, true))
            col.addView(label(ReminderLog.dueLabel(e), 12f, if (days <= 1) warn else accent))
            col.addView(label("from " + e.group, 11f, textSub))
            row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val remove = button("Done", false) {
                CalendarHelper.delete(this, e.eventId)
                s.removeLog(e.eventId)
                renderLog()
            }
            remove.textSize = 12f
            remove.minHeight = dp(34)
            remove.minimumHeight = dp(34)
            val snooze = button("Snooze", false) {
                toast(ReminderMaker.snooze(this, e, 3))
            }
            snooze.textSize = 12f
            snooze.minHeight = dp(34)
            snooze.minimumHeight = dp(34)
            val btns = LinearLayout(this)
            btns.orientation = LinearLayout.VERTICAL
            btns.addView(snooze, LinearLayout.LayoutParams(dp(78), dp(36)))
            btns.addView(remove, LinearLayout.LayoutParams(dp(78), dp(36)).apply { topMargin = dp(4) })
            row.addView(btns)
            val lp = match()
            lp.bottomMargin = dp(6)
            logBox.addView(row, lp)
        }
    }
}
