package com.ghostie.pet

import java.time.LocalTime
import java.time.format.DateTimeFormatter

/**
 * The conversation since you started chatting, kept in the phone's memory only (never written to storage until you
 * ask for it with "export"). It includes private/personal turns, marked as such, so a test run can be reviewed.
 * Cleared after an export and whenever Ghostie stops. Pure Kotlin (JVM tested).
 */
object SessionLog {
    private val lines = ArrayList<String>()
    private val fmt = DateTimeFormatter.ofPattern("HH:mm:ss")

    fun add(who: String, text: String, tag: String = "", at: LocalTime = LocalTime.now()) {
        val t = text.trim()
        if (t.isEmpty()) return
        lines.add("[" + fmt.format(at) + "] " + who + (if (tag.isNotEmpty()) " (" + tag + ")" else "") + ": " + t.replace("\n", "\n    "))
        while (lines.size > 3000) lines.removeAt(0)
    }

    val size get() = lines.size
    fun clear() = lines.clear()

    fun render(): String = "Ghostie chat export\n" +
        "Tags: local = answered on the phone; private = personal/sensitive talk, answered on the phone only, never sent to AI; AI = sent to your AI; command = a Ghostie command.\n" +
        "-----\n" + lines.joinToString("\n") + "\n"

    /** "export", "export chat", "export the conversation", "export this session"... */
    fun isExportRequest(raw: String) =
        Regex("^(?:ghostie[, ]*)?(?:please\\s+)?(?:export|extract|share)(?:\\s+(?:the|this|my|our))?(?:\\s+(?:chat|conversation|session|messages?|talk))?(?:\\s+(?:log|history|text))?\\s*[.!]*$", RegexOption.IGNORE_CASE).matches(raw.trim())
}
