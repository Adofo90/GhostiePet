package com.ghostie.pet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.LocalDateTime

/** Runs about every 30 s from the overlay service: silences the phone during class, asks about attendance, nudges about exams. */
object StudentTick {
    private var lastRun = 0L
    private const val CH = "ghostie_student"

    fun tick(ctx: Context) {
        val nowMs = System.currentTimeMillis()
        if (nowMs - lastRun < 30_000L) return
        lastRun = nowMs
        val st = Student.load(ctx)
        val now = LocalDateTime.now()
        var dirty = false

        // Do Not Disturb during class
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.isNotificationPolicyAccessGranted) {
                val inClass = st.dnd && Student.slotAt(st, now) != null
                val cur = nm.currentInterruptionFilter
                if (inClass && !st.dndWeSet && cur == NotificationManager.INTERRUPTION_FILTER_ALL) {
                    st.dndPrev = cur; st.dndWeSet = true; dirty = true
                    nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                } else if (!inClass && st.dndWeSet) {
                    // only undo our own change
                    if (cur == NotificationManager.INTERRUPTION_FILTER_PRIORITY) nm.setInterruptionFilter(st.dndPrev)
                    st.dndWeSet = false; dirty = true
                }
            }
        } catch (e: Exception) { }

        // "Did you attend?" after each class slot
        if (st.autoAsk) {
            for ((i, p, subject) in Student.finishedUnasked(st, now)) {
                st.asked.add("${now.toLocalDate()}|$i"); dirty = true
                // a slot with two subjects ("MAT/ESC") can't be answered from a notification: it waits in the app, where you pick which one
                if (subject.contains('/')) continue
                ask(ctx, subject, "${now.toLocalDate()}|$i", p.start + "-" + p.end)
            }
        }

        // heads-up before a class where attendance is at risk
        if (SettingsStore(ctx).attWarn) {
            val nowT = now.toLocalTime()
            val todaySched = Student.dayFor(st, now.toLocalDate())
            todaySched.periods.forEachIndexed { i, per ->
                val start = Student.parseTime(per.start) ?: return@forEachIndexed
                val mins = java.time.Duration.between(nowT, start).toMinutes()
                val subject = Student.label(todaySched.cell(i))
                if (subject.isBlank() || mins !in 1..15) return@forEachIndexed
                val key = "warn|${now.toLocalDate()}|$i"
                if (key in st.asked) return@forEachIndexed
                st.asked.add(key); dirty = true
                WeeklySummary.warnLine(st, subject)?.let { post(ctx, "⚠️ $subject in $mins min", it, 7000 + i) }
            }
        }

        // daily study nudge at 8 am
        val today = now.toLocalDate().toString()
        if (st.nudgeDay != today && now.hour >= 8) {
            st.nudgeDay = today; dirty = true
            Student.studyToday(st, now.toLocalDate())?.let { post(ctx, "Study plan", it, 5001) }
        }
        if (dirty) Student.save(ctx)
        WeeklySummary.tick(ctx, now)
        try {
            val s3 = SettingsStore(ctx)
            val todayKey = now.toLocalDate().toString()
            val sentNow = s3.studyBriefSent.split(",").filter { it.startsWith("$todayKey|") }.toMutableList()
            for (t in s3.studyTimes.split(",").filter { it.isNotBlank() }) {
                val key = "$todayKey|$t"
                if (key in sentNow || !StudyBrief.due(t, now.toLocalTime())) continue
                sentNow.add(key); s3.studyBriefSent = sentNow.joinToString(",")
                val lines = StudyBrief.tomorrowLines(s3.logs(), st.exams, ProjectStore.load(ctx).tasks, now.toLocalDate())
                if (lines.isNotEmpty()) post(ctx, "📚 Study time - due tomorrow", lines.joinToString("\n"), 5004)
            }
        } catch (e: Exception) { }
        try {
            val s2 = SettingsStore(ctx)
            if (s2.placementDaily && now.hour >= 19 && s2.placementSent != now.toLocalDate().toString()) {
                s2.placementSent = now.toLocalDate().toString()
                val q = PlacementBank.ofTheDay(PlacementStore.own(ctx), now.toLocalDate())
                post(ctx, "🎯 Question of the day", q.text + "\n" + q.options.mapIndexed { i, o -> "${'A' + i}) $o" }.joinToString("\n") + "\n(Open Ghostie > Placement prep for the answer)", 5003)
            }
        } catch (e: Exception) { }
    }

    private fun channel(ctx: Context): NotificationManager {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Ghostie student", NotificationManager.IMPORTANCE_DEFAULT))
        return nm
    }

    fun post(ctx: Context, title: String, text: String, id: Int) {
        try {
            val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            channel(ctx).notify(id, Notification.Builder(ctx, CH).setSmallIcon(R.drawable.ghost_pet).setContentTitle(title)
                .setContentText(text).setStyle(Notification.BigTextStyle().bigText(text)).setContentIntent(open).addAction(Notifier.summonAction(ctx)).setAutoCancel(true).build())
        } catch (e: Exception) { }
    }

    private fun ask(ctx: Context, subject: String, slot: String, time: String) {
        try {
            val nid = 6000 + (slot.hashCode() and 0xFFF)
            fun act(a: String, code: Int) = PendingIntent.getBroadcast(
                ctx, nid * 4 + code,
                Intent(ctx, AttendanceReceiver::class.java).setAction(a).putExtra("subject", subject).putExtra("nid", nid).putExtra("slot", slot),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(ctx, CH).setSmallIcon(R.drawable.ghost_pet)
                .setContentTitle("Did you attend $subject?").setContentText("Class $time is over")
                .setContentIntent(open).setAutoCancel(true)
                .addAction(Notification.Action.Builder(null, "Present", act(AttendanceReceiver.PRESENT, 0)).build())
                .addAction(Notification.Action.Builder(null, "Absent", act(AttendanceReceiver.ABSENT, 1)).build())
                .addAction(Notification.Action.Builder(null, "No class", act(AttendanceReceiver.NONE, 2)).build())
                .build()
            channel(ctx).notify(nid, n)
        } catch (e: Exception) { }
    }
}

class AttendanceReceiver : BroadcastReceiver() {
    companion object {
        const val PRESENT = "com.ghostie.pet.ATT_PRESENT"
        const val ABSENT = "com.ghostie.pet.ATT_ABSENT"
        const val NONE = "com.ghostie.pet.ATT_NONE"
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        val subject = intent.getStringExtra("subject") ?: return
        val st = Student.load(ctx)
        val slot = intent.getStringExtra("slot")
        val result = when (intent.action) { PRESENT -> 1; ABSENT -> 0; else -> -1 }
        if (slot != null) Student.answer(st, slot, subject, result)   // counts once and remembers it was answered
        else if (result >= 0) Student.mark(st, subject, result == 1)
        Student.save(ctx)
        try { ctx.getSystemService(NotificationManager::class.java).cancel(intent.getIntExtra("nid", 0)) } catch (e: Exception) { }
    }
}
