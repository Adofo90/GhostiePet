package com.ghostie.pet

/**
 * Turns the text found in a photo of a printed timetable (each piece with its position) into Ghostie's timetable.
 * Handles the two usual layouts: days down the side with time slots across the top, or the other way round.
 * Pure Kotlin (JVM tested); the photo reading itself is in [OcrReader].
 */
object TimetableOcr {
    data class Box(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int) {
        val cx get() = (left + right) / 2
        val cy get() = (top + bottom) / 2
        val h get() = (bottom - top).coerceAtLeast(1)
    }
    /** A Saturday that only some weeks have ("2nd Saturday", "2nd & 4th Saturday"), with its own timetable row. */
    class Sat(val ordinals: Set<Int>, val cells: Map<Int, String>)
    class Parsed(val periods: List<Pair<String, String>>, val cells: Map<Pair<Int, Int>, String>, val layout: String, val sats: List<Sat> = emptyList())

    private val ordinalWord = Regex("([1-5])\\s*(?:st|nd|rd|th)\\b", RegexOption.IGNORE_CASE)
    private val ordinalOnly = Regex("^[\\s1-5stndrh&,and]+$", RegexOption.IGNORE_CASE)

    /** "2nd Saturday" -> {2}; "2nd & 4th Sat" -> {2,4}; plain "Saturday" -> empty. */
    fun satOrdinals(text: String): Set<Int> {
        val t = text.trim()
        if (!Regex("sat", RegexOption.IGNORE_CASE).containsMatchIn(t)) return emptySet()
        return ordinalWord.findAll(t).map { it.groupValues[1].toInt() }.toSet()
    }
    private fun rowLabel(text: String): Boolean = dayIndex(text) != null || satOrdinals(text).isNotEmpty()

    /** Joins an ordinal box ("2nd") with the "Saturday" box beside it when the photo split them. */
    private fun joinSatLabels(boxes: List<Box>): List<Box> {
        val out = ArrayList<Box>(); val skip = HashSet<Box>()
        for (r in rows(boxes)) for ((i, b) in r.withIndex()) {
            if (b in skip) continue
            val n = r.getOrNull(i + 1)
            if (n != null && ordinalWord.containsMatchIn(b.text) && !b.text.contains("sat", true) && ordinalOnly.matches(b.text.trim()) && dayIndex(n.text) == 5 && n.left - b.right < b.h * 3) {
                skip.add(n); out.add(Box(b.text.trim() + " " + n.text.trim(), b.left, minOf(b.top, n.top), n.right, maxOf(b.bottom, n.bottom)))
            }
        }
        val consumed = HashSet<Box>()
        for (m in out) boxes.filter { it.left >= m.left && it.right <= m.right && it.top >= m.top && it.bottom <= m.bottom && it.text.length < m.text.length }.forEach { consumed.add(it) }
        return boxes.filter { it !in consumed } + out
    }

    private val days = listOf("mon", "tue", "wed", "thu", "fri", "sat")
    private val timeRange = Regex("(\\d{1,2})\\s*[:.]\\s*(\\d{2})\\s*(am|pm)?\\s*(?:-|–|—|to)\\s*(\\d{1,2})\\s*[:.]\\s*(\\d{2})\\s*(am|pm)?", RegexOption.IGNORE_CASE)
    private val hourRange = Regex("^\\s*(\\d{1,2})\\s*(?:-|–|—|to)\\s*(\\d{1,2})\\s*$", RegexOption.IGNORE_CASE)
    private val emptyCell = Regex("^(?:[-–—_.\\s]*|lunch(?: break)?|break|recess|free|nil|tea break|interval)$", RegexOption.IGNORE_CASE)

    fun dayIndex(text: String): Int? {
        val t = text.trim().lowercase().trimEnd('.', ':')
        if (t.length < 3) return null
        return days.indexOfFirst { t.startsWith(it) && (t.length == 3 || "monday tuesday wednesday thursday friday saturday".split(' ').any { f -> f == t } || t.length <= 4) }.takeIf { it >= 0 }
    }

    private fun hh(h: Int, m: Int, ap: String?): String {
        var hour = h
        if (ap != null && ap.equals("pm", true) && hour < 12) hour += 12
        else if (ap != null && ap.equals("am", true) && hour == 12) hour = 0
        else if (ap == null && hour in 1..6) hour += 12   // "1:00" in a college day means 13:00
        return "%02d:%02d".format(hour, m)
    }

    /** "9:00-10:00" / "9.00 - 10.00" / "1:00-2:00 pm" -> ("09:00", "10:00"). */
    fun parseRange(text: String): Pair<String, String>? {
        timeRange.find(text)?.let { m ->
            val g = m.groupValues
            val endAp = g[6].ifEmpty { null }
            val a = hh(g[1].toInt(), g[2].toInt(), g[3].ifEmpty { null } ?: if (endAp == "pm" && g[1].toInt() in 7..11) "am" else endAp)
            val b = hh(g[4].toInt(), g[5].toInt(), endAp)
            return a to b
        }
        hourRange.find(text)?.let { m -> return hh(m.groupValues[1].toInt(), 0, null) to hh(m.groupValues[2].toInt(), 0, null) }
        return null
    }

    private class Band(val key: Box, val boxes: MutableList<Box> = mutableListOf())

    private fun medianH(boxes: List<Box>) = boxes.map { it.h }.sorted().let { if (it.isEmpty()) 20 else it[it.size / 2] }

    /** Groups boxes into visual rows. */
    private fun rows(boxes: List<Box>): List<List<Box>> {
        val tol = medianH(boxes) * 0.6
        val out = ArrayList<MutableList<Box>>()
        for (b in boxes.sortedBy { it.cy }) {
            val r = out.lastOrNull()
            if (r != null && Math.abs(b.cy - r.map { it.cy }.average()) <= tol) r.add(b) else out.add(mutableListOf(b))
        }
        return out.map { it.sortedBy { b -> b.left } }
    }

    fun parse(boxes: List<Box>): Parsed? {
        if (boxes.size < 6) return null
        return parseJoined(joinSatLabels(boxes))
    }

    private fun parseJoined(boxes: List<Box>): Parsed? {
        val rs = rows(boxes)
        // Layout A: a row with several time ranges (periods across the top), days down the left
        val headA = rs.firstOrNull { r -> r.count { parseRange(it.text) != null } >= 3 }
        // Layout B: a row with several day names (days across the top), time ranges down the left
        val headB = rs.firstOrNull { r -> r.count { dayIndex(it.text) != null } >= 3 }
        return when {
            headA != null && (headB == null || rs.indexOf(headA) <= rs.indexOf(headB)) -> layoutA(boxes, headA)
            headB != null -> layoutB(boxes, headB)
            else -> null
        }
    }

    private fun assignToColumns(band: List<Box>, cols: List<Box>, skipLeft: Int): Map<Int, String> {
        val per = HashMap<Int, MutableList<Box>>()
        for (b in band) {
            if (b.cx < skipLeft) continue
            val ci = cols.indices.minByOrNull { Math.abs(cols[it].cx - b.cx) } ?: continue
            val spacing = if (cols.size > 1) cols.zipWithNext { a, c -> Math.abs(c.cx - a.cx) }.sorted().let { it[it.size / 2] } else 1000
            if (Math.abs(cols[ci].cx - b.cx) <= spacing * 0.6) per.getOrPut(ci) { mutableListOf() }.add(b)
        }
        return per.mapValues { e -> e.value.sortedWith(compareBy({ it.cy / 8 }, { it.left })).joinToString(" ") { it.text.trim() }.replace(Regex("\\s+"), " ").trim() }
    }

    private fun layoutA(all: List<Box>, head: List<Box>): Parsed? {
        val cols = head.filter { parseRange(it.text) != null }
        val periods = cols.map { parseRange(it.text)!! }
        val dayBoxes = all.filter { it.top > head.maxOf { h -> h.bottom } - 2 && rowLabel(it.text) }.sortedBy { it.cy }
            .filter { b -> b.cx < cols.first().left }
        if (dayBoxes.isEmpty()) return null
        val cells = HashMap<Pair<Int, Int>, String>()
        val sats = ArrayList<Sat>()
        val skipLeft = cols.first().left - (cols.first().right - cols.first().left) / 2
        for ((i, d) in dayBoxes.withIndex()) {
            val ords = satOrdinals(d.text)
            val day = dayIndex(d.text) ?: 5
            val from = if (i == 0) d.top - d.h else (dayBoxes[i - 1].cy + d.cy) / 2
            val to = if (i == dayBoxes.size - 1) d.bottom + d.h * 3 else (d.cy + dayBoxes[i + 1].cy) / 2
            val band = all.filter { it.cy in from..to && it !in dayBoxes }
            val found = assignToColumns(band, cols, skipLeft).filter { !emptyCell.matches(it.value) }
            if (ords.isNotEmpty()) { if (found.isNotEmpty() && sats.none { it.ordinals == ords }) sats.add(Sat(ords, found)) }
            else for ((ci, text) in found) cells[day to ci] = text
        }
        return if (cells.isEmpty() && sats.isEmpty()) null else Parsed(periods, cells, "days down the side", sats)
    }

    private fun layoutB(all: List<Box>, head: List<Box>): Parsed? {
        val cols = head.filter { dayIndex(it.text) != null }
        val dayOf = cols.map { dayIndex(it.text)!! }
        val timeBoxes = all.filter { it.top > head.maxOf { h -> h.bottom } - 2 && it.cx < cols.first().left && parseRange(it.text) != null }.sortedBy { it.cy }
        if (timeBoxes.isEmpty()) return null
        val periods = timeBoxes.map { parseRange(it.text)!! }
        val cells = HashMap<Pair<Int, Int>, String>()
        val skipLeft = cols.first().left - (cols.first().right - cols.first().left) / 2
        for ((i, tb) in timeBoxes.withIndex()) {
            val from = if (i == 0) tb.top - tb.h else (timeBoxes[i - 1].cy + tb.cy) / 2
            val to = if (i == timeBoxes.size - 1) tb.bottom + tb.h * 3 else (tb.cy + timeBoxes[i + 1].cy) / 2
            val band = all.filter { it.cy in from..to && it !in timeBoxes }
            for ((ci, text) in assignToColumns(band, cols, skipLeft)) if (!emptyCell.matches(text)) cells[dayOf[ci] to i] = text
        }
        return if (cells.isEmpty()) null else Parsed(periods, cells, "days across the top")
    }

    /** Readable preview for the confirmation dialog. */
    fun preview(p: Parsed): String {
        val names = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
        return "Layout: ${p.layout}\nPeriods: " + p.periods.joinToString(", ") { it.first + "-" + it.second } + "\n\n" +
            (0..5).joinToString("\n") { d ->
                val row = p.periods.indices.mapNotNull { i -> p.cells[d to i]?.let { "${p.periods[i].first} $it" } }
                if (row.isEmpty()) "" else names[d] + ": " + row.joinToString(", ")
            }.lines().filter { it.isNotBlank() }.joinToString("\n") +
            p.sats.joinToString("") { sat ->
                "\n" + satName(sat.ordinals) + ": " + p.periods.indices.mapNotNull { i -> sat.cells[i]?.let { "${p.periods[i].first} $it" } }.joinToString(", ")
            }
    }

    fun satName(o: Set<Int>) = o.sorted().joinToString(" & ") { "$it" + when (it) { 1 -> "st"; 2 -> "nd"; 3 -> "rd"; else -> "th" } } + " Saturday"

    /** Replaces the student's timetable with the parsed one. */
    fun apply(st: Student.State, p: Parsed) {
        st.periods = p.periods.map { Student.Period(it.first, it.second) }.toMutableList()
        st.cells = p.cells.entries.associate { "${it.key.first},${it.key.second}" to it.value }.toMutableMap()
        if (p.sats.isNotEmpty()) st.satTables = p.sats.map { sat ->
            Student.SatTable(satName(sat.ordinals), sat.ordinals.toMutableSet(), "", p.periods.map { Student.Period(it.first, it.second) }.toMutableList(),
                sat.cells.entries.associate { it.key.toString() to it.value }.toMutableMap())
        }.toMutableList()
    }
}
