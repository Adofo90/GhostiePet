package com.ghostie.pet

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import java.util.Locale
import kotlin.math.PI
import kotlin.math.sin

/** Synthesised squeaks and chirps (no audio files needed). Pure Kotlin so it can be tested. */
object Chirp {
    const val RATE = 22050

    /** A tone gliding from [f0] to [f1] Hz over [ms], with a soft fade in and out. [vibrato] adds a wobble. */
    fun sweep(f0: Double, f1: Double, ms: Int, vol: Double = 0.5, vibrato: Double = 0.0): ShortArray {
        val n = RATE * ms / 1000
        val out = ShortArray(n)
        var phase = 0.0
        for (i in 0 until n) {
            val p = i.toDouble() / n
            var f = f0 + (f1 - f0) * p
            if (vibrato > 0.0) f += sin(2 * PI * 22 * i / RATE) * vibrato
            phase += 2 * PI * f / RATE
            val env = minOf(1.0, p * 12) * minOf(1.0, (1 - p) * 8)
            out[i] = (sin(phase) * env * vol * Short.MAX_VALUE).toInt().toShort()
        }
        return out
    }

    fun silence(ms: Int) = ShortArray(RATE * ms / 1000)

    fun join(vararg parts: ShortArray): ShortArray {
        val out = ShortArray(parts.sumOf { it.size })
        var at = 0
        for (p in parts) { p.copyInto(out, at); at += p.size }
        return out
    }

    fun effect(kind: String): ShortArray = when (kind) {
        "pop" -> sweep(500.0, 1100.0, 90)
        "squeak" -> join(sweep(1500.0, 800.0, 130), silence(30), sweep(900.0, 1400.0, 90))
        "giggle" -> join(sweep(700.0, 1100.0, 70), silence(40), sweep(750.0, 1200.0, 70), silence(40), sweep(800.0, 1300.0, 90))
        "hello" -> join(sweep(700.0, 900.0, 90), silence(30), sweep(900.0, 1300.0, 130))
        "purr" -> sweep(260.0, 240.0, 650, 0.45, 18.0)
        else -> sweep(600.0, 900.0, 80)
    }
}

/** Ghostie's voice: spoken replies (the phone's text-to-speech, pitched up) and little sound effects. */
class GhostVoice(private val ctx: Context, private val s: SettingsStore) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private val cache = HashMap<String, ShortArray>()

    init {
        try {
            tts = TextToSpeech(ctx.applicationContext) { status ->
                val t = tts
                if (status == TextToSpeech.SUCCESS && t != null) {
                    val r = t.setLanguage(Locale("en", "IN"))
                    if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) t.setLanguage(Locale.US)
                    t.setAudioAttributes(
                        AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                    )
                    ready = true
                    pending?.let { speakNow(it) }
                    pending = null
                }
            }
        } catch (e: Exception) {
            tts = null
        }
    }

    private fun audible(): Boolean {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.ringerMode == AudioManager.RINGER_MODE_NORMAL
    }

    /** Strips emoji and symbols so the voice doesn't read "ghost face". */
    fun clean(text: String): String = text
        .replace(Regex("[^\\p{L}\\p{N}\\s.,!?'-]"), " ")
        .replace(Regex("\\s+"), " ").trim()

    fun speak(text: String) {
        if (!s.speak || !audible()) return
        val c = clean(text)
        if (c.isEmpty()) return
        if (!ready) { pending = c; return }
        speakNow(c)
    }

    private fun speakNow(c: String) {
        val t = tts ?: return
        t.setPitch((s.voicePitch / 10f).coerceIn(0.5f, 2f))
        t.setSpeechRate(1.05f)
        t.speak(c, TextToSpeech.QUEUE_FLUSH, null, "ghostie")
    }

    fun sfx(kind: String) {
        if (!s.sound || !audible()) return
        try {
            val data = cache.getOrPut(kind) { Chirp.effect(kind) }
            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(Chirp.RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(data.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(data, 0, data.size)
            track.play()
            handler.postDelayed({ try { track.release() } catch (e: Exception) { } }, data.size * 1000L / Chirp.RATE + 300)
        } catch (e: Exception) {
            // sound is a nice-to-have
        }
    }

    fun stop() {
        try { tts?.stop() } catch (e: Exception) { }
    }

    fun shutdown() {
        try { tts?.stop(); tts?.shutdown() } catch (e: Exception) { }
        tts = null
    }
}
