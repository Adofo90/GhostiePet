package com.ghostie.pet

/**
 * Makes study cards from plain notes (no questions in the file): "Term: explanation" lines and "X is / refers to Y" definitions.
 * Works on text that arrives as one long line per page, so it splits into sentences itself. Pure Kotlin (JVM tested).
 * The cards are only as good as the notes, so the app shows examples before adding them.
 */
object NotesMiner {
    data class Card(val q: String, val a: String)

    private val bad = setOf("note", "notes", "example", "examples", "figure", "table", "page", "module", "textbook", "chapter", "unit", "topic", "syllabus", "refer", "see", "source")
    private val verbish = setOf("aim", "aims", "ensure", "ensures", "help", "helps", "make", "makes", "can", "will", "should", "would", "may", "might", "must", "do", "does", "has", "have", "had", "use", "uses", "used", "allow", "allows", "provide", "provides", "need", "needs", "cause", "causes", "lead", "leads", "when", "while", "because", "if", "that", "which")
    private val pronounStart = Regex("^(it|its|this|that|these|those|they|them|there|which|who|what|when|where|how|why|he|she|we|you|i|here|some|many|most|each|both|all)\\b", RegexOption.IGNORE_CASE)
    private val termDef = Regex("^(?:\\(?\\d{1,2}[.)]\\s*)?([A-Z][\\w()/&'’,-]*(?:\\s+[\\w()/&'’,-]+){0,5}):\\s+(.{25,})$")
    private val isDef = Regex("^(?:(?:The|An?)\\s+)?([A-Z][\\w()/&'’-]*(?:\\s+[\\w()/&'’-]+){0,5}?)\\s+(is|are|refers to|refer to|means|can be defined as|is defined as|are defined as|is called|are called)\\s+(.{20,})$")

    private fun tidy(raw: String): String {
        val sb = StringBuilder(raw.length)
        for (ch in raw) sb.append(if (ch.isLetterOrDigit() || ch in " .,;:!?'’\"()-/&%+=\n") ch else ' ')
        return sb.toString().replace(Regex("Page\\s*\\d+"), " ").replace(Regex("[ \\t\\n]+"), " ").trim()
    }

    private fun clip(s0: String, n: Int = 280): String {
        val s = s0.trim().replace(Regex("^[o•\\-–*]\\s+"), "")
        if (s.length <= n) return s.trim()
        val cut = s.substring(0, n).let { c -> c.lastIndexOf(". ").takeIf { it > 80 }?.let { c.substring(0, it + 1) } ?: c.substring(0, c.lastIndexOf(' ').coerceAtLeast(80)) + "…" }
        return cut.trim()
    }

    fun mine(raw: String, max: Int = 80): List<Card> {
        val text = tidy(raw)
        val sentences = text.split(Regex("(?<=[.!?])\\s+")).map { it.trim() }.filter { it.length >= 30 }
        val out = LinkedHashMap<String, Card>()
        for (s in sentences) {
            if (out.size >= max) break
            if (Regex("RNSIT|BAIAP|Module\\s*-?\\s*\\d|©|www\\.|\\.com\\b|\\.in\\b", RegexOption.IGNORE_CASE).containsMatchIn(s)) continue
            termDef.find(s)?.let { m ->
                val term = m.groupValues[1].trim().trimEnd(',')
                if (term.split(' ').first().lowercase() in bad || term.length < 3 || term.endsWith(" and") || term.endsWith(" or")) return@let
                val ans = clip(m.groupValues[2])
                if (ans.count { it.isLetter() } < 20) return@let
                val key = term.lowercase()
                if (key !in out) out[key] = Card("Explain: $term", ans)
                return@let
            } ?: isDef.find(s)?.let { m ->
                val subj = m.groupValues[1].trim().let { s0 -> Regex("\\s(?:An?|The)\\s+(.+)$").find(s0)?.groupValues?.get(1) ?: s0 }.replace(Regex("^(?:The|An?)\\s+", RegexOption.IGNORE_CASE), "").replaceFirstChar { it.uppercase() }
                if (subj.split(' ').size > 4 || subj.split(' ').drop(1).any { it in verbish }) return@let
                if (pronounStart.containsMatchIn(subj) || subj.length < 3 || subj.split(' ').first().lowercase() in bad) return@let
                if (subj.split(' ').size > 6 || subj.any { it == ',' || it == ':' }) return@let
                val key = subj.lowercase()
                if (key in out) return@let
                val verb = m.groupValues[2]
                val q = if (verb.startsWith("are") || verb.startsWith("refer")) "What are $subj?" else "What is $subj?"
                out[key] = Card(q, clip(s))
            }
        }
        return out.values.toList()
    }
}
