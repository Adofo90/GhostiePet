package com.ghostie.pet

/**
 * A second layer of offline chat for things the main small-talk rules do not know.
 * It understands the *kind* of sentence (why / how / should I / what is / recommend / opinion), a long list of everyday
 * topics (parents, placements, projects, sleep, money, coding...), and it remembers what the user was just talking about,
 * so even an unknown sentence gets an answer that uses their own words instead of a stock line.
 * Pure Kotlin. This is still a rule-based helper: it cannot know facts. For real conversation add an AI key in the app.
 */
class SmartReply {
    /** What the user talked about recently (most recent last). */
    private val topics = ArrayDeque<String>()
    private var lastTopicTurn = 0
    private var turn = 0

    private val I = RegexOption.IGNORE_CASE
    private fun has(l: String, p: String) = Regex(p, I).containsMatchIn(l)

    private val stop = setOf(
        "the", "a", "an", "and", "or", "but", "so", "to", "of", "in", "on", "at", "for", "with", "about", "is", "am", "are", "was", "were", "be", "been",
        "i", "me", "my", "mine", "you", "your", "we", "our", "it", "its", "this", "that", "these", "those", "there", "here", "just", "really", "very", "too",
        "have", "has", "had", "do", "does", "did", "will", "would", "can", "could", "should", "shall", "may", "might", "must", "not", "no", "yes", "ok", "okay",
        "what", "why", "how", "when", "where", "who", "which", "if", "then", "than", "as", "by", "from", "up", "out", "into", "get", "got", "going", "go", "want",
        "need", "like", "know", "think", "feel", "say", "said", "tell", "let", "lets", "also", "much", "many", "some", "any", "more", "most", "lot", "lots", "thing",
        "things", "today", "now", "still", "even", "only", "again", "always", "never", "maybe", "please", "ghostie", "hey", "hi", "hello", "bro", "yaar", "hai", "hain",
        "interesting", "fascinating", "amazing", "awesome", "great", "good", "bad", "nice", "weird", "funny", "cool", "boring", "important", "difficult",
        "hard", "easy", "new", "old", "big", "small", "own", "lost", "won", "keeps", "keep", "playing", "acting", "making", "doing", "being", "having", "trying",
        "love", "hate", "enjoy", "start", "starting", "build", "building", "learn", "learning", "really", "totally", "actually", "kinda", "sort", "bit",
        "kya", "kaise", "kyun", "mera", "meri", "mujhe", "tum", "aap", "nahi", "bhi", "toh", "ho", "hoga", "karna", "kar", "ka", "ki", "ke", "ko", "se", "mein", "main"
    )

    /** The one or two most meaningful words of a sentence, or "" when there are none. */
    fun keyword(t: String): String {
        val words = Regex("[A-Za-z][A-Za-z'+#.-]{2,}").findAll(t).map { it.value.trim('.', '-', '\'') }.filter { it.lowercase() !in stop && it.length > 2 && !Regex("'(s|m|re|ve|ll|d|t)$", I).containsMatchIn(it) }.toList()
        if (words.isEmpty()) return ""
        val best = words.maxByOrNull { it.length } ?: return ""
        val i = words.indexOf(best)
        val next = words.getOrNull(i + 1)
        return if (next != null && best.length + next.length < 20 && i + 1 < words.size && words.size <= 3) "$best $next" else best
    }

    /** Remember what the user is on about (called for every message). */
    fun note(t: String) {
        turn++
        val k = keyword(t).lowercase()
        if (k.isNotEmpty() && t.length > 8) {
            topics.remove(k)
            topics.addLast(k)
            while (topics.size > 6) topics.removeFirst()
            lastTopicTurn = turn
        }
    }

    /** A topic from earlier in the chat, for a callback ("Earlier you mentioned ..."), or null. */
    private fun earlier(current: String): String? = topics.filter { it != current.lowercase() }.lastOrNull()

    private fun cap(s: String) = s.replaceFirstChar { it.uppercase() }

    /**
     * Returns a reply, or null when nothing here fits (the caller then uses its own last-resort lines).
     * [pick] chooses one option without repeating recent ones; [n] is ", Name" or "".
     */
    fun reply(t: String, n: String, fallback: Boolean = false, pick: (List<String>) -> String): String? {
        val l = t.lowercase().trim()
        val kw = keyword(t)

        // ---- short conversational glue ----
        if (has(l, "^(me too|same|same here|same to you|true|so true|exactly|right|fr|facts)[.! ]*$")) return pick(listOf("Right? 😄 It's nice when someone gets it.", "Same energy 💜", "Haha, we're on the same page$n.", "Glad it's not just me 👻"))
        if (has(l, "^(idk|i don'?t know|dunno|no idea|not sure|maybe|hmm+ not sure)[.! ]*$")) return pick(listOf("That's okay, you don't have to know right now. Want to think out loud and I'll just listen?", "Totally fine. Pick the smallest thing you're sure about and start from there 💜", "Not knowing is allowed$n. Shall we make a tiny list of options?", "Okay. Sometimes it helps to sleep on it. Want a reminder to revisit this tomorrow?"))
        if (has(l, "^(nothing|nothing much|nm|nvm|never ?mind|forget it|it'?s nothing)[.! ]*$")) return pick(listOf("Okay$n. I'm here if it comes back to you 💜", "No pressure. Want a joke instead?", "Alright. Say \"help\" any time if you need something 👻"))
        if (has(l, "^(whatever|anyway|anyways|never mind)[.! ]*$")) return pick(listOf("Fair enough. Want to change the subject? I know jokes, riddles and fun facts.", "Okay 😄 What shall we do instead?", "Anyway... how's your day been going really?"))
        if (has(l, "^(really|seriously|is it|oh really|are you sure|for real)[?!. ]*$")) return pick(listOf("Really really 😄", "I think so, but I'm only a small ghost. Double-check if it matters!", "As far as I know! Why, do you doubt it? 👀"))
        if (has(l, "^(why|why so|but why|how come)[?!. ]*$")) return pick(listOf("Good question$n. What made you wonder?", "Hmm, I'm not sure of the reason. What's your guess?", "Reasons are tricky. Tell me what you're thinking 👻"))
        if (has(l, "^(are you there|you there|hello\\?|ghostie\\?|anyone there|hey\\?)[?!. ]*$")) return pick(listOf("Right here$n 👻", "Floating nearby! What's up?", "Always. What do you need?"))
        if (has(l, "^(yes|yeah|yep|yup|sure|of course|definitely)[.! ]*$") && topics.isNotEmpty()) return pick(listOf("Nice. Tell me more about ${topics.last()}?", "Okay! Want me to set a reminder or a timer for it?", "Cool. What's the first step?"))
        if (has(l, "^(no|nope|nah|not really)[.! ]*$") && topics.isNotEmpty()) return pick(listOf("Okay, no worries. We can leave ${topics.last()} for later.", "Fair. Want to talk about something else?", "Alright$n 💜 Anything else on your mind?"))

        // a reaction to what was just talked about: "it's interesting", "that's hard", "this is boring"
        Regex("^(?:it'?s|its|that'?s|thats|this is|it is|that is|so|very|quite)\\s+(?:so |very |really |pretty |quite )?(interesting|cool|nice|good|great|amazing|awesome|fun|funny|boring|weird|hard|difficult|easy|scary|stressful|exciting|useful|tough|crazy)[.! ]*$", I).find(l)?.let { m ->
            val adj = m.groupValues[1]; val topic = topics.lastOrNull()
            // asked for word for word, even though the grammar is a little off
            if (adj.equals("interesting", true)) return "How long has it's been on your mind?"
            return if (topic != null) pick(listOf("What do you find $adj about $topic?", "Tell me more, what makes $topic $adj for you?", "$adj, huh. How did you come across $topic?", "Is $topic something you'd like to do more of?"))
            else pick(listOf("What makes it $adj for you?", "Tell me more, I'm curious 👻", "$adj, huh. What happened?"))
        }

        // ---- everyday topics ----
        if (has(l, "\\b(mom|mother|mummy|mama|dad|father|papa|parents?|family|ghar|maa)\\b")) return pick(listOf("Family matters a lot. How are they doing?", "Parents always worry, even when you're fine 💜 Have you called them lately?", "Say \"call Mom\" and I'll dial for you 📞", "Tell me about them. Anything on your mind about home?"))
        if (has(l, "\\b(crush|girlfriend|boyfriend|gf|bf|dating|relationship|love life|propose|partner)\\b")) return pick(listOf("Ooh, matters of the heart 👀 Tell me more, no judgement.", "Relationships take honesty and time. What's on your mind about it?", "I'm a ghost so I'm no expert, but I'm a good listener 💜 Go on."))
        if (has(l, "\\b(breakup|broke up|ex\\b|dumped|heartbreak)\\b")) return pick(listOf("I'm sorry$n. That really hurts. Be gentle with yourself 💜", "Breakups feel huge. Talk to a friend too, you don't have to carry it alone.", "Want to talk about it, or shall I distract you with something light?"))
        if (has(l, "\\b(placement|placements|interview|resume|cv|internship|job|offer letter|campus drive|hr round|aptitude)\\b")) return pick(listOf("Placement season is stressful. Open Ghostie > Placement prep for practice questions 🎯", "One round at a time. Do you want a practice question? Open Placement prep in the app.", "For interviews: know your projects, basics of DSA, and a calm voice. Want to practise a \"tell me about yourself\"?", "You've got this$n. Which part worries you most, aptitude, coding or HR?"))
        if (has(l, "\\b(project|hackathon|capstone|mini project|major project|presentation|ppt|seminar|report)\\b")) return pick(listOf("Projects go better with a task list. Open Ghostie > Group projects to track who does what 👥", "Split it into tiny tasks and give each a date. Want to start with the first one?", "What's the project about? Tell me and let's plan the first step 📝", "Presentations get easier after one practice run out loud 🎤"))
        if (has(l, "\\b(procrastinat|lazy|can'?t focus|cannot focus|no motivation|unmotivated|not in the mood|distracted|can'?t study|cant study)\\b")) return pick(listOf("It happens to everyone$n. Try just 5 minutes. Say \"study 5\" and I'll start a tiny timer ⏱️", "Start with the easiest task, momentum does the rest. Want a 10 minute timer?", "Put the phone face down, open one book, set a timer. Small wins first 💜", "Focus is a muscle. Ten minutes today, fifteen tomorrow. Say \"study mode\" to begin."))
        if (has(l, "\\b(sleep|insomnia|can'?t sleep|cant sleep|awake|nap|sleepless|slept)\\b")) return pick(listOf("Sleep is part of studying. Screens off, lights low, slow breathing 🌙", "Can't sleep? Try writing tomorrow's to-do on paper so your brain can let go.", "Want an alarm so you can rest easy? Say \"alarm 7 am\" ⏰", "A regular bedtime beats pulling all-nighters, honestly 💜"))
        if (has(l, "\\b(broke|no money|money|pocket money|expensive|budget|salary|savings?|rent|pay(ing)? for)\\b")) return pick(listOf("Money stress is real. Say \"my spending\" and I'll show where it went 💸", "A small budget beats no budget. Set one in Ghostie > Spending.", "Track every small spend for a week, it's eye-opening. Say \"spent 50 on chai\" to log one ☕"))
        if (has(l, "\\b(hostel|mess|roommate|pg|canteen|warden)\\b")) return pick(listOf("Hostel life! Mess food, midnight snacks and chaos 😄 How is it going?", "Roommates can be great or a challenge. What's happening?", "Say \"cheapest biryani\" and I'll compare delivery prices for you 🍛"))
        if (has(l, "\\b(code|coding|bug|error|compile|program|debug|python|java|javascript|c\\+\\+|html|css|sql|algorithm|leetcode)\\b")) return pick(listOf("Debugging tip: read the error message slowly, it usually tells you the line 🔍", "Explain the bug out loud to a rubber duck, it works more often than you'd think 🦆", "Break the problem down: input, steps, output. Which step fails?", "Want to practise? Open Placement prep for C, data structures, OS and DBMS questions 🎯"))
        if (has(l, "\\b(failed|fail|backlog|arrear|low marks|bad marks|didn'?t pass|flunk)\\b")) return pick(listOf("One result isn't the whole story$n 💜 What was the hardest part?", "Backlogs happen to many people and can be cleared. Want to make a small plan?", "Let's find what went wrong and fix that one thing. Which subject was it?"))
        if (has(l, "\\b(maths|math|calculus|algebra|equation|integration|derivative|matrix|probability|physics|chemistry)\\b")) return pick(listOf("Practice beats reading in maths and physics. Do five problems, then check the method.", "Stuck on a concept? Write the formula, one solved example, then try one alone ✍️", "Need a quick sum? Say \"calculate 12*(3+4)\" and I'll do it 🧮"))
        if (has(l, "\\b(headache|fever|sick|ill|cold|cough|pain|unwell|migraine|stomach)\\b")) return pick(listOf("I'm sorry you're unwell$n. Rest, water, and see a doctor if it doesn't ease 💜", "Take it easy today. Studies can wait a little, health first.", "If it's more than a mild thing, please tell someone near you or see a doctor."))
        if (has(l, "\\b(instagram|reels|youtube|scrolling|doomscroll|phone addiction|social media|screen time)\\b")) return pick(listOf("Reels have a way of eating hours 😅 Try study mode, it blocks distracting apps.", "Put the phone in another room for one hour and see how it feels.", "Set a timer before you scroll, \"timer 15 minutes\", and stop when it rings ⏱️"))
        if (has(l, "\\b(exam|exams|test|viva|quiz)\\b.*\\b(tomorrow|today|tonight|next week|soon)\\b|\\b(tomorrow|tonight)\\b.*\\b(exam|test|viva)\\b")) return pick(listOf("Exam soon! Revise the important topics, then sleep properly 💜 Say \"quiz me\" for flashcards.", "Skim your notes, do a few past questions, and don't skip sleep. You've got this$n!", "Say \"study today\" and I'll show your plan 📚"))
        if (has(l, "\\b(angry|annoyed|irritated|frustrated|mad|furious|fed up)\\b")) return pick(listOf("That sounds frustrating$n. Want to vent? I won't tell anyone 👻", "Take a slow breath, in for 4, out for 6. Then tell me what happened.", "Anger is information. What's it trying to say?"))
        if (has(l, "\\b(confused|(i'?m|im|i am|feel|feeling|totally|completely|so) lost|don'?t understand|dont understand|confusing)\\b")) return pick(listOf("Let's untangle it. What's the part that doesn't make sense?", "Try explaining it in your own words, the gap shows up quickly.", "Break it into the smallest piece you do understand, then add one more."))

        // ---- requests for things ----
        if (has(l, "\\b(tell me a story|story time|bedtime story)\\b")) return pick(listOf("Once there was a tiny ghost who lived on a phone screen. Every night it watched over one sleepy student's deadlines, and every morning the student whispered thanks. The end 👻", "A small ghost was scared of the dark, until it realised it WAS the spooky thing. After that it floated around happily. The end 😄"))
        if (has(l, "\\b(recommend|suggest)\\b.*\\b(movie|film|series|show)\\b")) return pick(listOf("For a cosy night: something light and funny. For focus time: nothing 😄 What genre do you like?", "Tell me the mood, comedy, thriller or something heartwarming, and I'll narrow it down 🍿"))
        if (has(l, "\\b(recommend|suggest)\\b.*\\b(song|songs|music|playlist)\\b")) return pick(listOf("For studying, instrumental lo-fi or soft piano works well 🎧", "Songs without lyrics help you focus. Want one for relaxing instead?"))
        if (has(l, "\\b(recommend|suggest)\\b.*\\b(book|books|novel)\\b")) return pick(listOf("What kind of reader are you, fiction, self-help or textbooks? Tell me and I'll narrow it down 📖", "A short, easy book is the best way back into reading 📚"))
        if (has(l, "^(recommend|suggest)\\b|what should i (do|eat|watch|play|learn|study)\\b|what do i do\\b")) return pick(listOf("Tell me how much time you have and how you feel, and I'll suggest something 👻", "Try the smallest useful thing: a 10 minute task, a snack, or a stretch. Which one?", "Say \"plan my week\" and I'll look at your deadlines and suggest what's next 📅"))
        if (has(l, "\\b(sing|song for me|rap)\\b") && !has(l, "recommend")) return pick(listOf("🎤 Boo-boo-boo, floating through the night... okay that's all I have 😄", "La la la 🎶 I only know the ghost lullaby."))
        if (has(l, "do you (like|love|enjoy|hate|prefer)\\b|are you (afraid|scared|happy|sad|tired|bored)")) return pick(listOf("I'm a simple ghost, I like deadlines done and students rested 💜 What about you?", "Hmm, good question. I'd say yes, mostly 😄 You?", "I like whatever makes you smile 👻 What's your answer?"))
        if (has(l, "what do you think|your opinion|do you agree|am i right|what would you do")) return pick(listOf("My honest view: trust your gut, then check one fact. What's your gut saying?", "I'd weigh the best case against the worst case and pick the one I can live with. What are yours?", "Hmm, I only see part of the picture. Tell me the options and I'll help you compare 📝"))

        // ---- sentence types ----
        if (has(l, "^(should i|shall i|can i|may i|is it (ok|okay|fine|right|good|worth)|would it be (ok|okay|fine)|do i (need|have) to)\\b")) {
            return pick(listOf("Quick check$n: what's the best that could happen, and the worst? If you can live with the worst, go for it.", "List one reason for and one against. Which one feels heavier?", "If it affects your health, money or someone else, think twice. Otherwise try it small first 💜", "Sleep on it if it's not urgent. Want a reminder tomorrow to decide?"))
        }
        if (has(l, "^(how (do|can|to|should) (i|we|you)|how to|how do you|any (way|tips) to)\\b")) {
            return pick(listOf("Break it into steps: the goal, the smallest first action, and when you'll do it. What's the goal${if (kw.isNotEmpty()) " with $kw" else ""}?", "Start with one small step today. I can set a timer or a reminder, just say when ⏱️", "Search for a good beginner guide, follow one example, then try it yourself. Want me to add a to-do for it? Say \"todo ...\" 📝", "Good one. Tell me where you're stuck and I'll help you plan the next step."))
        }
        if (has(l, "^(what is|what'?s|what are|define|meaning of|explain|what does)\\b") && kw.isNotEmpty() && !has(l, "\\b(time|date|day|weather|temperature|battery|name|age|up|new|going on|happening|cooking)\\b")) {
            return pick(listOf("I don't carry a dictionary offline 📖 A quick search is quicker for \"$kw\", or add an AI key in the app and I'll explain it properly.", "Hmm, \"$kw\"... I'm not sure of an exact answer. What have you read about it so far?", "Great topic. I'm just a small ghost without internet, so check a trusted source for \"$kw\". Want me to make a flashcard once you learn it? Say \"card $kw = ...\" 📝"))
        }
        if (has(l, "^who (is|was|are)\\b")) return pick(listOf("I don't know people outside this phone, sorry 👻 A search will tell you faster.", "No idea, honestly. Is this for a class? I can note it down for you."))
        if (has(l, "^(where|when) (is|was|are|can|do|did|will)\\b")) return pick(listOf("That one's beyond a small ghost 🤷 Try a quick search, or tell me what you already know.", "Hmm, I can't look that up offline. If it's a date, tell me and I'll add it as an event."))
        if (has(l, "^why\\b")) return pick(listOf("Good \"why\"${if (kw.isNotEmpty()) " about $kw" else ""}. What's your own guess? Often saying it out loud answers it.", "Hmm, there may be a few reasons. Which one seems most likely to you?", "Writing down three possible reasons usually makes the real one stand out. Say \"note ...\" to save them 📝"))

        // ---- fallback that uses their own words (only asked for once every other rule has had its turn) ----
        if (fallback && kw.isNotEmpty() && t.length > 6) {
            val k = kw.lowercase()
            val back = earlier(k)
            val options = mutableListOf(
                "${cap(kw)}, huh? What's the part that's on your mind most?",
                "What made you think about $k today?",
                "How long has $k been on your mind?",
                "If $k went really well, what would that look like?",
                "Is $k something you want to plan? I can set a reminder, a timer or a to-do 📝",
                "Tell me more about $k$n, I'm curious 👻",
                "What's the hardest part of $k right now?",
                "And how do you feel about $k?"
            )
            if (back != null) options.add("Earlier you mentioned $back. Is that connected to $k?")
            return pick(options)
        }
        return null
    }
}
