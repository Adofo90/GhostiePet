package com.ghostie.pet

import android.animation.ValueAnimator
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Full-screen "Ghostie calling" screen. Answer opens WhatsApp; Dismiss silences; drag the ghost into the bin to never ring for this chat. */
class CallAlertActivity : Activity() {
    private var voice: GhostVoice? = null
    private var pulse: ValueAnimator? = null
    private var chat = ""
    private var eventId = 0L
    private var acted = false
    private val closed = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { finish() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        chat = intent.getStringExtra("chat") ?: ""
        eventId = intent.getLongExtra("eventId", 0L)
        if (intent.getBooleanExtra("answer", false)) { answer(); return }
        val headline = intent.getStringExtra("headline") ?: "Someone is messaging you"
        val preview = intent.getStringExtra("preview") ?: ""
        build(headline, preview)
        registerReceiver(closed, IntentFilter("com.ghostie.pet.CALL_CLOSED"), Context.RECEIVER_NOT_EXPORTED)
        try {
            val s = SettingsStore(this)
            voice = GhostVoice(this, s)
            voice?.speak(headline.replace("\"", ""))
        } catch (e: Exception) { }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra("answer", false)) answer()
    }

    private fun answer() {
        acted = true
        CallAlerts.cancel(this)
        if (eventId > 0) { // a deadline call: Answer opens Ghostie, where the task can be checked
            try { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
            finish(); return
        }
        try {
            val li = packageManager.getLaunchIntentForPackage("com.whatsapp")
                ?: packageManager.getLaunchIntentForPackage("com.whatsapp.w4b")
            if (li != null) startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
        finish()
    }

    private fun build(headline: String, preview: String) {
        val root = FrameLayout(this)
        val pal = Themes.palette(SettingsStore(this))
        root.background = pal.background()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(24), dp(72), dp(24), dp(24))
        root.addView(col, FrameLayout.LayoutParams(-1, -1))

        fun text(t: String, size: Float, color: String, bold: Boolean = false) = TextView(this).apply {
            this.text = t; textSize = size; setTextColor(Color.parseColor(color)); gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
        col.addView(text("INCOMING GHOSTIE CALL", 13f, "#B8A1FF", true))

        val ghost = ImageView(this)
        ghost.setImageResource(R.drawable.ghost_pet)
        col.addView(ghost, LinearLayout.LayoutParams(dp(150), dp(150)).apply { topMargin = dp(36); bottomMargin = dp(24) })
        pulse = ValueAnimator.ofFloat(1f, 1.12f).apply {
            duration = 650; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE
            addUpdateListener { ghost.scaleX = it.animatedValue as Float; ghost.scaleY = it.animatedValue as Float }
            start()
        }

        col.addView(text(headline, 22f, "#FFFFFF", true))
        col.addView(text(if (preview.isBlank()) "" else "“" + preview.take(160) + "”", 15f, "#D8CCFF"),
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(14) })
        col.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        val dragHint = text("Drag the ghost into the bin to never ring for this chat", 12f, "#9C8BD6")
        col.addView(dragHint, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(10) })

        val bin = text("🗑", 34f, "#FFFFFF")
        bin.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#3A2A66")) }
        col.addView(bin, LinearLayout.LayoutParams(dp(68), dp(68)).apply { bottomMargin = dp(28) })
        if (eventId > 0) { dragHint.visibility = View.GONE; bin.visibility = View.GONE }

        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER
        fun circle(label: String, emoji: String, color: String, onClick: () -> Unit): LinearLayout {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.gravity = Gravity.CENTER
            val c = text(emoji, 30f, "#FFFFFF")
            c.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor(color)) }
            c.setOnClickListener { onClick() }
            box.addView(c, LinearLayout.LayoutParams(dp(76), dp(76)))
            box.addView(text(label, 13f, "#FFFFFF"), LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })
            return box
        }
        row.addView(circle("Dismiss", "✖", "#E5484D") { acted = true; CallAlerts.cancel(this); finish() }, LinearLayout.LayoutParams(0, -2, 1f))
        if (eventId > 0) row.addView(circle("Done", "✅", "#3B7BE8") {
            acted = true
            sendBroadcast(Intent(this, ReminderReceiver::class.java).setAction(ReminderAlarms.DONE).putExtra("id", eventId))
            CallAlerts.cancel(this); finish()
        }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(circle(if (eventId > 0) "Open" else "Answer", "💬", "#2FB86A") { answer() }, LinearLayout.LayoutParams(0, -2, 1f))
        col.addView(row, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        // Throw the ghost into the bin.
        var dx = 0f; var dy = 0f
        ghost.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX - v.translationX; dy = e.rawY - v.translationY; pulse?.cancel(); true }
                MotionEvent.ACTION_MOVE -> {
                    v.translationX = e.rawX - dx; v.translationY = e.rawY - dy
                    bin.scaleX = if (overBin(v, bin)) 1.3f else 1f; bin.scaleY = bin.scaleX
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (overBin(v, bin)) {
                        v.animate().scaleX(0f).scaleY(0f).alpha(0f).setDuration(200).withEndAction {
                            CallAlerts.mute(this, chat); CallAlerts.cancel(this); finish()
                        }.start()
                    } else {
                        v.animate().translationX(0f).translationY(0f).setDuration(200).start()
                        bin.scaleX = 1f; bin.scaleY = 1f
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun overBin(ghost: View, bin: View): Boolean {
        val a = IntArray(2); val b = IntArray(2)
        ghost.getLocationOnScreen(a); bin.getLocationOnScreen(b)
        val gx = a[0] + ghost.width / 2; val gy = a[1] + ghost.height / 2
        return gx in (b[0] - dp(20))..(b[0] + bin.width + dp(20)) && gy in (b[1] - dp(20))..(b[1] + bin.height + dp(20))
    }

    override fun onDestroy() {
        // Closed (swiped away, back pressed) without choosing: stop the ringing instead of leaving it going in the background.
        if (!acted && !isChangingConfigurations) CallAlerts.cancel(this)
        pulse?.cancel()
        try { unregisterReceiver(closed) } catch (e: Exception) { }
        try { voice?.shutdown() } catch (e: Exception) { }
        super.onDestroy()
    }
}
