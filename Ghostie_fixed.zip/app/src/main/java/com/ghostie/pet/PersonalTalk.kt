package com.ghostie.pet

/**
 * Personal conversations: a crush, friends, family pressure, confidence, venting, and the private kind of talk
 * (unwanted violent thoughts, secrets). Pure Kotlin so it can be tested on a computer.
 *
 * Privacy rules the rest of the app follows through [Sensitive]:
 *  - a "private" message is answered on the phone only (never sent to an AI service),
 *  - it is not learned, not logged, not kept in any history and not offered as a shortcut.
 *
 * Only a crush's name and a few short notes are remembered on purpose (the user asked for that), and they can be erased.
 */
object Sensitive {
    enum class Kind { NONE, SELF_HARM, INTRUSIVE, INTENT_OTHERS, SECRET }

    private val I = RegexOption.IGNORE_CASE
    private fun has(l: String, p: String) = Regex(p, I).containsMatchIn(l)

    private const val VIOLENT = "kill|killing|killed|murder|murdering|stab|stabbing|hurt|hurting|harm|harming|strangle|strangling|shoot|shooting|attack|attacking|beat|beating|slit|burn|burning"
    private const val MENTAL = "thoughts?|urges?|images?|visions?|voices?|pictures?|scenes?|imagin\\w+|visuali[sz]\\w+|fantas\\w+|flashes|intrusive|in my (head|mind|brain)|in (their|his|her) (head|mind)"

    fun kind(raw: String): Kind {
        val l = raw.lowercase()
        if (has(l, "\\b(kill myself|suicide|suicidal|end my life|want to die|self.?harm|hurt myself|cut myself)\\b")) return Kind.SELF_HARM
        // "I want to kill my teacher", "I'm going to hurt him": a stated wish or plan to hurt a person
        if (has(l, "\\b(i('?m| am) going to|i('?m| am) gonna|i will|i want to|i wanna|i('?m| am) planning to|i plan to|i('?ll| shall)|going to)\\s+(${VIOLENT})\\b\\s+(my|him|her|them|everyone|everybody|someone|somebody|people|a |the |\\w+)") &&
            !has(l, "\\b(game|movie|exam|paper|test|interview|presentation|it|that|this|time|mood|vibe|workout|gym)\\b")) return Kind.INTENT_OTHERS
        // unwanted violent thoughts / images, e.g. "I keep imagining killing everyone I see"
        if (has(l, "\\b(${MENTAL})\\b.*\\b(${VIOLENT})\\b") || has(l, "\\b(${VIOLENT})\\b.*\\b(everyone|everybody|people|strangers?|anyone|someone|my (family|parents|friends|classmates))\\b.*\\b(${MENTAL})\\b") ||
            has(l, "\\b(crazy|scary|dark|violent|bad|weird|disturbing|intrusive|sick|evil) (thoughts?|images?|urges?)\\b")) return Kind.INTRUSIVE
        if (has(l, "\\b(i have a secret|got a secret|can i tell you (something|a secret)|promise( me)?( you)?( that)?( you)?( will)?( won'?t| not)? tell|don'?t tell (anyone|anybody)|just (want|wanna|need) to (vent|rant)|let me (vent|rant)|keep (this|it) (a )?secret|just between us|between us)\\b")) return Kind.SECRET
        return Kind.NONE
    }

    fun isPrivate(k: Kind) = k != Kind.NONE
}

/** Where the few remembered things live. The app backs this with SharedPreferences; tests use [MapMemory]. */
interface PersonalMemory {
    fun get(key: String): String
    fun put(key: String, value: String)
    fun clearAll()
}

class MapMemory : PersonalMemory {
    private val m = HashMap<String, String>()
    override fun get(key: String) = m[key] ?: ""
    override fun put(key: String, value: String) { if (value.isEmpty()) m.remove(key) else m[key] = value }
    override fun clearAll() = m.clear()
}

/** Phone-only storage for the crush notes. Excluded from backups on purpose. */
class PrefsMemory(ctx: android.content.Context) : PersonalMemory {
    private val sp = ctx.applicationContext.getSharedPreferences("ghostie_private", android.content.Context.MODE_PRIVATE)
    override fun get(key: String) = sp.getString(key, "") ?: ""
    override fun put(key: String, value: String) { sp.edit().apply { if (value.isEmpty()) remove(key) else putString(key, value) }.apply() }
    override fun clearAll() { sp.edit().clear().apply() }
}

/** The secret code that opens the private memories from the search bar. Only a salted hash is kept. */
object PrivateCode {
    const val SETUP_PHRASE = "private code"
    private fun hash(salt: String, code: String): String =
        java.security.MessageDigest.getInstance("SHA-256").digest((salt + code.trim().lowercase()).toByteArray()).joinToString("") { "%02x".format(it) }
    fun isSet(mem: PersonalMemory) = mem.get("code_hash").isNotEmpty()
    /** Returns false when the code is too short (needs 4+ characters). */
    fun set(mem: PersonalMemory, code: String): Boolean {
        if (code.trim().length < 4) return false
        val salt = java.util.UUID.randomUUID().toString()
        mem.put("code_salt", salt); mem.put("code_hash", hash(salt, code)); return true
    }
    fun matches(mem: PersonalMemory, typed: String): Boolean {
        val h = mem.get("code_hash")
        return h.isNotEmpty() && typed.trim().length >= 4 && hash(mem.get("code_salt"), typed) == h
    }
    fun wantsSetup(mem: PersonalMemory, typed: String) = !isSet(mem) && typed.trim().equals(SETUP_PHRASE, true)
}

class PersonalTalk(private val mem: PersonalMemory) {
    private val I = RegexOption.IGNORE_CASE
    private fun has(l: String, p: String) = Regex(p, I).containsMatchIn(l)

    // ---- what is remembered (on the phone only, erasable) ----
    var crushName: String
        get() = mem.get("crush_name")
        private set(v) = mem.put("crush_name", v)
    private var pron: String
        get() = mem.get("crush_pron").ifEmpty { "them" }
        set(v) = mem.put("crush_pron", v)
    val notes: List<String> get() = mem.get("crush_notes").split("\n").filter { it.isNotBlank() }
    private fun addNote(s: String) {
        val list = (notes + s.trim().take(140)).takeLast(8)
        mem.put("crush_notes", list.joinToString("\n"))
    }
    fun forgetCrush() { mem.put("crush_name", ""); mem.put("crush_pron", ""); mem.put("crush_notes", "") }
    fun forgetAll() {
        val h = mem.get("code_hash"); val s = mem.get("code_salt")
        mem.clearAll(); mem.put("code_hash", h); mem.put("code_salt", s)   // the code itself stays
        crushTurns = 0; stage = 0; unsureKind = 0; unsureQ = 0; topicTurns = 0; lastTopic = ""
    }
    /** Quick replies for the last reply (yes / no for the questions). */
    var chips: List<String> = emptyList()
        private set
    private var unsureKind = 0   // 1 = "do I have a crush?", 2 = "does she/he like me?"
    private var unsureQ = 0
    private var unsureYes = 0
    fun summary(): String = if (crushName.isEmpty() && notes.isEmpty()) "Nothing saved." else
        "Crush: " + (crushName.ifEmpty { "(no name)" }) + (if (notes.isNotEmpty()) "\n" + notes.joinToString("\n") { "- $it" } else "")

    // ---- conversation state (not saved) ----
    private var crushTurns = 0
    private var stage = 0
    var ventMode = false
        private set
    private var intrusiveStage = 0

    /** True while a private conversation (secret / unwanted thoughts) is open: nothing from it may be stored or sent anywhere. */
    val privateActive: Boolean get() = ventMode || intrusiveStage != 0
    /** True when this message belongs to the private kinds or an open private chat. */
    fun isPrivate(raw: String) = privateActive || Sensitive.isPrivate(Sensitive.kind(raw))
    /** True when the crush chat is ongoing or this message starts it: answered on the phone only. */
    fun isCrush(raw: String): Boolean { val l = raw.lowercase(); return topicOpen(raw) || crushTurns > 0 || isCrushTalk(l) || has(l, "\\b(forget|delete|erase)\\b.*\\b(crush|private)") }

    private fun she() = when (pron) { "her" -> "she"; "him" -> "he"; else -> "they" }
    private fun her() = when (pron) { "her" -> "her"; "him" -> "him"; else -> "them" }
    private fun who() = crushName.ifEmpty { her() }

    // ================== private / sensitive ==================

    /** A reply for the private kinds of talk, or null when [kind] is NONE and no private follow-up is pending. */
    fun privateReply(kind: Sensitive.Kind, l: String, pick: (List<String>) -> String): Pair<String, List<String>>? {
        when (kind) {
            Sensitive.Kind.INTRUSIVE -> {
                intrusiveStage = 1; ventMode = false
                return pick(listOf(
                    "Thank you for telling me, that took trust. Unwanted, scary thoughts like this are far more common than people admit, and having a thought is not the same as wanting it or doing it. They can still be really upsetting. Nothing about this chat is saved in the app, and it isn't sent to any AI service.\n\nCan I ask one thing: do you ever feel you might actually act on them?"
                )) to listOf("No, they just show up", "I'm not sure", "I'm scared I might")
            }
            Sensitive.Kind.INTENT_OTHERS -> {
                intrusiveStage = 2; ventMode = false
                return "That's a heavy thing to say, and I'm glad you said it out loud. Is it anger at someone right now, or are you worried you might really hurt someone?\n\nIf you might hurt someone, please step away from them and from anything you could use, and call Tele-MANAS (14416, free, 24x7) or the emergency number 112 right now. Nothing in this chat is saved." to
                    listOf("I'm just very angry", "I'm scared I might", "Let me explain")
            }
            Sensitive.Kind.SECRET -> {
                ventMode = true
                return pick(listOf(
                    "Of course. I'm listening, no judgement. What you write here isn't saved in the app and isn't sent anywhere. Go ahead whenever you're ready 💜",
                    "I'm here. Say it however it comes out. This chat isn't saved in the app. Take your time 💜"
                )) to emptyList()
            }
            else -> {}
        }
        // follow-ups to the questions above
        if (intrusiveStage == 1) {
            intrusiveStage = 0
            return when {
                has(l, "\\b(scared|afraid)\\b.*\\b(might|will|could)\\b|\\b(yes|i might|i will|i('?m| am) going to|sometimes i feel i might)\\b") && !has(l, "\\b(no|not)\\b") -> urgent() to emptyList()
                has(l, "\\b(not sure|maybe|sometimes|i don'?t know|dunno|idk)\\b") ->
                    "Thank you for being honest. Because you're not sure, please don't carry this alone. Talk to a counsellor or doctor soon, and if things ever feel unsafe, tell someone you trust or call Tele-MANAS on 14416 (free, 24x7). If you ever feel you might act, move away from people and anything you could use, and call 112.\n\nI'm still here and still not saving this. What's it like when the thoughts come?" to emptyList()
                else ->
                    "That's a relief to hear, and it fits with what are called intrusive thoughts: sudden, unwanted ones that feel awful precisely because they go against who you are. Fighting or hiding them tends to make them louder. Noticing \"that's just a thought\" and letting it pass helps many people.\n\nIf they come often or make you anxious, a counsellor or psychiatrist can help a lot, and it's treatable. Your college counselling centre is a good first step. Want to tell me more about when they show up? I'm listening, and this still isn't saved." to emptyList()
            }
        }
        if (intrusiveStage == 2) {
            intrusiveStage = 0
            return when {
                has(l, "\\b(scared|afraid)\\b.*\\b(might|will|could)\\b|\\b(yes|i might|i will|i('?m| am) going to)\\b") && !has(l, "\\b(not|no|just)\\b") -> urgent() to emptyList()
                else -> "Okay. Anger is allowed, it's what we do with it that matters. Step away from the person for a bit, drink some water, breathe slowly, and walk if you can. Want to tell me what happened? I'm listening, and this isn't saved." to emptyList()
            }
        }
        if (ventMode) {
            if (has(l, "\\b(that'?s all|thats all|thanks|thank you|i'?m done|im done|enough|stop|change (the )?(topic|subject)|let'?s talk about something else|joke)\\b")) {
                ventMode = false
                return "Thank you for trusting me with that. None of it is saved. I'm here whenever you want to talk again 💜" to emptyList()
            }
            if (has(l, "\\bjust (listen|hear)\\b|don'?t (need|want) advice|no advice")) return "Okay, just listening. Take your time." to emptyList()
            if (has(l, "\\b(advice|suggest|what should i do|what do i do|help me)\\b")) return "Here's a gentle start: say it to one person you trust, even in one sentence. Writing it on paper and tearing it up also helps some people. Do you want to tell me the part that weighs most?" to emptyList()
            return say("vent", pick) to emptyList()
        }
        return null
    }

    private fun urgent() =
        "I'm really glad you told me. Please step away from anything you could use to hurt someone, and be somewhere safe, with other people nearby or in an open public place. Call Tele-MANAS on 14416 (free, 24x7) or the emergency number 112 now, or tell someone near you what's happening. You don't have to handle this alone 💜"

    // ================== crush ==================

    private val stopNames = setOf("I", "She", "He", "They", "It", "The", "My", "Her", "Him", "Them", "This", "That", "So", "And", "But", "Really", "Very", "Maybe", "Yes", "No", "Not", "Just", "Is", "Was", "Has", "Have", "When", "What", "Why", "How", "Who", "Ok", "Okay")

    private fun grabName(t: String): String? {
        val pats = listOf(
            "\\b(?:crush (?:on|is)|named|called|name is|name'?s|her name is|his name is|their name is|it'?s|its|about|like|love|for|with|on)\\s+([A-Za-z][a-z]{2,15})\\b",
            "^([A-Z][a-z]{2,15})$"
        )
        for (p in pats) {
            val m = Regex(p).find(t.trim()) ?: Regex(p, I).takeIf { it.pattern.contains("named|called") }?.find(t)
            val n = m?.groupValues?.get(1)?.replaceFirstChar { it.uppercase() }
            if (n != null && n !in stopNames && n.lowercase() !in setOf("crush", "girl", "boy", "guy", "person", "someone", "somebody", "friend", "college", "class")) return n
        }
        return null
    }

    private val unsureSelf = "(not sure|unsure|confused|don'?t know|dont know|wonder).*(crush|like (her|him|them|someone|somebody)|feelings|in love)|\\bdo i (like|have a crush|love)\\b|\\bis (this|it) a crush\\b|\\bam i in love\\b"
    private val unsureOther = "(not sure|unsure|confused|don'?t know|dont know|wonder).*((she|he|they) (likes?|has a crush)|crush on me|likes me)|\\bdoes (she|he|they) (like|have a crush on) me\\b|\\b(think|feel|maybe|might) (she|he|they|someone|somebody)\\b.*\\b(likes? me|crush on me)\\b|\\bis (she|he|they) into me\\b"
    private fun isUnsure(l: String) = has(l, unsureSelf) || has(l, unsureOther)
    private fun isCrushTalk(l: String) = isUnsure(l) || has(l, "\\b(crush|have a thing for|in love with|fell for|falling for|like (a|this|some)\\s*(girl|boy|guy|person|one)|i like (her|him)|i love (her|him)|likes? me|interested in (someone|somone|smone|smeone|somebody|a girl|a boy|a guy|a person|her|him)|approach(?:ing)? (her|him)|(?:talk|speak|chat|text|message)(?:ing)? (?:to|with) (her|him)|(?:met|meet|know) (?:someone|somebody) (?:interesting|intresting|special|nice|cute|new)|asked (her|him) out|ask (her|him) out|propose|confess)\\b")

    private fun notePron(l: String) {
        if (has(l, "\\b(she|her|girl)\\b")) pron = "her" else if (has(l, "\\b(he|him|his|boy|guy)\\b")) pron = "him"
    }

    fun crushReply(raw: String, pick: (List<String>) -> String): String? {
        val t = raw.trim()
        val l = t.lowercase()
        // erase on request
        if (has(l, "^(?:please\\s+)?(forget|delete|erase|clear|remove)\\s+(?:all\\s+)?(?:my\\s+)?(?:crush|crush memory|crush details|private (?:memories|stuff|things))\\s*[.!]*$")) {
            val all = has(l, "private")
            if (all) forgetAll() else forgetCrush()
            crushTurns = 0; stage = 0
            return if (all) "Done. I've erased everything private I had saved 🧹" else "Done. I've forgotten about your crush 🧹 Nothing about them is saved now."
        }
        if (has(l, "^(?:what|who)(?:'?s| is| do you remember| did i tell you)?.*\\b(?:my crush|crush'?s name|her name|his name|about my crush)\\b") || has(l, "^what do you remember about (my crush|them|her|him)")) {
            return if (crushName.isEmpty() && notes.isEmpty()) "You haven't told me about a crush yet. Tell me whenever you like 💜" else "You told me about ${crushName.ifEmpty { "someone" }}.\n" + (if (notes.isNotEmpty()) notes.joinToString("\n") { "- $it" } + "\n" else "") + "Say \"forget my crush\" any time and I'll erase it."
        }
        chips = emptyList()
        // "am I in love?" / "does she like me?": a short, honest check, one question at a time
        if (unsureKind > 0) {
            val yes = has(l, "^(yes|yeah|yep|yup|ya|often|always|a lot|sometimes|a bit|kind of|kinda|i do|she does|he does|they do)\\b")
            val no = has(l, "^(no|nope|nah|never|not really|rarely|i don'?t|she doesn'?t|he doesn'?t)\\b")
            if (!yes && !no) {
                if (has(l, "\\b(stop|never ?mind|cancel|skip|not now)\\b")) { unsureKind = 0; unsureQ = 0; crushTurns = 0; return "Okay, no problem 💜 We can come back to it any time." }
                chips = listOf("Yes", "No")
                return "Is that a yes or a no? Just so I don't guess 🙂"
            }
            if (yes) unsureYes++
            unsureQ++
            val qs = unsureQuestions()
            if (unsureQ < qs.size) { chips = listOf("Yes", "No"); return qs[unsureQ] }
            val kind = unsureKind; val n = unsureYes
            unsureKind = 0; unsureQ = 0; unsureYes = 0; crushTurns = 8
            return if (kind == 1) when {
                n >= 4 -> "That sounds a lot like a crush 💜 Wanting to be near someone, thinking about them and caring what they think are the classic signs. Want to talk about what you'd like to do, or just tell me about them?"
                n >= 2 -> "A mix: could be a crush starting, or just strong liking and admiration. Both are normal. Give it a little time and notice if the feeling grows when you're apart. Want to tell me about them?"
                else -> "Doesn't sound like a crush yet, maybe friendship or just curiosity, and that's okay. Feelings can take time to show up, or never. There's no rule you have to feel something 💜"
            } else when {
                n >= 4 -> "Several of those are the signs people usually look for. I honestly can't read ${her()} mind, so I won't promise, but it does look encouraging. The only way to be sure is an honest, kind chat. Want help thinking what to say?"
                n >= 2 -> "Mixed signs: ${she()} might like you, or just be friendly. Hard to tell from outside. Spend some relaxed time together, notice how ${she()} acts, and when you feel ready, ask kindly. Want ideas for that?"
                else -> "Not many signs there, so I wouldn't assume. But I can't see inside ${her()} head, and some people are shy or hide feelings. Friendship is a good place to start either way 💜"
            }
        }
        if (isUnsure(l)) {
            unsureKind = if (has(l, unsureOther)) 2 else 1; unsureQ = 0; unsureYes = 0; crushTurns = 8; notePron(l)
            chips = listOf("Yes", "No")
            return (if (unsureKind == 1) "Happens a lot. Let me ask a few quick things, answer yes or no, honestly 💜\n\n" else "That's a very human thing to wonder. I can't read minds, but a few questions may help you see the signs. Yes or no 💜\n\n") + unsureQuestions()[0]
        }
        val starting = isCrushTalk(l)
        if (!starting && crushTurns <= 0) {
            // a saved crush only comes up when the user brings up a relationship thing
            return null
        }
        if (!starting && has(l, "^(?:thanks|thank you|bye|nothing|never ?mind|change (?:the )?topic|enough|that'?s all)\\b") ) { crushTurns = 0; stage = 0; return null }
        // the user moved on to a command-like or unrelated sentence
        if (!starting && has(l, "^(?:what is|what'?s the|tell me a|open |alarm|remind|set |timer|study|play|call |note |todo)")) { crushTurns = 0; return null }

        if (starting) crushTurns = 8 else crushTurns--
        notePron(l)
        val nameBefore = crushName
        grabName(t)?.let { if (starting || stage <= 1) crushName = it }
        if (crushName != nameBefore && crushName.isNotEmpty() && stage <= 1) stage = maxOf(stage, 2)
        val x = who()

        // asking for advice
        adviceFor(l, x)?.let { return it }

        // the very first mention
        if (starting && stage == 0) {
            stage = 1
            if (crushName.isNotEmpty()) {
                return if (nameBefore == crushName) pick(listOf("Is this about $crushName again? 👀 Tell me what's new.", "Back to $crushName! What's been happening?"))
                else pick(listOf("Ooh, $crushName 👀 How long have you known ${her()}?", "$crushName, nice name. How did you two meet?"))
            }
            return pick(listOf("Ooh 👀 A crush! Who's the lucky one? You can tell me the name, or just call them \"her\" or \"him\" if you'd rather not.",
                "Aww, tell me about them 💜 Who is it? A name is fine, or just describe them."))
        }
        if (has(l, "^(just )?(listen|listening)\\b|^(just )?listen to me|^no advice")) return "Okay, I'm just listening 💜 Go on."
        // store what the user says as a short note
        if (t.length in 6..140 && !t.endsWith("?")) addNote(t)
        // a name given in answer to "who is it?"
        if (stage == 1 && crushName.isNotEmpty()) { stage = 2; return pick(listOf("$crushName 💜 How did you two meet? Or how long have you known ${her()}?", "Nice. How long have you known $crushName?")) }
        if (stage == 1) { stage = 2; return pick(listOf("Okay, I'll call ${her()} \"${her()}\" 💜 How did you two meet?", "Got it. How long have you known ${her()}?")) }
        stage++
        return when (stage) {
            3 -> pick(listOf("What do you like most about $x?", "What is it about $x that gets you?"))
            4 -> pick(listOf("How do you think ${she()} feels? Any signs, or no idea yet?", "Do you think $x has noticed? How does ${she()} act around you?"))
            5 -> pick(listOf("What would you like to happen: become closer friends first, tell $x how you feel, or keep it to yourself for now?", "What's your heart wanting here, a chat, a confession, or time?"))
            else -> if (stage % 3 == 0) pick(listOf("Want some advice on this, or shall I just listen?", "I can give you ideas if you ask \"what should I do?\" 💜")) else say("crush", pick)
        }
    }

    private fun unsureQuestions(): List<String> = if (unsureKind == 1) listOf(
        "Do you think about them even when they're not around?", "Do you feel nervous or extra happy when they talk to you?",
        "Do you look for them or want to be where they are?", "Do you feel a bit jealous when they're close to someone else?",
        "Do you care what they think of you more than what most people think?"
    ) else listOf(
        "Does ${she()} look for chances to talk to you or sit near you?", "Does ${she()} remember small things you said?",
        "Does ${she()} text first, or reply quickly and warmly?", "Do you catch ${her()} looking at you, or smiling when you're around?",
        "Does ${she()} get shy, awkward or teasing around you?"
    )

    private fun adviceFor(l: String, x: String): String? {
        fun p(vararg s: String) = s[(l.length + s.size) % s.size]
        return when {
            has(l, "\\b(confess|propose|tell (her|him|them) (how i feel|i like)|ask (her|him|them) out|tell (her|him|them))\\b") ->
                p("If you want to tell $x, pick a calm, private moment (not in front of friends), say it simply and kindly, and let ${her()} answer in ${her()} own time. Whatever the answer, you were brave. Be ready to hear a \"no\" without pressure, and keep the friendship if you can. Want to practise what you'd say?",
                    "A simple way: \"I enjoy talking to you and I like you. I wanted you to know, no pressure.\" Short, honest and kind works better than a big speech. Timing matters: not right before an exam or in a crowd.")
            has(l, "\\b(how (do|can|to|should) i (talk|speak|start|approach|text|message|chat)|(what|how) to (say|talk|speak|text|tell|start)|don'?t (know )?(what|how) to (say|talk|speak|text)|dont know (what|how)|what should i (say|text|talk)|start a (conversation|chat)|talk to (her|him|them))\\b") ->
                p("Start small: smile, say hi, and ask about something you both share (a class, an assignment, a show). People like feeling heard, so ask open questions and listen. You don't need a perfect line.",
                    "For texting: keep it light, reply to what ${she()} says, ask one real question, and don't send five messages in a row 😄 Let the conversation breathe.")
            has(l, "\\b(does|do) (she|he|they) like me\\b|\\bis (she|he|they) into me\\b") ->
                "I honestly can't know that, and guessing wouldn't be fair to you. Signs people look for: making time for you, remembering small things, eye contact, being warm in messages. The only way to be sure is a kind, honest conversation. How does ${she()} act around you?"
            has(l, "\\b(impress|get (her|him|them) to like me|make (her|him|them) like me)\\b") ->
                "Being yourself, kind and curious, works better than trying to impress. Compliment something real, be reliable, be interested in $x's interests. Chemistry can't be forced, but respect and warmth are the best start 💜"
            has(l, "\\b(rejected|said no|turned me down|ignores me|ignoring me|doesn'?t like me|not interested)\\b") ->
                "I'm sorry, that stings. A \"no\" is about fit, not about your worth. Give yourself a few days, lean on friends, and try not to reread old chats. Want to talk about how you're feeling?"
            has(l, "\\b(jealous|another (girl|boy|guy)|with someone else|has a (girlfriend|boyfriend))\\b") ->
                "Jealousy hurts, and it's a normal feeling. Try not to act on it right away: breathe, talk to a friend. If it keeps bothering you, it may help to talk to $x honestly or to focus on your own things for a while."
            has(l, "\\b(nervous|shy|scared|afraid|anxious|awkward|panic)\\b.*\\b(talk|speak|tell|approach|ask)\\b|\\b(too shy|so nervous)\\b") ->
                "Nerves mean it matters to you. Try small steps: a smile today, a short chat next time. Practise what you'd say alone or with a friend. Slow breaths help right before you talk."
            has(l, "\\b(what should i do|what do i do|any (advice|tips|suggestions)|help me|give me (advice|tips))\\b|^(some )?(advice|tips?|suggestions?|ideas?)\\b|^yes,? ?(please)?$") ->
                "A few ideas: get to know $x as a friend first, notice how ${she()} responds, and when you feel ready, tell ${her()} honestly and kindly. Don't rush, and don't pressure ${her()}. What feels like the right next step for you?"
            else -> null
        }
    }

    // ================== friends, family, confidence ==================

    /** Listen-first replies for friendships, family pressure and self-confidence. Null when the message is none of these. */
    fun topicReply(raw: String, pick: (List<String>) -> String): String? {
        val l = raw.lowercase()
        val adviceAsked = has(l, "\\b(what should i do|what do i do|advice|any tips|how (do|can|should) i (fix|handle|deal|talk))\\b")
        if (has(l, "\\b(friends?|bestie|bff|roommate|classmate)\\b.*\\b(fight|fought|argu\\w+|angry|ignor\\w+|left me|betray\\w*|backstab\\w*|ghost\\w*|jealous|toxic|left out|replac\\w+|avoid\\w*|talk\\w*|hates?|rude|cheat\\w*)\\b|\\b(fight|fought|argued|argument|misunderstanding) with (my )?(friend|bestie|bff|roommate)\\b")) {
            return if (adviceAsked) pick(listOf("When you're both calm, say what hurt without blaming (\"I felt left out when...\"), listen to their side, and ask what would help. If it's repeated, it's okay to keep some distance.",
                "Try one honest message: what happened, how you felt, and that you'd like to fix it. Give them time to reply. Real friends usually come back to a kind message."))
            else say("friends", pick)
        }
        if (has(l, "\\b(parents?|mom|mother|dad|father|family|relatives?|papa|mummy)\\b.*\\b(pressure|expect\\w*|compar\\w+|scold\\w*|shout\\w*|strict|don'?t understand|force\\w*|marks|rank|percentage|career|disappoint\\w*|fight|argu\\w+|trust|restrict\\w*|control\\w*)\\b|\\b(pressure from|my parents? (want|expect|force))\\b")) {
            return if (adviceAsked) pick(listOf("Pick a calm moment to talk, start with what they want for you (usually your safety and future), then explain your own plan with small steps they can see. Showing progress helps more than arguing.",
                "It can help to ask: \"What worries you most?\" Then answer that worry directly. If talking directly is hard, a letter or a trusted relative can help carry your message."))
            else say("family", pick)
        }
        if (has(l, "\\b(no confidence|low confidence|lack of confidence|self.?doubt|insecure|not good enough|worthless|useless|loser|ugly|i'?m fat|hate (my looks|my body|myself)|compare myself|feel (small|invisible|awkward)|i'?m (so )?(shy|awkward))\\b")) {
            return if (adviceAsked) pick(listOf("Small steps build confidence: do one thing a day that scares you a little, keep a list of things you did well, and talk to yourself like you would to a friend. If these feelings are heavy or constant, talking to a counsellor can really help.",
                "Try noticing the thought (\"I'm not good enough\"), asking \"is that a fact or a feeling?\", and writing one piece of evidence against it. Progress, not perfection."))
            else say("confidence", pick)
        }
        if (has(l, "\\b(lonely|alone|no friends|no one (cares|likes|talks)|nobody (cares|likes|talks)|isolated|left out|don'?t belong)\\b")) {
            return if (adviceAsked) pick(listOf("Small contact helps: send one short hello to someone today, join one class group or club activity, and plan one regular thing each week. If it stays heavy for weeks, a counsellor can really help.",
                "Try one tiny step: sit near someone you've seen before and say hi, or ask a classmate a simple question. Connection grows from small, repeated moments."))
            else say("lonely", pick)
        }
        if (has(l, "\\b(homesick|miss (my )?(home|mom|mother|dad|father|family|parents|mummy|papa)|miss home)\\b")) {
            return if (adviceAsked) pick(listOf("Set a regular call time with home, keep one small familiar thing around, and make a routine here (a walk, a meal). It usually eases as the new place starts to feel familiar.",
                "It can help to plan your next visit, cook or eat something from home, and tell a friend here that you miss home. Missing home means you're connected, not weak."))
            else say("homesick", pick)
        }
        if (has(l, "\\b(break ?up|broke up|breaking up|dumped|left me|ex (girlfriend|boyfriend|gf|bf)|heartbroken|cheated on me)\\b")) {
            return if (adviceAsked) pick(listOf("Give yourself time. Mute or step back from their chats for a while, lean on friends, keep simple routines (sleep, food, a walk), and avoid big decisions for a few days. It does get lighter.",
                "Write down what you're feeling instead of sending it. Let friends stay close. If it's hard to function for weeks, talking to a counsellor is a good idea."))
            else say("breakup", pick)
        }
        if (has(l, "\\b(anxious|anxiety|panic|panicking|overthinking|worried all the time|can'?t stop thinking|stress(ed)? out|nervous all the time)\\b")) {
            return if (adviceAsked) pick(listOf("Try slow breathing: in for 4, hold 4, out for 6, a few times. Write the worries down, circle what you can control, and do one small thing about it. If it keeps happening, a counsellor or doctor can help a lot.",
                "Ground yourself: name 5 things you see, 4 you can touch, 3 you hear. Then drink some water. Worries shrink when you give them a plan."))
            else say("anxious", pick)
        }
        if (has(l, "\\b(so angry|very angry|really angry|i'?m furious|i hate (him|her|them)|fed up|frustrated|pissed off|losing my temper)\\b")) {
            return if (adviceAsked) pick(listOf("Pause before you reply: breathe slowly, drink water, and walk if you can. Say what you feel after you've calmed down, using \"I feel...\" sentences. Anger is okay, hurting others or yourself is not.",
                "Give it ten minutes away from the situation. Then write what happened and what you actually want to change. Talking to a friend before you react often helps."))
            else say("anger", pick)
        }
        // an ongoing personal topic: short follow-ups ("she ignored me", "ok", "hmm") stay in the conversation
        if (topicTurns > 0 && lastTopic.isNotEmpty() && !toolLike(l)) {
            if (has(l, leaveRe)) { topicTurns = 0; lastTopic = ""; return "You're welcome 💜 I'm here any time you want to talk." }
            topicTurns--
            return if (adviceAsked || has(l, "^(some )?(advice|tips?|suggestions?|ideas?)\\b")) pick(stickyAdvice[lastTopic] ?: listOf("Take it one small step at a time, and talk to someone you trust about it."))
            else say(lastTopic, pick)
        }
        return null
    }

    private var lastTopic = ""
    private var topicTurns = 0
    private val leaveRe = "^(thanks|thank you|thx|bye|good ?night|that'?s all|thats all|nothing|never ?mind|change (the )?(topic|subject)|let'?s talk about something else|i'?m (fine|ok|okay) now|enough)\\b"
    private fun toolLike(l: String) = has(l, "^(hi+|hello+|hey+|heyy+|yo|sup|wassup|what'?s up|whats up|good (morning|afternoon|evening)|what'?s the|whats the|what is the|what time|who is|who was|when is|where is|how much|how many|tell me a|open |set |remind|alarm|timer|weather|joke|play |call |calculate|study|note |todo|spent|show )")
    private val stickyAdvice: Map<String, List<String>> = mapOf(
        "friends" to listOf("When you're both calm, say what hurt without blaming, and listen to their side. A short honest message often opens the door."),
        "family" to listOf("Pick a calm moment, start with what they want for you, then explain your plan in small steps they can see."),
        "confidence" to listOf("Do one small thing a day that scares you a little, keep a list of things you did well, and speak to yourself like a friend."),
        "lonely" to listOf("Send one short hello to someone today, and join one small activity each week. Connection grows from small repeated moments."),
        "homesick" to listOf("Set a regular call time with home, keep a familiar thing near you, and build a small routine here. It usually eases with time."),
        "breakup" to listOf("Step back from their chats for a while, lean on friends, keep sleep and meals steady, and avoid big decisions for a few days."),
        "anxious" to listOf("Try slow breathing (in 4, hold 4, out 6), write the worry down, and pick one small thing you can do about it."),
        "anger" to listOf("Take ten minutes away, breathe slowly, and speak once you've calmed down using \"I feel...\" sentences."),
        "crush" to listOf("Get to know them as a friend first, notice how they respond, and when you feel ready, tell them honestly and kindly.")
    )
    /** True while a personal topic is still open, so replies stay on the phone and aren't hijacked by commands or the AI. */
    fun topicOpen(raw: String) = topicTurns > 0 && lastTopic.isNotEmpty() && !toolLike(raw.lowercase())

    private val recentReplies = ArrayDeque<String>()
    /** A listening reply for a topic from [PersonalBank], not repeating a recent one. */
    fun say(topic: String, pick: (List<String>) -> String): String {
        lastTopic = topic; topicTurns = 5
        val r = PersonalBank.listen(topic, pick, recentReplies.toSet())
        recentReplies.addLast(r); while (recentReplies.size > 40) recentReplies.removeFirst()
        return r
    }
}
