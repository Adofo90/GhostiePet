package com.ghostie.pet

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable

/** Colours used by the app screens, the chat box and the call screen. Glass versions carry transparency. */
class Palette(
    val bg: Int, val card: Int, val stroke: Int, val field: Int, val text: Int, val sub: Int,
    val accent: Int, val onAccent: Int, val good: Int, val bubble: Int, val glass: Boolean, val bgTop: Int, val level: Int = 50
) {
    /** Window / screen background: a soft gradient for glass (so the see-through cards have something to show), solid otherwise. */
    fun background(): Drawable =
        if (glass) GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(bgTop, bg)) else GradientDrawable().apply { setColor(bg) }
}

object Themes {
    private class Base(val id: String, val label: String, val bg: String, val card: String, val stroke: String, val field: String,
                       val text: String, val sub: String, val accent: String, val light: Boolean = false, val onAccent: String = "#FFFFFF")

    private val bases = listOf(
        Base("midnight", "Midnight purple", "#170E2B", "#241640", "#3A2763", "#1B1033", "#F3ECFF", "#B9A8D9", "#A978E8"),
        Base("ocean", "Ocean blue", "#08141F", "#0F2536", "#1D4663", "#0A1B2A", "#E6F4FF", "#8FB4CE", "#3AA7E8"),
        Base("forest", "Forest green", "#0C1A12", "#14291C", "#25472F", "#0F2016", "#E8F6EC", "#96B8A0", "#4CC27A"),
        Base("rose", "Rose pink", "#2A0F1D", "#3A1628", "#5C2842", "#260C18", "#FFEAF2", "#D9A3BC", "#F06FA6"),
        Base("sunset", "Sunset orange", "#2B1408", "#3D1E0D", "#63351A", "#240F05", "#FFF1E6", "#D9B091", "#FF8A3D"),
        Base("bw", "Black & white", "#000000", "#141414", "#FFFFFF", "#0A0A0A", "#FFFFFF", "#BDBDBD", "#FFFFFF", onAccent = "#000000"),
        Base("wb", "White & black", "#FFFFFF", "#F1F1F1", "#111111", "#FFFFFF", "#111111", "#555555", "#111111", light = true)
    )

    val labels get() = bases.map { it.label }
    val ids get() = bases.map { it.id }

    /** Accent colours the user can pick over the theme's own. First entry = keep the theme's colour. */
    val accentLabels = listOf("Theme default", "Purple", "Blue", "Green", "Pink", "Orange", "Red", "Yellow", "Teal")
    private val accentHex = listOf("", "#A978E8", "#3AA7E8", "#4CC27A", "#F06FA6", "#FF8A3D", "#E5484D", "#F5C542", "#2EC4B6")

    private fun c(h: String) = Color.parseColor(h)
    private fun alpha(color: Int, a: Int) = Color.argb(a, Color.red(color), Color.green(color), Color.blue(color))
    private fun mix(a: Int, b: Int, t: Float) = Color.rgb(
        (Color.red(a) * (1 - t) + Color.red(b) * t).toInt(), (Color.green(a) * (1 - t) + Color.green(b) * t).toInt(), (Color.blue(a) * (1 - t) + Color.blue(b) * t).toInt())

    fun palette(s: SettingsStore): Palette = build(s.theme, s.glass, s.accentChoice, s.glassLevel)

    private fun lerp(a: Int, b: Int, t: Float) = (a + (b - a) * t).toInt()

    /** [level] 0..100: how glassy. Higher = clearer panels, stronger edge light (and more blur on the chat box). */
    fun build(themeId: String, glass: Boolean, accentIdx: Int, level: Int = 50): Palette {
        val t = level.coerceIn(0, 100) / 100f
        val b = bases.firstOrNull { it.id == themeId } ?: bases[0]
        var accent = c(b.accent)
        var onAccent = c(b.onAccent)
        if (accentIdx in 1 until accentHex.size) {
            accent = c(accentHex[accentIdx])
            val lum = (0.299 * Color.red(accent) + 0.587 * Color.green(accent) + 0.114 * Color.blue(accent)) / 255
            onAccent = if (lum > 0.62) Color.BLACK else Color.WHITE
        }
        val bg = c(b.bg)
        val text = c(b.text)
        val bwStroke = b.id == "bw" || b.id == "wb"
        if (!glass) {
            return Palette(bg, c(b.card), c(b.stroke), c(b.field), text, c(b.sub), accent, onAccent, c("#7BE0A4").let { if (b.light) c("#1E8E4E") else it },
                if (b.light) c("#E4E4E4") else if (bwStroke) c("#2A2A2A") else c(b.stroke), false, bg)
        }
        // Glass: translucent tinted panels with a bright hairline over a gradient that carries the accent.
        val tint = if (b.light) Color.WHITE else Color.WHITE
        val top = if (b.light) mix(Color.WHITE, accent, 0.35f) else mix(bg, accent, 0.45f)
        return Palette(
            bg = if (b.light) mix(Color.WHITE, accent, 0.12f) else mix(bg, Color.BLACK, 0.3f),
            card = alpha(tint, if (b.light) lerp(0xDD, 0x40, t) else lerp(0x55, 0x0D, t)),
            stroke = alpha(tint, if (b.light) lerp(0x80, 0xE0, t) else lerp(0x40, 0x90, t)),
            field = alpha(if (b.light) Color.WHITE else Color.BLACK, if (b.light) lerp(0xE0, 0x60, t) else lerp(0x66, 0x22, t)),
            text = text, sub = c(b.sub), accent = accent, onAccent = onAccent, good = c(if (b.light) "#1E8E4E" else "#7BE0A4"),
            bubble = alpha(tint, if (b.light) lerp(0xA0, 0x50, t) else lerp(0x50, 0x20, t)), glass = true, bgTop = top, level = level
        )
    }
}
