package com.ghostie.pet

/**
 * Which apps count as "protected" for the Privacy Shield. Pure logic (no Android calls) so it can be unit-tested.
 * Only package NAMES are compared; Ghostie never reads anything on screen.
 */
object ShieldPolicy {
    /** Well-known payment and banking apps (best effort; the list can be extended from the app). */
    val defaults: Map<String, String> = linkedMapOf(
        "com.google.android.apps.nbu.paisa.user" to "Google Pay",
        "com.phonepe.app" to "PhonePe",
        "net.one97.paytm" to "Paytm",
        "in.org.npci.upiapp" to "BHIM",
        "com.dreamplug.androidapp" to "CRED",
        "com.freecharge.android" to "Freecharge",
        "com.mobikwik_new" to "MobiKwik",
        "com.sbi.lotusintouch" to "YONO SBI",
        "com.sbi.SBIFreedomPlus" to "YONO Lite SBI",
        "com.snapwork.hdfc" to "HDFC Bank",
        "com.enstage.wibmo.hdfc" to "HDFC PayZapp",
        "com.csam.icici.bank.imobile" to "ICICI iMobile",
        "com.axis.mobile" to "Axis Mobile",
        "com.upi.axisbank" to "Axis Pay",
        "com.msf.kbank.mobile" to "Kotak Bank",
        "com.bankofbaroda.mconnect" to "Bank of Baroda",
        "com.canarabank.mobility" to "Canara Bank",
        "com.idbibank.abhay.app" to "IDBI Bank",
        "com.infrasofttech.indianbankmobilebanking" to "Indian Bank",
        "com.pnb.onestop" to "PNB ONE"
    )

    /** Parses the saved one-package-per-line text. */
    fun parse(text: String): Set<String> = text.lines().map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    /** True if any dot-separated part of the package name contains the word "bank". */
    fun looksLikeBank(pkg: String): Boolean = pkg.lowercase().split('.').any { it.contains("bank") }

    /**
     * @param custom   packages the user added
     * @param removed  default packages the user switched off
     * @param guessBanks also protect any package that looks like a bank app
     */
    fun isProtected(pkg: String?, custom: Set<String>, removed: Set<String>, guessBanks: Boolean): Boolean {
        if (pkg.isNullOrEmpty()) return false
        if (pkg in custom) return true
        if (pkg in removed) return false
        if (pkg in defaults) return true
        return guessBanks && looksLikeBank(pkg)
    }
}
