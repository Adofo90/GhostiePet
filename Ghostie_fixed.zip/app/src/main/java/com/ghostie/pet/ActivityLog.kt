package com.ghostie.pet

import android.content.Context
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Small on-device diary of what Ghostie did, so problems are easy to diagnose. Never leaves the phone. */
object ActivityLog {
    private const val MAX = 80
    data class Line(val time: Long, val source: String, val msg: String) {
        fun text(): String = Instant.ofEpochMilli(time).atZone(ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("d MMM HH:mm", Locale.ENGLISH)) + "  " + source + ": " + msg
    }

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("ghostie_log", Context.MODE_PRIVATE)

    @Synchronized
    fun add(ctx: Context, source: String, msg: String) {
        val line = System.currentTimeMillis().toString() + "\t" + source + "\t" + msg.replace(Regex("[\\t\\r\\n]+"), " ").take(200)
        val cur = (prefs(ctx).getString("lines", "") ?: "").lines().filter { it.isNotBlank() }
        prefs(ctx).edit().putString("lines", (cur + line).takeLast(MAX).joinToString("\n")).apply()
    }

    @Synchronized
    fun read(ctx: Context): List<Line> = (prefs(ctx).getString("lines", "") ?: "").lines().mapNotNull {
        val parts = it.split('\t', limit = 3)
        if (parts.size < 3) null else parts[0].toLongOrNull()?.let { t -> Line(t, parts[1], parts[2]) }
    }.reversed()

    fun lastTime(ctx: Context, source: String): Long? = read(ctx).firstOrNull { it.source == source }?.time

    @Synchronized
    fun clear(ctx: Context) {
        prefs(ctx).edit().remove("lines").apply()
    }
}
