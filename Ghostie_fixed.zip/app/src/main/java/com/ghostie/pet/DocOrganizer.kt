package com.ghostie.pet

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.concurrent.Executors

/** Copies WhatsApp documents into Documents/Ghostie/<Subject>/. Originals are never touched. */
object DocOrganizer {
    data class Result(
        val perSubject: Map<String, Int>,
        val alreadyThere: Int,
        val failed: Int,
        val foundFolders: Int,
        val total: Int,
        val readContent: Int = 0
    )

    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    fun sourceFolders(): List<File> {
        val root = Environment.getExternalStorageDirectory()
        val list = mutableListOf<File>()
        // Android 11+: WhatsApp keeps its files under Android/media. Older phones: /WhatsApp.
        for ((pkg, app, docs) in listOf(
            Triple("com.whatsapp", "WhatsApp", "WhatsApp Documents"),
            Triple("com.whatsapp.w4b", "WhatsApp Business", "WhatsApp Business Documents")
        )) {
            list.add(File(root, "Android/media/$pkg/$app/Media/$docs"))
            list.add(File(root, "$app/Media/$docs"))
        }
        return list.filter { it.isDirectory }
    }

    private fun safeFolderName(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|]"), "-").trim().ifEmpty { SubjectMatcher.UNSORTED }

    private fun uniqueTarget(dir: File, name: String): File {
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var n = 1
        var f = File(dir, "$base ($n)$ext")
        while (f.exists()) {
            n++
            f = File(dir, "$base ($n)$ext")
        }
        return f
    }

    /**
     * force = true re-checks every file (manual "organize now"). force = false skips files already handled,
     * which keeps automatic runs fast.
     * Order of clues: file name, then the WhatsApp chat it came from, then the first page of the document itself.
     */
    fun organize(ctx: Context, force: Boolean = true): Result {
        val s = SettingsStore(ctx)
        val subjects = SubjectMatcher.parse(s.subjects)
        val folders = sourceFolders()
        val dest = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "Ghostie")
        val done = s.loadProcessedDocs()
        val counts = linkedMapOf<String, Int>()
        var already = 0
        var failed = 0
        var total = 0
        var content = 0
        fun isFallback(name: String) = subjects.firstOrNull { it.name == name }?.fallback == true

        for (folder in folders) {
            val files = folder.walkTopDown().maxDepth(2).filter { it.isFile && !it.name.startsWith(".") }
            for (f in files) {
                val key = f.name + "|" + f.length()
                if (!force && key in done) continue
                total++
                try {
                    var subject = SubjectMatcher.classify(f.name, subjects)
                    if (subject == SubjectMatcher.UNSORTED || isFallback(subject)) {
                        val group = s.groupOfDoc(f.name)
                        if (group != null) {
                            val g = SubjectMatcher.classify(group, subjects)
                            if (g != SubjectMatcher.UNSORTED && !isFallback(g)) subject = g
                        }
                    }
                    if (subject == SubjectMatcher.UNSORTED || isFallback(subject)) {
                        val sample = DocText.sample(f)
                        if (sample.isNotBlank()) {
                            val c = SubjectMatcher.classify(sample, subjects, 2)
                            if (c != SubjectMatcher.UNSORTED && !isFallback(c)) {
                                subject = c
                                content++
                            }
                        }
                    }
                    val folderName = safeFolderName(subject)
                    val dir = File(dest, folderName)
                    dir.mkdirs()
                    val target = File(dir, f.name)
                    when {
                        !target.exists() -> f.copyTo(target)
                        target.length() == f.length() -> {
                            already++
                            done.add(key)
                            continue
                        }
                        else -> f.copyTo(uniqueTarget(dir, f.name))
                    }
                    done.add(key)
                    counts[folderName] = (counts[folderName] ?: 0) + 1
                } catch (e: Exception) {
                    failed++
                }
            }
        }
        s.saveProcessedDocs(done)
        return Result(counts, already, failed, folders.size, total, content)
    }

    /** Finds the Ghostie/<Subject> folder that best matches what the user typed. */
    fun listSubject(query: String, subjectsText: String): Pair<String, List<File>>? {
        val root = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "Ghostie")
        if (!root.isDirectory) return null
        val subject = SubjectMatcher.classify(query, SubjectMatcher.parse(subjectsText))
        var dir = File(root, safeFolderName(subject))
        if (subject == SubjectMatcher.UNSORTED || !dir.isDirectory) {
            dir = root.listFiles { f -> f.isDirectory }
                ?.firstOrNull { it.name.contains(query, true) || query.contains(it.name, true) } ?: return null
        }
        val files = dir.listFiles { f -> f.isFile }?.sortedByDescending { it.lastModified() } ?: emptyList()
        return dir.name to files
    }

    fun summary(r: Result): String {
        if (r.foundFolders == 0) {
            return "I couldn't find a WhatsApp documents folder. Open a document in WhatsApp once, or tell me if you use another WhatsApp app."
        }
        if (r.total == 0) return "WhatsApp's documents folder is empty - nothing to organize yet."
        val sb = StringBuilder()
        val copied = r.perSubject.values.sum()
        if (copied == 0) {
            sb.append("Everything is already organized ✅ (${r.alreadyThere} files).")
        } else {
            sb.append("Done! Copied $copied files into Documents/Ghostie:\n")
            r.perSubject.entries.sortedByDescending { it.value }.forEach { sb.append("• ${it.key}: ${it.value}\n") }
            if (r.alreadyThere > 0) sb.append("(${r.alreadyThere} were already there)\n")
            if (r.readContent > 0) sb.append("(${r.readContent} sorted by reading inside the file)\n")
        }
        if (r.failed > 0) sb.append("\n${r.failed} files couldn't be copied.")
        val unsorted = r.perSubject[SubjectMatcher.UNSORTED] ?: 0
        if (unsorted > 0) sb.append("\n$unsorted had no matching subject - add keywords in the Ghostie app to sort them.")
        return sb.toString().trim()
    }
}

/** Runs the organizer in the background when new documents arrive (debounced) and on a timer. */
object AutoOrganizer {
    private val handler = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private var pending: Runnable? = null

    fun request(ctx: Context, delayMs: Long = 20_000L) {
        val app = ctx.applicationContext
        pending?.let { handler.removeCallbacks(it) }
        val r = Runnable { exec.execute { runNow(app) } }
        pending = r
        handler.postDelayed(r, delayMs)
    }

    fun runNow(ctx: Context) {
        try {
            val s = SettingsStore(ctx)
            if (!s.autoOrganize || !DocOrganizer.hasAccess(ctx)) return
            val r = DocOrganizer.organize(ctx, force = false)
            val n = r.perSubject.values.sum()
            if (n > 0) {
                ActivityLog.add(ctx, "Documents", "Auto-sorted $n new file(s): " + r.perSubject.entries.joinToString { "${it.key} ${it.value}" })
                Notifier.post(ctx, "Sorted $n new document(s)", r.perSubject.entries.joinToString("\n") { "• ${it.key}: ${it.value}" })
            }
        } catch (e: Exception) {
            // ignore
        }
    }
}
