package com.ghostie.pet

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import java.io.File

/** Copies WhatsApp documents into Documents/Ghostie/<Subject>/. Originals are never touched. */
object DocOrganizer {
    data class Result(
        val perSubject: Map<String, Int>,
        val alreadyThere: Int,
        val failed: Int,
        val foundFolders: Int,
        val total: Int
    )

    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun sourceFolders(): List<File> {
        val root = Environment.getExternalStorageDirectory()
        val list = mutableListOf<File>()
        // Android 11+: WhatsApp keeps its files under Android/media. Older phones: /WhatsApp.
        for ((pkg, app, docs) in listOf(
            Triple("com.whatsapp", "WhatsApp", "WhatsApp Documents"),
            Triple("com.whatsapp.w4b", "WhatsApp Business", "WhatsApp Business Documents")
        )) {
            list.add(File(root, "Android/media/$pkg/$app/Media/$docs"))
            list.add(File(root, "$app/Media/$docs"))
        }
        return list.filter { it.isDirectory }
    }

    private fun safeFolderName(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|]"), "-").trim().ifEmpty { SubjectMatcher.UNSORTED }

    private fun uniqueTarget(dir: File, name: String): File {
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var n = 1
        var f = File(dir, "$base ($n)$ext")
        while (f.exists()) {
            n++
            f = File(dir, "$base ($n)$ext")
        }
        return f
    }

    fun organize(subjectsText: String): Result {
        val subjects = SubjectMatcher.parse(subjectsText)
        val folders = sourceFolders()
        val dest = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "Ghostie")
        val counts = linkedMapOf<String, Int>()
        var already = 0
        var failed = 0
        var total = 0
        for (folder in folders) {
            val files = folder.walkTopDown().maxDepth(2)
                .filter { it.isFile && !it.name.startsWith(".") }
            for (f in files) {
                total++
                try {
                    val subject = safeFolderName(SubjectMatcher.classify(f.name, subjects))
                    val dir = File(dest, subject)
                    dir.mkdirs()
                    val target = File(dir, f.name)
                    when {
                        !target.exists() -> f.copyTo(target)
                        target.length() == f.length() -> {
                            already++
                            continue
                        }
                        else -> f.copyTo(uniqueTarget(dir, f.name))
                    }
                    counts[subject] = (counts[subject] ?: 0) + 1
                } catch (e: Exception) {
                    failed++
                }
            }
        }
        return Result(counts, already, failed, folders.size, total)
    }

    /** Finds the Ghostie/<Subject> folder that best matches what the user typed. */
    fun listSubject(query: String, subjectsText: String): Pair<String, List<File>>? {
        val root = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "Ghostie")
        if (!root.isDirectory) return null
        val subject = SubjectMatcher.classify(query, SubjectMatcher.parse(subjectsText))
        var dir = File(root, safeFolderName(subject))
        if (subject == SubjectMatcher.UNSORTED || !dir.isDirectory) {
            dir = root.listFiles { f -> f.isDirectory }
                ?.firstOrNull { it.name.contains(query, true) || query.contains(it.name, true) } ?: return null
        }
        val files = dir.listFiles { f -> f.isFile }?.sortedByDescending { it.lastModified() } ?: emptyList()
        return dir.name to files
    }

    fun summary(r: Result): String {
        if (r.foundFolders == 0) {
            return "I couldn't find a WhatsApp documents folder. Open a document in WhatsApp once, or tell me if you use another WhatsApp app."
        }
        if (r.total == 0) return "WhatsApp's documents folder is empty - nothing to organize yet."
        val sb = StringBuilder()
        val copied = r.perSubject.values.sum()
        if (copied == 0) {
            sb.append("Everything is already organized ✅ (${r.alreadyThere} files).")
        } else {
            sb.append("Done! Copied $copied files into Documents/Ghostie:\n")
            r.perSubject.entries.sortedByDescending { it.value }.forEach { sb.append("• ${it.key}: ${it.value}\n") }
            if (r.alreadyThere > 0) sb.append("(${r.alreadyThere} were already there)\n")
        }
        if (r.failed > 0) sb.append("\n${r.failed} files couldn't be copied.")
        val unsorted = r.perSubject[SubjectMatcher.UNSORTED] ?: 0
        if (unsorted > 0) sb.append("\n$unsorted had no matching subject - add keywords in the Ghostie app to sort them.")
        return sb.toString().trim()
    }
}
