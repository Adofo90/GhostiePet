package com.ghostie.pet

/**
 * Subjects a student can tick in Documents. Built from the course lists of Indian engineering colleges (first-year common
 * courses such as Programming for Problem Solving, Basic Electrical Engineering, Physics, Chemistry, Engineering Graphics;
 * CSE/AI-ML schemes with Data Structures, DBMS, OS, DAA, Machine Learning, Java, Python; plus the usual ECE/EEE, Mechanical
 * and Civil courses). Pure Kotlin so it can be tested without Android.
 */
object SubjectCatalog {
    class Entry(val name: String, val keywords: String)
    class Group(val title: String, val entries: List<Entry>)

    private fun e(name: String, kw: String) = Entry(name, kw)

    val groups: List<Group> = listOf(
        Group("Computer & AI", listOf(
            e("C Programming", "c programming, programming in c, c language, programming for problem solving, pps, pointers, structures in c"),
            e("C++ & OOP", "c++, cpp, oop, oops, object oriented, object oriented programming, inheritance, polymorphism"),
            e("Java Programming", "java, jvm, servlet, jsp, java programming, collections framework"),
            e("Python Programming", "python, numpy, pandas, python programming, matplotlib"),
            e("Data Structures (DSA)", "dsa, data structures, data structure, linked list, stacks, queues, trees, graphs, hashing, sorting, searching"),
            e("Algorithms (DAA)", "daa, algorithms, algorithm design, analysis of algorithms, complexity, dynamic programming, greedy, divide and conquer"),
            e("Database Management (DBMS)", "dbms, database, databases, sql, normalization, rdbms, nosql, transactions, er diagram"),
            e("Operating Systems", "os, operating system, operating systems, scheduling, deadlock, paging, semaphores, memory management"),
            e("Computer Networks", "cn, computer networks, computer network, networking, tcp, ip, osi, routing, network layer"),
            e("Computer Organization & Architecture", "coa, computer organization, computer organisation, computer architecture, pipelining, cache memory, instruction set"),
            e("Software Engineering", "software engineering, se, sdlc, uml, agile, software testing, software design"),
            e("Web Development", "web, html, css, javascript, react, node, web technologies, web development, web application, web frameworks"),
            e("Artificial Intelligence", "ai, artificial intelligence, intelligent agents, search algorithms, expert systems, knowledge representation, ai tools"),
            e("Machine Learning", "machine learning, ml, regression, classification, clustering, supervised, unsupervised, ml essentials"),
            e("Deep Learning & NLP", "deep learning, neural networks, neural network, cnn, rnn, transformers, nlp, natural language processing, computer vision"),
            e("Data Science & Visualization", "data science, data analytics, data visualization, data visualisation, tableau, power bi, big data, data mining"),
            e("Theory of Computation & Compilers", "toc, flat, automata, finite automata, formal languages, turing, compiler design, compiler, compilers"),
            e("Cloud, Security & IoT", "cloud, cloud computing, cyber security, cybersecurity, cryptography, network security, iot, internet of things, blockchain, devops"),
            e("Discrete Mathematics", "discrete mathematics, discrete maths, discrete math, graph theory, set theory, boolean algebra, combinatorics, logic")
        )),
        Group("Maths & Science", listOf(
            e("Engineering Mathematics", "maths, math, mathematics, calculus, linear algebra, differential equations, laplace, fourier, complex variables, numerical methods, transforms, matrix, matrices, vectors"),
            e("Probability & Statistics", "probability, statistics, random variables, distributions, hypothesis testing, probability and statistics"),
            e("Physics", "physics, optics, quantum, thermodynamics, laser, semiconductor physics, wave, relativity, engineering physics"),
            e("Chemistry", "chemistry, chem, organic, inorganic, polymer, spectroscopy, electrochemistry, engineering chemistry"),
            e("Biology & Biotechnology", "biology, bio, botany, zoology, genetics, microbiology, biotech, biotechnology, biochemistry"),
            e("Environmental Science", "evs, environmental science, environmental studies, ecology, pollution, sustainability")
        )),
        Group("Electrical & Electronics", listOf(
            e("Basic Electrical Engineering", "bee, basic electrical, electrical engineering, kirchhoff, network theory, circuits, circuit, circuit theory, transformers, electrical"),
            e("Electrical Machines", "electrical machines, dc machines, induction motor, synchronous machines, motor, generator, machines"),
            e("Power Systems", "power systems, power system, transmission, distribution, power generation, switchgear, protection"),
            e("Power Electronics & Drives", "power electronics, drives, converters, inverter, rectifier, chopper"),
            e("Control Systems", "control systems, control system, transfer function, bode, stability, pid, control engineering"),
            e("Analog Electronics", "analog, analog electronics, analogue, op-amp, op amp, amplifiers, bjt, mosfet, electronic devices, electronics devices"),
            e("Digital Electronics", "digital electronics, digital logic, logic gates, flip flops, combinational, sequential circuits, hdl, verilog, vhdl"),
            e("Signals & Systems / DSP", "signals, signals and systems, dsp, digital signal processing, z transform, fft, filters"),
            e("Microprocessors & Embedded", "microprocessor, microprocessors, microcontroller, 8085, 8086, 8051, arm, embedded, embedded systems"),
            e("Communication Systems", "communication systems, communication engineering, modulation, antenna, wireless, microwave, analog communication, digital communication"),
            e("VLSI", "vlsi, cmos, chip design, fabrication, layout"),
            e("Measurements & Instrumentation", "measurements, instrumentation, sensors, transducers, measurement")
        )),
        Group("Mechanical", listOf(
            e("Engineering Graphics & Drawing", "engineering drawing, engineering graphics, graphics, autocad, cad, orthographic, isometric"),
            e("Workshop & Manufacturing", "workshop, manufacturing, manufacturing practice, welding, casting, machining, production"),
            e("Thermodynamics", "thermodynamics, thermal, thermal engineering, entropy, cycles, refrigeration"),
            e("Fluid Mechanics", "fluid, fluid mechanics, hydraulics, pumps, turbines, fluid machinery"),
            e("Engineering Mechanics & Materials", "engineering mechanics, statics, dynamics, strength of materials, mechanics of solids, som, materials"),
            e("Machine Design & Kinematics", "machine design, theory of machines, kinematics, gears, mechanical design, design of machine elements"),
            e("Heat Transfer & IC Engines", "heat transfer, ic engines, internal combustion, conduction, convection, radiation")
        )),
        Group("Civil", listOf(
            e("Structural Analysis & Design", "structural, structural analysis, structures, rcc, steel design, beams, design of structures"),
            e("Surveying", "surveying, levelling, total station, theodolite, gis"),
            e("Concrete & Construction", "concrete, construction, building materials, construction materials, civil, construction management"),
            e("Geotechnical Engineering", "geotechnical, soil mechanics, foundation, foundations, geotech"),
            e("Water Resources & Transportation", "hydrology, water resources, irrigation, transportation, highway, traffic, environmental engineering")
        )),
        Group("Chemical Engineering", listOf(
            e("Chemical Engineering", "chemical engineering, mass transfer, reaction engineering, process control, process engineering, unit operations")
        )),
        Group("Humanities & Management", listOf(
            e("English & Communication", "english, communication skills, technical english, grammar, literature, essay, technical writing, soft skills, english for technical writing"),
            e("Human Values & Ethics", "human values, universal human values, professional ethics, ethics, uhv, values"),
            e("Economics", "economics, micro economics, macroeconomics, managerial economics, engineering economics"),
            e("Management & Entrepreneurship", "management, entrepreneurship, startup, marketing, business, hr, organisational behaviour, principles of management"),
            e("Accounting & Finance", "accounts, accounting, finance, financial management, costing, banking"),
            e("Law & Constitution", "law, constitution, indian constitution, cyber law, ipr, intellectual property")
        ))
    )

    /** Handy extras: exam papers and lab/assignment files, used only when no chosen subject matches. */
    const val EXTRAS = "*Exams & Timetable: timetable, time table, schedule, syllabus, exam, question paper, previous year, pyq, qp, results, hall ticket, admit card, notice, circular, calendar\n" +
        "*Assignments & Labs: assignment, lab, record, practical, experiment, manual, report, project, worksheet"

    fun allNames(): List<String> = groups.flatMap { g -> g.entries.map { it.name } }

    /** Subject lines for the matcher: ticked subjects, the person's own lines, and (optionally) the exam/assignment categories. */
    fun build(picks: Set<String>, custom: String, extras: Boolean): String {
        val lines = ArrayList<String>()
        for (g in groups) for (en in g.entries) if (en.name in picks) lines.add(en.name + ": " + en.keywords)
        for (l in custom.lines()) if (l.isNotBlank() && l.contains(':')) lines.add(l.trim())
        if (extras) lines.add(EXTRAS)
        return lines.joinToString("\n")
    }

    fun parsePicks(text: String): Set<String> = text.split('|').map { it.trim() }.filter { it.isNotEmpty() }.toSet()
}
