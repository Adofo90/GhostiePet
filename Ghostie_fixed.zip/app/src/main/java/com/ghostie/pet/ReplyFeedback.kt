package com.ghostie.pet

import android.content.Context

/** Remembers which generated replies you liked or disliked, so thumbs-up phrases come back and thumbs-down ones don't. */
class ReplyFeedback(private val ctx: Context) : ReplyBank.Feedback {
    private val p get() = ctx.getSharedPreferences("ghostie", Context.MODE_PRIVATE)

    private fun banned(): MutableSet<String> = (p.getStringSet("rb_banned", emptySet()) ?: emptySet()).toMutableSet()
    private fun scores(): MutableMap<String, Int> =
        (p.getString("rb_parts", "") ?: "").split(';').filter { it.contains('=') }.associate { it.substringBefore('=') to (it.substringAfter('=').toIntOrNull() ?: 0) }.toMutableMap()

    override fun isBanned(text: String) = text.hashCode().toString() in banned()

    override fun weight(partId: String): Int = when (val s = scores()[partId] ?: 0) {
        in Int.MIN_VALUE..-3 -> 0     // disliked three times: stop using this phrase
        -2, -1 -> 1
        0 -> 2
        else -> 2 + s * 2             // liked: used noticeably more
    }

    private fun save(sc: Map<String, Int>) { p.edit().putString("rb_parts", sc.entries.joinToString(";") { "${it.key}=${it.value}" }).apply() }

    fun like(r: ReplyBank.Result) {
        val sc = scores(); r.parts.forEach { sc[it] = ((sc[it] ?: 0) + 1).coerceAtMost(4) }; save(sc)
    }

    fun dislike(r: ReplyBank.Result) {
        val b = banned(); b.add(r.text.hashCode().toString())
        if (b.size > 400) b.remove(b.first())
        p.edit().putStringSet("rb_banned", b).apply()
        val sc = scores(); r.parts.forEach { sc[it] = ((sc[it] ?: 0) - 1).coerceAtLeast(-4) }; save(sc)
    }

    fun clear() { p.edit().remove("rb_banned").remove("rb_parts").apply() }
}
