package com.ghostie.pet

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** One-file backup of everything you typed or taught Ghostie (timetable, attendance, exams, cards, alarms, settings, learned phrases). */
object Backup {
    private const val PREFS = "ghostie"

    fun export(ctx: Context): String {
        val o = JSONObject()
        o.put("ghostie_backup", 1)
        val data = JSONObject()
        for ((k, v) in ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).all) {
            when (v) {
                is String -> data.put(k, JSONObject().put("t", "s").put("v", v))
                is Int -> data.put(k, JSONObject().put("t", "i").put("v", v))
                is Long -> data.put(k, JSONObject().put("t", "l").put("v", v))
                is Boolean -> data.put(k, JSONObject().put("t", "b").put("v", v))
                is Float -> data.put(k, JSONObject().put("t", "f").put("v", v.toDouble()))
                is Set<*> -> data.put(k, JSONObject().put("t", "set").put("v", JSONArray(v.map { it.toString() })))
            }
        }
        o.put("prefs", data)
        return o.toString()
    }

    /** Returns how many entries were restored, or -1 if the file isn't a Ghostie backup. */
    fun import(ctx: Context, text: String): Int {
        val o = try { JSONObject(text) } catch (e: Exception) { return -1 }
        if (!o.has("ghostie_backup")) return -1
        val data = o.optJSONObject("prefs") ?: return -1
        val ed = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        var n = 0
        for (k in data.keys()) {
            val e = data.getJSONObject(k)
            when (e.getString("t")) {
                "s" -> ed.putString(k, e.getString("v"))
                "i" -> ed.putInt(k, e.getInt("v"))
                "l" -> ed.putLong(k, e.getLong("v"))
                "b" -> ed.putBoolean(k, e.getBoolean("v"))
                "f" -> ed.putFloat(k, e.getDouble("v").toFloat())
                "set" -> { val a = e.getJSONArray("v"); ed.putStringSet(k, (0 until a.length()).map { a.getString(it) }.toSet()) }
                else -> continue
            }
            n++
        }
        ed.commit()
        Student.reset()
        AlarmStore.rescheduleAll(ctx)
        return n
    }
}
