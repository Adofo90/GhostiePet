package com.ghostie.pet

/** Cleans up what speech recognition writes so the same commands work by voice: "six thirty a.m." -> "6:30 am". */
object Spoken {
    private val ones = mapOf("one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7, "eight" to 8,
        "nine" to 9, "ten" to 10, "eleven" to 11, "twelve" to 12)
    private val tens = mapOf("twenty" to 20, "thirty" to 30, "forty" to 40, "fifty" to 50)
    private val teens = mapOf("ten" to 10, "eleven" to 11, "twelve" to 12, "thirteen" to 13, "fourteen" to 14, "fifteen" to 15,
        "sixteen" to 16, "seventeen" to 17, "eighteen" to 18, "nineteen" to 19)

    private val hourWords = ones.keys.joinToString("|")
    private val minuteWords: String = run {
        val units = ones.keys.filter { ones[it]!! < 10 }.joinToString("|")
        val tensW = tens.keys.joinToString("|")
        "(?:(?:$tensW)(?:[ -](?:$units))?|${teens.keys.joinToString("|")}|(?:oh|o|zero) (?:$units))"
    }

    private fun minutes(w: String): Int {
        val p = w.split(' ', '-').filter { it.isNotEmpty() }
        return when {
            p.size == 2 && p[0] in listOf("oh", "o", "zero") -> ones[p[1]] ?: 0
            p.size == 1 && p[0] in teens -> teens[p[0]]!!
            p.size == 1 && p[0] in tens -> tens[p[0]]!!
            p.size == 2 -> (tens[p[0]] ?: 0) + (ones[p[1]] ?: 0)
            else -> 0
        }
    }

    fun normalize(raw: String): String {
        var t = raw.trim()
        t = t.replace(Regex("\\b([ap])\\.?\\s?m\\.?(?=\\W|$)", RegexOption.IGNORE_CASE)) { it.groupValues[1].lowercase() + "m" }
        val lo = t.lowercase()
        t = lo
        // "7 32 am", "7.32 am", "732 am" -> "7:32 am"
        t = t.replace(Regex("\\b(\\d{1,2})[ .](\\d{2})\\s?(am|pm)\\b")) { "${it.groupValues[1]}:${it.groupValues[2]} ${it.groupValues[3]}" }
        t = t.replace(Regex("\\b(\\d{1,2})(\\d{2})\\s?(am|pm)\\b")) { m -> if (m.groupValues[2].toInt() < 60 && m.groupValues[1].toInt() in 1..12) "${m.groupValues[1]}:${m.groupValues[2]} ${m.groupValues[3]}" else m.value }
        t = t.replace(Regex("\\bflash ?cards?\\b"), "flashcard")
        t = t.replace(Regex("^(card|flashcard)\\b(.*?)\\b(equals|equal to)\\b"), "$1$2=")
        t = t.replace(Regex("^(?:please )?wake me(?: up)? (?:at|by|for)\\b"), "alarm at")
        // "half past six", "quarter past six", "quarter to seven"
        t = t.replace(Regex("\\bhalf past ($hourWords)\\b")) { "${ones[it.groupValues[1]]}:30" }
        t = t.replace(Regex("\\bquarter past ($hourWords)\\b")) { "${ones[it.groupValues[1]]}:15" }
        t = t.replace(Regex("\\bquarter to ($hourWords)\\b")) { "${((ones[it.groupValues[1]]!! + 10) % 12) + 1}:45" }
        // "seven o'clock"
        t = t.replace(Regex("\\b($hourWords) o[' ]?clock\\b")) { "${ones[it.groupValues[1]]}:00" }
        // "six thirty", "seven oh five", "six forty five"
        t = t.replace(Regex("\\b($hourWords) ($minuteWords)\\b")) { m -> "${ones[m.groupValues[1]]}:%02d".format(minutes(m.groupValues[2])) }
        // a bare hour after "alarm"/"at"/"for", e.g. "alarm at seven am"
        t = t.replace(Regex("\\b(alarm|at|for)( (?:me )?(?:at |for )?)($hourWords)\\b(?= ?(?:am|pm|in the|on|every|daily|weekdays|weekends|$))")) {
            "${it.groupValues[1]}${it.groupValues[2]}${ones[it.groupValues[3]]}"
        }
        return t.trim().trimEnd('.', ',', '?', '!')
    }
}
