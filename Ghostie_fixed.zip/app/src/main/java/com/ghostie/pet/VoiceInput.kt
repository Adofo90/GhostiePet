package com.ghostie.pet

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Listens only when asked (hold the ghost, or tap the mic) and switches the microphone off straight after,
 * so it costs almost no battery. Prefers on-device recognition when the phone has it.
 * Result callbacks: [onText] gets the sentence; [onState] gets "partial:<text>", "nomatch" or "error".
 */
class VoiceInput(
    private val ctx: Context,
    private val onText: (String) -> Unit,
    private val onState: (String) -> Unit
) {
    private var rec: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    var active = false
        private set

    private val timeout = Runnable { finish(cancel = true); onState("nomatch") }

    fun hasMic() = ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    fun available() = SpeechRecognizer.isRecognitionAvailable(ctx)

    /** Returns false if listening can't start here (no permission or no recognition service). */
    fun start(): Boolean {
        if (active) return true
        if (!hasMic() || !available()) return false
        return try {
            val r = if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx)) {
                SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx)
            } else {
                SpeechRecognizer.createSpeechRecognizer(ctx)
            }
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { onState("ready") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onPartialResults(partialResults: Bundle?) {
                    partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { onState("partial:$it") }
                }

                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    finish(cancel = false)
                    if (text.isBlank()) onState("nomatch") else onText(text)
                }

                override fun onError(error: Int) {
                    finish(cancel = false)
                    onState(if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) "nomatch" else "error")
                }
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, SettingsStore(ctx).speechTag)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1300L)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
            rec = r
            active = true
            r.startListening(i)
            handler.postDelayed(timeout, 12_000L) // never leave the mic open
            true
        } catch (e: Exception) {
            finish(cancel = true)
            false
        }
    }

    /** User let go: finish and deliver what was heard. */
    fun stop() {
        if (active) try { rec?.stopListening() } catch (e: Exception) { finish(cancel = true) }
    }

    fun cancel() = finish(cancel = true)

    private fun finish(cancel: Boolean) {
        handler.removeCallbacks(timeout)
        active = false
        val r = rec
        rec = null
        try {
            if (cancel) r?.cancel()
            r?.destroy()
        } catch (e: Exception) {
            // already gone
        }
    }
}
