package com.ghostie.pet

import java.time.LocalDateTime

/**
 * Ghostie's decision-maker. Looks at deadlines, study history and learned habits and proposes at most one
 * useful thing at a time. The user approves with a chip; the answers feed back into [Habits].
 * Pure Kotlin, so it can be tested without a phone.
 */
object Agent {
    data class Deadline(val label: String, val daysLeft: Long)

    data class Snapshot(
        val now: LocalDateTime,
        val deadlines: List<Deadline>,
        /** minutes studied per subject (lowercase) in the last 7 days */
        val subjectMin7: Map<String, Int>,
        val studiedToday: Int,
        val streak: Int,
        val studyActive: Boolean,
        val habits: Habits,
        val defaultFocus: Int,
        /** keys suggested in the last 24 hours */
        val recentKeys: Set<String>,
        val suggestedToday: Int,
        val lastSuggestionAtMs: Long
    )

    sealed class Action {
        data class Study(val subject: String?, val focus: Int) : Action()
        data class QuietHours(val hours: List<Int>) : Action()
    }

    data class Suggestion(val type: String, val key: String, val text: String, val yes: String, val action: Action)

    private const val MAX_PER_DAY = 2
    private const val GAP_MS = 3 * 3_600_000L

    fun whenText(days: Long) = when {
        days <= 0L -> "today"
        days == 1L -> "tomorrow"
        else -> "in $days days"
    }

    fun decide(s: Snapshot, nowMs: Long): Suggestion? {
        if (s.studyActive) return null
        if (s.now.hour !in 8..22) return null
        if (s.suggestedToday >= MAX_PER_DAY) return null
        if (nowMs - s.lastSuggestionAtMs < GAP_MS) return null
        val h = s.habits
        val focus = h.bestFocus() ?: s.defaultFocus

        fun ok(type: String, key: String) = !h.isMuted(type, nowMs) && key !in s.recentKeys

        // 1. A close deadline for a subject you haven't studied lately
        val urgent = s.deadlines.filter { it.daysLeft in 0..3 }
            .map { it to (s.subjectMin7[it.label.lowercase()] ?: 0) }
            .filter { it.second < 30 }
            .minWithOrNull(compareBy({ it.first.daysLeft }, { it.second }))
        if (urgent != null) {
            val (d, mins) = urgent
            val key = "deadline:${d.label.lowercase()}:${s.now.toLocalDate()}"
            if (ok("deadlines", key)) {
                val studied = if (mins == 0) "haven't studied it this week" else "studied it only $mins min this week"
                return Suggestion("deadlines", key, "📌 ${d.label} is due ${whenText(d.daysLeft)} and you $studied. Start a $focus min block for it?", "Yes, start ⏱️", Action.Study(d.label, focus))
            }
        }
        // 2. Your usual study time
        val usual = h.usualStudyHour()
        if (usual != null && s.now.hour == usual && s.studiedToday == 0) {
            val key = "routine:${s.now.toLocalDate()}"
            if (ok("routine", key)) return Suggestion("routine", key, "⏰ It's about your usual study time. Start a $focus min focus block?", "Yes, start ⏱️", Action.Study(null, focus))
        }
        // 3. Keep the streak alive
        if (s.streak >= 2 && s.studiedToday == 0 && s.now.hour in 18..22) {
            val key = "streak:${s.now.toLocalDate()}"
            if (ok("streak", key)) return Suggestion("streak", key, "🔥 You're on a ${s.streak}-day study streak. One $focus min block keeps it alive!", "Yes, start ⏱️", Action.Study(null, focus))
        }
        // 4. Visit less at hours you never answer
        val quiet = h.quietCandidates()
        if (quiet.isNotEmpty()) {
            val key = "quiet:${s.now.toLocalDate().toEpochDay() / 7}"
            if (ok("quiet hours", key)) return Suggestion("quiet hours", key, "🤫 I've noticed you rarely answer my visits around ${h.rangeText(quiet)}. Want me to stay quiet then?", "Yes, stay quiet", Action.QuietHours(quiet))
        }
        return null
    }
}

/** A simple study plan for the next days. Pure Kotlin. */
object Planner {
    data class Item(val dayOffset: Int, val label: String, val minutes: Int)

    fun plan(deadlines: List<Agent.Deadline>, subjectMin7: Map<String, Int>, focus: Int, days: Int = 7, maxPerDay: Int = 2): List<Item> {
        val queue = ArrayDeque<Pair<String, Long>>()
        for (d in deadlines.filter { it.daysLeft in 0..14 }.sortedBy { it.daysLeft }) {
            val want = when {
                d.daysLeft <= 1 -> 3
                d.daysLeft <= 3 -> 2
                d.daysLeft <= 7 -> 2
                else -> 1
            }
            val have = (subjectMin7[d.label.lowercase()] ?: 0) / focus.coerceAtLeast(1)
            repeat((want - have).coerceAtLeast(0)) { queue.add(d.label to d.daysLeft) }
        }
        val items = mutableListOf<Item>()
        val perDay = IntArray(days)
        for ((label, due) in queue) {
            // earliest day with room, but never after the deadline day
            val last = minOf(due.toInt(), days - 1).coerceAtLeast(0)
            val day = (0..last).firstOrNull { perDay[it] < maxPerDay } ?: continue
            perDay[day]++
            val existing = items.indexOfFirst { it.dayOffset == day && it.label == label }
            if (existing >= 0) items[existing] = items[existing].copy(minutes = items[existing].minutes + focus)
            else items.add(Item(day, label, focus))
        }
        return items.sortedWith(compareBy({ it.dayOffset }, { it.label }))
    }

    fun format(items: List<Item>, today: java.time.LocalDate, usualHour: Int?): String {
        if (items.isEmpty()) return "Nothing urgent in the next days 🎉 Want to use the time for a study block anyway? Say \"study 25\"."
        val fmt = java.time.format.DateTimeFormatter.ofPattern("EEE d MMM", java.util.Locale.ENGLISH)
        val at = usualHour?.let { " around " + Habits().hourText(it) } ?: ""
        val sb = StringBuilder("Here's a plan 📋\n")
        for ((day, group) in items.groupBy { it.dayOffset }) {
            val name = when (day) { 0 -> "Today"; 1 -> "Tomorrow"; else -> today.plusDays(day.toLong()).format(fmt) }
            sb.append("• $name$at: ").append(group.joinToString(", ") { "${it.label} (${it.minutes} min)" }).append('\n')
        }
        return sb.toString().trimEnd()
    }
}
