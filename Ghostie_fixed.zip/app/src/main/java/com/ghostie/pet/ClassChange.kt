package com.ghostie.pet

/** Spots "class cancelled / moved / room changed / now online" messages in a group chat. Pure Kotlin. */
object ClassChange {
    enum class Kind(val label: String) { CANCELLED("cancelled"), RESCHEDULED("rescheduled"), ROOM("room changed"), ONLINE("now online"), OFFLINE("now offline") }

    data class Change(val kind: Kind, val summary: String)

    private val I = RegexOption.IGNORE_CASE
    private val strong = Regex("\\b(class(?:es)?|lectures?|sessions?|periods?|tutorials?|practicals?|lab\\s+(?:class|session|today|tomorrow))\\b", I)
    private val cancelled = Regex("\\b(cancel+ed|canceled|called off|not (?:happening|there|held)|(?:will|won'?t) not be held|won'?t be held|off today|no (?:class|lecture|lab|session))\\b", I)
    private val moved = Regex("\\b(postponed|preponed|re-?scheduled|rescheduled|shifted|moved|delayed|advanced|changed)\\b", I)
    private val timeTo = Regex("\\b(?:to|at|till|until|from)\\s+(\\d{1,2}(?::\\d{2})?\\s*(?:am|pm)?)\\b", I)
    private val room = Regex("\\b(?:room|hall|lab|venue|classroom|class room|seminar hall)\\s*(?:no\\.?|number|#|-)?\\s*([A-Za-z]?-?\\d{1,4}[A-Za-z]?)\\b", I)
    private val roomTo = Regex("\\b(?:room|hall|venue|classroom|class room)\\s+(?:changed|shifted|moved)\\s+to\\s+([A-Za-z]?-?\\d{1,4}[A-Za-z]?)\\b", I)
    private val online = Regex("\\b(online|on (?:google )?meet|on zoom|on teams|meet\\.google\\.com|zoom\\.us|teams\\.microsoft)\\b", I)
    private val offline = Regex("\\b(offline|in[- ]person|physical(?:ly)?|in (?:the )?(?:class ?room|college))\\b", I)
    private val changeWord = Regex("\\b(now|will be|shifted|moved|changed|instead|today|tomorrow|switched|going)\\b", I)
    private val notClass = Regex("\\b(submission|assignment|deadline|due|record|report|registration|fees?)\\b", I)

    /** [subject] is the subject name Ghostie recognised in the message (or null). */
    fun detect(text: String, subject: String?): Change? {
        val t = text.replace(Regex("\\s+"), " ").trim()
        if (t.length < 8 || !strong.containsMatchIn(t)) return null
        // "lab record submission moved" is a deadline, not a class change
        if (notClass.containsMatchIn(t) && !Regex("\\b(class|lecture|session|period|tutorial)\\b", I).containsMatchIn(t)) return null
        val who = subject?.takeIf { it.isNotBlank() && !it.equals("unsorted", true) } ?: "Class"
        val label = if (who == "Class") "Class" else "$who class"
        return when {
            cancelled.containsMatchIn(t) -> Change(Kind.CANCELLED, "$label cancelled")
            roomTo.containsMatchIn(t) -> Change(Kind.ROOM, "$label room changed to ${roomTo.find(t)!!.groupValues[1]}")
            moved.containsMatchIn(t) && room.containsMatchIn(t) && !timeTo.containsMatchIn(t) ->
                Change(Kind.ROOM, "$label moved to room ${room.find(t)!!.groupValues[1]}")
            moved.containsMatchIn(t) && (timeTo.containsMatchIn(t) || Regex("\\b(postponed|preponed|re-?scheduled|rescheduled|delayed|advanced)\\b", I).containsMatchIn(t)) ->
                Change(Kind.RESCHEDULED, "$label rescheduled" + (timeTo.find(t)?.let { " to ${it.groupValues[1].trim()}" } ?: ""))
            moved.containsMatchIn(t) && room.containsMatchIn(t) -> Change(Kind.ROOM, "$label room: ${room.find(t)!!.groupValues[1]}")
            online.containsMatchIn(t) && changeWord.containsMatchIn(t) -> Change(Kind.ONLINE, "$label is online")
            offline.containsMatchIn(t) && changeWord.containsMatchIn(t) -> Change(Kind.OFFLINE, "$label is offline")
            else -> null
        }
    }
}
