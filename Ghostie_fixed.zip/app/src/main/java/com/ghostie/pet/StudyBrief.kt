package com.ghostie.pet

import java.time.LocalDate
import java.time.LocalTime

/**
 * The student tells Ghostie when they usually study. At the start of each of those times Ghostie
 * lists everything that has to be handed in tomorrow (group deadlines, project tasks, exams).
 */
object StudyBrief {
    private val one = Regex("(\\d{1,2})(?:[:.](\\d{2}))?\\s*(am|pm|a\\.m\\.|p\\.m\\.)?", RegexOption.IGNORE_CASE)

    /** "7pm and 9:30 pm", "19:00, 21:30", "6 am" -> ["07:00" ... sorted, unique]. Returns empty if nothing readable. */
    fun parseTimes(text: String): List<String> {
        val out = sortedSetOf<String>()
        for (m in one.findAll(text.replace(Regex("(?i)\\bo'?clock\\b"), ""))) {
            var h = m.groupValues[1].toInt()
            val min = m.groupValues[2].ifEmpty { "0" }.toInt()
            val ap = m.groupValues[3].lowercase().replace(".", "")
            if (min > 59 || h > 24) continue
            if (ap.isEmpty() && m.groupValues[2].isEmpty()) {
                // a bare number like "7" is read as evening for 1-11 (students rarely mean 7 am), kept as is for 12+
                if (h in 1..11) h += 12 else if (h == 24) h = 0
            } else if (ap == "pm" && h < 12) h += 12
            else if (ap == "am" && h == 12) h = 0
            if (h > 23) continue
            out.add("%02d:%02d".format(h, min))
        }
        return out.toList()
    }

    fun parseTime(s: String): LocalTime? = try { LocalTime.parse(s) } catch (e: Exception) { null }

    fun pretty(t: String): String {
        val lt = parseTime(t) ?: return t
        val h = if (lt.hour % 12 == 0) 12 else lt.hour % 12
        return "$h:%02d %s".format(lt.minute, if (lt.hour < 12) "am" else "pm")
    }

    fun listText(times: List<String>) = times.joinToString(", ") { pretty(it) }

    /** True when [now] is inside the 2 hours that follow study time [t]. */
    fun due(t: String, now: LocalTime): Boolean {
        val st = parseTime(t) ?: return false
        val mins = java.time.Duration.between(st, now).toMinutes()
        return mins in 0..120
    }

    /** Lines for everything due tomorrow; empty when nothing is. */
    fun tomorrowLines(
        logs: List<LogEntry>, exams: List<Student.Exam>, tasks: List<Projects.Task>, today: LocalDate
    ): List<String> {
        val out = ArrayList<String>()
        for (e in ReminderLog.upcoming(logs, today)) {
            if (ReminderLog.daysLeft(e, today) != 1L) continue
            out.add((if (ReminderLog.isRegistration(e)) "📝 Register: " else "📌 Submit: ") + ReminderLog.label(e) + (if (e.group.isNotBlank()) " (${e.group})" else ""))
        }
        for (x in exams) if (Student.daysLeft(x, today) == 1) out.add("📚 Exam: ${x.subject}")
        for (t in tasks) if (!t.done && t.due == today.plusDays(1)) out.add("👥 Project: ${t.title}" + (if (t.owner.isNotBlank()) " (${t.owner})" else ""))
        return out
    }

    fun message(lines: List<String>) = "Due tomorrow:\n" + lines.joinToString("\n")
}
