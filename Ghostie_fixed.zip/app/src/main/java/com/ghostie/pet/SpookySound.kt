package com.ghostie.pet

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin

/**
 * A short ghostly "ooOOoo" wail, made up from maths on the phone (no sound file, nothing downloaded):
 * a gliding, wobbling voice, a low rumble, a breathy whisper and a cave-like echo.
 */
object SpookySound {
    const val RATE = 22050

    /** Pure function, so it can be tested without a phone. [kind] 0 = wail, 1 = low moan, 2 = quick "boo". */
    fun synth(kind: Int = 0, seed: Long = 7): ShortArray {
        val dur = when (kind) { 1 -> 2.6f; 2 -> 0.9f; else -> 2.2f }
        val n = (dur * RATE).toInt()
        val out = FloatArray(n)
        val rnd = java.util.Random(seed)
        var phase1 = 0.0; var phase2 = 0.0; var phase3 = 0.0
        var lp = 0f
        for (i in 0 until n) {
            val t = i.toFloat() / RATE
            val x = t / dur
            // pitch: rises a little, then falls into a moan; plus a slow wobble and a faster tremble
            val base = when (kind) { 1 -> 150f; 2 -> 260f; else -> 330f }
            val glide = when (kind) { 2 -> 1.0f - 0.55f * x; else -> 1.0f + 0.25f * sin((PI * x).toFloat() * 0.9f) - 0.45f * x }
            val f = base * glide + 9f * sin(2.0 * PI * 5.2 * t).toFloat() + 14f * sin(2.0 * PI * 0.8 * t).toFloat()
            phase1 += 2.0 * PI * f / RATE
            phase2 += 2.0 * PI * (f * 1.006f) / RATE      // slightly detuned twin: a shimmering, choir-like tone
            phase3 += 2.0 * PI * (f * 2.0f) / RATE        // octave above, quieter
            val voice = (0.55 * sin(phase1) + 0.45 * sin(phase2) + 0.18 * sin(phase3)).toFloat()
            val rumble = 0.25f * sin(2.0 * PI * 48.0 * t).toFloat() * (0.6f + 0.4f * sin(2.0 * PI * 3.1 * t).toFloat())
            // breath: noise through a one-pole low-pass
            lp += 0.12f * ((rnd.nextFloat() * 2f - 1f) - lp)
            val breath = lp * 1.6f
            val env = when {
                x < 0.12f -> x / 0.12f
                else -> exp((-(x - 0.12f) * 2.6f).toDouble()).toFloat()
            }
            val swell = 0.75f + 0.25f * sin(2.0 * PI * 1.7 * t).toFloat()
            out[i] = (voice * 0.55f * swell + rumble * 0.5f + breath * 0.22f) * env
        }
        // echo: three decaying taps
        val taps = intArrayOf((0.11f * RATE).toInt(), (0.23f * RATE).toInt(), (0.37f * RATE).toInt())
        val gains = floatArrayOf(0.42f, 0.28f, 0.18f)
        val mixed = out.copyOf()
        for (k in taps.indices) for (i in taps[k] until n) mixed[i] += out[i - taps[k]] * gains[k]
        // fade the very end so it never clicks, then normalise to ~70%
        val fade = (0.12f * RATE).toInt()
        for (i in 0 until fade) mixed[n - 1 - i] *= i.toFloat() / fade
        var peak = 0.0001f
        for (v in mixed) peak = maxOf(peak, abs(v))
        val g = 0.7f / peak
        return ShortArray(n) { (mixed[it] * g * 32767f).toInt().coerceIn(-32768, 32767).toShort() }
    }

    private var track: AudioTrack? = null

    /** Plays the wail quietly through the "notification-like" channel, so silent / do-not-disturb modes are respected. */
    fun play(kind: Int = 0, volume: Float = 0.55f) {
        try {
            stop()
            val pcm = synth(kind)
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(pcm.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(pcm, 0, pcm.size)
            t.setVolume(volume)
            t.play()
            track = t
            val ms = pcm.size * 1000L / RATE + 300
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ if (track === t) stop() }, ms)
        } catch (e: Exception) { }
    }

    fun stop() {
        try { track?.stop() } catch (e: Exception) { }
        try { track?.release() } catch (e: Exception) { }
        track = null
    }
}
