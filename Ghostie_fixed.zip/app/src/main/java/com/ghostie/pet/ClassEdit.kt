package com.ghostie.pet

import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * One-day changes to the timetable: a class cancelled, another subject taken instead, a class moved to another time or day, an extra class.
 * They are stored per date (Student.State.changes), so the normal timetable is never touched and the day goes back to normal afterwards.
 * Pure Kotlin (JVM tested). Understands chat sentences and class-group messages.
 */
object ClassEdit {
    private val I = RegexOption.IGNORE_CASE
    data class Edit(
        val kind: String,                 // cancel | replace | move | extra
        val subject: String? = null,      // the class that is changing (null for a whole day or when found by time)
        val newSubject: String? = null,   // replace: what is taken instead
        val date: LocalDate,
        val time: LocalTime? = null,      // which period (by start time) when no subject is given; for "extra" the start time
        val allDay: Boolean = false,
        val toDate: LocalDate? = null,
        val toTime: LocalTime? = null
    )
    /** [edit] is ready to apply when [ask] is null; otherwise [ask] is the question to put to the user (their next message completes it). */
    data class Result(val edit: Edit, val ask: String? = null)

    private val dayWords = "monday|tuesday|wednesday|thursday|friday|saturday|sunday|mon|tues|tue|wed|thurs|thur|thu|fri|sat|sun"
    private val whenRe = Regex("\\b(?:on\\s+|for\\s+|this\\s+|next\\s+)?(today'?s?|tomorrow'?s?|tmrw|tomorow|yesterday'?s?|(?:$dayWords)(?:'s)?)\\b", I)
    private val classWord = Regex("\\b(class|classes|lecture|lectures|period|periods|session|lab|practical|tutorial)\\b", I)
    private val notOurs = Regex("\\b(alarm|reminder|reminders|timer|event|events|study mode|order|subscription|plan|trip|meeting|appointment)\\b", I)
    private val stop = setOf("the", "my", "our", "a", "an", "class", "classes", "lecture", "lectures", "period", "periods", "session", "sessions", "is", "was", "are", "were", "has", "have", "had", "been", "got", "will", "be", "being",
        "today", "tomorrow", "tmrw", "yesterday", "on", "for", "at", "of", "in", "this", "that", "please", "pls", "cancelled", "canceled", "cancel", "called", "off", "not", "no", "happening", "held", "and", "also", "its", "it's", "timetable",
        "by", "with", "to", "from", "till", "until", "moved", "shifted", "rescheduled", "postponed", "preponed", "delayed", "advanced", "replaced", "substituted", "swapped", "changed", "instead", "place", "taken", "conducted", "extra", "there", "we", "next", "slot", "hour", "going", "now", "just", "again", "sir", "mam", "madam", "ma'am", "dear", "students", "everyone")

    private fun clean(raw: String): String = raw.replace('’', '\'').replace(Regex("^\\s*(?:dear|hello|hi|hey|attention|notice|good (?:morning|afternoon|evening))[ ,]+(?:students|all|everyone|guys|class|team|friends|batch)\\b[ ,:-]*", RegexOption.IGNORE_CASE), "").replace(Regex("[?!.,;]+"), " ").replace(Regex("\\s+"), " ").trim()

    /** First clock time in [s]: "at 2pm", "10:30", "to 3 pm". Bare numbers only count after at/to/till/@. */
    fun findTime(s: String): Pair<LocalTime, IntRange>? {
        val pats = listOf(
            Regex("(?:\\b(?:at|to|till|until|from|by|@)\\s*)?\\b(\\d{1,2})(?::(\\d{2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?)(?!\\w)", I),
            Regex("\\b(\\d{1,2}):(\\d{2})\\b()", I),
            Regex("\\b(?:at|to|till|until|from|@)\\s+(\\d{1,2})(?::(\\d{2}))?\\b()", I)
        )
        for (p in pats) {
            val m = p.find(s) ?: continue
            var h = m.groupValues[1].toInt(); val mi = m.groupValues[2].ifEmpty { "0" }.toInt()
            val ap = m.groupValues[3].lowercase().replace(".", "")
            if (h > 23 || mi > 59) continue
            if (ap == "pm" && h < 12) h += 12 else if (ap == "am" && h == 12) h = 0
            else if (ap.isEmpty() && h in 1..7) h += 12      // "at 2" in a college day means 2 pm
            return LocalTime.of(h, mi) to m.range
        }
        return null
    }

    private fun dateFrom(word: String, today: LocalDate): LocalDate? {
        val w = word.lowercase().replace("'s", "").replace("'", "")
        val spec = ClassInfo.normWhen(if (w.endsWith("s") && w.startsWith("today")) "today" else w)
        return ClassInfo.resolve(spec, today)
    }

    /** Removes dates and times from [s] and returns what is left plus what was found. */
    private class Bits(val rest: String, val date: LocalDate?, val time: LocalTime?)
    private fun bits(s: String, today: LocalDate): Bits {
        var x = s
        var time: LocalTime? = null
        findTime(x)?.let { (t, r) -> time = t; x = x.removeRange(r) }
        var date: LocalDate? = null
        whenRe.find(x)?.let { m -> date = dateFrom(m.groupValues[1], today); x = x.removeRange(m.range) }
        return Bits(x.replace(Regex("\\s+"), " ").trim(), date, time)
    }

    private fun subjOf(s: String): String? {
        val words = s.split(' ').map { it.trim('\'', '"', '(', ')', ':', '-') }.filter { it.isNotEmpty() && it.lowercase() !in stop }
        val out = words.joinToString(" ").trim()
        return out.takeIf { it.length >= 2 }?.let { cap(it) }
    }
    private fun cap(s: String): String = if (s.length <= 5 && s.none { it == ' ' } && s == s.lowercase()) s.uppercase().takeIf { s.length <= 3 } ?: s.replaceFirstChar { it.uppercase() }
        else s.split(' ').joinToString(" ") { w -> if (w.all { it.isLetter() } && w.length <= 3 && w == w.uppercase()) w else w.replaceFirstChar { c -> c.uppercase() } }

    private val vagueSubject = Regex("^(another|other|some other|someone else'?s?|different|new|other subject|another subject|a different subject)( subject| class)?$", I)

    /** A chat sentence or group message -> an edit, or null if it isn't one. Questions are never edits. */
    fun parse(raw: String, today: LocalDate): Result? {
        val t = clean(raw)
        val l = t.lowercase()
        if (l.length < 6 || raw.trim().endsWith("?")) return null
        if (Regex("^(is|was|will|did|does|do|can|are|has|have|what|which|when|who|how|why|should)\\b", I).containsMatchIn(l)) return null
        if (notOurs.containsMatchIn(l)) return null
        val hasClass = classWord.containsMatchIn(l)

        // ---- extra class ----
        if (Regex("\\bextra\\b", I).containsMatchIn(l) && hasClass) {
            val b = bits(l, today)
            val sub = Regex("\\b(?:of|for|on)\\s+([a-z][a-z .&/-]{1,30}?)(?=\\s+(?:class|lecture|period|session)\\b|$)", I).find(b.rest)?.groupValues?.get(1)?.let { subjOf(it) }
                ?: subjOf(b.rest.replace(classWord, " "))
            val date = b.date ?: today
            val e = Edit("extra", sub, null, date, b.time)
            return when {
                sub == null -> Result(e, "Which subject is the extra class? 🗓️")
                b.time == null -> Result(e, "What time is the extra $sub class? ⏰ For example: 4 pm")
                else -> Result(e)
            }
        }

        // ---- replaced / taken instead ----
        Regex("^(.+?)\\s+(?:class\\s+|lecture\\s+|period\\s+)?(?:is |was |got |has been |will be )?(?:replaced|substituted|swapped|changed)\\s+(?:by|with|to|into)\\s+(.+)$", I).find(l)?.let { m ->
            return replace(bits(m.groupValues[1], today), bits(m.groupValues[2], today), today, true)
        }
        Regex("^(.+?)\\s+(?:class\\s+|lecture\\s+)?(?:is |was |will be |has been |being )?(?:taken|conducted|held|going on|happening)\\s+(?:instead of|in place of)\\s+(.+)$", I).find(l)?.let { m ->
            return replace(bits(m.groupValues[2], today), bits(m.groupValues[1], today), today, false)
        }
        Regex("^(.+?)\\s+(?:class\\s+|lecture\\s+)?(?:is |was |will be |has been |being )?(?:taken|conducted|held)\\s+in\\s+(?:the\\s+)?(.+?)(?:'s)?\\s+(?:period|slot|class|lecture|hour)\\b(.*)$", I).find(l)?.let { m ->
            return replace(bits(m.groupValues[2] + " " + m.groupValues[3], today), bits(m.groupValues[1], today), today, false)
        }
        Regex("^instead of\\s+(.+?)\\s+(?:we have|there is|there'?s|we got|it'?s|we are having|we will have)\\s+(.+)$", I).find(l)?.let { m ->
            return replace(bits(m.groupValues[1], today), bits(m.groupValues[2], today), today, false)
        }

        // ---- moved / rescheduled ----
        Regex("^(.+?)\\s+(?:class\\s+|lecture\\s+|period\\s+|session\\s+)?(?:is |was |has been |got |will be |has )?(?:moved|shifted|re-?scheduled|postponed|preponed|delayed|advanced)(?:\\s+(?:to|till|until|for))?\\s*(.*)$", I).find(l)?.let { m ->
            val head = bits(m.groupValues[1], today); val tail = bits(m.groupValues[2], today)
            if (!(hasClass || subjOf(head.rest) != null)) return null
            val sub = subjOf(head.rest)
            val from = head.date ?: today
            val e = Edit("move", sub, null, from, head.time.takeIf { sub == null }, false, tail.date ?: from, tail.time)
            return when {
                sub == null && head.time == null -> Result(e, "Which class was moved? Tell me the subject, for example: maths moved to 2 pm 🗓️")
                tail.time == null -> Result(e, "What time is ${sub ?: "that class"} moved to? ⏰ For example: 2 pm (or say \"cancelled\")")
                else -> Result(e)
            }
        }

        // ---- cancelled ----
        val cancelRe = Regex("\\b(cancel+ed|canceled|cancel|called off|not happening|won'?t be held|will not be held|is off|are off)\\b", I)
        val noClass = Regex("\\b(no (?:classes|class|college|lectures?|lab)|holiday|college (?:is )?off|classes (?:are )?off|class off)\\b", I)
        if (noClass.containsMatchIn(l) && !Regex("\\bno (?:class|classes) (?:yet|so far)\\b", I).containsMatchIn(l)) {
            val b = bits(l, today)
            val subject = subjOf(b.rest.replace(noClass, " "))
            if (subject == null || !hasClass) return Result(Edit("cancel", null, null, b.date ?: today, null, true))
        }
        if (cancelRe.containsMatchIn(l) && (hasClass || Regex("\\bcancel(?:l?ed)?\\s+\\w+", I).containsMatchIn(l))) {
            val b = bits(l.replace(cancelRe, " "), today)
            val sub = subjOf(b.rest)
            if (!hasClass && sub == null) return null
            val e = Edit("cancel", sub, null, b.date ?: today, b.time.takeIf { sub == null }, sub == null && b.time == null)
            return if (sub == null && b.time == null && !Regex("\\b(all|every|whole|today|tomorrow|classes)\\b", I).containsMatchIn(l)) Result(e, "Which class? Tell me the subject, for example: maths cancelled today 🗓️") else Result(e)
        }
        return null
    }

    private fun replace(old: Bits, new: Bits, today: LocalDate, newSecond: Boolean): Result? {
        val oldS = subjOf(old.rest); val newS = subjOf(new.rest)
        val date = old.date ?: new.date ?: today
        val time = old.time ?: new.time
        if (oldS == null && time == null && newS == null) return null
        val e = Edit("replace", oldS, newS?.takeUnless { vagueSubject.matches(it) }, date, time.takeIf { oldS == null })
        return when {
            e.newSubject == null -> Result(e, "Which subject was taken${oldS?.let { " instead of $it" } ?: ""}? 🗓️")
            oldS == null && time == null -> Result(e, "Which class did ${e.newSubject} replace? Tell me the subject or the time, for example: maths or 10 am")
            else -> Result(e)
        }
    }

    /** The user's next message answers a question from [parse]: a subject, or a time. Null if it can't be used. */
    fun complete(r: Result, answer: String, today: LocalDate): Result? {
        val a = clean(answer)
        val l = a.lowercase()
        val e = r.edit
        if (Regex("^(cancel(l?ed)?|dont know|don't know|no idea|skip|never ?mind|no)\\b", I).containsMatchIn(l)) {
            return if (e.kind == "move" && e.subject != null || e.kind == "move" && e.time != null) Result(e.copy(kind = "cancel", toDate = null, toTime = null)) else null
        }
        val b = bits(l, today)
        return when {
            e.kind == "replace" && e.newSubject == null -> subjOf(b.rest)?.let { Result(e.copy(newSubject = it)) }
            e.kind == "replace" && e.subject == null && e.time == null -> (b.time?.let { Result(e.copy(time = it)) } ?: subjOf(b.rest)?.let { Result(e.copy(subject = it)) })
            (e.kind == "move" || e.kind == "cancel") && e.subject == null && e.time == null -> subjOf(b.rest)?.let { Result(e.copy(subject = it, allDay = false), if (e.kind == "move" && e.toTime == null) "What time is it moved to? ⏰" else null) }
            e.kind == "move" -> b.time?.let { Result(e.copy(toTime = it, toDate = b.date ?: e.toDate)) }
            e.kind == "extra" && e.subject == null -> subjOf(b.rest)?.let { s -> Result(e.copy(subject = s), if (e.time == null) "What time is the extra $s class? ⏰" else null) }
            e.kind == "extra" -> b.time?.let { Result(e.copy(time = it)) }
            else -> null
        }
    }

    // ------------------------- applying -------------------------

    private val fmt = DateTimeFormatter.ofPattern("EEE d MMM", Locale.ENGLISH)
    private fun dayName(d: LocalDate, today: LocalDate) = when (d) { today -> "today"; today.plusDays(1) -> "tomorrow"; today.minusDays(1) -> "yesterday"; else -> d.format(fmt) }

    private fun known(st: Student.State): List<String> = SubjectTidy.attendanceSubjects(st)

    /** Maps a typed subject to the timetable's own spelling when it is clearly the same subject. */
    fun canonical(st: Student.State, typed: String): String {
        val t = typed.trim()
        val k = known(st)
        k.firstOrNull { it.equals(t, true) }?.let { return it }
        if (t.length >= 3) k.firstOrNull { it.startsWith(t, true) || (t.length >= 4 && it.contains(t, true)) }?.let { return it }
        k.firstOrNull { s -> s.split(' ', '/').filter { it.isNotEmpty() }.let { w -> w.size > 1 && w.joinToString("") { it.take(1) }.equals(t, true) } }?.let { return it }
        return t
    }

    private fun matches(cell: String, subject: String): Boolean = Student.parts(cell).any { p ->
        p.equals(subject, true) || (subject.length >= 3 && (p.startsWith(subject, true) || subject.startsWith(p, true))) || (subject.length >= 4 && p.contains(subject, true))
    } || cell.equals(subject, true)

    private fun periodsFor(st: Student.State, e: Edit): List<Int> {
        val day = Student.dayFor(st, e.date)
        val idx = day.periods.indices.filter { day.cell(it).isNotBlank() }
        if (e.subject != null) {
            val byName = idx.filter { matches(day.cell(it), canonical(st, e.subject)) || matches(day.cell(it), e.subject) }
            if (byName.isNotEmpty()) return byName
        }
        if (e.time != null) {
            return idx.filter { i ->
                val a = Student.parseTime(day.periods[i].start) ?: return@filter false
                val z = Student.parseTime(day.periods[i].end) ?: a.plusHours(1)
                !e.time.isBefore(a) && e.time.isBefore(z)
            }
        }
        return emptyList()
    }

    private fun addExtra(st: Student.State, date: LocalDate, subject: String, start: LocalTime, minutes: Int) {
        val m = st.changes.getOrPut(date.toString()) { mutableMapOf() }
        val n = (m.keys.filter { it.startsWith("x") }.mapNotNull { it.drop(1).toIntOrNull() }.maxOrNull() ?: 0) + 1
        m["x$n"] = subject + "|" + start.format(DateTimeFormatter.ofPattern("HH:mm")) + "|" + start.plusMinutes(minutes.toLong()).format(DateTimeFormatter.ofPattern("HH:mm"))
    }

    /** Applies [e] to [st] and returns a confirmation (or why it couldn't be done). */
    fun apply(st: Student.State, e: Edit, today: LocalDate): String {
        val dn = dayName(e.date, today)
        fun shown() = "\n\n" + ClassInfo.dayText(st, e.date, today)
        val m = st.changes.getOrPut(e.date.toString()) { mutableMapOf() }
        when (e.kind) {
            "cancel" -> {
                val day = Student.dayFor(st, e.date)
                val idx = if (e.allDay) day.periods.indices.filter { day.cell(it).isNotBlank() } else periodsFor(st, e)
                if (idx.isEmpty()) { if (m.isEmpty()) st.changes.remove(e.date.toString()); return notFound(st, e, dn) }
                val names = idx.map { Student.label(day.cell(it)) }
                idx.forEach { m[it.toString()] = "-" }
                return (if (e.allDay) "Done ✅ No classes $dn (${idx.size} cancelled). They won't count for attendance." else "Done ✅ ${names.distinct().joinToString(" and ")} is cancelled $dn. It won't count for attendance.") + shown()
            }
            "replace" -> {
                val idx = periodsFor(st, e)
                if (idx.isEmpty()) { if (m.isEmpty()) st.changes.remove(e.date.toString()); return notFound(st, e, dn) }
                val day = Student.dayFor(st, e.date)
                val newS = canonical(st, e.newSubject ?: return "Which subject was taken instead?")
                val old = idx.map { Student.label(day.cell(it)) }.distinct().joinToString(" and ")
                idx.forEach { m[it.toString()] = newS }
                return "Done ✅ $newS is taken $dn instead of $old. Attendance for that period goes to $newS." + shown()
            }
            "move" -> {
                val idx = periodsFor(st, e)
                if (idx.isEmpty()) { if (m.isEmpty()) st.changes.remove(e.date.toString()); return notFound(st, e, dn) }
                val toTime = e.toTime ?: return "What time is it moved to? ⏰"
                val toDate = e.toDate ?: e.date
                val day = Student.dayFor(st, e.date)
                val i = idx.first()
                val sub = Student.label(day.cell(i))
                val a = Student.parseTime(day.periods[i].start); val z = Student.parseTime(day.periods[i].end)
                val mins = if (a != null && z != null && z.isAfter(a)) java.time.Duration.between(a, z).toMinutes().toInt() else 60
                idx.forEach { m[it.toString()] = "-" }
                addExtra(st, toDate, sub, toTime, mins)
                val tn = dayName(toDate, today)
                val at = toTime.format(DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH))
                return (if (toDate == e.date) "Done ✅ $sub moved to $at $dn." else "Done ✅ $sub moved from $dn to $tn at $at.") + "\n\n" + ClassInfo.dayText(st, toDate, today)
            }
            else -> {
                if (m.isEmpty()) st.changes.remove(e.date.toString())
                val sub = canonical(st, e.subject ?: return "Which subject is the extra class?")
                val t = e.time ?: return "What time is the extra $sub class? ⏰"
                addExtra(st, e.date, sub, t, 60)
                return "Done ✅ Extra $sub class $dn at ${t.format(DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH))}." + shown()
            }
        }
    }

    private fun notFound(st: Student.State, e: Edit, dn: String): String {
        val l = Student.classesOn(st, e.date)
        val what = e.subject ?: e.time?.let { "a class at $it" } ?: "any class"
        return "I can't find $what in your timetable for $dn, so I changed nothing." + (if (l.isEmpty()) "" else "\nThat day has: " + l.joinToString(", ") { it.third })
    }

    /** Puts a day (or every day) back to the normal timetable. */
    fun undo(st: Student.State, date: LocalDate?): String {
        if (date == null) { val n = st.changes.size; st.changes.clear(); return if (n == 0) "There were no class changes to undo." else "Done ✅ All $n changed day(s) are back to your normal timetable." }
        return if (st.changes.remove(date.toString()) != null) "Done ✅ That day is back to your normal timetable." else "That day had no changes."
    }

    /** One line saying what a group message would change, for "Apply this to your timetable?". */
    fun describe(e: Edit, today: LocalDate): String {
        val dn = dayName(e.date, today)
        val s = e.subject ?: e.time?.let { "the ${it.format(DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH))} class" } ?: "all classes"
        return when (e.kind) {
            "cancel" -> if (e.allDay) "no classes $dn" else "$s cancelled $dn"
            "replace" -> "${e.newSubject} instead of $s $dn"
            "move" -> "$s moved to ${dayName(e.toDate ?: e.date, today)} ${e.toTime?.format(DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH)) ?: ""}".trim()
            else -> "extra $s class $dn"
        }
    }
}
