package com.ghostie.pet

import android.app.Notification
import android.app.NotificationManager
import android.app.NotificationChannel
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object Notifier {
    fun post(ctx: Context, title: String, text: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ghostie_reminders", "Ghostie reminders", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, "ghostie_reminders")
            .setSmallIcon(R.drawable.ghost_pet)
            .setContentTitle(title)
            .setContentText(text.lines().first())
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
    }

    /**
     * Newer Android versions can silently block an activity launched by a background service.
     * A notification tap is always allowed, so offer one (it disappears by itself after a few seconds).
     */
    fun openFallback(ctx: Context, intent: Intent, label: String) {
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel("ghostie_open", "Ghostie: tap to open", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(null, null)
            ch.enableVibration(false)
            nm.createNotificationChannel(ch)
            val i = Intent(intent).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val pi = PendingIntent.getActivity(ctx, 9100, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(ctx, "ghostie_open")
                .setSmallIcon(R.drawable.ghost_pet)
                .setContentTitle("Tap to open $label")
                .setContentText("If it didn't open by itself, tap here 👻")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setTimeoutAfter(12_000)
                .build()
            nm.notify(9100, n)
        } catch (e: Exception) { }
    }
}
