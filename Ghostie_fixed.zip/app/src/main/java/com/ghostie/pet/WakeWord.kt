package com.ghostie.pet

/**
 * Finds the pet's name at the start of heard speech ("Ghostie, timer 10 minutes"). Speech recognizers often mishear the name
 * ("ghosty", "ghosti", "ghost e", "goasty"), so the match is forgiving: the first word (or the first two joined) only has to be close.
 * Pure Kotlin so it can be tested without a phone.
 */
object WakeWord {
    private val lead = Regex("^(?:hey|hi|hello|ok|okay|yo|oi)\\s+", RegexOption.IGNORE_CASE)

    /** Returns what was said after the name, or null if the speech doesn't start with it. May return "" for just the name. */
    fun match(heard: List<String>, name: String): String? {
        val want = norm(name.ifBlank { "Ghostie" })
        for (h in heard) {
            val t = h.trim().replace(lead, "")
            val words = t.split(Regex("\\s+")).filter { it.isNotEmpty() }
            if (words.isEmpty()) continue
            // one word, or two words said apart ("ghost e", "go sti")
            for (n in 2 downTo 1) {
                if (words.size < n) continue
                val said = norm(words.take(n).joinToString(""))
                if (close(said, want)) return words.drop(n).joinToString(" ").trim(' ', ',', '.', ':', '!', '-')
            }
        }
        return null
    }

    private fun norm(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }
        .replace("ie", "y").replace("ee", "y").replace("ey", "y")   // ghostie / ghosty / ghostee sound the same

    private fun close(a: String, b: String): Boolean {
        if (a.isEmpty() || b.isEmpty()) return false
        if (a == b) return true
        val allowed = when { b.length <= 4 -> 0; b.length <= 6 -> 1; else -> 2 }
        return dist(a, b) <= allowed
    }

    private fun dist(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]; d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }
}
