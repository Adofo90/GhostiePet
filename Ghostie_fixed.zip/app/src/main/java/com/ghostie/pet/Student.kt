package com.ghostie.pet

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import kotlin.math.ceil
import kotlin.math.floor

/**
 * Student tools: timetable grid, attendance with "can I bunk?", exams + syllabus checklist, flashcards with spaced
 * repetition, and a digest of what the class groups said. The maths and parsing are pure (tested on the JVM);
 * [Student.load]/[Student.save] keep everything as one JSON string in the app's settings.
 */
object Student {
    // ---------- data ----------
    data class Period(val start: String, val end: String)
    data class Topic(val text: String, val done: Boolean)
    data class Exam(val id: Long, val subject: String, val date: LocalDate, val topics: List<Topic>)
    data class Card(val id: Long, val subject: String, val q: String, val a: String, val box: Int, val due: Long)
    data class Msg(val ts: Long, val group: String, val text: String)

    class State {
        var periods: MutableList<Period> = mutableListOf(
            Period("09:00", "10:00"), Period("10:00", "11:00"), Period("11:15", "12:15"), Period("12:15", "13:15"),
            Period("14:00", "15:00"), Period("15:00", "16:00")
        )
        /** "day,period" (day 0 = Monday) -> subject */
        var cells: MutableMap<String, String> = mutableMapOf()
        var required = 75
        var subjectReq: MutableMap<String, Int> = mutableMapOf()
        /** subject -> [attended, total] */
        var att: MutableMap<String, IntArray> = mutableMapOf()
        /** "yyyy-MM-dd|period" slots already asked/answered */
        var asked: MutableList<String> = mutableListOf()
        var exams: MutableList<Exam> = mutableListOf()
        var cards: MutableList<Card> = mutableListOf()
        var digest: MutableList<Msg> = mutableListOf()
        /** "yyyy-MM-dd|group" -> number of messages */
        var counts: MutableMap<String, Int> = mutableMapOf()
        var lastDigestAt = 0L
        var autoAsk = true
        var dnd = false
        var dndWeSet = false
        var dndPrev = 0
        var nudgeDay = ""
    }

    // ---------- timetable ----------
    fun parseTime(s: String): LocalTime? = try {
        val m = Regex("^\\s*(\\d{1,2})[:.](\\d{2})\\s*([ap]m)?\\s*$", RegexOption.IGNORE_CASE).find(s)
        if (m == null) null else {
            var h = m.groupValues[1].toInt(); val mi = m.groupValues[2].toInt()
            val ap = m.groupValues[3].lowercase()
            if (ap == "pm" && h < 12) h += 12
            if (ap == "am" && h == 12) h = 0
            LocalTime.of(h, mi)
        }
    } catch (e: Exception) { null }

    fun slotAt(st: State, now: LocalDateTime): Int? {
        val t = now.toLocalTime()
        st.periods.forEachIndexed { i, p ->
            val a = parseTime(p.start) ?: return@forEachIndexed
            val b = parseTime(p.end) ?: return@forEachIndexed
            if (!t.isBefore(a) && t.isBefore(b) && st.cells["${now.dayOfWeek.value - 1},$i"].orEmpty().isNotBlank()) return i
        }
        return null
    }

    fun classesOn(st: State, dayIdx: Int): List<Triple<Int, Period, String>> =
        st.periods.mapIndexedNotNull { i, p -> st.cells["$dayIdx,$i"]?.takeIf { it.isNotBlank() }?.let { Triple(i, p, it) } }

    /** Class periods that ended in the last [withinMin] minutes and weren't asked about yet. */
    fun finishedUnasked(st: State, now: LocalDateTime, withinMin: Int = 180): List<Triple<Int, Period, String>> {
        val day = now.dayOfWeek.value - 1
        return classesOn(st, day).filter { (i, p, _) ->
            val end = parseTime(p.end) ?: return@filter false
            val e = now.toLocalDate().atTime(end)
            !now.isBefore(e) && now.isBefore(e.plusMinutes(withinMin.toLong())) && !st.asked.contains("${now.toLocalDate()}|$i")
        }
    }

    // ---------- attendance ----------
    fun reqFor(st: State, subject: String) = st.subjectReq[key(st.subjectReq.keys, subject)] ?: st.required

    fun pct(a: Int, t: Int) = if (t == 0) 100.0 else a * 100.0 / t

    /** How many more classes can be skipped and stay at/above [req]% (0 if none). */
    fun canSkip(a: Int, t: Int, req: Int): Int = if (a * 100 < req * t) 0 else floor(a * 100.0 / req - t + 1e-9).toInt().coerceAtLeast(0)

    /** Classes in a row you must attend to climb back to [req]% (0 if already there). */
    fun mustAttend(a: Int, t: Int, req: Int): Int {
        if (a * 100 >= req * t) return 0
        if (req >= 100) return Int.MAX_VALUE
        return ceil((req * t - 100.0 * a) / (100 - req) - 1e-9).toInt()
    }

    fun key(names: Collection<String>, subject: String): String =
        names.firstOrNull { it.equals(subject.trim(), true) } ?: subject.trim()

    fun subjects(st: State): List<String> =
        (st.cells.values.filter { it.isNotBlank() } + st.att.keys + st.exams.map { it.subject }).map { it.trim() }.distinct()

    /** Best known subject for free text ("maths", "dbms lab"); null if nothing matches. */
    fun matchSubject(st: State, text: String): String? {
        val q = text.trim().lowercase()
        if (q.isEmpty()) return null
        val all = subjects(st)
        return all.firstOrNull { it.equals(q, true) } ?: all.firstOrNull { it.lowercase().startsWith(q) || q.startsWith(it.lowercase()) }
            ?: all.firstOrNull { it.lowercase().contains(q) }
    }

    fun mark(st: State, subject: String, present: Boolean, count: Int = 1) {
        val k = key(st.att.keys, subject)
        val r = st.att.getOrPut(k) { intArrayOf(0, 0) }
        r[1] += count; if (present) r[0] += count
    }

    fun attendanceLine(st: State, subject: String): String {
        val r = st.att[subject] ?: intArrayOf(0, 0)
        val req = reqFor(st, subject)
        val p = pct(r[0], r[1])
        val verdict = when {
            r[1] == 0 -> "no classes marked yet"
            p >= req -> { val k = canSkip(r[0], r[1], req); if (k > 0) "you can skip $k more" else "right on the line, don't skip" }
            else -> "attend the next ${mustAttend(r[0], r[1], req)} in a row to reach $req%"
        }
        return "$subject: ${r[0]}/${r[1]} = ${"%.1f".format(p)}% (need $req%) - $verdict"
    }

    fun bunkAnswer(st: State, subject: String): String {
        val r = st.att[subject] ?: return "I have no attendance for $subject yet. Say \"present $subject\" or \"absent $subject\" after a class."
        val req = reqFor(st, subject)
        val k = canSkip(r[0], r[1], req)
        val p = pct(r[0], r[1])
        return when {
            r[1] == 0 -> "No classes marked for $subject yet."
            p < req -> "No 🚫 $subject is at ${"%.1f".format(p)}% (need $req%). Attend the next ${mustAttend(r[0], r[1], req)} classes in a row to get back."
            k == 0 -> "Better not 😬 $subject is at ${"%.1f".format(p)}% - skipping one drops you under $req%."
            else -> "Yes ✅ $subject is at ${"%.1f".format(p)}%. You can skip $k more class${if (k == 1) "" else "es"} and stay at $req%+."
        }
    }

    // ---------- exams ----------
    fun daysLeft(e: Exam, today: LocalDate) = java.time.temporal.ChronoUnit.DAYS.between(today, e.date).toInt()

    fun upcoming(st: State, today: LocalDate) = st.exams.filter { daysLeft(it, today) >= 0 }.sortedBy { it.date }

    fun examLine(e: Exam, today: LocalDate): String {
        val d = daysLeft(e, today)
        val done = e.topics.count { it.done }
        val left = when (d) { 0 -> "TODAY"; 1 -> "tomorrow"; else -> "in $d days" }
        return "${e.subject} - $left (${e.date})" + if (e.topics.isNotEmpty()) " - syllabus $done/${e.topics.size}" else ""
    }

    /** One line for today: what to study. Spreads the unfinished topics over the days left. */
    fun studyToday(st: State, today: LocalDate): String? {
        val ex = upcoming(st, today).firstOrNull { e -> e.topics.any { !it.done } } ?: return null
        val rest = ex.topics.filter { !it.done }
        val d = daysLeft(ex, today).coerceAtLeast(1)
        val n = ceil(rest.size / d.toDouble()).toInt().coerceAtLeast(1)
        return "📚 ${ex.subject} exam ${if (daysLeft(ex, today) == 0) "is today" else "in ${daysLeft(ex, today)} day(s)"}. Study today: " + rest.take(n).joinToString(", ") { it.text } +
            " (${rest.size} topic${if (rest.size == 1) "" else "s"} left)"
    }

    // ---------- flashcards (Leitner boxes) ----------
    private val INTERVALS = intArrayOf(1, 2, 4, 8, 16)

    fun graded(c: Card, good: Boolean, today: LocalDate): Card {
        val b = if (good) (c.box + 1).coerceAtMost(INTERVALS.size - 1) else 0
        return c.copy(box = b, due = today.toEpochDay() + INTERVALS[b])
    }

    fun dueCards(st: State, today: LocalDate) = st.cards.filter { it.due <= today.toEpochDay() }.sortedWith(compareBy({ it.box }, { it.due }))

    /** "Subject: Q = A" or "Q = A" (also "Q - A" is NOT accepted, definitions often contain dashes). Returns null for a non-card line. */
    fun parseCardLine(line: String, defaultSubject: String = "General"): Triple<String, String, String>? {
        var s = line.trim()
        if (s.isEmpty() || !s.contains("=")) return null
        var subject = defaultSubject
        val m = Regex("^([A-Za-z][\\w &.-]{0,30}):\\s*(.+)$").find(s)
        if (m != null && m.groupValues[2].contains("=")) { subject = m.groupValues[1].trim(); s = m.groupValues[2] }
        val i = s.indexOf('=')
        val q = s.substring(0, i).trim(); val a = s.substring(i + 1).trim()
        return if (q.isNotEmpty() && a.isNotEmpty()) Triple(subject, q, a) else null
    }

    fun addCards(st: State, text: String, today: LocalDate, defaultSubject: String = "General"): Int {
        var n = 0
        for (line in text.lines()) {
            val (s, q, a) = parseCardLine(line, defaultSubject) ?: continue
            if (st.cards.any { it.q.equals(q, true) && it.subject.equals(s, true) }) continue
            st.cards.add(Card(System.currentTimeMillis() + n, s, q, a, 0, today.toEpochDay())); n++
        }
        return n
    }

    // ---------- digest ----------
    private val IMPORTANT = Regex("\\b(exam|test|quiz|viva|deadline|due|submit|submission|assignment|tomorrow|today|cancel(?:l?ed)?|postponed|preponed|rescheduled|holiday|urgent|important|lab|record|project|syllabus|timetable|results?|notice|circular|fees?)\\b", RegexOption.IGNORE_CASE)

    fun isImportant(text: String) = IMPORTANT.containsMatchIn(text)

    fun digestAdd(st: State, group: String, text: String, nowMs: Long) {
        val day = java.time.Instant.ofEpochMilli(nowMs).atZone(java.time.ZoneId.systemDefault()).toLocalDate()
        val k = "$day|$group"
        st.counts[k] = (st.counts[k] ?: 0) + 1
        if (isImportant(text)) {
            st.digest.add(Msg(nowMs, group, text.take(160)))
            val cut = nowMs - 7 * 86_400_000L
            st.digest = st.digest.filter { it.ts >= cut }.takeLast(200).toMutableList()
        }
        val old = day.minusDays(8).toString()
        st.counts.keys.filter { it.substringBefore('|') < old }.forEach { st.counts.remove(it) }
    }

    fun digestText(st: State, sinceMs: Long, nowMs: Long): String {
        val items = st.digest.filter { it.ts >= sinceMs }
        val sinceDay = java.time.Instant.ofEpochMilli(sinceMs).atZone(java.time.ZoneId.systemDefault()).toLocalDate().toString()
        val total = st.counts.filter { it.key.substringBefore('|') >= sinceDay }
        if (total.isEmpty() && items.isEmpty()) return "Nothing new from your class groups 🎉"
        val byGroup = total.entries.groupBy({ it.key.substringAfter('|') }, { it.value }).mapValues { it.value.sum() }
        val sb = StringBuilder("While you were away 👀\n")
        for ((g, n) in byGroup.entries.sortedByDescending { it.value }) {
            sb.append("\n$g - $n message${if (n == 1) "" else "s"}")
            items.filter { it.group == g }.takeLast(5).forEach { sb.append("\n  • ").append(it.text.replace('\n', ' ')) }
        }
        return sb.toString()
    }

    // ---------- JSON ----------
    fun toJson(st: State): String {
        val o = JSONObject()
        o.put("periods", JSONArray().also { a -> st.periods.forEach { a.put(JSONArray().put(it.start).put(it.end)) } })
        o.put("cells", JSONObject(st.cells as Map<*, *>))
        o.put("required", st.required)
        o.put("subjectReq", JSONObject(st.subjectReq as Map<*, *>))
        o.put("att", JSONObject().also { j -> st.att.forEach { (k, v) -> j.put(k, JSONArray().put(v[0]).put(v[1])) } })
        o.put("asked", JSONArray(st.asked.takeLast(300)))
        o.put("exams", JSONArray().also { a -> st.exams.forEach { e ->
            a.put(JSONObject().put("id", e.id).put("s", e.subject).put("d", e.date.toString())
                .put("t", JSONArray().also { t -> e.topics.forEach { t.put(JSONArray().put(it.text).put(it.done)) } }))
        } })
        o.put("cards", JSONArray().also { a -> st.cards.forEach { a.put(JSONObject().put("id", it.id).put("s", it.subject).put("q", it.q).put("a", it.a).put("b", it.box).put("d", it.due)) } })
        o.put("digest", JSONArray().also { a -> st.digest.forEach { a.put(JSONObject().put("t", it.ts).put("g", it.group).put("x", it.text)) } })
        o.put("counts", JSONObject(st.counts as Map<*, *>))
        o.put("lastDigestAt", st.lastDigestAt); o.put("autoAsk", st.autoAsk); o.put("dnd", st.dnd)
        o.put("dndWeSet", st.dndWeSet); o.put("dndPrev", st.dndPrev); o.put("nudgeDay", st.nudgeDay)
        return o.toString()
    }

    fun fromJson(s: String): State {
        val st = State()
        try {
            val o = JSONObject(s)
            o.optJSONArray("periods")?.let { a -> st.periods = (0 until a.length()).map { Period(a.getJSONArray(it).getString(0), a.getJSONArray(it).getString(1)) }.toMutableList() }
            o.optJSONObject("cells")?.let { j -> j.keys().forEach { st.cells[it] = j.getString(it) } }
            st.required = o.optInt("required", 75)
            o.optJSONObject("subjectReq")?.let { j -> j.keys().forEach { st.subjectReq[it] = j.getInt(it) } }
            o.optJSONObject("att")?.let { j -> j.keys().forEach { k -> val a = j.getJSONArray(k); st.att[k] = intArrayOf(a.getInt(0), a.getInt(1)) } }
            o.optJSONArray("asked")?.let { a -> st.asked = (0 until a.length()).map { a.getString(it) }.toMutableList() }
            o.optJSONArray("exams")?.let { a -> st.exams = (0 until a.length()).map { i ->
                val e = a.getJSONObject(i); val t = e.optJSONArray("t") ?: JSONArray()
                Exam(e.getLong("id"), e.getString("s"), LocalDate.parse(e.getString("d")),
                    (0 until t.length()).map { Topic(t.getJSONArray(it).getString(0), t.getJSONArray(it).getBoolean(1)) })
            }.toMutableList() }
            o.optJSONArray("cards")?.let { a -> st.cards = (0 until a.length()).map { i ->
                val c = a.getJSONObject(i); Card(c.getLong("id"), c.getString("s"), c.getString("q"), c.getString("a"), c.getInt("b"), c.getLong("d"))
            }.toMutableList() }
            o.optJSONArray("digest")?.let { a -> st.digest = (0 until a.length()).map { i -> val m = a.getJSONObject(i); Msg(m.getLong("t"), m.getString("g"), m.getString("x")) }.toMutableList() }
            o.optJSONObject("counts")?.let { j -> j.keys().forEach { st.counts[it] = j.getInt(it) } }
            st.lastDigestAt = o.optLong("lastDigestAt", 0L); st.autoAsk = o.optBoolean("autoAsk", true); st.dnd = o.optBoolean("dnd", false)
            st.dndWeSet = o.optBoolean("dndWeSet", false); st.dndPrev = o.optInt("dndPrev", 0); st.nudgeDay = o.optString("nudgeDay")
        } catch (e: Exception) { }
        return st
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ghostie", Context.MODE_PRIVATE)
    @Volatile private var cache: State? = null
    @Synchronized fun load(ctx: Context): State = cache ?: fromJson(prefs(ctx).getString("student_json", "") ?: "").also { cache = it }
    @Synchronized fun reset() { cache = null }
    @Synchronized fun save(ctx: Context) { cache?.let { prefs(ctx).edit().putString("student_json", toJson(it)).apply() } }

    // ---------- chat quiz (in memory) ----------
    private var quizCard: Card? = null
    private var quizShown = false

    /** Starts or continues a quiz in chat. Returns (message, quick-reply buttons). */
    fun quizNext(ctx: Context): Pair<String, List<String>> {
        val st = load(ctx)
        val c = dueCards(st, LocalDate.now()).firstOrNull()
        if (c == null) { quizCard = null; return (if (st.cards.isEmpty()) "No flashcards yet. Say \"card What is a deadlock = circular wait for resources\"" else "All caught up 🎉 No cards due today.") to emptyList() }
        quizCard = c; quizShown = false
        return "🃏 ${c.subject}: ${c.q}\n(say \"show\" for the answer)" to listOf("Show answer")
    }

    /** Handles "show answer" / "got it" / "again" while a quiz is open; null if not in a quiz. */
    fun quizReply(ctx: Context, text: String): Pair<String, List<String>>? {
        val c = quizCard ?: return null
        val t = text.trim().lowercase()
        if (!quizShown) {
            if (Regex("^(show( answer)?|answer|flip|reveal)\\b").containsMatchIn(t)) { quizShown = true; return "💡 ${c.a}\n\nDid you know it? Say \"got it\" or \"again\"." to listOf("Got it", "Again") }
            if (Regex("^(stop|quit|end|exit)\\b").containsMatchIn(t)) { quizCard = null; return "Quiz stopped 👍" to emptyList() }
            return null
        }
        val good = Regex("^(got it|good|yes|yeah|easy|knew it|right)\\b").containsMatchIn(t)
        val again = Regex("^(again|no|nope|wrong|forgot|hard)\\b").containsMatchIn(t)
        if (Regex("^(stop|quit|end|exit)\\b").containsMatchIn(t)) { quizCard = null; return "Quiz stopped 👍" to emptyList() }
        if (!good && !again) return null
        val st = load(ctx)
        val upd = graded(c, good, LocalDate.now())
        st.cards = st.cards.map { if (it.id == c.id) upd else it }.toMutableList()
        save(ctx)
        val next = quizNext(ctx)
        val note = if (good) "✅ See it again in ${INTERVALS[upd.box]} day(s)." else "🔁 We'll repeat it tomorrow."
        return "$note\n\n${next.first}" to next.second
    }
}
