package com.ghostie.pet

import android.content.Context

/**
 * Who owes whom after shared expenses. A positive balance means that person owes YOU; negative means you owe them.
 * [Ledger] is pure (tested on the JVM); [SplitStore] keeps it on the phone.
 */
object Ledger {
    fun clean(name: String): String = name.trim().trim('.', ',').split(Regex("\\s+")).joinToString(" ") { it.lowercase().replaceFirstChar { c -> c.uppercase() } }

    fun key(balances: Map<String, Double>, name: String): String = balances.keys.firstOrNull { it.equals(clean(name), true) } ?: clean(name)

    /** "Ravi, Meena and Tej" -> [Ravi, Meena, Tej]; "me" and "myself" are ignored (you are always included). */
    fun names(text: String): List<String> = text.split(Regex("\\s*(?:,|&|\\band\\b)\\s*", RegexOption.IGNORE_CASE))
        .map { clean(it) }.filter { it.isNotEmpty() && it.lowercase() !in setOf("Me", "Myself", "Us").map { s -> s.lowercase() } }.distinct()

    private fun r2(x: Double) = Math.round(x * 100) / 100.0

    /** You paid [total] for everyone: each friend owes an equal share (you are one of the people sharing). */
    fun split(b: MutableMap<String, Double>, total: Double, friends: List<String>): Double {
        if (friends.isEmpty() || total <= 0) return 0.0
        val share = r2(total / (friends.size + 1))
        for (f in friends) { val k = key(b, f); b[k] = r2((b[k] ?: 0.0) + share) }
        return share
    }

    /** [name] paid you back (reduces what they owe you). */
    fun paidBack(b: MutableMap<String, Double>, name: String, amount: Double) { val k = key(b, name); b[k] = r2((b[k] ?: 0.0) - amount) }

    /** You paid [name] (reduces what you owe them). */
    fun paidTo(b: MutableMap<String, Double>, name: String, amount: Double) { val k = key(b, name); b[k] = r2((b[k] ?: 0.0) + amount) }

    /** You owe [name] [amount]. */
    fun owe(b: MutableMap<String, Double>, name: String, amount: Double) { val k = key(b, name); b[k] = r2((b[k] ?: 0.0) - amount) }

    fun settle(b: MutableMap<String, Double>, name: String): Boolean = b.remove(key(b, name)) != null

    fun text(b: Map<String, Double>): String {
        val live = b.filter { Math.abs(it.value) >= 0.01 }
        if (live.isEmpty()) return "Nobody owes anything 🎉"
        val owedToMe = live.filter { it.value > 0 }.entries.sortedByDescending { it.value }
        val iOwe = live.filter { it.value < 0 }.entries.sortedBy { it.value }
        val sb = StringBuilder()
        if (owedToMe.isNotEmpty()) sb.append("Owe you: ").append(owedToMe.joinToString(", ") { it.key + " " + MoneyParser.format(it.value) }).append("  (total ").append(MoneyParser.format(owedToMe.sumOf { it.value })).append(")")
        if (iOwe.isNotEmpty()) { if (sb.isNotEmpty()) sb.append("\n"); sb.append("You owe: ").append(iOwe.joinToString(", ") { it.key + " " + MoneyParser.format(-it.value) }) }
        return sb.toString()
    }

    fun reminderText(name: String, amount: Double, note: String = ""): String =
        "Hey $name, quick reminder: you owe me ${MoneyParser.format(amount)}${if (note.isNotBlank()) " for $note" else ""}. Send it when you can 🙂"
}

object SplitStore {
    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences("ghostie_split", Context.MODE_PRIVATE)

    @Synchronized fun load(ctx: Context): MutableMap<String, Double> {
        val m = LinkedHashMap<String, Double>()
        (p(ctx).getString("b", "") ?: "").lines().forEach { l -> val x = l.split('\t'); if (x.size == 2) x[1].toDoubleOrNull()?.let { m[x[0]] = it } }
        return m
    }
    @Synchronized fun save(ctx: Context, m: Map<String, Double>) {
        p(ctx).edit().putString("b", m.filter { Math.abs(it.value) >= 0.01 }.entries.joinToString("\n") { it.key + "\t" + it.value }).apply()
    }
    /** Remembers what the last split was for, so a reminder can mention it. */
    fun noteFor(ctx: Context, name: String): String = p(ctx).getString("n_" + name.lowercase(), "") ?: ""
    fun setNote(ctx: Context, names: List<String>, note: String) { val e = p(ctx).edit(); names.forEach { e.putString("n_" + it.lowercase(), note) }; e.apply() }
}
