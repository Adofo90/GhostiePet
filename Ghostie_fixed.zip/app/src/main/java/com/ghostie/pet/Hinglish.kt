package com.ghostie.pet

/**
 * Turns Hindi / Hinglish commands (typed or spoken, Devanagari or Roman) into the English forms the command
 * parser already understands: "सुबह 7 बजे अलार्म लगाओ" -> "alarm 7 am". English text passes through unchanged.
 */
object Hinglish {
    private val I = RegexOption.IGNORE_CASE

    private val words = listOf(
        "अलार्म" to "alarm", "अलार्म" to "alarm", "टाइमर" to "timer", "टाईमर" to "timer", "इवेंट" to "event", "ईवेंट" to "event",
        "जन्मदिन" to "birthday", "बर्थडे" to "birthday", "एनिवर्सरी" to "anniversary", "कॉल" to "call", "फोन" to "call", "फ़ोन" to "call",
        "कल" to "tomorrow", "आज" to "today", "परसों" to "day after tomorrow", "मदद" to "help", "हेल्प" to "help",
        "मिनट" to "minutes", "घंटे" to "hours", "घंटा" to "hours", "सेकंड" to "seconds", "व्हाट्सएप" to "whatsapp", "वाट्सएप" to "whatsapp"
    )

    fun normalize(raw: String): String {
        var t = raw.trim()
        if (t.isEmpty()) return t
        // Devanagari digits
        t = t.map { c -> if (c in '०'..'९') ('0' + (c - '०')) else c }.joinToString("")
        for ((a, b) in words) t = t.replace(a, " $b ")
        t = t.replace(Regex("\\b(kal)\\b", I), "tomorrow").replace(Regex("\\b(aaj)\\b", I), "today").replace(Regex("\\b(parso)\\b", I), "day after tomorrow")
        t = t.replace(Regex("\\b(minute|min|mint)\\b", I), "minutes").replace(Regex("\\b(ghante|ghanta|ghantey)\\b", I), "hours")
        // "सुबह 7 बजे" / "subah 7 baje" -> "7 am";  "शाम 6 बजे" / "raat 9 baje" -> "6 pm"
        val clock = "(\\d{1,2}(?::\\d{2})?)"
        t = t.replace(Regex("(?:सुबह|subah|subha|morning)\\s+$clock\\s*(?:बजे|baje|bje)?", I)) { it.groupValues[1] + " am" }
        t = t.replace(Regex("(?:शाम|shaam|sham|रात|raat|दोपहर|dopahar|evening|night|afternoon)\\s+$clock\\s*(?:बजे|baje|bje)?", I)) { it.groupValues[1] + " pm" }
        t = t.replace(Regex("$clock\\s*(?:बजे|baje|bje)\\s*(सुबह|subah|subha)", I)) { it.groupValues[1] + " am" }
        t = t.replace(Regex("$clock\\s*(?:बजे|baje|bje)\\s*(शाम|shaam|sham|रात|raat|दोपहर|dopahar)", I)) { it.groupValues[1] + " pm" }
        t = t.replace(Regex("$clock\\s*(?:बजे|baje|bje)", I)) { it.groupValues[1] }
        // "mom ko call karo" -> "call mom"
        t = t.replace(Regex("^(.+?)\\s+(?:ko|को)\\s+(?:call|phone|fone)\\b.*$", I)) { "call " + it.groupValues[1].trim() }
        // "whatsapp kholo" -> "open whatsapp"
        t = t.replace(Regex("^(.+?)\\s+(?:kholo|khol do|khol de|खोलो|खोल दो|खोलिए)\\b.*$", I)) { "open " + it.groupValues[1].trim() }
        // action verbs and glue words
        val wantsEvent = Regex("\\bevent\\b", I).containsMatchIn(t) && Regex("(add|jodo|bana|banao|जोड़|बना|create|new)", I).containsMatchIn(t) && !Regex("^(add|new|create|make|schedule|set)\\b", I).containsMatchIn(t)
        t = t.replace(Regex("\\b(laga do|laga de|lagao|laga dena|lagana|set karo|set kar do|kar do|karo|bana do|banao|jodo|add karo|add kar do|please karo)\\b", I), " ")
        t = t.replace(Regex("(लगा दो|लगा दे|लगाओ|लगाना|सेट करो|सेट कर दो|कर दो|करो|बना दो|बनाओ|जोड़ो|का|के|की|ka|ke|ki)(?=\\s|$)", I), " ")
        t = t.replace(Regex("\\s+"), " ").trim()
        if (wantsEvent) t = "add event " + t.replace(Regex("\\b(add|event|new|create)\\b", I), " ").replace(Regex("\\s+"), " ").trim()
        // "5 minutes timer" -> "timer 5 minutes";  "7 am alarm" -> "alarm 7 am"
        t = t.replace(Regex("^(\\d+)\\s*(minutes|hours|seconds)\\s+timer$", I)) { "timer " + it.groupValues[1] + " " + it.groupValues[2] }
        t = t.replace(Regex("^(\\d{1,2}(?::\\d{2})?\\s*(?:am|pm)?)\\s+alarm$", I)) { "alarm " + it.groupValues[1] }
        return t
    }
}
