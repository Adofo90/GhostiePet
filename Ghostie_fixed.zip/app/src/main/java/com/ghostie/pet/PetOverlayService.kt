package com.ghostie.pet

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.BounceInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

class PetOverlayService : Service() {

    companion object {
        const val ACTION_SUMMON = "SUMMON"
        const val ACTION_RESET = "RESET"
    }

    private lateinit var wm: WindowManager
    private lateinit var s: SettingsStore
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var pet: ImageView? = null
    private var petParams: WindowManager.LayoutParams? = null
    private var handle: ImageView? = null
    private var bubble: TextView? = null
    private var chatBox: View? = null
    private var idleAnim: ObjectAnimator? = null
    private var slideAnim: ValueAnimator? = null
    private var swayAnim: ObjectAnimator? = null
    private var handleAnim: ObjectAnimator? = null
    private var hopAnim: ValueAnimator? = null
    private var reacting = false
    private val chatter by lazy { Chatter(s.userName) }
    private val chatHistory = mutableListOf<Pair<String, String>>()

    private val ink = Color.rgb(55, 35, 75)
    private val overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    // ---- periodic tasks -------------------------------------------------------------------

    /** Little idle behaviours: a blink, or a quick glance to the side. Skipped while reacting. */
    private val blinkTask = object : Runnable {
        override fun run() {
            val p = pet
            if (p != null && !reacting) {
                if ((0..9).random() < 7) {
                    p.scaleY = 0.88f
                    handler.postDelayed({ if (!reacting) p.scaleY = 1f }, 120)
                } else {
                    val dir = if ((0..1).random() == 0) -1 else 1
                    p.animate().translationX(dir * dp(6).toFloat()).setDuration(350)
                        .withEndAction { p.animate().translationX(0f).setDuration(350).start() }.start()
                }
            }
            handler.postDelayed(this, (3500L..7500L).random())
        }
    }
    private val leaveTask = Runnable { leave() }
    private val checkInTask = object : Runnable {
        override fun run() {
            if (canVisit() && s.checkins) summon()
            handler.postDelayed(this, s.visitMinutes * 60_000L)
        }
    }
    private val waterTask = object : Runnable {
        override fun run() {
            if (canVisit()) summon("Water check 💧 A few sips?")
            handler.postDelayed(this, s.waterMinutes * 60_000L)
        }
    }

    // ---- lifecycle ------------------------------------------------------------------------

    override fun onCreate() {
        super.onCreate()
        s = SettingsStore(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startInForeground()
        createViews()
        handler.postDelayed(checkInTask, s.visitMinutes * 60_000L)
        handler.postDelayed(waterTask, s.waterMinutes * 60_000L)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createViews() // no-op if already created; picks up a newly granted overlay permission
        when (intent?.action) {
            ACTION_SUMMON -> summon()
            ACTION_RESET -> {
                s.resetPosition()
                destroyViews()
                createViews()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        destroyViews()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startInForeground() {
        val channelId = "ghostie_service"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Ghostie service", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
        )
        val notification = Notification.Builder(this, channelId)
            .setSmallIcon(R.drawable.ghost_pet)
            .setContentTitle("Ghostie is nearby")
            .setContentText("Floating companion is running")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(7, notification)
        }
    }

    // ---- helpers --------------------------------------------------------------------------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun screenW(): Int = resources.displayMetrics.widthPixels
    private fun screenH(): Int = resources.displayMetrics.heightPixels
    private fun homeX(): Int = if (s.x >= 0) s.x else dp(16)
    private fun homeY(): Int = if (s.y >= 0) s.y else screenH() - s.petSize - dp(60)
    private fun canVisit(): Boolean = s.enabled && System.currentTimeMillis() > s.quietUntil

    private fun removeQuietly(v: View?) {
        if (v == null) return
        try {
            wm.removeView(v)
        } catch (ex: IllegalArgumentException) {
            // already removed
        }
    }

    private fun bubbleBg() = GradientDrawable().apply {
        setColor(Color.WHITE)
        cornerRadius = dp(14).toFloat()
        setStroke(2, Color.rgb(190, 150, 235))
    }

    // ---- views ----------------------------------------------------------------------------

    private fun createViews() {
        if (pet != null || !Settings.canDrawOverlays(this)) return

        val size = s.petSize
        val lp = WindowManager.LayoutParams(
            size, size, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = homeX()
        lp.y = homeY()

        val view = ImageView(this)
        view.setImageResource(R.drawable.ghost_pet)
        view.scaleType = ImageView.ScaleType.FIT_CENTER
        view.setOnTouchListener(DragTouch(lp, view, true) {
            react()
            openChat()
        })
        wm.addView(view, lp)
        pet = view
        petParams = lp
        startIdle(view)

        // Small draggable handle on the screen edge: tap to summon Ghostie.
        val hp = WindowManager.LayoutParams(
            dp(48), dp(48), overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        hp.gravity = Gravity.TOP or Gravity.START
        hp.x = dp(4)
        hp.y = screenH() / 2
        val h = ImageView(this)
        h.setImageResource(R.drawable.ghost_pet)
        h.scaleType = ImageView.ScaleType.CENTER_INSIDE
        h.alpha = 0.7f
        h.setPadding(dp(6), dp(6), dp(6), dp(6))
        h.setOnTouchListener(DragTouch(hp, h, false) {
            react()
            summon()
        })
        handleAnim = ObjectAnimator.ofPropertyValuesHolder(
            h,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.1f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.1f)
        ).apply {
            duration = 1400
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        wm.addView(h, hp)
        handle = h
    }

    private fun destroyViews() {
        handler.removeCallbacks(blinkTask)
        handler.removeCallbacks(leaveTask)
        idleAnim?.cancel()
        slideAnim?.cancel()
        swayAnim?.cancel()
        handleAnim?.cancel()
        hopAnim?.cancel()
        swayAnim = null
        handleAnim = null
        hopAnim = null
        idleAnim = null
        slideAnim = null
        removeQuietly(bubble)
        removeQuietly(chatBox)
        removeQuietly(handle)
        removeQuietly(pet)
        bubble = null
        chatBox = null
        handle = null
        pet = null
        petParams = null
    }

    private fun startIdle(view: View) {
        idleAnim?.cancel()
        idleAnim = ObjectAnimator.ofFloat(view, View.TRANSLATION_Y, 0f, dp(8).toFloat()).apply {
            duration = (900 / s.animSpeed.coerceAtLeast(0.1f)).toLong()
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        swayAnim?.cancel()
        swayAnim = ObjectAnimator.ofFloat(view, View.ROTATION, -4f, 4f).apply {
            duration = 2200
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        handler.removeCallbacks(blinkTask)
        handler.postDelayed(blinkTask, 3000)
    }

    /** Squash-and-stretch pop: used when tapped, when it speaks and when it arrives. */
    private fun react() {
        val p = pet ?: return
        if (reacting) return
        reacting = true
        p.scaleY = 1f
        val pop = ObjectAnimator.ofPropertyValuesHolder(
            p,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.14f, 0.95f, 1f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 0.86f, 1.08f, 1f)
        )
        pop.duration = 500
        pop.interpolator = OvershootInterpolator()
        pop.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                reacting = false
            }
        })
        pop.start()
    }

    /** A bouncy landing after sliding in. */
    private fun hop() {
        val lp = petParams ?: return
        val p = pet ?: return
        hopAnim?.cancel()
        val landing = lp.y
        val from = (landing - dp(36)).coerceAtLeast(0)
        val anim = ValueAnimator.ofInt(from, landing)
        anim.duration = 750
        anim.interpolator = BounceInterpolator()
        anim.addUpdateListener { a ->
            lp.y = a.animatedValue as Int
            try {
                wm.updateViewLayout(p, lp)
            } catch (ex: IllegalArgumentException) {
                // removed
            }
        }
        hopAnim = anim
        anim.start()
    }

    // ---- coming and going -----------------------------------------------------------------

    /** Slides the pet window horizontally (a view cannot leave its own window, so move the window). */
    private fun slide(toX: Int, toAlpha: Float, endAction: (() -> Unit)? = null) {
        val p = pet ?: return
        val lp = petParams ?: return
        slideAnim?.cancel()
        val fromX = lp.x
        val fromAlpha = p.alpha
        val anim = ValueAnimator.ofFloat(0f, 1f)
        anim.duration = 600
        anim.addUpdateListener { a ->
            val f = a.animatedValue as Float
            lp.x = (fromX + (toX - fromX) * f).toInt()
            p.alpha = fromAlpha + (toAlpha - fromAlpha) * f
            try {
                wm.updateViewLayout(p, lp)
            } catch (ex: IllegalArgumentException) {
                // view removed mid-animation
            }
        }
        anim.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (!cancelled) endAction?.invoke()
            }
        })
        slideAnim = anim
        anim.start()
    }

    /** A deadline due today/tomorrow beats the usual small talk. */
    private fun pickMessage(): String {
        val soon = ReminderLog.upcoming(s.logs()).firstOrNull { ReminderLog.daysLeft(it) <= 1 }
        return if (soon != null) {
            val `when` = if (ReminderLog.daysLeft(soon) == 0L) "TODAY" else "tomorrow"
            if (ReminderLog.isRegistration(soon)) "📝 Registration for ${ReminderLog.label(soon)} closes $`when`!"
            else "📌 ${ReminderLog.label(soon)} is due $`when`!"
        } else chatter.idleLine()
    }

    private fun summon(message: String = pickMessage()) {
        val p = pet ?: return
        if (chatBox != null) return
        p.visibility = View.VISIBLE
        slide(homeX(), 1f) { hop() }
        showBubble(message)
        handler.postDelayed({ react() }, 500)
        handler.removeCallbacks(leaveTask)
        handler.postDelayed(leaveTask, (12_000L..30_000L).random())
    }

    private fun leave() {
        removeQuietly(bubble)
        bubble = null
        if (chatBox != null) return
        val p = pet ?: return
        slide(-s.petSize, 0f) { p.visibility = View.INVISIBLE }
    }

    private fun showBubble(msg: String) {
        removeQuietly(bubble)
        val tv = TextView(this)
        tv.text = msg
        tv.setTextColor(ink)
        tv.textSize = 15f
        tv.setPadding(dp(14), dp(10), dp(14), dp(10))
        tv.background = bubbleBg()
        val width = dp(220)
        val lp = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = minOf(homeX() + s.petSize - dp(20), maxOf(0, screenW() - width))
        lp.y = maxOf(dp(40), homeY() + dp(30))
        wm.addView(tv, lp)
        bubble = tv
    }

    // ---- chat -----------------------------------------------------------------------------

    private fun openChat() {
        if (chatBox != null) return
        removeQuietly(bubble)
        bubble = null
        handler.removeCallbacks(leaveTask)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(12), dp(12), dp(12))
        box.background = bubbleBg()

        val log = TextView(this)
        log.text = "Ghostie: Hi! 💜\n\n"
        log.textSize = 14f
        log.setTextColor(ink)
        val scroll = ScrollView(this)
        scroll.addView(log)
        box.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(160)))

        val input = EditText(this)
        input.hint = "Say something…"
        input.isSingleLine = true
        input.setTextColor(ink)
        input.setHintTextColor(Color.GRAY)
        val send = Button(this)
        send.text = "➤"
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(send, LinearLayout.LayoutParams(dp(56), LinearLayout.LayoutParams.WRAP_CONTENT))
        box.addView(row)

        val close = Button(this)
        close.text = "Close"
        close.setOnClickListener { closeChat() }
        box.addView(close)

        fun append(who: String, text: String) {
            log.append("$who: $text\n\n")
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }

        send.setOnClickListener {
            val q = input.text.toString().trim()
            if (q.isEmpty()) return@setOnClickListener
            input.text.clear()
            append("You", q)
            val command = Commands.parse(q)
            val useAi = s.ai && s.key.isNotBlank()
            if (command != null) {
                runCommand(command) { append("Ghostie", it) }
            } else if (useAi) {
                val past = chatHistory.toList()
                scope.launch {
                    val a = ChatEngine.openAi(s.key, past, q)
                    chatHistory.add("user" to q)
                    chatHistory.add("assistant" to a)
                    append("Ghostie", a)
                }
            } else {
                val answer = chatter.reply(q)
                if (chatter.userName != s.userName) s.userName = chatter.userName
                // a short "thinking" pause makes it feel like a friend, not a lookup table
                handler.postDelayed({
                    append("Ghostie", answer)
                    react()
                }, (450L + answer.length * 12L).coerceAtMost(1500L))
            }
        }

        val width = dp(300)
        val lp = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = homeX().coerceIn(0, maxOf(0, screenW() - width))
        lp.y = maxOf(dp(40), homeY() - dp(300))
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        wm.addView(box, lp)
        chatBox = box
    }

    // ---- commands -------------------------------------------------------------------------

    private fun startSafely(intent: Intent): Boolean = try {
        startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }

    private fun runCommand(cmd: Command, say: (String) -> Unit) {
        when (cmd) {
            is Command.Help -> say(Commands.HELP)
            is Command.Incomplete -> say(cmd.message)
            is Command.Organize -> organizeDocs(say)
            is Command.Event -> {
                val whenText = java.time.Instant.ofEpochMilli(cmd.startMillis).atZone(java.time.ZoneId.systemDefault())
                    .format(java.time.format.DateTimeFormatter.ofPattern("EEE d MMM, h:mm a", java.util.Locale.ENGLISH))
                val id = CalendarHelper.insert(this, cmd.title, "Added by Ghostie", cmd.startMillis, 60, 10)
                if (id != null) {
                    say("Added \"${cmd.title}\" to your calendar for $whenText 📅")
                } else {
                    // No calendar permission yet: fall back to the calendar's own screen, pre-filled.
                    val i = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                        .putExtra(CalendarContract.Events.TITLE, cmd.title)
                        .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, cmd.startMillis)
                        .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, cmd.startMillis + 60 * 60_000L)
                    say(if (startSafely(i)) "Opening your calendar to save it 📅 (turn on Calendar in the Ghostie app and I'll add events instantly.)"
                    else "I couldn't find a calendar app on this phone.")
                }
            }
            is Command.Watch -> {
                s.addWatchedGroup(cmd.group)
                val listenerOn = androidx.core.app.NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
                if (listenerOn) {
                    say("Watching \"${cmd.group}\" 👀 If someone posts a submission date there, I'll set a reminder for the day before.")
                } else {
                    startSafely(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    say("Added \"${cmd.group}\" 👀 Now switch on Notification access for Ghostie (I opened the page) so I can read that group's messages.")
                }
            }
            is Command.ShowDocs -> {
                if (!DocOrganizer.hasAccess(this)) {
                    say("I need file access first - say \"organize documents\" and I'll open the setting.")
                } else {
                    val found = DocOrganizer.listSubject(cmd.subject, s.subjects)
                    if (found == null) {
                        say("I don't have a folder for \"${cmd.subject}\" yet. Try \"organize documents\" first.")
                    } else {
                        val (folder, files) = found
                        if (files.isEmpty()) say("$folder is empty.")
                        else {
                            val shown = files.take(8).joinToString("\n") { "• ${it.name}" }
                            val more = if (files.size > 8) "\n...and ${files.size - 8} more" else ""
                            say("$folder has ${files.size} files (newest first):\n$shown$more\n📂 Documents/Ghostie/$folder")
                        }
                    }
                }
            }
            is Command.Timer -> {
                val i = Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, cmd.seconds)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                say(if (startSafely(i)) "Timer set for ${formatDuration(cmd.seconds)} ⏱️" else "I couldn't start a timer on this phone.")
            }
            is Command.Alarm -> {
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, cmd.hour)
                    .putExtra(AlarmClock.EXTRA_MINUTES, cmd.minute)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                say(if (startSafely(i)) "Alarm set for %02d:%02d ⏰".format(cmd.hour, cmd.minute) else "I couldn't set an alarm on this phone.")
            }
            is Command.OpenApp -> {
                val pm = packageManager
                val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                val wanted = cmd.name.lowercase().trim()
                val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == wanted }
                    ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(wanted) }
                val intent = match?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
                say(if (intent != null && startSafely(intent)) "Opening ${match?.loadLabel(pm)} 🚀" else "I couldn't find an app called \"${cmd.name}\".")
            }
        }
    }

    private fun formatDuration(seconds: Int): String {
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val sec = seconds % 60
        return listOfNotNull(
            if (h > 0) "$h h" else null,
            if (m > 0) "$m min" else null,
            if (sec > 0) "$sec s" else null
        ).joinToString(" ")
    }

    private fun organizeDocs(say: (String) -> Unit) {
        if (!DocOrganizer.hasAccess(this)) {
            val i = if (Build.VERSION.SDK_INT >= 30) {
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            } else {
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            }
            startSafely(i)
            say("I need file access first 📂 I opened the settings - switch it on for Ghostie, then ask me again.")
            return
        }
        say("On it... sorting your WhatsApp documents 📂")
        scope.launch {
            val result = try {
                withContext(Dispatchers.IO) { DocOrganizer.organize(s.subjects) }
            } catch (e: Exception) {
                null
            }
            say(if (result != null) DocOrganizer.summary(result) else "Something went wrong while organizing.")
        }
    }

    private fun closeChat() {
        removeQuietly(chatBox)
        chatBox = null
        handler.removeCallbacks(leaveTask)
        handler.postDelayed(leaveTask, 3000)
    }

    // ---- touch: drag to move, tap to act --------------------------------------------------

    private inner class DragTouch(
        private val lp: WindowManager.LayoutParams,
        private val target: View,
        private val persist: Boolean,
        private val onTap: () -> Unit
    ) : View.OnTouchListener {
        private var startRawX = 0f
        private var startRawY = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = e.rawX
                    startRawY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - startRawX
                    val dy = e.rawY - startRawY
                    val slop = dp(6).toFloat()
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = (startX + dx).toInt().coerceIn(0, maxOf(0, screenW() - lp.width))
                        lp.y = (startY + dy).toInt().coerceIn(0, maxOf(0, screenH() - lp.height))
                        try {
                            wm.updateViewLayout(target, lp)
                        } catch (ex: IllegalArgumentException) {
                            // view removed
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        if (persist) {
                            s.x = lp.x
                            s.y = lp.y
                        }
                    } else {
                        onTap()
                    }
                }
            }
            return true
        }
    }
}
