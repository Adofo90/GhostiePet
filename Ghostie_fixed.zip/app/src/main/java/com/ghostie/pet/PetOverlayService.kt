package com.ghostie.pet

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioManager
import android.os.FileObserver
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import android.net.Uri
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.BounceInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

class PetOverlayService : Service() {

    companion object {
        const val ACTION_SUMMON = "SUMMON"
        const val ACTION_RESET = "RESET"
        const val ACTION_SKIN = "SKIN"
        const val ACTION_SAY = "SAY"
        const val ACTION_PLAN = "PLAN"
        const val ACTION_STUDY_START = "STUDY_START"
        const val ACTION_STUDY_STOP = "STUDY_STOP"
        const val ACTION_VOICE = "VOICE"
    }

    private lateinit var wm: WindowManager
    private lateinit var s: SettingsStore
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var pet: ImageView? = null
    private var petParams: WindowManager.LayoutParams? = null
    private var handle: ImageView? = null
    private var bubble: TextView? = null
    private var chatBox: View? = null
    private var idleAnim: ObjectAnimator? = null
    private var slideAnim: ValueAnimator? = null
    private var swayAnim: ObjectAnimator? = null
    private var handleAnim: ObjectAnimator? = null
    private var hopAnim: ValueAnimator? = null
    private var reacting = false
    private var suppressed = false
    private var fgNotification: Notification? = null
    private var listenStartedAt = 0L
    private var silentMisses = 0
    private var vin: VoiceInput? = null
    private var voiceSink: ((String) -> Unit)? = null
    private var lastEvent: Pair<Command.Event, Long>? = null
    private var pendingChips: List<String> = emptyList()
    private var binView: TextView? = null
    private var binParams: WindowManager.LayoutParams? = null
    private var overBin = false
    private var voice: GhostVoice? = null
    private var lastLine: Chatter.Line? = null
    private var lastLineAt = 0L
    private var chipRow: LinearLayout? = null
    private var submitRef: (String) -> Unit = {}
    private val petLines = listOf("Hehe, that tickles 💜", "Aww 🥹", "More pets please 👻", "I'm purring (ghosts can do that) 💜", "Best human 💜")
    private var sleeping = false
    private var wakeUntil = 0L
    private var lastDp = 0
    private val observers = mutableListOf<FileObserver>()
    private val hw = WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
    private val chatter by lazy { Chatter(s.userName, learner = LearnStore.get(this), model = SentenceStore.get(this)) }
    private val chatHistory = mutableListOf<Pair<String, String>>()

    private val ink = Color.rgb(55, 35, 75)
    private val overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    // ---- periodic tasks -------------------------------------------------------------------

    /** Little idle behaviours: a blink, or a quick glance to the side. Skipped while reacting. */
    private val blinkTask = object : Runnable {
        override fun run() {
            val p = pet
            if (p != null && !reacting && !suppressed && !sleeping && bigShown()) {
                if (s.tricks && (0..9).random() == 0) {
                    trick(listOf("dance", "wave", "yawn", "shiver", "flip").random())
                } else if ((0..9).random() < 4) {
                    p.animate().translationY(-dp(7).toFloat()).rotation(3f).setDuration(700)
                        .withEndAction { p.animate().translationY(0f).rotation(0f).setDuration(700).start() }.start()
                } else if ((0..9).random() < 6) {
                    p.scaleY = 0.88f
                    handler.postDelayed({ if (!reacting) p.scaleY = 1f }, 120)
                } else {
                    val dir = if ((0..1).random() == 0) -1 else 1
                    p.animate().translationX(dir * dp(6).toFloat()).setDuration(350)
                        .withEndAction { p.animate().translationX(0f).setDuration(350).start() }.start()
                }
            }
            else if (s.tricks && !suppressed && !sleeping && !reacting && !bigShown() && handle?.visibility == View.VISIBLE && (0..6).random() == 0) {
                trick(listOf("dance", "wave", "yawn", "shiver", "flip").random())
            }
            handler.postDelayed(this, (2500L..5000L).random())
        }
    }
    private val leaveTask = Runnable { leave() }

    /** Every few seconds: hide during calls / landscape / Do Not Disturb, sleep at night, follow size changes. */
    private val stateTask = object : Runnable {
        override fun run() {
            try {
                refreshState()
            } catch (e: Exception) {
                // never let a state check crash the overlay
            }
            handler.postDelayed(this, 3000)
        }
    }
    private val autoOrganizeTask = object : Runnable {
        override fun run() {
            if (s.autoOrganize && DocOrganizer.hasAccess(this@PetOverlayService)) AutoOrganizer.request(this@PetOverlayService, 5_000L)
            handler.postDelayed(this, 6 * 60 * 60_000L)
        }
    }
    private val checkInTask = object : Runnable {
        override fun run() {
            if (canVisit() && s.checkins) summon()
            handler.postDelayed(this, s.visitMinutes * 60_000L)
        }
    }
    private val waterTask = object : Runnable {
        override fun run() {
            if (canVisit()) summon(chatter.prompt("water", "Water check 💧 A few sips?", listOf("Just did", "Not yet")))
            handler.postDelayed(this, s.waterMinutes * 60_000L)
        }
    }

    // ---- lifecycle ------------------------------------------------------------------------

    override fun onCreate() {
        super.onCreate()
        s = SettingsStore(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        voice = GhostVoice(this, s)
        vin = VoiceInput(this, { handleSpoken(it) }, { handleVoiceState(it) })
        startInForeground()
        createViews()
        handler.postDelayed(checkInTask, s.visitMinutes * 60_000L)
        handler.postDelayed(waterTask, s.waterMinutes * 60_000L)
        handler.postDelayed(stateTask, 1000)
        handler.postDelayed(autoOrganizeTask, 30_000L)
        startObservers()
        startBatteryWatch()
        if (s.studyActive) handler.postDelayed(studyTask, 2000)
        handler.postDelayed(agentTask, 90_000L)
        ActivityLog.add(this, "Ghost", "Ghostie started")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createViews() // no-op if already created; picks up a newly granted overlay permission
        startObservers()
        when (intent?.action) {
            ACTION_STUDY_START -> startStudy(intent.getIntExtra("focus", s.studyFocus), intent.getIntExtra("brk", s.studyBreak), null)
            ACTION_STUDY_STOP -> stopStudy(true)
            ACTION_SUMMON -> summon()
            ACTION_PLAN -> planCommand { msg -> val c = pendingChips; pendingChips = emptyList(); summon(Chatter.Line(msg, c)) }
            ACTION_SAY -> intent.getStringExtra("text")?.let { summon(it) }
            ACTION_SKIN -> {
                pet?.setImageDrawable(Skins.drawable(this, Skins.byId(s.skin)))
                handle?.setImageDrawable(Skins.drawable(this, Skins.byId(s.skin)))
            }
            ACTION_VOICE -> intent.getStringExtra("text")?.let { handleSpoken(it) }
            ACTION_RESET -> {
                s.resetPosition()
                destroyViews()
                createViews()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(agentTask)
        handler.removeCallbacks(studyTask)
        hideBlock()
        try { batteryReceiver?.let { unregisterReceiver(it) } } catch (e: Exception) { }
        batteryReceiver = null
        observers.forEach { it.stopWatching() }
        observers.clear()
        SentenceStore.save(this)
        voice?.shutdown()
        voice = null
        vin?.cancel()
        vin = null
        removeQuietly(binView)
        binView = null
        handler.removeCallbacksAndMessages(null)
        destroyViews()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startInForeground() {
        val channelId = "ghostie_service"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Ghostie service", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
        )
        val notification = Notification.Builder(this, channelId)
            .setSmallIcon(R.drawable.ghost_pet)
            .setContentTitle("Ghostie is nearby")
            .setContentText("Floating companion is running")
            .setOngoing(true)
            .build()
        fgNotification = notification
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(7, notification)
        }
    }

    // ---- helpers --------------------------------------------------------------------------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun screenW(): Int = resources.displayMetrics.widthPixels
    private fun screenH(): Int = resources.displayMetrics.heightPixels
    private fun homeX(): Int = if (s.x >= 0) s.x else dp(16)
    private fun homeY(): Int = if (s.y >= 0) s.y else screenH() - petPx() - dp(60)
    private fun petPx(): Int = dp(s.petDp.coerceIn(48, 220))
    private fun canVisit(): Boolean = s.enabled && !suppressed && !sleeping && System.currentTimeMillis() > s.quietUntil && !(s.studyActive && s.studyPhase == "focus") && java.time.LocalTime.now().hour !in s.quietHourSet()

    private fun isNight(): Boolean {
        val h = java.time.LocalTime.now().hour
        return h >= 23 || h < 6
    }

    private fun refreshState() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val inCall = am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION || am.mode == AudioManager.MODE_RINGTONE
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val nm = getSystemService(NotificationManager::class.java)
        val dnd = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL && nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
        val now = System.currentTimeMillis()
        val shouldSuppress = inCall || landscape || (dnd && !s.studyActive)
        if (shouldSuppress != suppressed) {
            suppressed = shouldSuppress
            if (suppressed) {
                removeQuietly(bubble); bubble = null
                removeQuietly(chatBox); chatBox = null
                pet?.visibility = View.INVISIBLE
                handle?.visibility = View.GONE
            } else {
                handle?.visibility = View.VISIBLE
            }
        }
        val shouldSleep = s.sleepEnabled && isNight() && now > wakeUntil
        if (shouldSleep != sleeping) {
            sleeping = shouldSleep
            handle?.alpha = if (sleeping) 0.3f else 0.7f
            if (sleeping) { removeQuietly(bubble); bubble = null; if (chatBox == null) pet?.visibility = View.INVISIBLE }
        }
        if (lastDp != s.petDp) {
            lastDp = s.petDp
            pet?.let { v ->
                petParams?.let { lp ->
                    lp.width = petPx(); lp.height = petPx()
                    try { wm.updateViewLayout(v, lp) } catch (e: IllegalArgumentException) { }
                }
            }
        }
    }

    private fun startObservers() {
        observers.forEach { it.stopWatching() }
        observers.clear()
        if (!s.autoOrganize || !DocOrganizer.hasAccess(this)) return
        for (dir in DocOrganizer.sourceFolders()) {
            if (!dir.isDirectory) continue
            @Suppress("DEPRECATION")
            val o = object : FileObserver(dir.absolutePath, CREATE or MOVED_TO or CLOSE_WRITE) {
                override fun onEvent(event: Int, path: String?) {
                    if (path != null && !path.startsWith(".")) AutoOrganizer.request(this@PetOverlayService)
                }
            }
            o.startWatching()
            observers.add(o)
        }
    }

    private fun removeQuietly(v: View?) {
        if (v == null) return
        try {
            wm.removeView(v)
        } catch (ex: IllegalArgumentException) {
            // already removed
        }
    }

    private fun bubbleBg() = GradientDrawable().apply {
        setColor(Color.WHITE)
        cornerRadius = dp(14).toFloat()
        setStroke(2, Color.rgb(190, 150, 235))
    }

    // ---- views ----------------------------------------------------------------------------

    private fun createViews() {
        if (pet != null || !Settings.canDrawOverlays(this)) return

        val size = petPx()
        lastDp = s.petDp
        val lp = WindowManager.LayoutParams(
            size, size, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or hw,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = homeX()
        lp.y = homeY()

        val view = ImageView(this)
        view.setImageDrawable(Skins.drawable(this, Skins.byId(s.skin)))
        view.scaleType = ImageView.ScaleType.FIT_CENTER
        view.setOnTouchListener(PetTouch(lp, view))
        wm.addView(view, lp)
        pet = view
        petParams = lp
        startIdle(view)

        // Small draggable handle on the screen edge: tap to summon Ghostie.
        val hp = WindowManager.LayoutParams(
            dp(48), dp(48), overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or hw,
            PixelFormat.TRANSLUCENT
        )
        hp.gravity = Gravity.TOP or Gravity.START
        hp.x = dp(4)
        hp.y = screenH() / 2
        val h = ImageView(this)
        h.setImageDrawable(Skins.drawable(this, Skins.byId(s.skin)))
        h.scaleType = ImageView.ScaleType.CENTER_INSIDE
        h.alpha = 0.7f
        h.setPadding(dp(6), dp(6), dp(6), dp(6))
        h.setOnTouchListener(DragTouch(hp, h, false) {
            s.quietUntil = 0L
            if (sleeping) {
                wakeUntil = System.currentTimeMillis() + 10 * 60_000L
                sleeping = false
                h.alpha = 0.7f
                summon("Mmh... I'm up 🥱 (for a bit)")
            } else if (s.directChat) openChatDirect()
            else summon()
            react()
        })
        wm.addView(h, hp)
        handle = h
    }

    private fun destroyViews() {
        handler.removeCallbacks(blinkTask)
        handler.removeCallbacks(leaveTask)
        idleAnim?.cancel()
        slideAnim?.cancel()
        swayAnim?.cancel()
        handleAnim?.cancel()
        hopAnim?.cancel()
        swayAnim = null
        handleAnim = null
        hopAnim = null
        idleAnim = null
        slideAnim = null
        removeQuietly(bubble)
        removeQuietly(chatBox)
        removeQuietly(handle)
        removeQuietly(pet)
        bubble = null
        chatBox = null
        handle = null
        pet = null
        petParams = null
    }

    private fun startIdle(view: View) {
        // No endless animators (they redraw every frame and made the ghost laggy);
        // blinkTask plays a short bob / blink / glance every few seconds instead.
        handler.removeCallbacks(blinkTask)
        handler.postDelayed(blinkTask, 1500)
    }

    /** Squash-and-stretch pop: used when tapped, when it speaks and when it arrives. */
    private fun react() {
        val p = pet ?: return
        if (reacting) return
        reacting = true
        p.scaleY = 1f
        val pop = ObjectAnimator.ofPropertyValuesHolder(
            p,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.14f, 0.95f, 1f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 0.86f, 1.08f, 1f)
        )
        pop.duration = 500
        pop.interpolator = OvershootInterpolator()
        pop.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                reacting = false
            }
        })
        pop.start()
    }

    /** A bouncy landing after sliding in. */
    private fun hop() {
        val lp = petParams ?: return
        val p = pet ?: return
        hopAnim?.cancel()
        val landing = lp.y
        val from = (landing - dp(36)).coerceAtLeast(0)
        val anim = ValueAnimator.ofInt(from, landing)
        anim.duration = 750
        anim.interpolator = BounceInterpolator()
        anim.addUpdateListener { a ->
            lp.y = a.animatedValue as Int
            try {
                wm.updateViewLayout(p, lp)
            } catch (ex: IllegalArgumentException) {
                // removed
            }
        }
        hopAnim = anim
        anim.start()
    }

    // ---- coming and going -----------------------------------------------------------------

    /** Slides the pet window horizontally (a view cannot leave its own window, so move the window). */
    private fun slide(toX: Int, toAlpha: Float, endAction: (() -> Unit)? = null) {
        val p = pet ?: return
        val lp = petParams ?: return
        slideAnim?.cancel()
        val fromX = lp.x
        val fromAlpha = p.alpha
        val anim = ValueAnimator.ofFloat(0f, 1f)
        anim.duration = 600
        anim.addUpdateListener { a ->
            val f = a.animatedValue as Float
            lp.x = (fromX + (toX - fromX) * f).toInt()
            p.alpha = fromAlpha + (toAlpha - fromAlpha) * f
            try {
                wm.updateViewLayout(p, lp)
            } catch (ex: IllegalArgumentException) {
                // view removed mid-animation
            }
        }
        anim.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (!cancelled) endAction?.invoke()
            }
        })
        slideAnim = anim
        anim.start()
    }

    /** A deadline due today/tomorrow beats the usual small talk. */
    private fun pickMessage(): Chatter.Line {
        val soon = ReminderLog.upcoming(s.logs()).firstOrNull { ReminderLog.daysLeft(it) <= 1 }
        return if (soon != null) {
            val `when` = if (ReminderLog.daysLeft(soon) == 0L) "TODAY" else "tomorrow"
            val text = if (ReminderLog.isRegistration(soon)) "📝 Registration for ${ReminderLog.label(soon)} closes $`when`!"
            else "📌 ${ReminderLog.label(soon)} is due $`when`!"
            chatter.prompt("deadline", Moods.deadline(s.mood, text), listOf("Done ✅", "Remind me later"))
        } else {
            val base = chatter.idle()
            idleVisitFlag = true
            val flavoured = Moods.idle(s.mood, base.text)
            if (flavoured != base.text) { chatter.clearTopic(); Chatter.Line(flavoured) } else base
        }
    }

    private fun canSpeak() = !suppressed && !sleeping && System.currentTimeMillis() > s.quietUntil

    private fun summon(line: Chatter.Line = pickMessage()) {
        val p = pet ?: return
        if (chatBox != null || suppressed) return
        lastLine = line
        lastLineAt = System.currentTimeMillis()
        visitPending = idleVisitFlag
        idleVisitFlag = false
        p.visibility = View.VISIBLE
        slide(homeX(), 1f) { hop() }
        showBubble(line.text)
        if (canSpeak()) {
            voice?.sfx("hello")
            voice?.speak(line.text)
        }
        handler.postDelayed({ react() }, 500)
        handler.removeCallbacks(leaveTask)
        handler.postDelayed(leaveTask, (14_000L..30_000L).random())
    }

    private fun summon(text: String) = summon(Chatter.Line(text))

    /** "Open chat directly" option: the ghost slides in and the chat box opens at once, with no speech first. */
    private fun openChatDirect() {
        val p = pet ?: return
        if (chatBox != null || suppressed) return
        handler.removeCallbacks(leaveTask)
        removeQuietly(bubble)
        bubble = null
        lastLine = null
        p.visibility = View.VISIBLE
        slide(homeX(), 1f) { hop(); openChat() }
    }

    private fun leave() {
        if (chatBox == null) {
            chatter.unanswered(); LearnStore.save(this)
            if (visitPending) { visitPending = false; HabitStore.get(this).visit(java.time.LocalTime.now().hour, false); HabitStore.save(this) }
        }
        removeQuietly(bubble)
        bubble = null
        if (chatBox != null) return
        val p = pet ?: return
        slide(-petPx(), 0f) { p.visibility = View.INVISIBLE }
    }

    private fun showBubble(msg: String, atX: Int = homeX(), atY: Int = homeY()) {
        removeQuietly(bubble)
        val tv = TextView(this)
        tv.text = msg
        tv.setTextColor(ink)
        tv.textSize = 15f
        tv.setPadding(dp(14), dp(10), dp(14), dp(10))
        tv.background = bubbleBg()
        val width = dp(220)
        val lp = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or hw,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = minOf(atX + petPx() - dp(20), maxOf(0, screenW() - width)).coerceAtLeast(0)
        lp.y = maxOf(dp(40), atY + dp(30))
        wm.addView(tv, lp)
        bubble = tv
    }

    // ---- chat -----------------------------------------------------------------------------

    private fun openChat() {
        if (chatBox != null) return
        removeQuietly(bubble)
        bubble = null
        handler.removeCallbacks(leaveTask)

        // Same look as the app (theme, accent and glass come from the Companion settings).
        val pal = Themes.palette(s)
        val lightTheme = (0.299 * Color.red(pal.text) + 0.587 * Color.green(pal.text) + 0.114 * Color.blue(pal.text)) < 128
        // On top of other apps glass needs a firmer base than inside Ghostie, or text gets lost in busy screens.
        val cBox = if (!pal.glass) pal.card else if (lightTheme) Color.argb(0xB8, 255, 255, 255) else Color.argb(0x9E, 18, 16, 28)
        val cStroke = pal.stroke
        val cField = pal.field
        val cText = pal.text
        val cSub = pal.sub
        val cAccent = pal.accent
        val cOn = pal.onAccent
        val cGhostBubble = pal.bubble
        var boxLp: WindowManager.LayoutParams? = null
        var wDp = s.chatW.coerceIn(220, 520)
        var hDp = s.chatH.coerceIn(100, 560)
        fun boxWidthPx() = minOf(dp(wDp), screenW() - dp(8))
        fun bubbleMaxPx() = (boxWidthPx() * 0.74f).toInt()

        fun shape(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }

        fun circleButton(text: String, filled: Boolean): TextView = TextView(this).apply {
            this.text = text
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(if (filled) cOn else cAccent)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                if (filled) setColor(cAccent) else { setColor(cField); setStroke(dp(1), cAccent) }
            }
            isClickable = true
        }

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(10), dp(12), dp(12))
        box.background = shape(cBox, 20, cStroke)

        // Header: avatar, name, close
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val avatar = ImageView(this)
        avatar.setImageResource(R.drawable.ghost_pet)
        header.addView(avatar, LinearLayout.LayoutParams(dp(30), dp(30)))
        val nameCol = LinearLayout(this)
        nameCol.orientation = LinearLayout.VERTICAL
        nameCol.setPadding(dp(8), 0, 0, 0)
        nameCol.addView(TextView(this).apply { text = "Ghostie"; textSize = 15f; setTextColor(cText); setTypeface(typeface, android.graphics.Typeface.BOLD) })
        nameCol.addView(TextView(this).apply { text = "hold the ghost to talk 🎙️"; textSize = 10f; setTextColor(cSub) })
        header.addView(nameCol, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val closeX = TextView(this)
        closeX.text = "✕"
        closeX.textSize = 18f
        closeX.setTextColor(cSub)
        closeX.setPadding(dp(12), dp(6), dp(4), dp(6))
        closeX.setOnClickListener { closeChat() }
        header.addView(closeX)
        box.addView(header)

        // Messages
        val msgs = LinearLayout(this)
        msgs.orientation = LinearLayout.VERTICAL
        msgs.setPadding(0, dp(8), 0, dp(4))
        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(msgs)
        val scrollLp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(hDp))
        box.addView(scroll, scrollLp)

        fun bubbleView(mine: Boolean, text: String): TextView = TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(if (mine) cOn else cText)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = shape(if (mine) cAccent else cGhostBubble, 16)
            maxWidth = bubbleMaxPx()
        }

        fun append(who: String, text: String) {
            val mine = who == "You"
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.gravity = if (mine) Gravity.END else Gravity.START
            lp.topMargin = dp(6)
            msgs.addView(bubbleView(mine, text), lp)
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }

        // Continue whatever the ghost just said when it popped up.
        val carry = lastLine?.takeIf { System.currentTimeMillis() - lastLineAt < 15 * 60_000L }
        append("Ghostie", carry?.text ?: "Hi! 💜")
        if (carry != null && s.ai && s.key.isNotBlank() && chatHistory.isEmpty()) chatHistory.add("assistant" to carry.text)

        // Quick replies
        val chipScroll = HorizontalScrollView(this)
        chipScroll.isHorizontalScrollBarEnabled = false
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        chips.setPadding(0, dp(4), 0, dp(4))
        chipScroll.addView(chips)
        box.addView(chipScroll)
        chipRow = chips

        // Input row
        val input = EditText(this)
        input.hint = "Say something…"
        input.isSingleLine = true
        input.textSize = 14f
        input.setTextColor(cText)
        input.setHintTextColor(cSub)
        input.background = shape(cField, 22, cStroke)
        input.setPadding(dp(14), dp(8), dp(14), dp(8))
        val mic = circleButton("🎙", false)
        val send = circleButton("➤", true)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(input, LinearLayout.LayoutParams(0, dp(44), 1f))
        row.addView(mic, LinearLayout.LayoutParams(dp(44), dp(44)).apply { leftMargin = dp(6) })
        row.addView(send, LinearLayout.LayoutParams(dp(44), dp(44)).apply { leftMargin = dp(6) })
        box.addView(row)

        // Drag this corner to resize the box; drag the header to move it. Both are remembered.
        val grip = TextView(this)
        grip.text = "◢"
        grip.textSize = 16f
        grip.setTextColor(cSub)
        grip.gravity = Gravity.END or Gravity.BOTTOM
        grip.setPadding(dp(24), dp(2), dp(2), 0)
        box.addView(grip, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        grip.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var w0 = 0; var h0 = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val l = boxLp ?: return false
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; w0 = l.width; h0 = scrollLp.height; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val maxW = maxOf(dp(220), screenW() - l.x)
                        val w = (w0 + (e.rawX - sx)).toInt().coerceIn(dp(220), maxW)
                        val h = (h0 + (e.rawY - sy)).toInt().coerceIn(dp(100), maxOf(dp(100), screenH() - l.y - dp(200)))
                        wDp = (w / resources.displayMetrics.density).toInt(); hDp = (h / resources.displayMetrics.density).toInt()
                        l.width = w; scrollLp.height = h; scroll.layoutParams = scrollLp
                        val bm = (w * 0.74f).toInt()
                        for (i in 0 until msgs.childCount) (msgs.getChildAt(i) as? TextView)?.maxWidth = bm
                        try { wm.updateViewLayout(box, l) } catch (ex: IllegalArgumentException) { }
                        return true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { s.chatW = wDp; s.chatH = hDp; return true }
                }
                return false
            }
        })
        header.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var x0 = 0; var y0 = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val l = boxLp ?: return false
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; x0 = l.x; y0 = l.y; return true }
                    MotionEvent.ACTION_MOVE -> {
                        l.x = (x0 + (e.rawX - sx)).toInt().coerceIn(0, maxOf(0, screenW() - l.width))
                        l.y = (y0 + (e.rawY - sy)).toInt().coerceIn(0, maxOf(0, screenH() - dp(160)))
                        try { wm.updateViewLayout(box, l) } catch (ex: IllegalArgumentException) { }
                        return true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { s.chatX = l.x; s.chatY = l.y; return true }
                }
                return false
            }
        })

        fun ghostSays(text: String) {
            append("Ghostie", text)
            if (canSpeak()) voice?.speak(text)
        }

        fun showChips(list: List<String>, submit: (String) -> Unit) {
            chips.removeAllViews()
            for (c in list) {
                val b = TextView(this)
                b.text = c
                b.textSize = 13f
                b.setTextColor(cAccent)
                b.setPadding(dp(14), dp(6), dp(14), dp(6))
                b.background = shape(cField, 18, cAccent)
                b.isClickable = true
                b.setOnClickListener { submit(c) }
                chips.addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) })
            }
        }

        fun submit(q: String) {
            append("You", q)
            chips.removeAllViews()
            converse(q) { text, next ->
                ghostSays(text)
                react()
                voice?.sfx("pop")
                showChips(next) { submitRef(it) }
            }
        }
        submitRef = ::submit

        mic.setOnClickListener {
            input.hint = "Listening…"
            startListening { text -> input.hint = "Say something…"; submit(text) }
        }
        send.setOnClickListener {
            val q = input.text.toString().trim()
            if (q.isEmpty()) return@setOnClickListener
            input.text.clear()
            submit(q)
        }
        carry?.let { showChips(it.chips) { c -> submit(c) } }

        val width = boxWidthPx()
        val lp = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or hw,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (s.chatX >= 0 && s.chatY >= 0) {
            lp.x = s.chatX.coerceIn(0, maxOf(0, screenW() - width))
            lp.y = s.chatY.coerceIn(0, maxOf(0, screenH() - dp(160)))
        } else {
            lp.x = homeX().coerceIn(0, maxOf(0, screenW() - width))
            lp.y = maxOf(dp(40), homeY() - dp(300))
        }
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        if (pal.glass && Build.VERSION.SDK_INT >= 31) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = dp(28)
        }
        boxLp = lp
        wm.addView(box, lp)
        chatBox = box
    }

    // ---- commands -------------------------------------------------------------------------

    private fun startSafely(intent: Intent, label: String = "it"): Boolean = try {
        startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        if (s.openFallback) Notifier.openFallback(this, intent, label)
        ActivityLog.add(this, "Launch", "Asked Android to open $label")
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }

    private fun runCommand(cmd: Command, say: (String) -> Unit) {
        when (cmd) {
            is Command.Help -> say(Commands.HELP)
            is Command.Incomplete -> say(cmd.message)
            is Command.Organize -> organizeDocs(say)
            is Command.Event -> addEvent(cmd, say)
            is Command.Note -> {
                s.setNotes(s.notes() + cmd.text)
                say("Noted 📝 \"${cmd.text}\" (${s.notes().size} note(s)). Say \"show notes\" anytime.")
            }
            is Command.ShowNotes -> {
                val n = s.notes()
                say(if (n.isEmpty()) "No notes yet. Try: note buy milk" else "Your notes 📝\n" + n.mapIndexed { i, x -> "${i + 1}. $x" }.joinToString("\n"))
            }
            is Command.ClearNotes -> { s.setNotes(emptyList()); say("All notes cleared 🧹") }
            is Command.TodoAdd -> {
                s.setTodos(s.todos() + (false to cmd.text))
                say("Added to your to-do list ✅ (${s.todos().count { !it.first }} open). Say \"done ${s.todos().size}\" when finished.")
            }
            is Command.TodoList -> {
                val l = s.todos()
                say(if (l.isEmpty()) "Your to-do list is empty 🎉 Try: todo finish lab record"
                else "To-do list ✅\n" + l.mapIndexed { i, x -> "${i + 1}. " + (if (x.first) "✔ " else "") + x.second }.joinToString("\n"))
            }
            is Command.TodoDone -> {
                val l = s.todos().toMutableList()
                if (cmd.n < 1 || cmd.n > l.size) say("I don't have a task ${cmd.n}. Say \"my todos\" to see the list.")
                else {
                    l[cmd.n - 1] = true to l[cmd.n - 1].second
                    s.setTodos(l.filter { !it.first } + l.filter { it.first }.takeLast(10))
                    say("Nice! Ticked off \"${l[cmd.n - 1].second}\" 🎉")
                }
            }
            is Command.Flashlight -> setTorch(cmd.on, say)
            is Command.Quick -> say(
                when (cmd.kind) {
                    "coin" -> "🪙 " + listOf("Heads!", "Tails!").random()
                    "dice" -> "🎲 You rolled a ${(1..6).random()}"
                    "time" -> "It's " + java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("h:mm a", java.util.Locale.ENGLISH)) + " ⏰"
                    "date" -> "Today is " + java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", java.util.Locale.ENGLISH)) + " 📅"
                    else -> {
                        val pct = try { (getSystemService(BATTERY_SERVICE) as android.os.BatteryManager).getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) } catch (e: Exception) { -1 }
                        if (pct < 0) "I can't read the battery 🤷" else "Battery is at $pct% 🔋" + if (pct <= 20) " - maybe charge soon?" else ""
                    }
                }
            )
            is Command.Calculate -> {
                val v = Calc.eval(cmd.expr)
                say(if (v == null) "I couldn't work that out 🤔 Try: calculate 12*(3+4)" else "${cmd.expr.trim()} = ${Calc.format(v)} 🧮")
            }
            is Command.RemindIn -> {
                ReminderAlarms.quick(this, cmd.text, System.currentTimeMillis() + cmd.minutes * 60_000L)
                say("Okay! I'll remind you to ${cmd.text} in ${if (cmd.minutes >= 60 && cmd.minutes % 60 == 0) "${cmd.minutes / 60} hour(s)" else "${cmd.minutes} minute(s)"} ⏰")
            }
            is Command.Trick -> { trick(cmd.kind); say(when (cmd.kind) { "dance" -> "💃 La la la~"; "wave" -> "Hiii! 👋"; "yawn" -> "Yaaawn... 🥱"; "shiver" -> "Brrr! 🥶"; else -> "Wheee! 🤸" }) }
            is Command.Study -> startStudy(cmd.focus ?: s.studyFocus, cmd.brk ?: s.studyBreak, say, cmd.subject?.let { canonicalSubject(it) })
            is Command.Plan -> planCommand(say)
            is Command.FoodStop -> { FoodScanService.stop(); say("Okay, stopping the price check 🛑") }
            is Command.Food -> foodCompare(cmd.items, say)
            is Command.Suggestions -> { s.suggestions = cmd.on; say(if (cmd.on) "Suggestions are on 💡 I'll only suggest things now and then." else "Okay, no more suggestions. Say \"start suggestions\" to turn them back on.") }
            is Command.ForgetHabits -> { HabitStore.reset(this); s.quietHoursList = ""; s.subjectLog = ""; say("Done. I've forgotten your routines and study history for subjects 🧹") }
            is Command.StudyStop -> if (s.studyActive) stopStudy(false).also { say("Study mode stopped. " + studySummary()) } else say("Study mode isn't running. Say \"study mode\" to start 📚")
            is Command.StudyLog -> say(studySummary(true))
            is Command.MakeKind -> remakeEvent(cmd.kind, say)
            is Command.Undo -> {
                val last = lastEvent
                if (last == null) say("Nothing to undo. I only undo the event I just added.")
                else {
                    CalendarHelper.delete(this, last.second)
                    s.removeLog(last.second)
                    RecentEvents.remove(this, last.second)
                    lastEvent = null
                    ActivityLog.add(this, "Calendar", "Undid ${last.first.title}")
                    say("Removed \"${last.first.title}\" from your calendar ↩️")
                }
            }
            is Command.Teach -> {
                val l = LearnStore.get(this)
                l.addAlias(cmd.phrase, cmd.meaning)
                LearnStore.save(this)
                ActivityLog.add(this, "Learning", "Taught: \"${cmd.phrase}\"")
                say(when {
                    cmd.meaning.startsWith("word:") -> "Got it 🧠 I'll read \"${cmd.phrase}\" as \"${cmd.meaning.removePrefix("word:")}\"."
                    cmd.meaning.startsWith("say:") -> "Got it 🧠 When you say \"${cmd.phrase}\" I'll say: ${cmd.meaning.removePrefix("say:")}"
                    else -> "Got it 🧠 When you say \"${cmd.phrase}\" I'll do: ${cmd.meaning}"
                })
            }
            is Command.Forget -> {
                val ok = LearnStore.get(this).removeAlias(cmd.phrase)
                LearnStore.save(this)
                say(if (ok) "Forgotten \"${cmd.phrase}\" 🧹" else "I don't have anything taught for \"${cmd.phrase}\".")
            }
            is Command.ForgetAll -> {
                LearnStore.reset(this)
                ActivityLog.add(this, "Learning", "Forgot everything")
                say("Memory wiped 🧹 I'm a blank ghost again.")
            }
            is Command.Learned -> {
                val l = LearnStore.get(this)
                val taught = l.aliases.entries.take(6).joinToString("\n") { "• \"${it.key}\" → ${it.value.removePrefix("word:").removePrefix("say:")}" }
                val ins = HabitStore.get(this).insights()
                say("Here's what I've learned 🧠\n" + l.summary() + (if (taught.isNotEmpty()) "\n$taught" else "") +
                    (if (ins.isEmpty()) "\n\nAbout your routines: still watching. Use me for a few days (study, chat, answer reminders) and I'll start spotting patterns."
                    else "\n\nAbout your routines:\n" + ins.joinToString("\n") { "• $it" }))
            }
            is Command.Watch -> {
                s.addWatchedGroup(cmd.group)
                val listenerOn = androidx.core.app.NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
                if (listenerOn) {
                    say("Watching \"${cmd.group}\" 👀 If someone posts a submission date there, I'll set a reminder for the day before.")
                } else {
                    startSafely(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    say("Added \"${cmd.group}\" 👀 Now switch on Notification access for Ghostie (I opened the page) so I can read that group's messages.")
                }
            }
            is Command.ShowDocs -> {
                if (!DocOrganizer.hasAccess(this)) {
                    say("I need file access first - say \"organize documents\" and I'll open the setting.")
                } else {
                    val found = DocOrganizer.listSubject(cmd.subject, s.subjects)
                    if (found == null) {
                        say("I don't have a folder for \"${cmd.subject}\" yet. Try \"organize documents\" first.")
                    } else {
                        val (folder, files) = found
                        if (files.isEmpty()) say("$folder is empty.")
                        else {
                            val shown = files.take(8).joinToString("\n") { "• ${it.name}" }
                            val more = if (files.size > 8) "\n...and ${files.size - 8} more" else ""
                            say("$folder has ${files.size} files (newest first):\n$shown$more\n📂 Documents/Ghostie/$folder")
                        }
                    }
                }
            }
            is Command.Timer -> {
                val i = Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, cmd.seconds)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                say(if (startSafely(i)) "Timer set for ${formatDuration(cmd.seconds)} ⏱️" else "I couldn't start a timer on this phone.")
            }
            is Command.Alarm -> {
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, cmd.hour)
                    .putExtra(AlarmClock.EXTRA_MINUTES, cmd.minute)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                if (cmd.label.isNotBlank()) i.putExtra(AlarmClock.EXTRA_MESSAGE, cmd.label.replaceFirstChar { it.uppercase() })
                val lbl = if (cmd.label.isNotBlank()) " (\"${cmd.label}\")" else ""
                say(if (startSafely(i)) "Alarm set for %02d:%02d$lbl ⏰".format(cmd.hour, cmd.minute) else "I couldn't set an alarm on this phone.")
            }
            is Command.Call -> callSomeone(cmd.target, say)
            is Command.OpenApp -> {
                val pm = packageManager
                val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                val wanted = cmd.name.lowercase().trim()
                val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == wanted }
                    ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(wanted) }
                val intent = match?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
                say(if (intent != null && startSafely(intent, match?.loadLabel(pm)?.toString() ?: "app")) "Opening ${match?.loadLabel(pm)} 🚀" else "I couldn't find an app called \"${cmd.name}\".")
            }
        }
    }

    private fun granted(perm: String) = ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED

    private fun callSomeone(target: String, say: (String) -> Unit) {
        val digits = target.filter { it.isDigit() || it == '+' }
        val looksLikeNumber = digits.count { it.isDigit() } >= 3 && target.all { it.isDigit() || it in "+ -()" }
        var number: String? = null
        var name = target
        if (looksLikeNumber) {
            number = digits
        } else {
            if (!granted(android.Manifest.permission.READ_CONTACTS)) {
                say("I need Contacts access to find \"$target\" 📇 Open the Ghostie app → Setup → Contacts & calls. (Or say a number: call 9876543210)")
                return
            }
            val found = findContact(target)
            if (found == null) { say("I couldn't find \"$target\" in your contacts."); return }
            name = found.first
            number = found.second
        }
        val emergency = number.filter { it.isDigit() }.let { it in setOf("100", "101", "102", "108", "112", "911", "999", "000") }
        val uri = Uri.parse("tel:" + Uri.encode(number))
        if (!emergency && granted(android.Manifest.permission.CALL_PHONE)) {
            say(if (startSafely(Intent(Intent.ACTION_CALL, uri))) "Calling $name 📞" else "I couldn't place that call.")
        } else {
            val why = if (emergency) "" else " (turn on Phone in the Ghostie app and I'll dial instantly)"
            say(if (startSafely(Intent(Intent.ACTION_DIAL, uri))) "Opened the dialer for $name 📞$why" else "I couldn't open the dialer.")
        }
    }

    /** Best match by name: exact, then starts-with, then contains. Returns (display name, number). */
    private fun findContact(query: String): Pair<String, String>? {
        val q = query.lowercase().trim()
        val rows = mutableListOf<Pair<String, String>>()
        try {
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0) ?: continue
                    val num = c.getString(1) ?: continue
                    rows.add(n to num)
                }
            }
        } catch (e: SecurityException) {
            return null
        }
        return rows.firstOrNull { it.first.lowercase() == q }
            ?: rows.firstOrNull { it.first.lowercase().startsWith(q) }
            ?: rows.firstOrNull { it.first.lowercase().split(" ").any { w -> w.startsWith(q) } }
            ?: rows.firstOrNull { it.first.lowercase().contains(q) }
    }

    // ---- calendar categories ----------------------------------------------------------------

    private fun whenText(e: Command.Event): String {
        val z = java.time.Instant.ofEpochMilli(e.startMillis).atZone(java.time.ZoneId.systemDefault())
        val fmt = if (e.allDay) "EEE d MMM" else "EEE d MMM, h:mm a"
        return z.format(java.time.format.DateTimeFormatter.ofPattern(fmt, java.util.Locale.ENGLISH))
    }

    private fun describe(e: Command.Event): String {
        val repeat = when (e.repeat) {
            "YEARLY" -> " (repeats every year)"; "WEEKLY" -> " (repeats weekly)"; "DAILY" -> " (repeats daily)"; "MONTHLY" -> " (repeats monthly)"; else -> ""
        }
        val extra = when (e.kind) {
            EventKind.BIRTHDAY -> "\nI'll remind you the day before and that morning."
            EventKind.ANNIVERSARY -> "\nReminders: a week before, the day before and that morning."
            EventKind.COUNTDOWN -> {
                val days = java.time.temporal.ChronoUnit.DAYS.between(java.time.LocalDate.now(), java.time.Instant.ofEpochMilli(e.startMillis).atZone(java.time.ZoneId.systemDefault()).toLocalDate())
                "\n$days days to go!"
            }
            else -> ""
        }
        return "Added ${e.kind.icon} ${e.title} on ${whenText(e)}$repeat$extra"
    }

    private fun addEvent(cmd: Command.Event, say: (String) -> Unit) {
        val l = LearnStore.get(this)
        var ev = cmd
        var note = ""
        val base = Commands.baseTitle(cmd.title)
        if (!cmd.explicit) {
            val kind = l.suggestKind(base)?.let { EventKind.parse(it) }
            if (kind != null && kind != EventKind.EVENT) {
                ev = Commands.withKind(cmd, kind)
                note = "\n(I remembered $base is a ${kind.label.lowercase()} ${kind.icon}. Say \"make it an event\" if that's wrong.)"
            }
        } else {
            l.teachKind(base, ev.kind.name)
            LearnStore.save(this)
        }
        val id = CalendarHelper.insertEvent(this, ev, "Added by Ghostie")
        if (id != null) {
            lastEvent = ev to id
            RecentEvents.add(this, ev, id)
            pendingChips = listOf("Undo ↩️", "Make it a birthday")
            if (ev.kind == EventKind.COUNTDOWN) {
                val d = java.time.Instant.ofEpochMilli(ev.startMillis).atZone(java.time.ZoneId.systemDefault()).toLocalDate()
                s.addLog(LogEntry(System.currentTimeMillis(), "Countdown", "⏳ Countdown: $base", d.toString(), id, ev.startMillis))
            }
            ActivityLog.add(this, "Calendar", "Added ${ev.kind.label}: ${ev.title}")
            say(describe(ev) + note)
        } else {
            // No calendar permission yet: open the calendar's own form, pre-filled.
            val i = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.Events.TITLE, ev.title)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, ev.startMillis)
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, ev.startMillis + ev.durationMin * 60_000L)
                .putExtra(CalendarContract.EXTRA_EVENT_ALL_DAY, ev.allDay)
            if (ev.repeat.isNotEmpty()) i.putExtra(CalendarContract.Events.RRULE, "FREQ=${ev.repeat}")
            if (ev.description.isNotBlank()) i.putExtra(CalendarContract.Events.DESCRIPTION, ev.description)
            say(if (startSafely(i)) "Opening your calendar to save it ${ev.kind.icon} (turn on Calendar in the Ghostie app and I'll add events instantly.)"
            else "I couldn't find a calendar app on this phone.")
        }
    }

    /** "make it a birthday": replaces the last event with the right category and remembers the correction. */
    private fun remakeEvent(kind: EventKind, say: (String) -> Unit) {
        val last = lastEvent
        if (last == null) { say("Which event? Add one first, e.g. \"add event Tikki on 19 October\"."); return }
        val (old, oldId) = last
        val ev = Commands.withKind(old, kind)
        CalendarHelper.delete(this, oldId)
        s.removeLog(oldId)
        val id = CalendarHelper.insertEvent(this, ev, "Added by Ghostie")
        if (id == null) { say("I couldn't change it - is Calendar allowed?"); return }
        lastEvent = ev to id
        RecentEvents.remove(this, oldId)
        RecentEvents.add(this, ev, id)
        pendingChips = listOf("Undo ↩️")
        val l = LearnStore.get(this)
        l.teachKind(Commands.baseTitle(ev.title), kind.name)
        LearnStore.save(this)
        ActivityLog.add(this, "Learning", "${Commands.baseTitle(ev.title)} is a ${kind.label}")
        say(describe(ev) + "\nI'll remember that \"${Commands.baseTitle(ev.title)}\" is a ${kind.label.lowercase()} 🧠")
    }

    // ---- learning agent -------------------------------------------------------------------------

    private var pendingSuggestion: Agent.Suggestion? = null
    private var pendingAt = 0L
    private var pendingAlias: Pair<String, String>? = null
    private var lastUnknown: Pair<String, Long>? = null
    private val declinedAliases = HashSet<String>()
    private var visitPending = false
    private var idleVisitFlag = false

    private val agentTask = object : Runnable {
        override fun run() {
            try { agentCheck() } catch (e: Exception) { }
            handler.postDelayed(this, 60_000L)
        }
    }

    private fun noteUse() {
        val h = HabitStore.get(this)
        val hour = java.time.LocalTime.now().hour
        h.touch(hour)
        if (visitPending) { visitPending = false; h.visit(hour, true) }
        HabitStore.save(this)
    }

    fun canonicalSubject(text: String): String {
        val c = SubjectMatcher.classify(text, SubjectMatcher.parse(s.subjects))
        return if (c != SubjectMatcher.UNSORTED) c else text.trim().replaceFirstChar { it.uppercase() }
    }

    private fun logFocus(mins: Int, finished: Boolean) {
        if (s.studySubject.isNotBlank()) s.subjectLog = SubjectLog.add(s.subjectLog, s.studySubject, mins)
        if (finished || mins >= 3) { HabitStore.get(this).focusResult(s.studyFocus, finished); HabitStore.save(this) }
    }

    private fun agentSnapshot(): Agent.Snapshot {
        val nowMs = System.currentTimeMillis()
        val dl = ReminderLog.upcoming(s.logs()).filter { !it.title.startsWith("⏳") }.map { Agent.Deadline(ReminderLog.label(it), ReminderLog.daysLeft(it)) }
        val today = java.time.LocalDate.now().toString()
        val countToday = s.suggestionDay.split('|').let { if (it.getOrNull(0) == today) it.getOrNull(1)?.toIntOrNull() ?: 0 else 0 }
        val recent = s.suggestionKeys.lines().mapNotNull {
            val ms = it.substringBefore('\t').toLongOrNull(); val k = it.substringAfter('\t', "")
            if (ms != null && nowMs - ms < 86_400_000L && k.isNotEmpty()) k else null
        }.toSet()
        return Agent.Snapshot(
            java.time.LocalDateTime.now(), dl, SubjectLog.bySubject(s.subjectLog), StudyLog.today(s.studyLog), StudyLog.streak(s.studyLog),
            s.studyActive, HabitStore.get(this), s.studyFocus, recent, countToday, s.lastSuggestionAt
        )
    }

    private fun agentCheck() {
        if (!s.suggestions || s.studyActive || chatBox != null || !canVisit()) return
        val nowMs = System.currentTimeMillis()
        if (pendingSuggestion != null && nowMs - pendingAt < 30 * 60_000L) return
        val sug = Agent.decide(agentSnapshot(), nowMs) ?: return
        val today = java.time.LocalDate.now().toString()
        val n = s.suggestionDay.split('|').let { if (it.getOrNull(0) == today) it.getOrNull(1)?.toIntOrNull() ?: 0 else 0 }
        s.suggestionDay = "$today|${n + 1}"
        s.lastSuggestionAt = nowMs
        s.suggestionKeys = (s.suggestionKeys.lines().filter { it.isNotBlank() } + "$nowMs\t${sug.key}").takeLast(30).joinToString("\n")
        pendingSuggestion = sug
        pendingAt = nowMs
        ActivityLog.add(this, "Agent", "Suggested: ${sug.type}")
        summon(chatter.prompt("suggest", sug.text, listOf(sug.yes, "Not now", "Stop these")))
    }

    private fun agentContext(): String {
        if (!s.aiContext) return ""
        val snap = agentSnapshot()
        val parts = mutableListOf<String>()
        if (snap.deadlines.isNotEmpty()) parts.add("Upcoming deadlines: " + snap.deadlines.take(6).joinToString("; ") { "${it.label} (${Agent.whenText(it.daysLeft)})" })
        parts.add("Studied today: ${snap.studiedToday} min; this week: ${StudyLog.week(s.studyLog)} min; streak: ${snap.streak} days")
        val ins = snap.habits.insights()
        if (ins.isNotEmpty()) parts.add("Habits: " + ins.take(4).joinToString(" "))
        return parts.joinToString("\n")
    }

    /** Handles a Yes/No to a pending suggestion or shortcut question. Returns true if the message was an answer. */
    private fun handlePending(raw: String, reply: (String, List<String>) -> Unit): Boolean {
        val t = raw.trim().lowercase()
        val yes = Regex("^(yes|yeah|yep|yup|sure|ok|okay|start|do it|haan|ha|please)\\b").containsMatchIn(t)
        val no = Regex("^(no|nope|nah|not now|later|skip|nahi)\\b").containsMatchIn(t)
        val stop = Regex("^(stop these|stop suggest|never)").containsMatchIn(t)
        val h = HabitStore.get(this)
        val nowMs = System.currentTimeMillis()

        pendingAlias?.let { (phrase, meaning) ->
            pendingAlias = null
            if (yes) {
                LearnStore.get(this).addAlias(phrase, meaning); LearnStore.save(this)
                h.suggestion("shortcuts", true, nowMs); HabitStore.save(this)
                ActivityLog.add(this, "Learning", "Shortcut: \"$phrase\" = \"$meaning\"")
                reply("Got it 🧠 From now on \"$phrase\" means \"$meaning\".", emptyList()); return true
            }
            if (no || stop) {
                declinedAliases.add(phrase.lowercase()); h.suggestion("shortcuts", false, nowMs); HabitStore.save(this)
                reply("Okay, I won't ask about that one again 💜", emptyList()); return true
            }
        }
        val sug = pendingSuggestion ?: return false
        if (nowMs - pendingAt > 60 * 60_000L) { pendingSuggestion = null; return false }
        if (!(yes || no || stop)) return false
        pendingSuggestion = null
        chatter.clearTopic()
        if (stop) {
            s.suggestions = false
            h.suggestion(sug.type, false, nowMs); HabitStore.save(this)
            reply("Okay, no more suggestions. Say \"start suggestions\" to turn them back on.", emptyList()); return true
        }
        h.suggestion(sug.type, yes, nowMs); HabitStore.save(this)
        if (no) { reply("No problem 💜 I'll remember that.", emptyList()); return true }
        when (val a = sug.action) {
            is Agent.Action.Study -> {
                startStudy(a.focus, s.studyBreak, null, a.subject)
                reply("On it 📚 " + (a.subject?.let { "$it, " } ?: "") + "${a.focus} min starts now.", emptyList())
            }
            is Agent.Action.QuietHours -> {
                s.quietHoursList = (s.quietHourSet() + a.hours).sorted().joinToString(",")
                reply("Okay 🤫 I'll stay quiet around ${h.rangeText(a.hours)}. (You can change this in the Brain tab.)", emptyList())
            }
        }
        return true
    }

    /** Remember a short phrase Ghostie didn't understand, in case the user rephrases it as a command right after. */
    private fun noteUnknown(raw: String) {
        val words = raw.trim().split(Regex("\\s+")).size
        val chatty = Regex("^(hi+|hello+|hey+|ok+|okay|lol|haha+|thanks?|thank you|yes|no|bye|hmm+|nice|cool|wow|good.*)\\b", RegexOption.IGNORE_CASE).containsMatchIn(raw.trim())
        lastUnknown = if (words in 1..5 && !chatty && raw.length >= 3) raw.trim() to System.currentTimeMillis() else null
    }

    /** If the user just said something Ghostie didn't get, and now said a real command, offer to learn the first as a shortcut. */
    private fun shortcutOffer(command: Command, executed: String): Pair<String, String>? {
        val u = lastUnknown ?: return null
        lastUnknown = null
        if (System.currentTimeMillis() - u.second > 60_000L) return null
        if (command is Command.Help || command is Command.Incomplete || command is Command.Teach || command is Command.Forget || command is Command.ForgetAll || command is Command.Learned || command is Command.Undo) return null
        val phrase = u.first
        if (phrase.equals(executed, true) || declinedAliases.contains(phrase.lowercase())) return null
        if (LearnStore.get(this).findAlias(phrase) != null) return null
        if (HabitStore.get(this).isMuted("shortcuts", System.currentTimeMillis())) return null
        return phrase to executed.trim()
    }

    /** Price check: Ghostie opens the food apps, searches, reads prices and reports. It never orders. */
    private fun foodCompare(items: List<WantedItem>, say: (String) -> Unit) {
        if (!FoodScanService.isEnabled(this)) {
            say("To compare food prices I need the \"Ghostie food price reader\" switched on (Settings > Accessibility > Installed apps). It only works on food apps, only when you ask, and never orders. The Setup tab has a button 🍽️")
            return
        }
        val ids = s.foodApps.split(',').filter { it.isNotBlank() }
        val names = ids.mapNotNull { FoodApps.byId(it)?.label }
        val err = FoodScanService.start(this, items, ids, s.foodFee, progress = { m -> say(m) }, done = { r -> say(r) })
        when (err) {
            "off" -> say("The food price reader isn't running yet. Switch it on in Accessibility settings, then ask again 🍽️")
            "busy" -> say("I'm already checking prices - say \"stop price check\" to cancel.")
            else -> say("On it 🍽️ I'll open ${names.joinToString(", ")} one by one - about a minute. Please don't touch the phone meanwhile. I only read prices, I never order. (say \"stop price check\" to cancel)")
        }
    }

    private fun planCommand(say: (String) -> Unit) {
        val snap = agentSnapshot()
        val h = snap.habits
        val focus = h.bestFocus() ?: s.studyFocus
        val items = Planner.plan(snap.deadlines, snap.subjectMin7, focus)
        val draft = Planner.format(items, java.time.LocalDate.now(), h.usualStudyHour())
        val chips = if (items.isNotEmpty()) {
            pendingSuggestion = Agent.Suggestion("plan", "plan:${System.currentTimeMillis()}", "", "Start first block", Agent.Action.Study(items.first().label, focus))
            pendingAt = System.currentTimeMillis()
            listOf("Start first block ⏱️", "Not now")
        } else emptyList()
        if (s.ai && s.key.isNotBlank() && items.isNotEmpty()) {
            scope.launch {
                val a = ChatEngine.openAi(s.key, emptyList(), "Rewrite this study plan as a short, friendly message (max 6 lines). Keep every subject, day and number of minutes exactly as given:\n$draft", s.aiBase, s.aiModel, s.mood, agentContext())
                pendingChips = chips
                say(if (ChatEngine.isError(a)) draft else a)
            }
        } else {
            pendingChips = chips
            say(draft)
        }
    }

    // ---- study mode ---------------------------------------------------------------------------

    private val studyTask = object : Runnable {
        override fun run() {
            studyTick()
            if (s.studyActive) handler.postDelayed(this, 2000)
        }
    }
    private var blockView: View? = null
    private var blockText: TextView? = null
    private var lastFgPkg: String? = null
    private var lastFgCheck = 0L

    private fun studySummary(detail: Boolean = false): String {
        val raw = s.studyLog
        val today = StudyLog.today(raw)
        val base = "Today: ${StudyLog.format(today)} focused · this week: ${StudyLog.format(StudyLog.week(raw))}"
        val streak = StudyLog.streak(raw)
        val extra = if (streak >= 2) " · $streak-day streak 🔥" else ""
        val status = if (detail && s.studyActive) "\n" + studyStatus() else ""
        return "📈 $base$extra$status"
    }

    private fun studyStatus(): String {
        val left = ((s.studyPhaseEnd - System.currentTimeMillis()) / 1000).coerceAtLeast(0)
        return (if (s.studyPhase == "focus") "Focusing" else "On break") + ": %d:%02d left".format(left / 60, left % 60)
    }

    fun startStudy(focus: Int, brk: Int, say: ((String) -> Unit)?, subject: String? = null) {
        s.studySubject = subject ?: ""
        HabitStore.get(this).studyStart(java.time.LocalTime.now().hour)
        HabitStore.save(this)
        s.studyFocus = focus.coerceIn(5, 180)
        s.studyBreak = brk.coerceIn(1, 60)
        s.studyActive = true
        s.studyCycles = 0
        beginPhase("focus")
        handler.removeCallbacks(studyTask)
        handler.postDelayed(studyTask, 2000)
        val dndNote = if (s.studyDnd && !dndAllowed()) "\n(Do Not Disturb needs permission: open Ghostie → Home → Study mode.)" else ""
        val blockNote = if (s.studyBlock && s.studyAppSet().isNotEmpty() && !usageAllowed()) "\n(App blocking needs Usage access: open Ghostie → Home → Study mode.)" else ""
        val msg = Moods.study(s.mood, 0, "Focus time 📚") + (if (s.studySubject.isNotBlank()) " (${s.studySubject})" else "") + "\n${s.studyFocus} min focus, then a ${s.studyBreak} min break." + dndNote + blockNote
        if (say != null) say(msg) else summon(msg)
    }

    private fun beginPhase(phase: String) {
        val now = System.currentTimeMillis()
        s.studyPhase = phase
        s.studyPhaseStart = now
        s.studyPhaseEnd = now + (if (phase == "focus") s.studyFocus else s.studyBreak) * 60_000L
        val focusing = phase == "focus"
        setDnd(focusing && s.studyDnd)
        if (!focusing) hideBlock()
    }

    fun stopStudy(announce: Boolean) {
        if (!s.studyActive) return
        if (s.studyPhase == "focus") {
            val mins = ((System.currentTimeMillis() - s.studyPhaseStart) / 60_000L).toInt().coerceAtMost(s.studyFocus)
            s.studyLog = StudyLog.add(s.studyLog, mins)
            logFocus(mins, false)
        }
        s.studyActive = false
        handler.removeCallbacks(studyTask)
        setDnd(false)
        hideBlock()
        ActivityLog.add(this, "Study", "Study mode stopped")
        if (announce) summon("Study mode stopped. " + studySummary())
    }

    private fun studyTick() {
        if (!s.studyActive) return
        val now = System.currentTimeMillis()
        if (now >= s.studyPhaseEnd) {
            if (s.studyPhase == "focus") {
                s.studyLog = StudyLog.add(s.studyLog, s.studyFocus)
                logFocus(s.studyFocus, true)
                s.studyCycles = s.studyCycles + 1
                beginPhase("break")
                val msg = Moods.study(s.mood, 2, "Block done ✅") + " Break for ${s.studyBreak} min 💧\n" + studySummary()
                Notifier.post(this, "☕ Study break", "Nice work! ${s.studyBreak} min break. " + studySummary())
                summon(Chatter.Line(msg))
                voice?.sfx("giggle")
            } else {
                beginPhase("focus")
                Notifier.post(this, "📚 Back to focus", "Next ${s.studyFocus} min block starts now.")
                summon(Moods.study(s.mood, 0, "Focus time 📚") + " ${s.studyFocus} min.")
            }
            return
        }
        if (s.studyPhase == "focus" && s.studyBlock) checkBlock() else hideBlock()
        blockText?.text = blockMessage()
    }

    // Do Not Disturb (the user chooses it in the Study card; needs one-time policy access)
    private fun dndAllowed() = getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted

    private fun setDnd(on: Boolean) {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            if (!nm.isNotificationPolicyAccessGranted) return
            if (on) {
                if (s.studyPrevFilter < 0) s.studyPrevFilter = nm.currentInterruptionFilter
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            } else if (s.studyPrevFilter >= 0) {
                nm.setInterruptionFilter(s.studyPrevFilter)
                s.studyPrevFilter = -1
            }
        } catch (e: Exception) { }
    }

    // App blocking: needs Usage access to know which app is in front; a full-screen Ghostie panel covers blocked apps.
    private fun usageAllowed(): Boolean = try {
        val ops = getSystemService(APP_OPS_SERVICE) as android.app.AppOpsManager
        ops.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == android.app.AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) { false }

    private fun foregroundPackage(): String? {
        val um = getSystemService(USAGE_STATS_SERVICE) as android.app.usage.UsageStatsManager
        val end = System.currentTimeMillis()
        val from = if (lastFgCheck == 0L) end - 15_000L else lastFgCheck - 1_000L
        lastFgCheck = end
        val ev = um.queryEvents(from, end)
        val e = android.app.usage.UsageEvents.Event()
        var pkg = lastFgPkg
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED) pkg = e.packageName
            else if (e.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_PAUSED && e.packageName == pkg) { /* keep: next resume decides */ }
        }
        lastFgPkg = pkg
        return pkg
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    private var blockedPkg = ""

    private fun checkBlock() {
        val blocked = s.studyAppSet()
        if (blocked.isEmpty() || !usageAllowed()) { hideBlock(); return }
        val pkg = try { foregroundPackage() } catch (e: Exception) { null }
        if (pkg != null && pkg in blocked && pkg != packageName) {
            blockedPkg = pkg
            showBlock()
        } else hideBlock()
    }

    private fun blockMessage(): String = "${appLabel(blockedPkg)} is blocked while you focus.\n" + studyStatus()

    private fun showBlock() {
        if (blockView != null) return
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.setBackgroundColor(Color.parseColor("#F01B1033"))
        col.setPadding(dp(28), dp(28), dp(28), dp(28))
        val img = ImageView(this)
        img.setImageDrawable(Skins.drawable(this, Skins.byId(s.skin)))
        col.addView(img, LinearLayout.LayoutParams(dp(120), dp(120)))
        fun txt(text: String, size: Float, color: String, bold: Boolean = false) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(Color.parseColor(color)); gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        col.addView(txt("📚 Study mode", 24f, "#FFFFFF", true), LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) })
        val msg = txt(blockMessage(), 16f, "#D8CCFF")
        blockText = msg
        col.addView(msg, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
        fun btn(label: String, fill: String, onClick: () -> Unit) = TextView(this).apply {
            text = label; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(26).toFloat(); setColor(Color.parseColor(fill)) }
            setPadding(dp(24), dp(14), dp(24), dp(14))
            setOnClickListener { onClick() }
        }
        col.addView(btn("Back to studying", "#7E57C2") {
            hideBlock()
            startSafely(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), "home")
        }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(28) })
        col.addView(btn("End study mode", "#3A2A66") { stopStudy(true) }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) })
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or hw,
            PixelFormat.TRANSLUCENT
        )
        try { wm.addView(col, lp); blockView = col } catch (e: Exception) { blockView = null }
    }

    private fun hideBlock() {
        blockView?.let { removeQuietly(it) }
        blockView = null
        blockText = null
    }

    // ---- tricks, torch, battery ---------------------------------------------------------------

    private var torchOn = false

    private fun setTorch(want: Boolean?, say: (String) -> Unit) {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as android.hardware.camera2.CameraManager
            val id = cm.cameraIdList.firstOrNull {
                val c = cm.getCameraCharacteristics(it)
                c.get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(android.hardware.camera2.CameraCharacteristics.LENS_FACING) == android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK
            }
            if (id == null) { say("This phone doesn't seem to have a flashlight I can use 🔦"); return }
            val on = want ?: !torchOn
            cm.setTorchMode(id, on)
            torchOn = on
            say(if (on) "Flashlight on 🔦" else "Flashlight off")
        } catch (e: Exception) {
            say("I couldn't switch the flashlight (another app may be using the camera).")
        }
    }

    /** Extra idle tricks and chat-triggered ones. Only view properties are animated, so it stays smooth. */
    private fun bigShown(): Boolean = pet?.let { it.visibility == View.VISIBLE && it.alpha > 0.5f } == true

    private fun trick(kind: String) {
        // The big ghost only visits now and then; the small edge ghost is always there, so it does the tricks otherwise.
        val p: View = (if (bigShown()) pet else handle) ?: return
        if (reacting || sleeping) return
        reacting = true
        val done = object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                p.rotation = 0f; p.scaleX = 1f; p.scaleY = 1f; p.translationX = 0f; p.translationY = 0f
                reacting = false
            }
        }
        val a: Animator = when (kind) {
            "wave" -> ObjectAnimator.ofFloat(p, View.ROTATION, 0f, -16f, 16f, -16f, 16f, -10f, 0f).apply { duration = 1300 }
            "yawn" -> ObjectAnimator.ofPropertyValuesHolder(
                p, PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.18f, 1.18f, 0.92f, 1f), PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 0.92f, 0.92f, 1.04f, 1f)
            ).apply { duration = 1800 }
            "shiver" -> ObjectAnimator.ofFloat(p, View.TRANSLATION_X, 0f, -5f * resources.displayMetrics.density, 5f * resources.displayMetrics.density, -5f * resources.displayMetrics.density, 5f * resources.displayMetrics.density, 0f).apply { duration = 700; repeatCount = 2 }
            "flip" -> ObjectAnimator.ofFloat(p, View.ROTATION, 0f, -360f).apply { duration = 800; interpolator = OvershootInterpolator(0.8f) }
            else -> ObjectAnimator.ofPropertyValuesHolder(
                p,
                PropertyValuesHolder.ofFloat(View.ROTATION, 0f, -12f, 12f, -12f, 12f, -12f, 12f, 0f),
                PropertyValuesHolder.ofFloat(View.TRANSLATION_Y, 0f, -dp(10).toFloat(), 0f, -dp(10).toFloat(), 0f, -dp(10).toFloat(), 0f, 0f)
            ).apply { duration = 1800 }
        }
        a.addListener(done)
        a.start()
        voice?.sfx(if (kind == "yawn") "purr" else "giggle")
    }

    private var batteryReceiver: android.content.BroadcastReceiver? = null
    private var lowWarned = false

    private fun startBatteryWatch() {
        if (batteryReceiver != null) return
        val r = object : android.content.BroadcastReceiver() {
            override fun onReceive(c: android.content.Context?, i: Intent?) {
                if (!s.batteryReacts || suppressed || sleeping) return
                when (i?.action) {
                    Intent.ACTION_POWER_CONNECTED -> { lowWarned = false; summon("Yum, power! ⚡ Thanks for feeding the phone."); trick("dance") }
                    Intent.ACTION_BATTERY_LOW -> if (!lowWarned) { lowWarned = true; summon("I'm getting hungry... the battery is low 🔋 Please charge soon.") }
                }
            }
        }
        val f = android.content.IntentFilter()
        f.addAction(Intent.ACTION_POWER_CONNECTED)
        f.addAction(Intent.ACTION_BATTERY_LOW)
        try { registerReceiver(r, f); batteryReceiver = r } catch (e: Exception) { }
    }

    // ---- talking and listening ---------------------------------------------------------------

    /** One place that understands a sentence: taught phrases, commands, AI or small talk. */
    private fun converse(raw: String, reply: (String, List<String>) -> Unit) {
        val l = LearnStore.get(this)
        noteUse()
        if (handlePending(raw, reply)) return
        var q = raw.trim()
        val alias = l.findAlias(q)
        if (alias != null && !alias.startsWith("word:")) {
            if (alias.startsWith("say:")) { reply(alias.removePrefix("say:"), emptyList()); return }
            q = alias
        } else {
            q = l.applyWords(q)
        }
        // Tapping one of Ghostie's own quick-reply chips is always answered locally, never sent to AI.
        val isChip = chatter.topic.isNotEmpty() && chatter.chips.any { it.trim().equals(raw.trim(), true) }
        s.chatCount = s.chatCount + 1
        val command = if (isChip) null else (Commands.parse(Hinglish.normalize(q)) ?: Commands.parse(q))
        val offer = if (command != null) shortcutOffer(command, q) else null
        val useAi = s.ai && s.key.isNotBlank() && !isChip
        when {
            command != null -> {
                pendingChips = emptyList()
                runCommand(command) { msg ->
                    var c = pendingChips; pendingChips = emptyList()
                    var m = msg
                    if (offer != null && c.isEmpty()) { m = msg + "\n\n🧠 Want me to remember that \"${offer.first}\" means \"${offer.second}\"?"; c = listOf("Yes, remember 🧠", "No"); pendingAlias = offer }
                    reply(m, c)
                }
            }
            useAi -> {
                val past = chatHistory.toList()
                val text = q
                scope.launch {
                    val a = ChatEngine.openAi(s.key, past, text, s.aiBase, s.aiModel, s.mood, agentContext())
                    chatHistory.add("user" to text)
                    chatHistory.add("assistant" to a)
                    reply(a, emptyList())
                }
            }
            else -> {
                val answer = Moods.reply(s.mood, q, chatter.reply(q), chatter.topic.isNotEmpty())
                if (chatter.topic.isEmpty() && !isChip) noteUnknown(raw)
                val next = chatter.chips
                if (chatter.userName != s.userName) s.userName = chatter.userName
                LearnStore.save(this)
                // a short "thinking" pause makes it feel like a friend, not a lookup table
                handler.postDelayed({ reply(answer, next) }, (250L + answer.length * 6L).coerceAtMost(800L))
            }
        }
    }

    /**
     * Android silences the microphone for apps in the background, which makes recognition hear nothing.
     * While listening, the service declares itself a microphone service (it is visible via its overlay).
     */
    private fun setMicForeground(on: Boolean) {
        if (Build.VERSION.SDK_INT < 30) return
        val n = fgNotification ?: return
        try {
            if (on) {
                val type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or (if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0)
                startForeground(7, n, type)
            } else if (Build.VERSION.SDK_INT >= 34) {
                startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(7, n)
            }
        } catch (e: Exception) {
            if (on) ActivityLog.add(this, "Voice", "Couldn't switch on microphone mode: ${e.javaClass.simpleName}")
        }
    }

    private fun startListening(sink: ((String) -> Unit)? = null) {
        if (suppressed) return
        voice?.stop()
        voiceSink = sink
        setMicForeground(true)
        if (vin?.start() == true) {
            listenStartedAt = System.currentTimeMillis()
            pet?.animate()?.scaleX(1.1f)?.scaleY(1.1f)?.setDuration(150)?.start()
            if (chatBox == null) petParams?.let { showBubble("🎙️ Getting ready…", it.x, it.y) }
        } else {
            setMicForeground(false)
            startVoiceDialog()
        }
    }

    /** Fallback: the phone's own speech dialog. */
    private fun startVoiceDialog() {
        startSafely(Intent(this, VoiceActivity::class.java))
    }

    private fun stopListeningUi() {
        setMicForeground(false)
        pet?.animate()?.scaleX(1f)?.scaleY(1f)?.setDuration(150)?.start()
        if (chatBox == null) { removeQuietly(bubble); bubble = null }
    }

    private fun handleVoiceState(st: String) {
        when {
            st == "ready" -> {
                // Only now does the recognizer hear you, so only now say "speak".
                voice?.sfx("pop")
                if (chatBox == null) petParams?.let { showBubble("🎙️ Speak now…", it.x, it.y) }
            }
            st.startsWith("partial:") -> if (chatBox == null) petParams?.let { showBubble("🎙️ " + st.removePrefix("partial:"), it.x, it.y) }
            st == "nomatch" -> {
                stopListeningUi()
                voiceSink = null
                silentMisses++
                ActivityLog.add(this, "Voice", "Heard nothing ($silentMisses in a row)")
                if (silentMisses >= 2) {
                    // The built-in listener keeps hearing silence: use the phone's own speech dialog instead.
                    silentMisses = 0
                    summon("Let me use the phone's voice box instead 🎙️")
                    handler.postDelayed({ startVoiceDialog() }, 900)
                } else if (chatBox == null) {
                    summon("I didn't catch that 🙉 Wait for \"Speak now\", then talk.")
                }
            }
            else -> {
                stopListeningUi()
                ActivityLog.add(this, "Voice", "Listener error - opening the phone's voice box")
                startVoiceDialog()
            }
        }
    }

    private fun handleSpoken(text: String) {
        silentMisses = 0
        stopListeningUi()
        val sink = voiceSink
        voiceSink = null
        if (sink != null) { sink(text); return }
        if (chatBox != null) { submitRef(text); return }
        ActivityLog.add(this, "Voice", "Heard: $text")
        converse(text) { answer, chips -> summon(Chatter.Line(answer, chips)) }
    }

    // ---- the bin: throw the ghost away -------------------------------------------------------

    private fun showBin() {
        if (binView != null) return
        val tv = TextView(this)
        tv.text = "🗑️"
        tv.textSize = 30f
        tv.gravity = Gravity.CENTER
        tv.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(210, 255, 255, 255))
            setStroke(3, Color.rgb(190, 150, 235))
        }
        val sz = dp(76)
        val lp = WindowManager.LayoutParams(
            sz, sz, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or hw,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (screenW() - sz) / 2
        lp.y = screenH() - sz - dp(96)
        tv.alpha = 0f
        try {
            wm.addView(tv, lp)
        } catch (e: Exception) {
            return
        }
        tv.animate().alpha(1f).setDuration(150).start()
        binView = tv
        binParams = lp
    }

    private fun hideBin() {
        val v = binView
        binView = null
        binParams = null
        overBin = false
        v?.animate()?.alpha(0f)?.setDuration(150)?.withEndAction { removeQuietly(v) }?.start()
    }

    private fun updateBin(lp: WindowManager.LayoutParams) {
        val b = binParams ?: return
        val dx = (lp.x + lp.width / 2) - (b.x + b.width / 2)
        val dy = (lp.y + lp.height / 2) - (b.y + b.height / 2)
        val near = Math.hypot(dx.toDouble(), dy.toDouble()) < dp(70) + lp.width / 3
        if (near != overBin) {
            overBin = near
            val sc = if (near) 1.3f else 1f
            binView?.animate()?.scaleX(sc)?.scaleY(sc)?.setDuration(120)?.start()
            pet?.animate()?.alpha(if (near) 0.7f else 1f)?.setDuration(120)?.start()
            if (near) voice?.sfx("pop")
        }
    }

    /** Dropped on the bin: the ghost crumples and spins in, then goes away for an hour. */
    private fun throwAway(view: View, lp: WindowManager.LayoutParams) {
        val b = binParams ?: return
        val tx = b.x + b.width / 2 - lp.width / 2
        val ty = b.y + b.height / 2 - lp.height / 2
        val fx = lp.x
        val fy = lp.y
        if (canSpeak()) voice?.speak("Okay, okay. I'll go away for a while. Tap my little edge ghost to call me back.")
        voice?.sfx("squeak")
        ActivityLog.add(this, "Bin", "Ghost thrown in the bin - quiet for 1 hour")
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 520
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                lp.x = (fx + (tx - fx) * f).toInt()
                lp.y = (fy + (ty - fy) * f).toInt()
                view.scaleX = 1f - 0.9f * f
                view.scaleY = 1f - 0.9f * f
                view.rotation = 540f * f
                try { wm.updateViewLayout(view, lp) } catch (ex: IllegalArgumentException) { }
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    view.visibility = View.INVISIBLE
                    view.scaleX = 1f; view.scaleY = 1f; view.rotation = 0f; view.alpha = 1f
                    lp.x = homeX(); lp.y = homeY()
                    try { wm.updateViewLayout(view, lp) } catch (ex: IllegalArgumentException) { }
                    hideBin()
                    s.quietUntil = System.currentTimeMillis() + 60 * 60_000L
                }
            })
            start()
        }
    }

    private fun formatDuration(seconds: Int): String {
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val sec = seconds % 60
        return listOfNotNull(
            if (h > 0) "$h h" else null,
            if (m > 0) "$m min" else null,
            if (sec > 0) "$sec s" else null
        ).joinToString(" ")
    }

    private fun organizeDocs(say: (String) -> Unit) {
        if (!DocOrganizer.hasAccess(this)) {
            val i = if (Build.VERSION.SDK_INT >= 30) {
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            } else {
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            }
            startSafely(i)
            say("I need file access first 📂 I opened the settings - switch it on for Ghostie, then ask me again.")
            return
        }
        say("On it... sorting your WhatsApp documents 📂")
        scope.launch {
            val result = try {
                withContext(Dispatchers.IO) { DocOrganizer.organize(this@PetOverlayService) }
            } catch (e: Exception) {
                null
            }
            say(if (result != null) DocOrganizer.summary(result) else "Something went wrong while organizing.")
        }
    }

    private fun closeChat() {
        SentenceStore.save(this)
        voice?.stop()
        removeQuietly(chatBox)
        chatBox = null
        handler.removeCallbacks(leaveTask)
        handler.postDelayed(leaveTask, 3000)
    }

    // ---- touch: drag to move, tap to act --------------------------------------------------

    /**
     * The pet: leans toward your finger while touched; hold it to talk to it; tap to chat; double-tap to spin;
     * triple-tap to pet it; drag to carry it (shake for dizzy) and drop it on the bin that appears to throw it away.
     */
    private inner class PetTouch(private val lp: WindowManager.LayoutParams, private val target: ImageView) : View.OnTouchListener {
        private var startRawX = 0f
        private var startRawY = 0f
        private var lastRawX = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false
        private var held = false
        private var dizzy = false
        private var shake = 0f
        private var taps = 0
        private var vt: VelocityTracker? = null
        private var lastTapAt = 0L
        private val holdTask = Runnable {
            if (!moved) {
                held = true
                startListening()
            }
        }
        private val openLater = Runnable { openChat() }
        private val spinLater = Runnable { spin(target) }

        private fun lean(e: MotionEvent) {
            val w = maxOf(1, target.width).toFloat()
            val h = maxOf(1, target.height).toFloat()
            val fx = ((e.x / w) - 0.5f).coerceIn(-0.5f, 0.5f) * 2f
            val fy = ((e.y / h) - 0.5f).coerceIn(-0.5f, 0.5f) * 2f
            target.cameraDistance = 9000f * resources.displayMetrics.density
            target.rotationY = fx * 16f
            target.rotationX = -fy * 16f
            target.translationX = fx * dp(3)
        }

        private fun unlean() {
            target.animate().rotationX(0f).rotationY(0f).translationX(0f).setDuration(180).start()
        }

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = e.rawX
                    startRawY = e.rawY
                    lastRawX = e.rawX
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    held = false
                    dizzy = false
                    shake = 0f
                    vt?.recycle()
                    vt = VelocityTracker.obtain()
                    vt?.addMovement(e)
                    handler.postDelayed(holdTask, 600)
                    lean(e)
                }
                MotionEvent.ACTION_MOVE -> {
                    vt?.addMovement(e)
                    val dx = e.rawX - startRawX
                    val dy = e.rawY - startRawY
                    val slop = if (held) dp(48) else dp(8) // a held finger wobbles; only a real drag cancels listening
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) {
                        moved = true
                        if (held) {
                            // Held first, then moved: this is a drag, not talking.
                            held = false
                            voiceSink = null
                            vin?.cancel()
                            stopListeningUi()
                        }
                        handler.removeCallbacks(holdTask)
                        handler.removeCallbacks(openLater)
                        handler.removeCallbacks(spinLater)
                        target.animate().rotationX(0f).rotationY(0f).translationX(0f).scaleX(1.1f).scaleY(1.1f).setDuration(120).start()
                        voice?.sfx("squeak")
                        showBin()
                    }
                    if (!moved) {
                        if (!held) lean(e)
                    } else {
                        lp.x = (startX + dx).toInt().coerceIn(0, maxOf(0, screenW() - lp.width))
                        lp.y = (startY + dy).toInt().coerceIn(0, maxOf(0, screenH() - lp.height))
                        val step = (e.rawX - lastRawX) / resources.displayMetrics.density
                        lastRawX = e.rawX
                        target.rotation = (target.rotation * 0.7f + step * 2.5f * 0.3f).coerceIn(-22f, 22f)
                        shake += abs(step)
                        if (!dizzy && shake > 700f) {
                            dizzy = true
                            voice?.sfx("giggle")
                            showBubble("Wheeeee! 😵‍💫", lp.x, lp.y)
                            handler.postDelayed({ removeQuietly(bubble); bubble = null }, 1800)
                        }
                        updateBin(lp)
                        try {
                            wm.updateViewLayout(target, lp)
                        } catch (ex: IllegalArgumentException) {
                            // removed
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(holdTask)
                    unlean()
                    vt?.addMovement(e)
                    vt?.computeCurrentVelocity(1000)
                    val vx = vt?.xVelocity ?: 0f
                    val vy = vt?.yVelocity ?: 0f
                    vt?.recycle()
                    vt = null
                    // A fast flick aimed at the bin counts as a throw, like tossing paper.
                    var flung = false
                    val b = binParams
                    if (moved && !overBin && b != null && e.actionMasked == MotionEvent.ACTION_UP) {
                        val speed = Math.hypot(vx.toDouble(), vy.toDouble())
                        val bx = (b.x + b.width / 2 - (lp.x + lp.width / 2)).toDouble()
                        val by = (b.y + b.height / 2 - (lp.y + lp.height / 2)).toDouble()
                        val dist = Math.hypot(bx, by)
                        if (speed > 1300 && dist > 1 && (vx * bx + vy * by) / (speed * dist) > 0.8) flung = true
                    }
                    if (held) {
                        // Let go: finish and answer. A very short hold keeps listening until you stop talking.
                        if (System.currentTimeMillis() - listenStartedAt > 1500L) vin?.stop()
                    } else if (moved) {
                        if (overBin || flung) {
                            throwAway(target, lp)
                        } else {
                            s.x = lp.x
                            s.y = lp.y
                            dropFx(target, dizzy)
                            hideBin()
                        }
                    } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                        val now = System.currentTimeMillis()
                        taps = if (now - lastTapAt < 380) taps + 1 else 1
                        lastTapAt = now
                        handler.removeCallbacks(openLater)
                        handler.removeCallbacks(spinLater)
                        when (taps) {
                            1 -> {
                                react()
                                voice?.sfx("pop")
                                handler.postDelayed(openLater, if (s.directChat) 0L else 330L)
                            }
                            2 -> handler.postDelayed(spinLater, 330)
                            else -> {
                                taps = 0
                                petIt(target)
                            }
                        }
                    }
                }
            }
            return true
        }
    }

    /** Lands with a squash and a little bounce. */
    private fun dropFx(view: View, wasDizzy: Boolean) {
        view.animate().rotation(0f).scaleX(1f).scaleY(1f).setDuration(150).start()
        ObjectAnimator.ofPropertyValuesHolder(
            view,
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 0.78f, 1.06f, 1f),
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.12f, 0.97f, 1f)
        ).apply { duration = 420; interpolator = OvershootInterpolator(); startDelay = 80; start() }
        voice?.sfx("pop")
        if (wasDizzy) {
            handler.postDelayed({
                showBubble("Whoa... everything is spinning 😵‍💫", petParams?.x ?: homeX(), petParams?.y ?: homeY())
                handler.postDelayed({ removeQuietly(bubble); bubble = null }, 2200)
                if (canSpeak()) voice?.speak("Whoa. Everything is spinning.")
            }, 300)
        }
    }

    private fun spin(view: View) {
        ObjectAnimator.ofFloat(view, View.ROTATION, 0f, 360f).apply {
            duration = 700
            interpolator = OvershootInterpolator(0.8f)
            start()
        }
        hop()
        voice?.sfx("giggle")
        showBubble("Wheee! 🌀", petParams?.x ?: homeX(), petParams?.y ?: homeY())
        handler.postDelayed({ removeQuietly(bubble); bubble = null }, 1500)
    }

    /** Long-press: hearts float up and the ghost wiggles and purrs. */
    private fun petIt(view: View) {
        ObjectAnimator.ofFloat(view, View.ROTATION, 0f, -10f, 10f, -8f, 8f, 0f).apply { duration = 700; start() }
        voice?.sfx("purr")
        val line = petLines.random()
        if (canSpeak()) voice?.speak(line)
        val lp0 = petParams ?: return
        val hearts = TextView(this)
        hearts.text = "💜 💗 💜"
        hearts.textSize = 22f
        val hp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or hw,
            PixelFormat.TRANSLUCENT
        )
        hp.gravity = Gravity.TOP or Gravity.START
        hp.x = lp0.x
        val startY = maxOf(0, lp0.y - dp(10))
        hp.y = startY
        try {
            wm.addView(hearts, hp)
        } catch (e: Exception) {
            return
        }
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1400
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                hp.y = (startY - dp(90) * f).toInt().coerceAtLeast(0)
                hearts.alpha = 1f - f
                try { wm.updateViewLayout(hearts, hp) } catch (ex: IllegalArgumentException) { }
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) { removeQuietly(hearts) }
            })
            start()
        }
        showBubble(line, lp0.x, lp0.y)
        handler.postDelayed({ removeQuietly(bubble); bubble = null }, 2000)
    }

    private inner class DragTouch(
        private val lp: WindowManager.LayoutParams,
        private val target: View,
        private val persist: Boolean,
        private val onTap: () -> Unit
    ) : View.OnTouchListener {
        private var startRawX = 0f
        private var startRawY = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = e.rawX
                    startRawY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - startRawX
                    val dy = e.rawY - startRawY
                    val slop = dp(6).toFloat()
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = (startX + dx).toInt().coerceIn(0, maxOf(0, screenW() - lp.width))
                        lp.y = (startY + dy).toInt().coerceIn(0, maxOf(0, screenH() - lp.height))
                        try {
                            wm.updateViewLayout(target, lp)
                        } catch (ex: IllegalArgumentException) {
                            // view removed
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        if (persist) {
                            s.x = lp.x
                            s.y = lp.y
                        }
                    } else {
                        onTap()
                    }
                }
            }
            return true
        }
    }
}
