package com.ghostie.pet

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioManager
import android.os.FileObserver
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import android.net.Uri
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.BounceInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

class PetOverlayService : Service() {

    companion object {
        const val ACTION_SUMMON = "SUMMON"
        const val ACTION_RESET = "RESET"
        const val ACTION_VOICE = "VOICE"
    }

    private lateinit var wm: WindowManager
    private lateinit var s: SettingsStore
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var pet: ImageView? = null
    private var petParams: WindowManager.LayoutParams? = null
    private var handle: ImageView? = null
    private var bubble: TextView? = null
    private var chatBox: View? = null
    private var idleAnim: ObjectAnimator? = null
    private var slideAnim: ValueAnimator? = null
    private var swayAnim: ObjectAnimator? = null
    private var handleAnim: ObjectAnimator? = null
    private var hopAnim: ValueAnimator? = null
    private var reacting = false
    private var suppressed = false
    private var vin: VoiceInput? = null
    private var voiceSink: ((String) -> Unit)? = null
    private var lastEvent: Pair<Command.Event, Long>? = null
    private var binView: TextView? = null
    private var binParams: WindowManager.LayoutParams? = null
    private var overBin = false
    private var voice: GhostVoice? = null
    private var lastLine: Chatter.Line? = null
    private var lastLineAt = 0L
    private var chipRow: LinearLayout? = null
    private var submitRef: (String) -> Unit = {}
    private val petLines = listOf("Hehe, that tickles 💜", "Aww 🥹", "More pets please 👻", "I'm purring (ghosts can do that) 💜", "Best human 💜")
    private var sleeping = false
    private var wakeUntil = 0L
    private var lastDp = 0
    private val observers = mutableListOf<FileObserver>()
    private val hw = WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
    private val chatter by lazy { Chatter(s.userName, learner = LearnStore.get(this)) }
    private val chatHistory = mutableListOf<Pair<String, String>>()

    private val ink = Color.rgb(55, 35, 75)
    private val overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    // ---- periodic tasks -------------------------------------------------------------------

    /** Little idle behaviours: a blink, or a quick glance to the side. Skipped while reacting. */
    private val blinkTask = object : Runnable {
        override fun run() {
            val p = pet
            if (p != null && !reacting && !suppressed && !sleeping && p.visibility == View.VISIBLE) {
                if ((0..9).random() < 4) {
                    p.animate().translationY(-dp(7).toFloat()).rotation(3f).setDuration(700)
                        .withEndAction { p.animate().translationY(0f).rotation(0f).setDuration(700).start() }.start()
                } else if ((0..9).random() < 6) {
                    p.scaleY = 0.88f
                    handler.postDelayed({ if (!reacting) p.scaleY = 1f }, 120)
                } else {
                    val dir = if ((0..1).random() == 0) -1 else 1
                    p.animate().translationX(dir * dp(6).toFloat()).setDuration(350)
                        .withEndAction { p.animate().translationX(0f).setDuration(350).start() }.start()
                }
            }
            handler.postDelayed(this, (2500L..5000L).random())
        }
    }
    private val leaveTask = Runnable { leave() }

    /** Every few seconds: hide during calls / landscape / Do Not Disturb, sleep at night, follow size changes. */
    private val stateTask = object : Runnable {
        override fun run() {
            try {
                refreshState()
            } catch (e: Exception) {
                // never let a state check crash the overlay
            }
            handler.postDelayed(this, 3000)
        }
    }
    private val autoOrganizeTask = object : Runnable {
        override fun run() {
            if (s.autoOrganize && DocOrganizer.hasAccess(this@PetOverlayService)) AutoOrganizer.request(this@PetOverlayService, 5_000L)
            handler.postDelayed(this, 6 * 60 * 60_000L)
        }
    }
    private val checkInTask = object : Runnable {
        override fun run() {
            if (canVisit() && s.checkins) summon()
            handler.postDelayed(this, s.visitMinutes * 60_000L)
        }
    }
    private val waterTask = object : Runnable {
        override fun run() {
            if (canVisit()) summon(chatter.prompt("water", "Water check 💧 A few sips?", listOf("Just did", "Not yet")))
            handler.postDelayed(this, s.waterMinutes * 60_000L)
        }
    }

    // ---- lifecycle ------------------------------------------------------------------------

    override fun onCreate() {
        super.onCreate()
        s = SettingsStore(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        voice = GhostVoice(this, s)
        vin = VoiceInput(this, { handleSpoken(it) }, { handleVoiceState(it) })
        startInForeground()
        createViews()
        handler.postDelayed(checkInTask, s.visitMinutes * 60_000L)
        handler.postDelayed(waterTask, s.waterMinutes * 60_000L)
        handler.postDelayed(stateTask, 1000)
        handler.postDelayed(autoOrganizeTask, 30_000L)
        startObservers()
        ActivityLog.add(this, "Ghost", "Ghostie started")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createViews() // no-op if already created; picks up a newly granted overlay permission
        startObservers()
        when (intent?.action) {
            ACTION_SUMMON -> summon()
            ACTION_VOICE -> intent.getStringExtra("text")?.let { handleSpoken(it) }
            ACTION_RESET -> {
                s.resetPosition()
                destroyViews()
                createViews()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        observers.forEach { it.stopWatching() }
        observers.clear()
        voice?.shutdown()
        voice = null
        vin?.cancel()
        vin = null
        removeQuietly(binView)
        binView = null
        handler.removeCallbacksAndMessages(null)
        destroyViews()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startInForeground() {
        val channelId = "ghostie_service"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Ghostie service", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
        )
        val notification = Notification.Builder(this, channelId)
            .setSmallIcon(R.drawable.ghost_pet)
            .setContentTitle("Ghostie is nearby")
            .setContentText("Floating companion is running")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(7, notification)
        }
    }

    // ---- helpers --------------------------------------------------------------------------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun screenW(): Int = resources.displayMetrics.widthPixels
    private fun screenH(): Int = resources.displayMetrics.heightPixels
    private fun homeX(): Int = if (s.x >= 0) s.x else dp(16)
    private fun homeY(): Int = if (s.y >= 0) s.y else screenH() - petPx() - dp(60)
    private fun petPx(): Int = dp(s.petDp.coerceIn(48, 220))
    private fun canVisit(): Boolean = s.enabled && !suppressed && !sleeping && System.currentTimeMillis() > s.quietUntil

    private fun isNight(): Boolean {
        val h = java.time.LocalTime.now().hour
        return h >= 23 || h < 6
    }

    private fun refreshState() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val inCall = am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION || am.mode == AudioManager.MODE_RINGTONE
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val nm = getSystemService(NotificationManager::class.java)
        val dnd = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL && nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
        val now = System.currentTimeMillis()
        val shouldSuppress = inCall || landscape || dnd
        if (shouldSuppress != suppressed) {
            suppressed = shouldSuppress
            if (suppressed) {
                removeQuietly(bubble); bubble = null
                removeQuietly(chatBox); chatBox = null
                pet?.visibility = View.INVISIBLE
                handle?.visibility = View.GONE
            } else {
                handle?.visibility = View.VISIBLE
            }
        }
        val shouldSleep = s.sleepEnabled && isNight() && now > wakeUntil
        if (shouldSleep != sleeping) {
            sleeping = shouldSleep
            handle?.alpha = if (sleeping) 0.3f else 0.7f
            if (sleeping) { removeQuietly(bubble); bubble = null; if (chatBox == null) pet?.visibility = View.INVISIBLE }
        }
        if (lastDp != s.petDp) {
            lastDp = s.petDp
            pet?.let { v ->
                petParams?.let { lp ->
                    lp.width = petPx(); lp.height = petPx()
                    try { wm.updateViewLayout(v, lp) } catch (e: IllegalArgumentException) { }
                }
            }
        }
    }

    private fun startObservers() {
        observers.forEach { it.stopWatching() }
        observers.clear()
        if (!s.autoOrganize || !DocOrganizer.hasAccess(this)) return
        for (dir in DocOrganizer.sourceFolders()) {
            if (!dir.isDirectory) continue
            @Suppress("DEPRECATION")
            val o = object : FileObserver(dir.absolutePath, CREATE or MOVED_TO or CLOSE_WRITE) {
                override fun onEvent(event: Int, path: String?) {
                    if (path != null && !path.startsWith(".")) AutoOrganizer.request(this@PetOverlayService)
                }
            }
            o.startWatching()
            observers.add(o)
        }
    }

    private fun removeQuietly(v: View?) {
        if (v == null) return
        try {
            wm.removeView(v)
        } catch (ex: IllegalArgumentException) {
            // already removed
        }
    }

    private fun bubbleBg() = GradientDrawable().apply {
        setColor(Color.WHITE)
        cornerRadius = dp(14).toFloat()
        setStroke(2, Color.rgb(190, 150, 235))
    }

    // ---- views ----------------------------------------------------------------------------

    private fun createViews() {
        if (pet != null || !Settings.canDrawOverlays(this)) return

        val size = petPx()
        lastDp = s.petDp
        val lp = WindowManager.LayoutParams(
            size, size, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or hw,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = homeX()
        lp.y = homeY()

        val view = ImageView(this)
        view.setImageResource(R.drawable.ghost_pet)
        view.scaleType = ImageView.ScaleType.FIT_CENTER
        view.setOnTouchListener(PetTouch(lp, view))
        wm.addView(view, lp)
        pet = view
        petParams = lp
        startIdle(view)

        // Small draggable handle on the screen edge: tap to summon Ghostie.
        val hp = WindowManager.LayoutParams(
            dp(48), dp(48), overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or hw,
            PixelFormat.TRANSLUCENT
        )
        hp.gravity = Gravity.TOP or Gravity.START
        hp.x = dp(4)
        hp.y = screenH() / 2
        val h = ImageView(this)
        h.setImageResource(R.drawable.ghost_pet)
        h.scaleType = ImageView.ScaleType.CENTER_INSIDE
        h.alpha = 0.7f
        h.setPadding(dp(6), dp(6), dp(6), dp(6))
        h.setOnTouchListener(DragTouch(hp, h, false) {
            s.quietUntil = 0L
            if (sleeping) {
                wakeUntil = System.currentTimeMillis() + 10 * 60_000L
                sleeping = false
                h.alpha = 0.7f
                summon("Mmh... I'm up 🥱 (for a bit)")
            } else summon()
            react()
        })
        wm.addView(h, hp)
        handle = h
    }

    private fun destroyViews() {
        handler.removeCallbacks(blinkTask)
        handler.removeCallbacks(leaveTask)
        idleAnim?.cancel()
        slideAnim?.cancel()
        swayAnim?.cancel()
        handleAnim?.cancel()
        hopAnim?.cancel()
        swayAnim = null
        handleAnim = null
        hopAnim = null
        idleAnim = null
        slideAnim = null
        removeQuietly(bubble)
        removeQuietly(chatBox)
        removeQuietly(handle)
        removeQuietly(pet)
        bubble = null
        chatBox = null
        handle = null
        pet = null
        petParams = null
    }

    private fun startIdle(view: View) {
        // No endless animators (they redraw every frame and made the ghost laggy);
        // blinkTask plays a short bob / blink / glance every few seconds instead.
        handler.removeCallbacks(blinkTask)
        handler.postDelayed(blinkTask, 1500)
    }

    /** Squash-and-stretch pop: used when tapped, when it speaks and when it arrives. */
    private fun react() {
        val p = pet ?: return
        if (reacting) return
        reacting = true
        p.scaleY = 1f
        val pop = ObjectAnimator.ofPropertyValuesHolder(
            p,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.14f, 0.95f, 1f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 0.86f, 1.08f, 1f)
        )
        pop.duration = 500
        pop.interpolator = OvershootInterpolator()
        pop.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                reacting = false
            }
        })
        pop.start()
    }

    /** A bouncy landing after sliding in. */
    private fun hop() {
        val lp = petParams ?: return
        val p = pet ?: return
        hopAnim?.cancel()
        val landing = lp.y
        val from = (landing - dp(36)).coerceAtLeast(0)
        val anim = ValueAnimator.ofInt(from, landing)
        anim.duration = 750
        anim.interpolator = BounceInterpolator()
        anim.addUpdateListener { a ->
            lp.y = a.animatedValue as Int
            try {
                wm.updateViewLayout(p, lp)
            } catch (ex: IllegalArgumentException) {
                // removed
            }
        }
        hopAnim = anim
        anim.start()
    }

    // ---- coming and going -----------------------------------------------------------------

    /** Slides the pet window horizontally (a view cannot leave its own window, so move the window). */
    private fun slide(toX: Int, toAlpha: Float, endAction: (() -> Unit)? = null) {
        val p = pet ?: return
        val lp = petParams ?: return
        slideAnim?.cancel()
        val fromX = lp.x
        val fromAlpha = p.alpha
        val anim = ValueAnimator.ofFloat(0f, 1f)
        anim.duration = 600
        anim.addUpdateListener { a ->
            val f = a.animatedValue as Float
            lp.x = (fromX + (toX - fromX) * f).toInt()
            p.alpha = fromAlpha + (toAlpha - fromAlpha) * f
            try {
                wm.updateViewLayout(p, lp)
            } catch (ex: IllegalArgumentException) {
                // view removed mid-animation
            }
        }
        anim.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (!cancelled) endAction?.invoke()
            }
        })
        slideAnim = anim
        anim.start()
    }

    /** A deadline due today/tomorrow beats the usual small talk. */
    private fun pickMessage(): Chatter.Line {
        val soon = ReminderLog.upcoming(s.logs()).firstOrNull { ReminderLog.daysLeft(it) <= 1 }
        return if (soon != null) {
            val `when` = if (ReminderLog.daysLeft(soon) == 0L) "TODAY" else "tomorrow"
            val text = if (ReminderLog.isRegistration(soon)) "📝 Registration for ${ReminderLog.label(soon)} closes $`when`!"
            else "📌 ${ReminderLog.label(soon)} is due $`when`!"
            chatter.prompt("deadline", text, listOf("Done ✅", "Remind me later"))
        } else chatter.idle()
    }

    private fun canSpeak() = !suppressed && !sleeping && System.currentTimeMillis() > s.quietUntil

    private fun summon(line: Chatter.Line = pickMessage()) {
        val p = pet ?: return
        if (chatBox != null || suppressed) return
        lastLine = line
        lastLineAt = System.currentTimeMillis()
        p.visibility = View.VISIBLE
        slide(homeX(), 1f) { hop() }
        showBubble(line.text)
        if (canSpeak()) {
            voice?.sfx("hello")
            voice?.speak(line.text)
        }
        handler.postDelayed({ react() }, 500)
        handler.removeCallbacks(leaveTask)
        handler.postDelayed(leaveTask, (14_000L..30_000L).random())
    }

    private fun summon(text: String) = summon(Chatter.Line(text))

    private fun leave() {
        if (chatBox == null) { chatter.unanswered(); LearnStore.save(this) }
        removeQuietly(bubble)
        bubble = null
        if (chatBox != null) return
        val p = pet ?: return
        slide(-petPx(), 0f) { p.visibility = View.INVISIBLE }
    }

    private fun showBubble(msg: String, atX: Int = homeX(), atY: Int = homeY()) {
        removeQuietly(bubble)
        val tv = TextView(this)
        tv.text = msg
        tv.setTextColor(ink)
        tv.textSize = 15f
        tv.setPadding(dp(14), dp(10), dp(14), dp(10))
        tv.background = bubbleBg()
        val width = dp(220)
        val lp = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or hw,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = minOf(atX + petPx() - dp(20), maxOf(0, screenW() - width)).coerceAtLeast(0)
        lp.y = maxOf(dp(40), atY + dp(30))
        wm.addView(tv, lp)
        bubble = tv
    }

    // ---- chat -----------------------------------------------------------------------------

    private fun openChat() {
        if (chatBox != null) return
        removeQuietly(bubble)
        bubble = null
        handler.removeCallbacks(leaveTask)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(12), dp(12), dp(12))
        box.background = bubbleBg()

        val log = TextView(this)
        // Continue whatever the ghost just said when it popped up.
        val carry = lastLine?.takeIf { System.currentTimeMillis() - lastLineAt < 15 * 60_000L }
        log.text = "Ghostie: ${carry?.text ?: "Hi! 💜"}\n\n"
        if (carry != null && s.ai && s.key.isNotBlank() && chatHistory.isEmpty()) chatHistory.add("assistant" to carry.text)
        log.textSize = 14f
        log.setTextColor(ink)
        val scroll = ScrollView(this)
        scroll.addView(log)
        box.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(160)))

        val chipScroll = HorizontalScrollView(this)
        chipScroll.isHorizontalScrollBarEnabled = false
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        chipScroll.addView(chips)
        box.addView(chipScroll)
        chipRow = chips

        val input = EditText(this)
        input.hint = "Say something…"
        input.isSingleLine = true
        input.setTextColor(ink)
        input.setHintTextColor(Color.GRAY)
        val mic = Button(this)
        mic.text = "🎙"
        val send = Button(this)
        send.text = "➤"
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(mic, LinearLayout.LayoutParams(dp(52), LinearLayout.LayoutParams.WRAP_CONTENT))
        row.addView(send, LinearLayout.LayoutParams(dp(56), LinearLayout.LayoutParams.WRAP_CONTENT))
        box.addView(row)

        val close = Button(this)
        close.text = "Close"
        close.setOnClickListener { closeChat() }
        box.addView(close)

        fun append(who: String, text: String) {
            log.append("$who: $text\n\n")
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }

        fun ghostSays(text: String) {
            append("Ghostie", text)
            if (canSpeak()) voice?.speak(text)
        }

        fun showChips(list: List<String>, submit: (String) -> Unit) {
            chips.removeAllViews()
            for (c in list) {
                val b = Button(this)
                b.text = c
                b.isAllCaps = false
                b.textSize = 13f
                b.minHeight = dp(34)
                b.minimumHeight = dp(34)
                b.setOnClickListener { submit(c) }
                chips.addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(38)).apply { rightMargin = dp(6) })
            }
        }

        fun submit(q: String) {
            append("You", q)
            chips.removeAllViews()
            converse(q) { text, next ->
                ghostSays(text)
                react()
                voice?.sfx("pop")
                showChips(next) { submitRef(it) }
            }
        }
        submitRef = ::submit

        mic.setOnClickListener {
            input.hint = "Listening…"
            startListening { text -> input.hint = "Say something…"; submit(text) }
        }
        send.setOnClickListener {
            val q = input.text.toString().trim()
            if (q.isEmpty()) return@setOnClickListener
            input.text.clear()
            submit(q)
        }
        carry?.let { showChips(it.chips) { c -> submit(c) } }

        val width = dp(300)
        val lp = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or hw,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = homeX().coerceIn(0, maxOf(0, screenW() - width))
        lp.y = maxOf(dp(40), homeY() - dp(300))
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        wm.addView(box, lp)
        chatBox = box
    }

    // ---- commands -------------------------------------------------------------------------

    private fun startSafely(intent: Intent): Boolean = try {
        startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }

    private fun runCommand(cmd: Command, say: (String) -> Unit) {
        when (cmd) {
            is Command.Help -> say(Commands.HELP)
            is Command.Incomplete -> say(cmd.message)
            is Command.Organize -> organizeDocs(say)
            is Command.Event -> addEvent(cmd, say)
            is Command.MakeKind -> remakeEvent(cmd.kind, say)
            is Command.Teach -> {
                val l = LearnStore.get(this)
                l.addAlias(cmd.phrase, cmd.meaning)
                LearnStore.save(this)
                ActivityLog.add(this, "Learning", "Taught: \"${cmd.phrase}\"")
                say(when {
                    cmd.meaning.startsWith("word:") -> "Got it 🧠 I'll read \"${cmd.phrase}\" as \"${cmd.meaning.removePrefix("word:")}\"."
                    cmd.meaning.startsWith("say:") -> "Got it 🧠 When you say \"${cmd.phrase}\" I'll say: ${cmd.meaning.removePrefix("say:")}"
                    else -> "Got it 🧠 When you say \"${cmd.phrase}\" I'll do: ${cmd.meaning}"
                })
            }
            is Command.Forget -> {
                val ok = LearnStore.get(this).removeAlias(cmd.phrase)
                LearnStore.save(this)
                say(if (ok) "Forgotten \"${cmd.phrase}\" 🧹" else "I don't have anything taught for \"${cmd.phrase}\".")
            }
            is Command.ForgetAll -> {
                LearnStore.reset(this)
                ActivityLog.add(this, "Learning", "Forgot everything")
                say("Memory wiped 🧹 I'm a blank ghost again.")
            }
            is Command.Learned -> {
                val l = LearnStore.get(this)
                val taught = l.aliases.entries.take(6).joinToString("\n") { "• \"${it.key}\" → ${it.value.removePrefix("word:").removePrefix("say:")}" }
                say("Here's what I've learned 🧠\n" + l.summary() + if (taught.isNotEmpty()) "\n$taught" else "")
            }
            is Command.Watch -> {
                s.addWatchedGroup(cmd.group)
                val listenerOn = androidx.core.app.NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
                if (listenerOn) {
                    say("Watching \"${cmd.group}\" 👀 If someone posts a submission date there, I'll set a reminder for the day before.")
                } else {
                    startSafely(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    say("Added \"${cmd.group}\" 👀 Now switch on Notification access for Ghostie (I opened the page) so I can read that group's messages.")
                }
            }
            is Command.ShowDocs -> {
                if (!DocOrganizer.hasAccess(this)) {
                    say("I need file access first - say \"organize documents\" and I'll open the setting.")
                } else {
                    val found = DocOrganizer.listSubject(cmd.subject, s.subjects)
                    if (found == null) {
                        say("I don't have a folder for \"${cmd.subject}\" yet. Try \"organize documents\" first.")
                    } else {
                        val (folder, files) = found
                        if (files.isEmpty()) say("$folder is empty.")
                        else {
                            val shown = files.take(8).joinToString("\n") { "• ${it.name}" }
                            val more = if (files.size > 8) "\n...and ${files.size - 8} more" else ""
                            say("$folder has ${files.size} files (newest first):\n$shown$more\n📂 Documents/Ghostie/$folder")
                        }
                    }
                }
            }
            is Command.Timer -> {
                val i = Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, cmd.seconds)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                say(if (startSafely(i)) "Timer set for ${formatDuration(cmd.seconds)} ⏱️" else "I couldn't start a timer on this phone.")
            }
            is Command.Alarm -> {
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, cmd.hour)
                    .putExtra(AlarmClock.EXTRA_MINUTES, cmd.minute)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                if (cmd.label.isNotBlank()) i.putExtra(AlarmClock.EXTRA_MESSAGE, cmd.label.replaceFirstChar { it.uppercase() })
                val lbl = if (cmd.label.isNotBlank()) " (\"${cmd.label}\")" else ""
                say(if (startSafely(i)) "Alarm set for %02d:%02d$lbl ⏰".format(cmd.hour, cmd.minute) else "I couldn't set an alarm on this phone.")
            }
            is Command.Call -> callSomeone(cmd.target, say)
            is Command.OpenApp -> {
                val pm = packageManager
                val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                val wanted = cmd.name.lowercase().trim()
                val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == wanted }
                    ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(wanted) }
                val intent = match?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
                say(if (intent != null && startSafely(intent)) "Opening ${match?.loadLabel(pm)} 🚀" else "I couldn't find an app called \"${cmd.name}\".")
            }
        }
    }

    private fun granted(perm: String) = ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED

    private fun callSomeone(target: String, say: (String) -> Unit) {
        val digits = target.filter { it.isDigit() || it == '+' }
        val looksLikeNumber = digits.count { it.isDigit() } >= 3 && target.all { it.isDigit() || it in "+ -()" }
        var number: String? = null
        var name = target
        if (looksLikeNumber) {
            number = digits
        } else {
            if (!granted(android.Manifest.permission.READ_CONTACTS)) {
                say("I need Contacts access to find \"$target\" 📇 Open the Ghostie app → Setup → Contacts & calls. (Or say a number: call 9876543210)")
                return
            }
            val found = findContact(target)
            if (found == null) { say("I couldn't find \"$target\" in your contacts."); return }
            name = found.first
            number = found.second
        }
        val emergency = number.filter { it.isDigit() }.let { it in setOf("100", "101", "102", "108", "112", "911", "999", "000") }
        val uri = Uri.parse("tel:" + Uri.encode(number))
        if (!emergency && granted(android.Manifest.permission.CALL_PHONE)) {
            say(if (startSafely(Intent(Intent.ACTION_CALL, uri))) "Calling $name 📞" else "I couldn't place that call.")
        } else {
            val why = if (emergency) "" else " (turn on Phone in the Ghostie app and I'll dial instantly)"
            say(if (startSafely(Intent(Intent.ACTION_DIAL, uri))) "Opened the dialer for $name 📞$why" else "I couldn't open the dialer.")
        }
    }

    /** Best match by name: exact, then starts-with, then contains. Returns (display name, number). */
    private fun findContact(query: String): Pair<String, String>? {
        val q = query.lowercase().trim()
        val rows = mutableListOf<Pair<String, String>>()
        try {
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0) ?: continue
                    val num = c.getString(1) ?: continue
                    rows.add(n to num)
                }
            }
        } catch (e: SecurityException) {
            return null
        }
        return rows.firstOrNull { it.first.lowercase() == q }
            ?: rows.firstOrNull { it.first.lowercase().startsWith(q) }
            ?: rows.firstOrNull { it.first.lowercase().split(" ").any { w -> w.startsWith(q) } }
            ?: rows.firstOrNull { it.first.lowercase().contains(q) }
    }

    // ---- calendar categories ----------------------------------------------------------------

    private fun whenText(e: Command.Event): String {
        val z = java.time.Instant.ofEpochMilli(e.startMillis).atZone(java.time.ZoneId.systemDefault())
        val fmt = if (e.allDay) "EEE d MMM" else "EEE d MMM, h:mm a"
        return z.format(java.time.format.DateTimeFormatter.ofPattern(fmt, java.util.Locale.ENGLISH))
    }

    private fun describe(e: Command.Event): String {
        val repeat = when (e.repeat) {
            "YEARLY" -> " (repeats every year)"; "WEEKLY" -> " (repeats weekly)"; "DAILY" -> " (repeats daily)"; "MONTHLY" -> " (repeats monthly)"; else -> ""
        }
        val extra = when (e.kind) {
            EventKind.BIRTHDAY -> "\nI'll remind you the day before and that morning."
            EventKind.ANNIVERSARY -> "\nReminders: a week before, the day before and that morning."
            EventKind.COUNTDOWN -> {
                val days = java.time.temporal.ChronoUnit.DAYS.between(java.time.LocalDate.now(), java.time.Instant.ofEpochMilli(e.startMillis).atZone(java.time.ZoneId.systemDefault()).toLocalDate())
                "\n$days days to go!"
            }
            else -> ""
        }
        return "Added ${e.kind.icon} ${e.title} on ${whenText(e)}$repeat$extra"
    }

    private fun addEvent(cmd: Command.Event, say: (String) -> Unit) {
        val l = LearnStore.get(this)
        var ev = cmd
        var note = ""
        val base = Commands.baseTitle(cmd.title)
        if (!cmd.explicit) {
            val kind = l.suggestKind(base)?.let { EventKind.parse(it) }
            if (kind != null && kind != EventKind.EVENT) {
                ev = Commands.withKind(cmd, kind)
                note = "\n(I remembered $base is a ${kind.label.lowercase()} ${kind.icon}. Say \"make it an event\" if that's wrong.)"
            }
        } else {
            l.teachKind(base, ev.kind.name)
            LearnStore.save(this)
        }
        val id = CalendarHelper.insertEvent(this, ev, "Added by Ghostie")
        if (id != null) {
            lastEvent = ev to id
            if (ev.kind == EventKind.COUNTDOWN) {
                val d = java.time.Instant.ofEpochMilli(ev.startMillis).atZone(java.time.ZoneId.systemDefault()).toLocalDate()
                s.addLog(LogEntry(System.currentTimeMillis(), "Countdown", "⏳ Countdown: $base", d.toString(), id, ev.startMillis))
            }
            ActivityLog.add(this, "Calendar", "Added ${ev.kind.label}: ${ev.title}")
            say(describe(ev) + note)
        } else {
            // No calendar permission yet: open the calendar's own form, pre-filled.
            val i = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.Events.TITLE, ev.title)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, ev.startMillis)
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, ev.startMillis + ev.durationMin * 60_000L)
                .putExtra(CalendarContract.EXTRA_EVENT_ALL_DAY, ev.allDay)
            if (ev.repeat.isNotEmpty()) i.putExtra(CalendarContract.Events.RRULE, "FREQ=${ev.repeat}")
            if (ev.description.isNotBlank()) i.putExtra(CalendarContract.Events.DESCRIPTION, ev.description)
            say(if (startSafely(i)) "Opening your calendar to save it ${ev.kind.icon} (turn on Calendar in the Ghostie app and I'll add events instantly.)"
            else "I couldn't find a calendar app on this phone.")
        }
    }

    /** "make it a birthday": replaces the last event with the right category and remembers the correction. */
    private fun remakeEvent(kind: EventKind, say: (String) -> Unit) {
        val last = lastEvent
        if (last == null) { say("Which event? Add one first, e.g. \"add event Tikki on 19 October\"."); return }
        val (old, oldId) = last
        val ev = Commands.withKind(old, kind)
        CalendarHelper.delete(this, oldId)
        s.removeLog(oldId)
        val id = CalendarHelper.insertEvent(this, ev, "Added by Ghostie")
        if (id == null) { say("I couldn't change it - is Calendar allowed?"); return }
        lastEvent = ev to id
        val l = LearnStore.get(this)
        l.teachKind(Commands.baseTitle(ev.title), kind.name)
        LearnStore.save(this)
        ActivityLog.add(this, "Learning", "${Commands.baseTitle(ev.title)} is a ${kind.label}")
        say(describe(ev) + "\nI'll remember that \"${Commands.baseTitle(ev.title)}\" is a ${kind.label.lowercase()} 🧠")
    }

    // ---- talking and listening ---------------------------------------------------------------

    /** One place that understands a sentence: taught phrases, commands, AI or small talk. */
    private fun converse(raw: String, reply: (String, List<String>) -> Unit) {
        val l = LearnStore.get(this)
        var q = raw.trim()
        val alias = l.findAlias(q)
        if (alias != null && !alias.startsWith("word:")) {
            if (alias.startsWith("say:")) { reply(alias.removePrefix("say:"), emptyList()); return }
            q = alias
        } else {
            q = l.applyWords(q)
        }
        val command = Commands.parse(q)
        val useAi = s.ai && s.key.isNotBlank()
        when {
            command != null -> runCommand(command) { reply(it, emptyList()) }
            useAi -> {
                val past = chatHistory.toList()
                val text = q
                scope.launch {
                    val a = ChatEngine.openAi(s.key, past, text)
                    chatHistory.add("user" to text)
                    chatHistory.add("assistant" to a)
                    reply(a, emptyList())
                }
            }
            else -> {
                val answer = chatter.reply(q)
                val next = chatter.chips
                if (chatter.userName != s.userName) s.userName = chatter.userName
                LearnStore.save(this)
                // a short "thinking" pause makes it feel like a friend, not a lookup table
                handler.postDelayed({ reply(answer, next) }, (250L + answer.length * 6L).coerceAtMost(800L))
            }
        }
    }

    private fun startListening(sink: ((String) -> Unit)? = null) {
        if (suppressed) return
        voice?.stop()
        voiceSink = sink
        if (vin?.start() == true) {
            voice?.sfx("pop")
            pet?.animate()?.scaleX(1.1f)?.scaleY(1.1f)?.setDuration(150)?.start()
            if (chatBox == null) petParams?.let { showBubble("🎙️ Listening…", it.x, it.y) }
        } else {
            startVoiceDialog()
        }
    }

    /** Fallback: the phone's own speech dialog. */
    private fun startVoiceDialog() {
        startSafely(Intent(this, VoiceActivity::class.java))
    }

    private fun stopListeningUi() {
        pet?.animate()?.scaleX(1f)?.scaleY(1f)?.setDuration(150)?.start()
        if (chatBox == null) { removeQuietly(bubble); bubble = null }
    }

    private fun handleVoiceState(st: String) {
        when {
            st.startsWith("partial:") -> if (chatBox == null) petParams?.let { showBubble("🎙️ " + st.removePrefix("partial:"), it.x, it.y) }
            st == "nomatch" -> {
                stopListeningUi()
                voiceSink = null
                if (chatBox == null) summon("Hmm, I didn't catch that 🙉 Hold me and try again.")
            }
            else -> {
                stopListeningUi()
                startVoiceDialog()
            }
        }
    }

    private fun handleSpoken(text: String) {
        stopListeningUi()
        val sink = voiceSink
        voiceSink = null
        if (sink != null) { sink(text); return }
        if (chatBox != null) { submitRef(text); return }
        ActivityLog.add(this, "Voice", "Heard: $text")
        converse(text) { answer, chips -> summon(Chatter.Line(answer, chips)) }
    }

    // ---- the bin: throw the ghost away -------------------------------------------------------

    private fun showBin() {
        if (binView != null) return
        val tv = TextView(this)
        tv.text = "🗑️"
        tv.textSize = 30f
        tv.gravity = Gravity.CENTER
        tv.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(210, 255, 255, 255))
            setStroke(3, Color.rgb(190, 150, 235))
        }
        val sz = dp(76)
        val lp = WindowManager.LayoutParams(
            sz, sz, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or hw,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (screenW() - sz) / 2
        lp.y = screenH() - sz - dp(96)
        tv.alpha = 0f
        try {
            wm.addView(tv, lp)
        } catch (e: Exception) {
            return
        }
        tv.animate().alpha(1f).setDuration(150).start()
        binView = tv
        binParams = lp
    }

    private fun hideBin() {
        val v = binView
        binView = null
        binParams = null
        overBin = false
        v?.animate()?.alpha(0f)?.setDuration(150)?.withEndAction { removeQuietly(v) }?.start()
    }

    private fun updateBin(lp: WindowManager.LayoutParams) {
        val b = binParams ?: return
        val dx = (lp.x + lp.width / 2) - (b.x + b.width / 2)
        val dy = (lp.y + lp.height / 2) - (b.y + b.height / 2)
        val near = Math.hypot(dx.toDouble(), dy.toDouble()) < dp(70) + lp.width / 3
        if (near != overBin) {
            overBin = near
            val sc = if (near) 1.3f else 1f
            binView?.animate()?.scaleX(sc)?.scaleY(sc)?.setDuration(120)?.start()
            pet?.animate()?.alpha(if (near) 0.7f else 1f)?.setDuration(120)?.start()
            if (near) voice?.sfx("pop")
        }
    }

    /** Dropped on the bin: the ghost crumples and spins in, then goes away for an hour. */
    private fun throwAway(view: View, lp: WindowManager.LayoutParams) {
        val b = binParams ?: return
        val tx = b.x + b.width / 2 - lp.width / 2
        val ty = b.y + b.height / 2 - lp.height / 2
        val fx = lp.x
        val fy = lp.y
        if (canSpeak()) voice?.speak("Okay, okay. I'll go away for a while. Tap my little edge ghost to call me back.")
        voice?.sfx("squeak")
        ActivityLog.add(this, "Bin", "Ghost thrown in the bin - quiet for 1 hour")
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 520
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                lp.x = (fx + (tx - fx) * f).toInt()
                lp.y = (fy + (ty - fy) * f).toInt()
                view.scaleX = 1f - 0.9f * f
                view.scaleY = 1f - 0.9f * f
                view.rotation = 540f * f
                try { wm.updateViewLayout(view, lp) } catch (ex: IllegalArgumentException) { }
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    view.visibility = View.INVISIBLE
                    view.scaleX = 1f; view.scaleY = 1f; view.rotation = 0f; view.alpha = 1f
                    lp.x = homeX(); lp.y = homeY()
                    try { wm.updateViewLayout(view, lp) } catch (ex: IllegalArgumentException) { }
                    hideBin()
                    s.quietUntil = System.currentTimeMillis() + 60 * 60_000L
                }
            })
            start()
        }
    }

    private fun formatDuration(seconds: Int): String {
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val sec = seconds % 60
        return listOfNotNull(
            if (h > 0) "$h h" else null,
            if (m > 0) "$m min" else null,
            if (sec > 0) "$sec s" else null
        ).joinToString(" ")
    }

    private fun organizeDocs(say: (String) -> Unit) {
        if (!DocOrganizer.hasAccess(this)) {
            val i = if (Build.VERSION.SDK_INT >= 30) {
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            } else {
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            }
            startSafely(i)
            say("I need file access first 📂 I opened the settings - switch it on for Ghostie, then ask me again.")
            return
        }
        say("On it... sorting your WhatsApp documents 📂")
        scope.launch {
            val result = try {
                withContext(Dispatchers.IO) { DocOrganizer.organize(this@PetOverlayService) }
            } catch (e: Exception) {
                null
            }
            say(if (result != null) DocOrganizer.summary(result) else "Something went wrong while organizing.")
        }
    }

    private fun closeChat() {
        voice?.stop()
        removeQuietly(chatBox)
        chatBox = null
        handler.removeCallbacks(leaveTask)
        handler.postDelayed(leaveTask, 3000)
    }

    // ---- touch: drag to move, tap to act --------------------------------------------------

    /**
     * The pet: leans toward your finger while touched; hold it to talk to it; tap to chat; double-tap to spin;
     * triple-tap to pet it; drag to carry it (shake for dizzy) and drop it on the bin that appears to throw it away.
     */
    private inner class PetTouch(private val lp: WindowManager.LayoutParams, private val target: ImageView) : View.OnTouchListener {
        private var startRawX = 0f
        private var startRawY = 0f
        private var lastRawX = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false
        private var held = false
        private var dizzy = false
        private var shake = 0f
        private var taps = 0
        private var lastTapAt = 0L
        private val holdTask = Runnable {
            if (!moved) {
                held = true
                startListening()
            }
        }
        private val openLater = Runnable { openChat() }
        private val spinLater = Runnable { spin(target) }

        private fun lean(e: MotionEvent) {
            val w = maxOf(1, target.width).toFloat()
            val h = maxOf(1, target.height).toFloat()
            val fx = ((e.x / w) - 0.5f).coerceIn(-0.5f, 0.5f) * 2f
            val fy = ((e.y / h) - 0.5f).coerceIn(-0.5f, 0.5f) * 2f
            target.cameraDistance = 9000f * resources.displayMetrics.density
            target.rotationY = fx * 16f
            target.rotationX = -fy * 16f
            target.translationX = fx * dp(3)
        }

        private fun unlean() {
            target.animate().rotationX(0f).rotationY(0f).translationX(0f).setDuration(180).start()
        }

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = e.rawX
                    startRawY = e.rawY
                    lastRawX = e.rawX
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    held = false
                    dizzy = false
                    shake = 0f
                    handler.postDelayed(holdTask, 450)
                    lean(e)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - startRawX
                    val dy = e.rawY - startRawY
                    if (!moved && !held && (abs(dx) > dp(8) || abs(dy) > dp(8))) {
                        moved = true
                        handler.removeCallbacks(holdTask)
                        handler.removeCallbacks(openLater)
                        handler.removeCallbacks(spinLater)
                        target.animate().rotationX(0f).rotationY(0f).translationX(0f).scaleX(1.1f).scaleY(1.1f).setDuration(120).start()
                        voice?.sfx("squeak")
                        showBin()
                    }
                    if (!moved) {
                        if (!held) lean(e)
                    } else {
                        lp.x = (startX + dx).toInt().coerceIn(0, maxOf(0, screenW() - lp.width))
                        lp.y = (startY + dy).toInt().coerceIn(0, maxOf(0, screenH() - lp.height))
                        val step = (e.rawX - lastRawX) / resources.displayMetrics.density
                        lastRawX = e.rawX
                        target.rotation = (target.rotation * 0.7f + step * 2.5f * 0.3f).coerceIn(-22f, 22f)
                        shake += abs(step)
                        if (!dizzy && shake > 700f) {
                            dizzy = true
                            voice?.sfx("giggle")
                            showBubble("Wheeeee! 😵‍💫", lp.x, lp.y)
                            handler.postDelayed({ removeQuietly(bubble); bubble = null }, 1800)
                        }
                        updateBin(lp)
                        try {
                            wm.updateViewLayout(target, lp)
                        } catch (ex: IllegalArgumentException) {
                            // removed
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(holdTask)
                    unlean()
                    if (held) {
                        vin?.stop() // let go: finish listening and answer
                    } else if (moved) {
                        if (overBin) {
                            throwAway(target, lp)
                        } else {
                            s.x = lp.x
                            s.y = lp.y
                            dropFx(target, dizzy)
                            hideBin()
                        }
                    } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                        val now = System.currentTimeMillis()
                        taps = if (now - lastTapAt < 380) taps + 1 else 1
                        lastTapAt = now
                        handler.removeCallbacks(openLater)
                        handler.removeCallbacks(spinLater)
                        when (taps) {
                            1 -> {
                                react()
                                voice?.sfx("pop")
                                handler.postDelayed(openLater, 330)
                            }
                            2 -> handler.postDelayed(spinLater, 330)
                            else -> {
                                taps = 0
                                petIt(target)
                            }
                        }
                    }
                }
            }
            return true
        }
    }

    /** Lands with a squash and a little bounce. */
    private fun dropFx(view: View, wasDizzy: Boolean) {
        view.animate().rotation(0f).scaleX(1f).scaleY(1f).setDuration(150).start()
        ObjectAnimator.ofPropertyValuesHolder(
            view,
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 0.78f, 1.06f, 1f),
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.12f, 0.97f, 1f)
        ).apply { duration = 420; interpolator = OvershootInterpolator(); startDelay = 80; start() }
        voice?.sfx("pop")
        if (wasDizzy) {
            handler.postDelayed({
                showBubble("Whoa... everything is spinning 😵‍💫", petParams?.x ?: homeX(), petParams?.y ?: homeY())
                handler.postDelayed({ removeQuietly(bubble); bubble = null }, 2200)
                if (canSpeak()) voice?.speak("Whoa. Everything is spinning.")
            }, 300)
        }
    }

    private fun spin(view: View) {
        ObjectAnimator.ofFloat(view, View.ROTATION, 0f, 360f).apply {
            duration = 700
            interpolator = OvershootInterpolator(0.8f)
            start()
        }
        hop()
        voice?.sfx("giggle")
        showBubble("Wheee! 🌀", petParams?.x ?: homeX(), petParams?.y ?: homeY())
        handler.postDelayed({ removeQuietly(bubble); bubble = null }, 1500)
    }

    /** Long-press: hearts float up and the ghost wiggles and purrs. */
    private fun petIt(view: View) {
        ObjectAnimator.ofFloat(view, View.ROTATION, 0f, -10f, 10f, -8f, 8f, 0f).apply { duration = 700; start() }
        voice?.sfx("purr")
        val line = petLines.random()
        if (canSpeak()) voice?.speak(line)
        val lp0 = petParams ?: return
        val hearts = TextView(this)
        hearts.text = "💜 💗 💜"
        hearts.textSize = 22f
        val hp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or hw,
            PixelFormat.TRANSLUCENT
        )
        hp.gravity = Gravity.TOP or Gravity.START
        hp.x = lp0.x
        val startY = maxOf(0, lp0.y - dp(10))
        hp.y = startY
        try {
            wm.addView(hearts, hp)
        } catch (e: Exception) {
            return
        }
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1400
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                hp.y = (startY - dp(90) * f).toInt().coerceAtLeast(0)
                hearts.alpha = 1f - f
                try { wm.updateViewLayout(hearts, hp) } catch (ex: IllegalArgumentException) { }
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) { removeQuietly(hearts) }
            })
            start()
        }
        showBubble(line, lp0.x, lp0.y)
        handler.postDelayed({ removeQuietly(bubble); bubble = null }, 2000)
    }

    private inner class DragTouch(
        private val lp: WindowManager.LayoutParams,
        private val target: View,
        private val persist: Boolean,
        private val onTap: () -> Unit
    ) : View.OnTouchListener {
        private var startRawX = 0f
        private var startRawY = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = e.rawX
                    startRawY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - startRawX
                    val dy = e.rawY - startRawY
                    val slop = dp(6).toFloat()
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = (startX + dx).toInt().coerceIn(0, maxOf(0, screenW() - lp.width))
                        lp.y = (startY + dy).toInt().coerceIn(0, maxOf(0, screenH() - lp.height))
                        try {
                            wm.updateViewLayout(target, lp)
                        } catch (ex: IllegalArgumentException) {
                            // view removed
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        if (persist) {
                            s.x = lp.x
                            s.y = lp.y
                        }
                    } else {
                        onTap()
                    }
                }
            }
            return true
        }
    }
}
