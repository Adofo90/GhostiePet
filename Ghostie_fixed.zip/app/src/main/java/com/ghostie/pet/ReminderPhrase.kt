package com.ghostie.pet

import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Many ways to ask for a reminder that rings at a clock time:
 * "add reminder for 7 as AI assignment", "reminder AI assignment 7 o'clock", "add assignment reminder at 7:00",
 * "assignment reminder at 7", "Aaj reminder for assignment" (asks the time), "remind me to submit it at 7 pm", "kal 8 baje reminder gym".
 * A bare hour such as "7" means the next 7 o'clock that is still ahead (7 pm if it is afternoon now). Pure Kotlin (JVM tested).
 */
object ReminderPhrase {
    private val I = RegexOption.IGNORE_CASE
    private class Hit(val hour: Int, val minute: Int, val ap: String?, val start: Int, val end: Int)

    private val connectors = setOf("to", "for", "about", "as", "that", "at", "by", "on", "ki", "ka", "ke", "ko", "of", "and", "-", ":")
    private val prepLeft = Regex("\\b(?:at|by|for|around|before|till|until)\\s*$", I)

    private fun findTime(s: String): Hit? {
        fun ok(h: Int, m: Int, ap: String?) = m in 0..59 && (if (ap != null) h in 1..12 else h in 0..23)
        val pats = listOf(
            Regex("(?<![\\d:.])(\\d{1,2})[:.](\\d{2})\\s*(a\\.?m\\.?|p\\.?m\\.?)?(?![\\d])", I) to 1,
            Regex("(?<![\\d:.])(\\d{1,2})\\s*(a\\.?m\\.?|p\\.?m\\.?)(?![a-z])", I) to 2,
            Regex("(?<![\\d:.])(\\d{1,2})\\s*(?:o'?\\s?clock|oclock|baje|bje)\\b", I) to 3,
            Regex("\\b(?:at|by|for|till|until|before|around)\\s+(\\d{1,2})(?![\\d:.]|\\s*(?:min|hour|hr|day|week|sec|%|rs\\b|marks|question|assignment|page|item|people))", I) to 4
        )
        for ((re, kind) in pats) {
            val m = re.find(s) ?: continue
            val h = m.groupValues[1].toInt()
            val min = if (kind == 1) m.groupValues[2].toInt() else 0
            val apRaw = when (kind) { 1 -> m.groupValues[3]; 2 -> m.groupValues[2]; else -> "" }
            val ap = if (apRaw.isEmpty()) null else if (apRaw.lowercase().startsWith("p")) "pm" else "am"
            if (!ok(h, min, ap)) continue
            var start = m.range.first
            if (kind != 4) { val left = prepLeft.find(s.substring(0, start)); if (left != null) start = left.range.first }
            return Hit(h, min, ap, start, m.range.last + 1)
        }
        return null
    }

    private fun resolve(hit: Hit, now: LocalDateTime, dayOffset: Int, part: String?): LocalDateTime {
        val date = now.toLocalDate().plusDays(dayOffset.toLong())
        var h = hit.hour
        val explicit = hit.ap != null || h == 0 || h >= 13 || part != null
        if (hit.ap == "pm") h = h % 12 + 12 else if (hit.ap == "am") h %= 12
        else if (part == "pm" && h in 1..11) h += 12
        else if (part == "am" && h == 12) h = 0
        if (explicit) {
            var t = date.atTime(h, hit.minute)
            if (!t.isAfter(now) && dayOffset == 0) t = t.plusDays(1)
            return t
        }
        if (dayOffset == 0) {
            val am = date.atTime(h % 12, hit.minute); val pm = date.atTime(h % 12 + 12, hit.minute)
            // a plain "12" means noon
            val cands = if (h == 12) listOf(pm, am.plusDays(1)) else listOf(am, pm, am.plusDays(1))
            return cands.first { it.isAfter(now) }
        }
        val hh = when (h) { in 1..6 -> h + 12; 12 -> 12; else -> h }
        return date.atTime(hh, hit.minute)
    }

    private fun dayOffset(s: String): Int? = when {
        Regex("\\b(?:tomorrow|tmrw|kal)\\b", I).containsMatchIn(s) -> 1
        Regex("\\b(?:today|aaj|tonight|tonite)\\b", I).containsMatchIn(s) -> 0
        else -> null
    }
    private fun partOfDay(s: String): String? = when {
        Regex("\\b(?:evening|night|tonight|tonite|shaam|raat|afternoon|dopahar)\\b", I).containsMatchIn(s) -> "pm"
        Regex("\\b(?:morning|subah)\\b", I).containsMatchIn(s) -> "am"
        else -> null
    }

    /** What is left of the sentence once the time, day and the "add reminder" words are taken out. */
    private fun task(s: String, hit: Hit?): String {
        var t = if (hit != null) s.substring(0, hit.start) + " " + s.substring(hit.end) else s
        t = t.replace(Regex("\\b(?:today|tomorrow|tmrw|tonight|tonite|aaj|kal|morning|evening|night|afternoon|subah|shaam|raat|dopahar)\\b", I), " ")
        t = t.replace(Regex("\\b(?:please|pls|plz)\\b", I), " ")
        t = t.replace(Regex("\\bremind(?:er)?s?\\b(?:\\s+me)?", I), " ")
        t = t.trim().replace(Regex("\\s+"), " ")
        t = t.replace(Regex("^(?:(?:add|set|create|make|put|new|save|do)\\b\\s*)+", I), "")
        t = t.replace(Regex("^(?:(?:a|an|my|new)\\s+)+", I), "")
        val parts = t.split(' ').filter { it.isNotEmpty() }.toMutableList()
        while (parts.isNotEmpty() && parts.first().lowercase().trim(',', '.') in connectors) parts.removeAt(0)
        while (parts.isNotEmpty() && parts.last().lowercase().trim(',', '.') in connectors) parts.removeAt(parts.size - 1)
        return parts.joinToString(" ").trim(' ', ',', '.', '-', ':')
    }

    private val questionLead = Regex("^(?:what|which|when|who|how|why|do|does|did|is|are|can|could|show|list|see|view|cancel|delete|remove|clear|forget|my|stop|no|any|have|has)\\b", I)

    private fun fmt(at: LocalDateTime, now: LocalDateTime): String {
        val day = when (at.toLocalDate()) { now.toLocalDate() -> "today"; now.toLocalDate().plusDays(1) -> "tomorrow"; else -> at.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.ENGLISH) }
        return at.format(DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH)) + " " + day
    }

    /** Asked for a reminder with a clock time or a missing time. [hasDate] is true when a calendar date is in the sentence (those stay events). */
    fun parse(t: String, now: LocalDateTime, hasDate: Boolean): Command? {
        val s = t.trim().replace(Regex("\\s+"), " ")
        if (!Regex("\\bremind(?:er)?s?\\b", I).containsMatchIn(s)) return null
        if (questionLead.containsMatchIn(s) || hasDate) return null
        if (Regex("\\b(?:event|meeting|birthday|anniversary|countdown|calendar)\\b", I).containsMatchIn(s)) return null
        if (Regex("\\bin\\s+\\d+\\s*(?:seconds?|secs?|minutes?|mins?|hours?|hrs?)\\b", I).containsMatchIn(s)) return null
        val hit = findTime(s)
        val day = dayOffset(s) ?: 0
        val what = task(s, hit)
        if (hit == null) {
            // "add reminder", "Aaj reminder for assignment": ask for the missing piece
            return Command.RemindNeedTime(what.ifEmpty { null }, day)
        }
        if (what.isEmpty()) return Command.RemindNeedTime(null, day, resolve(hit, now, day, partOfDay(s)).let { it.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli() })
        val at = resolve(hit, now, day, partOfDay(s))
        return Command.RemindAt(what, at.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(), fmt(at, now))
    }

    /** The follow-up after "What time?" / "What should I remind you about?". Returns null if the reply isn't an answer. */
    fun answer(raw: String, now: LocalDateTime, knownTask: String?, dayOffset: Int, knownAtMs: Long?): Command? {
        val s = raw.trim().replace(Regex("\\s+"), " ")
        if (s.isEmpty() || s.length > 80) return null
        val hit = findTime(s) ?: Regex("^(\\d{1,2})$").find(s)?.let { Hit(it.groupValues[1].toInt(), 0, null, 0, s.length) }?.takeIf { it.hour in 0..23 }
        val day = dayOffset(s) ?: dayOffset
        val what = knownTask ?: task(s, hit).ifEmpty { null }
        if (knownAtMs != null && what != null) {
            val at = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(knownAtMs), ZoneId.systemDefault())
            return Command.RemindAt(what, knownAtMs, fmt(at, now))
        }
        if (what == null && hit == null) return null
        if (hit == null) return Command.RemindNeedTime(what, day)
        val at = resolve(hit, now, day, partOfDay(s))
        if (what == null) return Command.RemindNeedTime(null, day, at.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli())
        return Command.RemindAt(what, at.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(), fmt(at, now))
    }
}
