package com.ghostie.pet

/**
 * Keeps the subject list clean: one list taken from the timetable and used for attendance, near-duplicates
 * ("Maths" / "Mathematics" / "Mathamatics") spotted so the student can merge them, and a way to remove a subject.
 * Pure Kotlin (tested on a computer). Nothing is merged without the student confirming.
 */
object SubjectTidy {
    private val aliases: Map<String, String> = mapOf(
        "math" to "math", "maths" to "math", "mathematics" to "math", "mathematic" to "math",
        "phy" to "physics", "physic" to "physics", "physics" to "physics",
        "chem" to "chemistry", "chemistry" to "chemistry", "bio" to "biology", "biology" to "biology",
        "eng" to "english", "english" to "english", "hindi" to "hindi",
        "dbms" to "dbms", "databasemanagementsystem" to "dbms", "databasemanagementsystems" to "dbms",
        "os" to "os", "operatingsystem" to "os", "operatingsystems" to "os",
        "cn" to "cn", "computernetwork" to "cn", "computernetworks" to "cn", "networks" to "cn",
        "oop" to "oop", "oops" to "oop", "objectorientedprogramming" to "oop",
        "ds" to "ds", "datastructure" to "ds", "datastructures" to "ds",
        "evs" to "evs", "environmentalscience" to "evs", "environmentalstudies" to "evs",
        "coa" to "coa", "computerorganization" to "coa", "computerorganisation" to "coa", "computerarchitecture" to "coa",
        "toc" to "toc", "theoryofcomputation" to "toc", "automatatheory" to "toc",
        "ml" to "ml", "machinelearning" to "ml", "ai" to "ai", "artificialintelligence" to "ai"
    )
    private val stop = setOf("and", "of", "the", "to", "in", "for", "a", "an")
    private val labWords = setOf("lab", "labs", "laboratory", "practical", "practicals", "prac", "workshop")
    private val tutWords = setOf("tutorial", "tutorials", "tut")
    private val skipWords = setOf("theory", "lecture", "lec", "class", "subject")
    private val romans = mapOf("i" to "1", "ii" to "2", "iii" to "3", "iv" to "4", "v" to "5", "vi" to "6")

    /** What decides whether two names are the same subject: the name core, lab/tutorial, and a number (Physics 1 vs 2). */
    private data class Sig(val core: String, val raw: String, val lab: Boolean, val tut: Boolean, val num: String)
    private val tokenAbbr = mapOf("comp" to "computer", "sci" to "science", "mgmt" to "management", "mech" to "mechanical", "elec" to "electrical", "prog" to "programming", "intro" to "introduction", "lang" to "language", "stats" to "statistics")

    private fun sig(name: String): Sig {
        val toks = name.lowercase().replace("&", " and ").replace(Regex("[^a-z0-9]+"), " ").trim().split(' ').filter { it.isNotEmpty() }
        var lab = false; var tut = false; var num = ""
        val kept = ArrayList<String>()
        for (t in toks) {
            when {
                t in labWords -> lab = true
                t in tutWords -> tut = true
                t in skipWords || t in stop -> {}
                t.all { it.isDigit() } -> num = t
                t in romans && kept.isNotEmpty() -> num = romans.getValue(t)
                else -> kept.add(tokenAbbr[t] ?: t)
            }
        }
        val raw = kept.joinToString("")
        var core = raw
        core = aliases[core] ?: core
        if (core.length > 5 && core.endsWith("s") && !core.endsWith("ss")) core = core.dropLast(1)
        core = aliases[core] ?: core
        return Sig(core, raw, lab, tut, num)
    }

    private fun distance(a: String, b: String): Int {
        if (a == b) return 0
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]; dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    /** True when the two names very likely mean the same subject. Lab vs theory and Physics 1 vs 2 are never the same. */
    fun similar(a: String, b: String): Boolean {
        if (a.trim().equals(b.trim(), true)) return true
        val x = sig(a); val y = sig(b)
        if (x.core.isEmpty() || y.core.isEmpty()) return false
        if (x.lab != y.lab || x.tut != y.tut || x.num != y.num) return false
        if (x.core == y.core) return true
        fun near(p: String, q: String): Boolean {
            val len = minOf(p.length, q.length)
            val allowed = when { len >= 12 -> 2; len >= 6 -> 1; else -> 0 }
            return allowed > 0 && distance(p, q) <= allowed
        }
        // a typo of the full word ("Mathamatics") or of the short form
        return near(x.core, y.core) || near(x.raw, y.raw) || near(x.raw, y.core) || near(x.core, y.raw)
    }

    /** Subjects from the timetable, one spelling each (case ignored), in the order they first appear in the week. */
    fun timetableSubjects(st: Student.State): List<String> {
        val out = ArrayList<String>()
        val keys = st.cells.keys.sortedWith(compareBy({ it.substringBefore(',').toIntOrNull() ?: 0 }, { it.substringAfter(',').toIntOrNull() ?: 0 }))
        for (k in keys) {
            val v = st.cells[k].orEmpty().trim()
            if (v.isNotEmpty() && out.none { it.equals(v, true) }) out.add(v)
        }
        return out
    }

    /** How many timetable boxes use this subject. */
    fun boxes(st: Student.State, subject: String) = st.cells.values.count { it.trim().equals(subject.trim(), true) }

    /** The list attendance shows: the timetable's subjects, plus any the student added by hand. One entry per subject. */
    fun attendanceSubjects(st: Student.State): List<String> {
        val out = ArrayList<String>(timetableSubjects(st))
        for (k in st.att.keys) { val t = k.trim(); if (t.isNotEmpty() && out.none { it.equals(t, true) }) out.add(t) }
        return out
    }

    /** Makes sure every timetable subject has an attendance record (0/0 if new). Returns how many were added. */
    fun syncAttendance(st: Student.State): Int {
        var n = 0
        for (s in timetableSubjects(st)) {
            val k = Student.key(st.att.keys, s)
            if (!st.att.containsKey(k)) { st.att[k] = intArrayOf(0, 0); n++ }
        }
        return n
    }

    class Group(val names: List<String>, val suggested: String)

    /** Groups of subjects that look like the same one, each with the spelling used most in the timetable as the suggestion. */
    fun duplicateGroups(st: Student.State): List<Group> {
        val names = attendanceSubjects(st)
        val parent = IntArray(names.size) { it }
        fun find(i: Int): Int { var r = i; while (parent[r] != r) r = parent[r]; return r }
        for (i in names.indices) for (j in i + 1 until names.size) if (similar(names[i], names[j])) parent[find(i)] = find(j)
        return names.indices.groupBy { find(it) }.values.filter { it.size > 1 }.map { idx ->
            val list = idx.map { names[it] }
            val best = list.maxWithOrNull(compareBy<String>({ boxes(st, it) }, { it.length })) ?: list.first()
            Group(list, best)
        }
    }

    /** Folds [from] into [to]: timetable boxes, attendance counts, required %, exams and flashcards all move over. */
    fun merge(st: Student.State, from: String, to: String) {
        if (from.equals(to, true)) return
        for (k in st.cells.keys.toList()) if (st.cells[k].orEmpty().trim().equals(from.trim(), true)) st.cells[k] = to
        val fk = st.att.keys.firstOrNull { it.equals(from.trim(), true) }
        if (fk != null) {
            val f = st.att.remove(fk)!!
            val tk = Student.key(st.att.keys, to)
            val t = st.att.getOrPut(tk) { intArrayOf(0, 0) }
            t[0] += f[0]; t[1] += f[1]
        }
        val rk = st.subjectReq.keys.firstOrNull { it.equals(from.trim(), true) }
        if (rk != null) { val v = st.subjectReq.remove(rk)!!; if (st.subjectReq.keys.none { it.equals(to, true) }) st.subjectReq[to] = v }
        st.exams = st.exams.map { if (it.subject.trim().equals(from.trim(), true)) it.copy(subject = to) else it }.toMutableList()
        st.cards = st.cards.map { if (it.subject.trim().equals(from.trim(), true)) it.copy(subject = to) else it }.toMutableList()
    }

    class Removed(val boxes: Int, val attended: Int, val total: Int)

    /** Removes a subject from the timetable and from attendance. Exams and flashcards are left alone. */
    fun remove(st: Student.State, subject: String): Removed {
        val keys = st.cells.entries.filter { it.value.trim().equals(subject.trim(), true) }.map { it.key }
        keys.forEach { st.cells.remove(it) }
        val fk = st.att.keys.firstOrNull { it.equals(subject.trim(), true) }
        val rec = fk?.let { st.att.remove(it) } ?: intArrayOf(0, 0)
        st.subjectReq.keys.filter { it.equals(subject.trim(), true) }.forEach { st.subjectReq.remove(it) }
        return Removed(keys.size, rec[0], rec[1])
    }
}
