package com.ghostie.pet

/** fallback = generic category (exams, labs): only used when no normal subject matches. */
data class Subject(val name: String, val keywords: List<String>, val fallback: Boolean = false)

/** Pure logic (no Android classes): decides which subject a file name belongs to. */
object SubjectMatcher {
    const val UNSORTED = "Unsorted"

    /** One subject per line:  Subject: keyword, keyword, ...   (editable in the app).
     *  Start a line with * to make it a fallback category. */
    val DEFAULT_SUBJECTS = """
Mathematics: maths, math, mathematics, calculus, algebra, trigonometry, differential, integration, matrix, matrices, probability, statistics, laplace, fourier, numerical, discrete, vectors
Physics: physics, optics, quantum, thermodynamics, laser, semiconductor, wave, relativity
Chemistry: chemistry, chem, organic, inorganic, polymer, spectroscopy, electrochemistry
Biology: biology, bio, botany, zoology, genetics, microbiology, biotech, biochemistry
Computer Science: cs, cse, programming, python, java, c++, cpp, dsa, algorithms, data structures, dbms, sql, os, operating system, computer networks, cn, oop, oops, software engineering, web, html, machine learning, ml, ai, compiler, toc, cloud, cyber security
Electronics: electronics, electrical, circuits, circuit, analog, digital, vlsi, microprocessor, embedded, signals, dsp, ece, eee, power systems, control systems, networks theory
Mechanical: mechanical, thermal, fluid, manufacturing, cad, machine design, heat transfer, engineering drawing, workshop
Civil: civil, structural, surveying, concrete, geotechnical, hydraulics, construction
English: english, communication skills, grammar, literature, essay, technical writing, soft skills
Economics & Management: economics, management, accounts, accounting, finance, marketing, business, entrepreneurship, hr, ethics
*Exams & Timetable: timetable, time table, schedule, syllabus, exam, question paper, previous year, pyq, qp, results, hall ticket, admit card, notice, circular, calendar
*Assignments & Labs: assignment, lab, record, practical, experiment, manual, report, project, worksheet
""".trimIndent()

    /** Lowercases, splits camelCase and punctuation, pads with spaces so whole words match. */
    private fun norm(s: String): String {
        val spaced = s.replace(Regex("([a-z])([A-Z])"), "\$1 \$2").lowercase()
        return " " + spaced.replace(Regex("[^a-z0-9+#]+"), " ").trim() + " "
    }

    fun parse(text: String): List<Subject> = text.lines().mapNotNull { line ->
        val i = line.indexOf(':')
        if (i <= 0) return@mapNotNull null
        var name = line.substring(0, i).trim()
        val fallback = name.startsWith("*")
        if (fallback) name = name.removePrefix("*").trim()
        if (name.isEmpty()) return@mapNotNull null
        val kws = line.substring(i + 1).split(',').map { it.trim() }.filter { it.isNotEmpty() }
        Subject(name, kws, fallback)
    }

    /** Most matching keywords wins (ties go to the earlier line). Fallback categories only apply if no normal subject matched. */
    fun classify(fileName: String, subjects: List<Subject>): String {
        val base = fileName.substringBeforeLast('.', fileName)
        val padded = norm(base)
        fun best(list: List<Subject>): Pair<String, Int> {
            var name = UNSORTED
            var top = 0
            for (s in list) {
                val keys = (s.keywords + s.name).map { norm(it) }.filter { it.isNotBlank() }.distinct()
                val score = keys.count { padded.contains(it) }
                if (score > top) {
                    top = score
                    name = s.name
                }
            }
            return name to top
        }
        val main = best(subjects.filter { !it.fallback })
        if (main.second > 0) return main.first
        return best(subjects.filter { it.fallback }).first
    }
}
