package com.ghostie.pet

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews

/** Home-screen widget: the next three deadlines, each with ✅ Done and 🗑 Never buttons (widgets can't be dragged). */
class GhostieWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, build(ctx))
    }

    companion object {
        fun refresh(ctx: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, GhostieWidget::class.java))
                for (id in ids) mgr.updateAppWidget(id, build(ctx))
            } catch (e: Exception) { }
        }

        private fun act(ctx: Context, action: String, eventId: Long, slot: Int) = PendingIntent.getBroadcast(
            ctx, 700000 + (eventId % 10000).toInt() * 10 + slot,
            Intent(ctx, ReminderReceiver::class.java).setAction(action).putExtra("id", eventId),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        fun build(ctx: Context): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_ghostie)
            val open = PendingIntent.getActivity(ctx, 5, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            rv.setOnClickPendingIntent(R.id.widget_root, open)
            val items = ReminderLog.upcoming(SettingsStore(ctx).logs()).take(3)
            val rows = listOf(Triple(R.id.row1, R.id.text1, 1), Triple(R.id.row2, R.id.text2, 2), Triple(R.id.row3, R.id.text3, 3))
            val dones = listOf(R.id.done1, R.id.done2, R.id.done3)
            val bins = listOf(R.id.bin1, R.id.bin2, R.id.bin3)
            rv.setViewVisibility(R.id.empty, if (items.isEmpty()) View.VISIBLE else View.GONE)
            for ((i, r) in rows.withIndex()) {
                val e = items.getOrNull(i)
                if (e == null) { rv.setViewVisibility(r.first, View.GONE); continue }
                rv.setViewVisibility(r.first, View.VISIBLE)
                rv.setTextViewText(r.second, ReminderLog.label(e) + "\n" + ReminderLog.dueLabel(e))
                rv.setOnClickPendingIntent(dones[i], act(ctx, ReminderAlarms.DONE, e.eventId, 1))
                rv.setOnClickPendingIntent(bins[i], act(ctx, ReminderAlarms.TRASH, e.eventId, 2))
            }
            return rv
        }
    }
}
