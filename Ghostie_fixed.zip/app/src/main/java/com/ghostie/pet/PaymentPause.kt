package com.ghostie.pet

import android.content.Context
import android.provider.Settings

/**
 * Payment apps such as Paytm and BharatPe refuse to work while another app has Accessibility switched on.
 * Android lets an accessibility service switch ITSELF off but never back on, so this only does the first half:
 * [pause] turns Ghostie's screen readers off, and the user switches them on again in Accessibility settings when they want them.
 */
object PaymentPause {
    /** Switches off Ghostie's accessibility services that are running. Returns how many were switched off. */
    fun pause(): Int {
        var n = 0
        ChatScreenService.instance?.let { try { it.disableSelf(); n++ } catch (e: Exception) { } }
        FoodScanService.instance?.let { try { it.disableSelf(); n++ } catch (e: Exception) { } }
        return n
    }

    /** True while one of Ghostie's accessibility services is switched on in Android settings. */
    fun isOn(ctx: Context): Boolean {
        val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.startsWith(ctx.packageName + "/") }
    }

    const val AFTER = "To turn Ghostie's reading back on later: phone Settings > Accessibility > Installed apps > Ghostie chat reader (or say \"turn screen reading on\" and I'll open that screen)."
}
