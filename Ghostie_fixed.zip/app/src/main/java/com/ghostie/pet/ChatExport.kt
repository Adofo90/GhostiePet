package com.ghostie.pet

import java.time.DateTimeException
import java.time.LocalDate

data class ChatMsg(val date: LocalDate, val sender: String, val text: String)

/** Pure logic: reads a WhatsApp "Export chat" text file into messages (Android and iPhone formats). */
object ChatExport {
    private val androidLine = Regex(
        "^(\\d{1,2})[/.\\-](\\d{1,2})[/.\\-](\\d{2,4}),?\\s+\\d{1,2}[:.]\\d{2}(?::\\d{2})?\\s*(?:[ap]\\.?m\\.?)?\\s*[-–]\\s+(.*)$",
        RegexOption.IGNORE_CASE
    )
    private val iosLine = Regex("^\\[(\\d{1,2})[/.\\-](\\d{1,2})[/.\\-](\\d{2,4}),?\\s+[^\\]]*\\]\\s+(.*)$")

    private class Header(val a: Int, val b: Int, val y: Int, val rest: String)

    fun parse(raw: String): List<ChatMsg> {
        val clean = raw.replace(Regex("[‎‏﻿]"), "").replace(Regex("[  ]"), " ")
        val lines = clean.lines()

        fun header(line: String): Header? {
            val m = androidLine.find(line) ?: iosLine.find(line) ?: return null
            return Header(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt(), m.groupValues[4])
        }

        val headers = lines.mapNotNull { header(it) }
        // 30/10/26 -> day first (India/UK). If a number above 12 shows up in the second slot it is month first (US).
        val dayFirst = when {
            headers.any { it.a > 12 } -> true
            headers.any { it.b > 12 } -> false
            else -> true
        }

        val out = mutableListOf<ChatMsg>()
        var curDate: LocalDate? = null
        var curSender = ""
        var cur: StringBuilder? = null
        fun flush() {
            val d = curDate
            val c = cur
            if (d != null && c != null && c.isNotBlank()) out.add(ChatMsg(d, curSender, c.toString().trim()))
            curDate = null
            cur = null
        }

        for (line in lines) {
            val h = header(line)
            if (h != null) {
                flush()
                val year = if (h.y < 100) 2000 + h.y else h.y
                val date = try {
                    if (dayFirst) LocalDate.of(year, h.b, h.a) else LocalDate.of(year, h.a, h.b)
                } catch (e: DateTimeException) {
                    null
                }
                val idx = h.rest.indexOf(": ")
                if (date != null && idx > 0) { // lines without "Sender: " are system notices
                    curDate = date
                    curSender = h.rest.substring(0, idx)
                    cur = StringBuilder(h.rest.substring(idx + 2))
                }
            } else {
                cur?.append('\n')?.append(line)
            }
        }
        flush()
        return out
    }
}
