package com.ghostie.pet

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast

/**
 * Fallback listener: opens the phone's own speech dialog (no microphone permission needed for Ghostie itself),
 * then hands the sentence to the ghost. Used when in-app listening isn't allowed or available.
 */
class VoiceActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, SettingsStore(this).speechTag)
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Talk to Ghostie 👻")
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(i, 1)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "No speech recognition app found on this phone", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (resultCode == RESULT_OK && !text.isNullOrBlank()) {
            startService(Intent(this, PetOverlayService::class.java).setAction(PetOverlayService.ACTION_VOICE).putExtra("text", text))
        }
        finish()
    }
}
