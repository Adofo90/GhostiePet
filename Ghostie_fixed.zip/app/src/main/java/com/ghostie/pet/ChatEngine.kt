package com.ghostie.pet

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object ChatEngine {
    private const val FALLBACK = "I couldn't reach AI mode right now. I'm still here 💜"

    private val basic = listOf(
        Regex("\\b(hi|hello|hey)\\b", RegexOption.IGNORE_CASE) to "Hi! I'm here with you 💜",
        Regex("nice to meet", RegexOption.IGNORE_CASE) to "Nice to meet you too! I'll keep you company.",
        Regex("how are you", RegexOption.IGNORE_CASE) to "I'm happy to be here. How are you doing?",
        Regex("tired|sleepy", RegexOption.IGNORE_CASE) to "A tiny break might help. Stretch a little and breathe.",
        Regex("water|thirst", RegexOption.IGNORE_CASE) to "Water check! A few sips would be lovely 💧",
        Regex("stressed|stress", RegexOption.IGNORE_CASE) to "Take one slow breath with me. You don't have to rush.",
        Regex("break|stretch", RegexOption.IGNORE_CASE) to "Good idea. Stand up, stretch, then come back when you're ready."
    )

    fun offline(text: String): String =
        basic.firstOrNull { it.first.containsMatchIn(text) }?.second
            ?: "I'm listening 💜 Tell me what's on your mind. (Say \"help\" to see what I can do.)"

    /** history = list of (role, message) where role is "user" or "assistant". */
    suspend fun openAi(key: String, history: List<Pair<String, String>>, text: String): String =
        withContext(Dispatchers.IO) {
            try {
                val input = JSONArray()
                history.takeLast(8).forEach { (role, msg) ->
                    input.put(JSONObject().put("role", role).put("content", msg))
                }
                input.put(JSONObject().put("role", "user").put("content", text))
                val body = JSONObject()
                    .put("model", "gpt-4.1-mini")
                    .put("instructions", Personality.TEXT)
                    .put("input", input)

                val conn = URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 15_000
                conn.readTimeout = 30_000
                conn.setRequestProperty("Authorization", "Bearer $key")
                conn.setRequestProperty("Content-Type", "application/json")
                conn.doOutput = true
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

                val ok = conn.responseCode in 200..299
                val raw = (if (ok) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() }.orEmpty()
                conn.disconnect()
                if (!ok) return@withContext FALLBACK

                extractText(JSONObject(raw)).ifBlank { "I'm here with you 💜" }
            } catch (e: Exception) {
                FALLBACK
            }
        }

    /** The REST API has no top-level "output_text"; the text lives in output[].content[]. */
    private fun extractText(root: JSONObject): String {
        root.optString("output_text").takeIf { it.isNotBlank() }?.let { return it }
        val sb = StringBuilder()
        val output = root.optJSONArray("output") ?: return ""
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            if (item.optString("type") != "message") continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val part = content.optJSONObject(j) ?: continue
                if (part.optString("type") == "output_text") sb.append(part.optString("text"))
            }
        }
        return sb.toString().trim()
    }
}
