package com.ghostie.pet

import android.content.Context

/** Pure logic for the trip pack list: built-in usual items plus the person's own, minus anything they removed. */
object TripPack {
    class Item(val category: String, val name: String, val custom: Boolean)

    val defaults: List<Pair<String, String>> = listOf(
        "Documents & money" to "ID card / Aadhaar", "Documents & money" to "College ID", "Documents & money" to "Tickets (train / bus / flight)",
        "Documents & money" to "Hotel or stay booking", "Documents & money" to "Wallet", "Documents & money" to "Cash", "Documents & money" to "Debit / credit card",
        "Clothes" to "T-shirts / shirts", "Clothes" to "Jeans / pants", "Clothes" to "Underwear", "Clothes" to "Socks", "Clothes" to "Nightwear",
        "Clothes" to "Jacket / hoodie", "Clothes" to "Shoes", "Clothes" to "Slippers", "Clothes" to "Cap / sunglasses", "Clothes" to "Raincoat / umbrella",
        "Toiletries" to "Toothbrush", "Toiletries" to "Toothpaste", "Toiletries" to "Soap / face wash", "Toiletries" to "Shampoo", "Toiletries" to "Comb",
        "Toiletries" to "Deodorant", "Toiletries" to "Hand sanitiser", "Toiletries" to "Sunscreen", "Toiletries" to "Towel",
        "Electronics" to "Phone", "Electronics" to "Phone charger", "Electronics" to "Power bank", "Electronics" to "Earphones",
        "Electronics" to "Laptop and charger", "Electronics" to "Camera",
        "Health" to "Medicines", "Health" to "First-aid kit", "Health" to "Water bottle", "Health" to "Masks", "Health" to "Glasses / lenses",
        "Study" to "Notebook and pens", "Study" to "Books / notes", "Study" to "Pen drive",
        "Other" to "Backpack", "Other" to "Padlock", "Other" to "Snacks", "Other" to "Tissues"
    )

    val categories: List<String> = defaults.map { it.first }.distinct()

    private fun same(a: String, b: String) = a.trim().equals(b.trim(), ignoreCase = true)

    /** The list shown to the person, in category order. */
    fun items(custom: List<Pair<String, String>>, removed: Set<String>): List<Item> {
        val out = ArrayList<Item>()
        for ((c, n) in defaults) if (removed.none { same(it, n) }) out.add(Item(c, n, false))
        for ((c, n) in custom) if (out.none { same(it.name, n) }) out.add(Item(c, n.trim(), true))
        val order = categories + custom.map { it.first }.distinct().filter { it !in categories }
        return out.sortedBy { order.indexOf(it.category) }
    }

    fun parseCustom(text: String): List<Pair<String, String>> = text.lines().mapNotNull {
        val p = it.split('\t', limit = 2)
        if (p.size == 2 && p[1].isNotBlank()) p[0] to p[1] else null
    }

    fun serializeCustom(list: List<Pair<String, String>>): String = list.joinToString("\n") { it.first + "\t" + it.second }

    fun parseSet(text: String): Set<String> = text.lines().map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    fun progress(items: List<Item>, packed: Set<String>): Pair<Int, Int> = items.count { i -> packed.any { same(it, i.name) } } to items.size

    // ---- how many of each thing, from the trip length ----
    private val scaling = mapOf(
        "T-shirts / shirts" to "shirts", "Underwear" to "under", "Socks" to "under", "Jeans / pants" to "pants",
        "Nightwear" to "night", "Masks" to "masks"
    )

    /** True when the number of this item depends on how long the trip is. */
    fun scales(name: String) = scaling.keys.any { same(it, name) }

    /** How many to pack for a trip of [days] days (0 = length not given). Fewer per day on long trips, since clothes get washed. */
    fun autoQty(name: String, days: Int): Int {
        val kind = scaling.entries.firstOrNull { same(it.key, name) }?.value ?: return 1
        if (days <= 0) return 1
        val d = if (days <= 7) days else 7 + (days - 7) / 3
        return when (kind) {
            "shirts" -> d
            "under" -> d + 1
            "pants" -> (d + 2) / 3
            "night" -> (d + 3) / 4
            "masks" -> d.coerceAtLeast(2)
            else -> 1
        }.coerceAtLeast(1)
    }

    fun number(w: String): Int? = w.toIntOrNull() ?: mapOf("a" to 1, "an" to 1, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7,
        "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11, "twelve" to 12, "fourteen" to 14).get(w.lowercase())

    /** "I'm going for 5 days", "trip for 3 nights", "weekend trip", "2 week trip": the trip length in days, or null. */
    fun parseTripDays(text: String): Int? {
        val t = text.trim().trimEnd('.', '!').lowercase()
        val num = "(\\d+|a|an|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fourteen)"
        val unit = "(day|night|week)s?"
        fun days(n: String, u: String): Int? {
            val k = number(n) ?: return null
            val d = when (u) { "week" -> k * 7; "night" -> k + 1; else -> k }
            return d.takeIf { it in 1..120 }
        }
        Regex("^(?:i'?m|i am|we'?re|we are)\\s+(?:going|travelling|traveling|leaving|off)(?:\\s+(?:on a trip|away|out|to \\w+(?: \\w+)?))?\\s+for\\s+$num[ -]?$unit$").find(t)?.let { return days(it.groupValues[1], it.groupValues[2]) }
        Regex("^(?:trip|pack|packing|travel|pack list|trip list)(?: list)?\\s+for\\s+$num[ -]?$unit$").find(t)?.let { return days(it.groupValues[1], it.groupValues[2]) }
        Regex("^(?:a |an |my )?$num[ -]$unit(?: long)? trip$").find(t)?.let { return days(it.groupValues[1], it.groupValues[2]) }
        Regex("^(?:i have |i'?m taking |planning )?(?:a |an )?trip (?:of|for) $num[ -]?$unit$").find(t)?.let { return days(it.groupValues[1], it.groupValues[2]) }
        if (Regex("^(?:a |my )?weekend (?:trip|getaway)$|^i'?m going (?:away )?for the weekend$").matches(t)) return 2
        return null
    }

    fun isPacked(packed: Set<String>, name: String) = packed.any { same(it, name) }
}

/** Saves the list on the phone. Tick state, own items, removed built-ins. */
object TripStore {
    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences("ghostie_trip", Context.MODE_PRIVATE)

    fun packed(ctx: Context): Set<String> = TripPack.parseSet(p(ctx).getString("packed", "") ?: "")
    fun removed(ctx: Context): Set<String> = TripPack.parseSet(p(ctx).getString("removed", "") ?: "")
    fun custom(ctx: Context): List<Pair<String, String>> = TripPack.parseCustom(p(ctx).getString("custom", "") ?: "")
    fun items(ctx: Context): List<TripPack.Item> = TripPack.items(custom(ctx), removed(ctx))

    fun setPacked(ctx: Context, name: String, on: Boolean) {
        val cur = packed(ctx).filterNot { it.equals(name, true) }.toMutableList()
        if (on) cur.add(name)
        p(ctx).edit().putString("packed", cur.joinToString("\n")).apply()
    }

    /** Adds the person's own item (ignored if it is already on the list). Returns false for a duplicate or empty name. */
    fun add(ctx: Context, category: String, name: String): Boolean {
        val n = name.trim().take(40)
        if (n.isEmpty() || items(ctx).any { it.name.equals(n, true) }) return false
        val list = custom(ctx) + (category to n)
        p(ctx).edit().putString("custom", TripPack.serializeCustom(list)).apply()
        return true
    }

    /** Removes an item: own items are deleted, built-in items are hidden. */
    fun remove(ctx: Context, item: TripPack.Item) {
        if (item.custom) p(ctx).edit().putString("custom", TripPack.serializeCustom(custom(ctx).filterNot { it.second.equals(item.name, true) })).apply()
        else p(ctx).edit().putString("removed", (removed(ctx) + item.name).joinToString("\n")).apply()
        setPacked(ctx, item.name, false)
    }

    fun days(ctx: Context): Int = p(ctx).getInt("days", 0)
    private fun overrides(ctx: Context): Map<String, Int> = (p(ctx).getString("qty", "") ?: "").lines().mapNotNull {
        val x = it.split('\t', limit = 2); val n = x.getOrNull(1)?.toIntOrNull(); if (x.size == 2 && n != null) x[0] to n else null
    }.toMap()

    /** The number to pack: the person's own number if they set one, else worked out from the trip length. */
    fun qty(ctx: Context, name: String): Int = overrides(ctx).entries.firstOrNull { it.key.equals(name, true) }?.value ?: TripPack.autoQty(name, days(ctx))
    fun hasOverride(ctx: Context, name: String) = overrides(ctx).keys.any { it.equals(name, true) }
    /** Whether a number is worth showing for this item. */
    fun showsQty(ctx: Context, name: String) = TripPack.scales(name) && days(ctx) > 0 || hasOverride(ctx, name)

    fun setQty(ctx: Context, name: String, n: Int) {
        val m = overrides(ctx).filterKeys { !it.equals(name, true) }.toMutableMap()
        m[name] = n.coerceIn(1, 99)
        p(ctx).edit().putString("qty", m.entries.joinToString("\n") { it.key + "\t" + it.value }).apply()
    }

    /** Sets the trip length (0 clears it). The numbers the person typed in themselves are dropped so everything follows the new length. */
    fun setDays(ctx: Context, days: Int) { p(ctx).edit().putInt("days", days.coerceIn(0, 120)).remove("qty").apply() }

    /** New trip: untick everything, keep the list as it is. */
    fun newTrip(ctx: Context) { p(ctx).edit().remove("packed").remove("days").remove("qty").apply() }

    /** Back to the built-in list only: removes own items, restores removed items, unticks all. */
    fun reset(ctx: Context) { p(ctx).edit().clear().apply() }

    fun summary(ctx: Context): String {
        val items = items(ctx)
        val packed = packed(ctx)
        val (done, total) = TripPack.progress(items, packed)
        val left = items.filter { !TripPack.isPacked(packed, it.name) }
        fun nm(i: TripPack.Item) = if (showsQty(ctx, i.name)) "${i.name} x${qty(ctx, i.name)}" else i.name
        val d = days(ctx)
        val head = if (d > 0) "🧳 Trip: $d day${if (d == 1) "" else "s"}. " else "🧳 "
        return if (left.isEmpty()) head + "Everything is packed ($total of $total)!"
        else head + "$done of $total packed. Still to pack:\n" + left.groupBy { it.category }.entries.joinToString("\n") { "• ${it.key}: " + it.value.joinToString(", ") { i -> nm(i) } }
    }
}
