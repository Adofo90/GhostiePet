package com.ghostie.pet

import android.content.Context

/** Pure logic for the trip pack list: built-in usual items plus the person's own, minus anything they removed. */
object TripPack {
    class Item(val category: String, val name: String, val custom: Boolean)

    val defaults: List<Pair<String, String>> = listOf(
        "Documents & money" to "ID card / Aadhaar", "Documents & money" to "College ID", "Documents & money" to "Tickets (train / bus / flight)",
        "Documents & money" to "Hotel or stay booking", "Documents & money" to "Wallet", "Documents & money" to "Cash", "Documents & money" to "Debit / credit card",
        "Clothes" to "T-shirts / shirts", "Clothes" to "Jeans / pants", "Clothes" to "Underwear", "Clothes" to "Socks", "Clothes" to "Nightwear",
        "Clothes" to "Jacket / hoodie", "Clothes" to "Shoes", "Clothes" to "Slippers", "Clothes" to "Cap / sunglasses", "Clothes" to "Raincoat / umbrella",
        "Toiletries" to "Toothbrush", "Toiletries" to "Toothpaste", "Toiletries" to "Soap / face wash", "Toiletries" to "Shampoo", "Toiletries" to "Comb",
        "Toiletries" to "Deodorant", "Toiletries" to "Hand sanitiser", "Toiletries" to "Sunscreen", "Toiletries" to "Towel",
        "Electronics" to "Phone", "Electronics" to "Phone charger", "Electronics" to "Power bank", "Electronics" to "Earphones",
        "Electronics" to "Laptop and charger", "Electronics" to "Camera",
        "Health" to "Medicines", "Health" to "First-aid kit", "Health" to "Water bottle", "Health" to "Masks", "Health" to "Glasses / lenses",
        "Study" to "Notebook and pens", "Study" to "Books / notes", "Study" to "Pen drive",
        "Other" to "Backpack", "Other" to "Padlock", "Other" to "Snacks", "Other" to "Tissues"
    )

    val categories: List<String> = defaults.map { it.first }.distinct()

    private fun same(a: String, b: String) = a.trim().equals(b.trim(), ignoreCase = true)

    /** The list shown to the person, in category order. */
    fun items(custom: List<Pair<String, String>>, removed: Set<String>): List<Item> {
        val out = ArrayList<Item>()
        for ((c, n) in defaults) if (removed.none { same(it, n) }) out.add(Item(c, n, false))
        for ((c, n) in custom) if (out.none { same(it.name, n) }) out.add(Item(c, n.trim(), true))
        val order = categories + custom.map { it.first }.distinct().filter { it !in categories }
        return out.sortedBy { order.indexOf(it.category) }
    }

    fun parseCustom(text: String): List<Pair<String, String>> = text.lines().mapNotNull {
        val p = it.split('\t', limit = 2)
        if (p.size == 2 && p[1].isNotBlank()) p[0] to p[1] else null
    }

    fun serializeCustom(list: List<Pair<String, String>>): String = list.joinToString("\n") { it.first + "\t" + it.second }

    fun parseSet(text: String): Set<String> = text.lines().map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    fun progress(items: List<Item>, packed: Set<String>): Pair<Int, Int> = items.count { i -> packed.any { same(it, i.name) } } to items.size

    fun isPacked(packed: Set<String>, name: String) = packed.any { same(it, name) }
}

/** Saves the list on the phone. Tick state, own items, removed built-ins. */
object TripStore {
    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences("ghostie_trip", Context.MODE_PRIVATE)

    fun packed(ctx: Context): Set<String> = TripPack.parseSet(p(ctx).getString("packed", "") ?: "")
    fun removed(ctx: Context): Set<String> = TripPack.parseSet(p(ctx).getString("removed", "") ?: "")
    fun custom(ctx: Context): List<Pair<String, String>> = TripPack.parseCustom(p(ctx).getString("custom", "") ?: "")
    fun items(ctx: Context): List<TripPack.Item> = TripPack.items(custom(ctx), removed(ctx))

    fun setPacked(ctx: Context, name: String, on: Boolean) {
        val cur = packed(ctx).filterNot { it.equals(name, true) }.toMutableList()
        if (on) cur.add(name)
        p(ctx).edit().putString("packed", cur.joinToString("\n")).apply()
    }

    /** Adds the person's own item (ignored if it is already on the list). Returns false for a duplicate or empty name. */
    fun add(ctx: Context, category: String, name: String): Boolean {
        val n = name.trim().take(40)
        if (n.isEmpty() || items(ctx).any { it.name.equals(n, true) }) return false
        val list = custom(ctx) + (category to n)
        p(ctx).edit().putString("custom", TripPack.serializeCustom(list)).apply()
        return true
    }

    /** Removes an item: own items are deleted, built-in items are hidden. */
    fun remove(ctx: Context, item: TripPack.Item) {
        if (item.custom) p(ctx).edit().putString("custom", TripPack.serializeCustom(custom(ctx).filterNot { it.second.equals(item.name, true) })).apply()
        else p(ctx).edit().putString("removed", (removed(ctx) + item.name).joinToString("\n")).apply()
        setPacked(ctx, item.name, false)
    }

    /** New trip: untick everything, keep the list as it is. */
    fun newTrip(ctx: Context) { p(ctx).edit().remove("packed").apply() }

    /** Back to the built-in list only: removes own items, restores removed items, unticks all. */
    fun reset(ctx: Context) { p(ctx).edit().clear().apply() }

    fun summary(ctx: Context): String {
        val items = items(ctx)
        val packed = packed(ctx)
        val (done, total) = TripPack.progress(items, packed)
        val left = items.filter { !TripPack.isPacked(packed, it.name) }
        return if (left.isEmpty()) "🧳 Everything is packed ($total of $total)!"
        else "🧳 $done of $total packed. Still to pack:\n" + left.groupBy { it.category }.entries.joinToString("\n") { "• ${it.key}: " + it.value.joinToString(", ") { i -> i.name } }
    }
}
