package com.ghostie.pet

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

/** Ways to look at the timetable and the bunk calculator: any day, the week, the next class, a whole day's bunk check, all subjects at once. Pure Kotlin (JVM tested). */
object ClassInfo {
    private val dayWord = "monday|tuesday|wednesday|thursday|friday|saturday|sunday|mon|tues|tue|wed|thurs|thur|thu|fri|sat|sun"
    private val thing = "(?:classes|class|timetable|time table|schedule|lectures?|periods|lessons)"
    private val whenW = "(today|todays|tomorrow|tmrw|tomorow|tommorow|yesterday|$dayWord|this week|the week|next week|week|weekly)"
    private val I = RegexOption.IGNORE_CASE

    /** Turns a day word into "today" / "tomorrow" / "yesterday" / "mon".."sun" / "week". */
    fun normWhen(w: String): String {
        val x = w.lowercase().trim().removeSuffix("'s")
        return when {
            x == "today" || x == "todays" -> "today"
            x == "tomorrow" || x == "tmrw" || x == "tomorow" || x == "tommorow" -> "tomorrow"
            x == "yesterday" -> "yesterday"
            x.contains("week") -> "week"
            else -> x.take(3)
        }
    }

    /** "what is today's timetable", "classes tomorrow", "my timetable", "do I have class on friday", "show this week"... -> a day word, or null. */
    fun classQuery(raw: String): String? {
        val l = raw.lowercase().replace("what's", "what is").replace("whats", "what is").replace(Regex("[?!.]+$"), "").replace(Regex("\\s+"), " ").trim()
        if (l.isEmpty()) return null
        val lead = "(?:(?:what|which|show|tell|check|see|view|open|give|list|display|get)\\s*(?:me\\s*)?(?:is|are|do i have|have i got)?\\s*)?"
        Regex("^$lead(?:the |my |our )*$whenW(?:'s|s)?\\s+$thing(?:\\s+(?:please|pls))?$", I).find(l)?.let { return normWhen(it.groupValues[1]) }
        Regex("^$lead(?:the |my |our )*$thing(?:\\s+(?:do i have|are there|have i got|is there))?\\s*(?:for |on |this |is )?$whenW(?:\\s+(?:please|pls))?$", I).find(l)?.let { return normWhen(it.groupValues[1]) }
        Regex("^(?:do i have|is there|are there|have i got)\\s+(?:any\\s+)?(?:college|class|classes|lectures?|school|clg)\\s*(?:on |for )?$whenW$", I).find(l)?.let { return normWhen(it.groupValues[1]) }
        Regex("^(?:what|which)\\s+(?:classes|lectures|periods|subjects)\\s+(?:do i have|are there|have i got|are)\\s*(?:on |for )?$whenW$", I).find(l)?.let { return normWhen(it.groupValues[1]) }
        if (Regex("^$lead(?:the |my |our |today )*$thing(?:\\s+(?:do i have|are there|have i got))?(?:\\s+today)?(?:\\s+(?:please|pls))?$", I).matches(l)) return "today"
        return null
    }

    fun isNextClassQuery(raw: String): Boolean {
        val l = raw.lowercase().replace("what's", "what is").replace(Regex("[?!.]+$"), "").replace(Regex("\\s+"), " ").trim()
        return Regex("^(?:what|which)?\\s*(?:is )?(?:my |the )?next (?:class|lecture|period)(?: is)?(?: today)?$|^when is (?:my |the )?next (?:class|lecture|period)$|^what (?:class|lecture|period) (?:is it |do i have )?(?:now|right now|next)$|^which (?:class|lecture) (?:is|do i have) (?:now|next)$|^(?:current|ongoing) (?:class|lecture)$|^what is (?:going on|happening) in (?:class|college)$", I).matches(l)
    }

    /** "can I bunk today", "is it safe to skip tomorrow", "can I skip college on friday" -> day word, else null. */
    fun bunkDayQuery(raw: String): String? {
        val l = raw.lowercase().replace(Regex("[?!.]+$"), "").replace(Regex("\\s+"), " ").trim()
        Regex("^(?:can|may|should|could|shall) i (?:bunk|skip|miss|cut|ditch|leave|take (?:a )?(?:leave|off))\\s*(?:the |all )?(?:classes |college |class |lectures |clg |school )?(?:on |for )?$whenW(?:'s)?(?:\\s+(?:classes|class|college|lectures|clg|school))?$", I).find(l)?.let { return normWhen(it.groupValues[1]) }
        Regex("^(?:is it|am i|would it be)\\s+(?:safe|ok|okay|fine|alright)\\s+to\\s+(?:bunk|skip|miss|cut)\\s*(?:the |all )?(?:classes |college |class )?(?:on |for )?$whenW?$", I).find(l)?.let { return normWhen(it.groupValues[1].ifEmpty { "today" }) }
        Regex("^(?:bunk|skip)\\s+(?:check|safety|status)\\s+(?:for\\s+)?$whenW$", I).find(l)?.let { return normWhen(it.groupValues[1]) }
        return null
    }

    /** "which subjects can I bunk", "bunk status", "how many can I bunk", "am I safe"... */
    fun isBunkOverview(raw: String): Boolean {
        val l = raw.lowercase().replace(Regex("[?!.]+$"), "").replace(Regex("\\s+"), " ").trim()
        return Regex("^(?:which|what)\\s+(?:subjects?|classes|lectures|class)?\\s*(?:can|could) i (?:safely )?(?:bunk|skip|miss)(?: safely| now)?$|^(?:bunk|skip)\\s+(?:status|list|summary|overview|calculator|safety|chart)$|^(?:how (?:many|much))\\s+(?:classes |lectures )?(?:can|could) i (?:bunk|skip|miss)(?: in (?:each|every|all)(?: subjects?)?)?$|^(?:who|where|what|when) can i (?:bunk|skip)$|^(?:my )?bunk(?:s)?$|^(?:am i|is my attendance)\\s+(?:safe|ok|okay|fine)$|^(?:bunk|skip)\\s+(?:all|everything)$|^where (?:can|could) i (?:bunk|skip)$|^(?:show|check|see)\\s+(?:my )?bunk(?:s| status| list| calculator)?$", I).matches(l)
    }

    fun isLowAttendance(raw: String): Boolean {
        val l = raw.lowercase().replace(Regex("[?!.]+$"), "").replace(Regex("\\s+"), " ").trim()
        return Regex("^(?:am i|do i have)\\s+(?:short|low)(?: on| in| of)?\\s*(?:attendance)?$|^(?:which|what)\\s+(?:subjects?|classes)\\s+(?:have|has|are|is)\\s+(?:low|short|below|at risk|in danger)(?:\\s+attendance)?(?: in attendance)?$|^(?:low|short|risky|danger)\\s+attendance$|^(?:attendance|subjects?)\\s+(?:at risk|in danger|shortage|alert|warning)$|^(?:where|which) (?:is|are) my attendance (?:low|short)$|^(?:show|check|see)\\s+(?:my\\s+)?(?:low|short)\\s+attendance$", I).matches(l)
    }

    // ------------------------- answers -------------------------

    fun resolve(spec: String, today: LocalDate): LocalDate? = when (spec) {
        "today" -> today
        "tomorrow" -> today.plusDays(1)
        "yesterday" -> today.minusDays(1)
        "week" -> null
        else -> {
            val target = listOf("mon", "tue", "wed", "thu", "fri", "sat", "sun").indexOf(spec)
            if (target < 0) today else today.plusDays(((target - (today.dayOfWeek.value - 1) + 7) % 7).toLong())
        }
    }

    private fun title(d: LocalDate, today: LocalDate): String {
        val name = d.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH) + " " + d.format(DateTimeFormatter.ofPattern("d MMM", Locale.ENGLISH))
        return when (d) { today -> "Today, $name"; today.plusDays(1) -> "Tomorrow, $name"; today.minusDays(1) -> "Yesterday, $name"; else -> name }
    }

    private fun none(d: LocalDate, today: LocalDate): String = when {
        d.dayOfWeek == DayOfWeek.SUNDAY -> "No classes on Sunday 🎉"
        d.dayOfWeek == DayOfWeek.SATURDAY -> "No classes that Saturday 🎉 (not a working Saturday for you, or nothing filled in)"
        else -> "No classes in your timetable for that day. Fill it in on the More tab 🗓️"
    }

    fun dayText(st: Student.State, d: LocalDate, today: LocalDate): String {
        val l = Student.classesOn(st, d).sortedBy { Student.parseTime(it.second.start) ?: java.time.LocalTime.MIN }
        val gone = Student.cancelledOn(st, d)
        val changed = st.changes[d.toString()].orEmpty().isNotEmpty()
        val goneText = if (gone.isEmpty()) "" else "\n❌ Cancelled: " + gone.joinToString(", ") { "${it.second} (${it.first.start})" }
        return if (l.isEmpty()) title(d, today) + "\n" + (if (gone.isNotEmpty()) "No classes left that day 🎉" else none(d, today)) + goneText
        else title(d, today) + " 🗓️" + (if (changed) " (changed)" else "") + "\n" + l.joinToString("\n") { "${it.second.start}-${it.second.end}  ${it.third}" } + goneText
    }

    fun weekText(st: Student.State, today: LocalDate): String {
        val monday = today.minusDays((today.dayOfWeek.value - 1).toLong())
        val sb = StringBuilder("This week 🗓️")
        for (i in 0..5) {
            val d = monday.plusDays(i.toLong())
            val l = Student.classesOn(st, d)
            sb.append("\n\n").append(d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.ENGLISH)).append(' ').append(d.dayOfMonth).append(if (d == today) " (today)" else "").append(if (st.changes[d.toString()].orEmpty().isNotEmpty()) " (changed)" else "").append(": ")
            sb.append(if (l.isEmpty()) "no classes" else l.joinToString(", ") { "${it.second.start} ${it.third}" })
        }
        return sb.toString()
    }

    fun answerClasses(st: Student.State, spec: String, today: LocalDate): String =
        if (spec == "week") weekText(st, today) else dayText(st, resolve(spec, today) ?: today, today)

    /** What is on now and what comes next (looks up to 7 days ahead). */
    fun nextClass(st: Student.State, now: LocalDateTime): String {
        val sb = StringBuilder()
        val cur = Student.slotAt(st, now)
        if (cur != null) {
            val day = Student.dayFor(st, now.toLocalDate())
            sb.append("Now: ").append(Student.label(day.cell(cur))).append(" (").append(day.periods[cur].start).append("-").append(day.periods[cur].end).append(")\n")
        }
        for (off in 0..7) {
            val d = now.toLocalDate().plusDays(off.toLong())
            for ((_, p, sub) in Student.classesOn(st, d)) {
                val a = Student.parseTime(p.start) ?: continue
                if (d.atTime(a).isAfter(now)) {
                    val whenTxt = when (off) { 0 -> "today"; 1 -> "tomorrow"; else -> d.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH) }
                    return sb.append("Next: ").append(sub).append(" at ").append(p.start).append(" ").append(whenTxt).toString()
                }
            }
        }
        return if (sb.isNotEmpty()) sb.append("Nothing after that this week.").toString() else "I can't find a class coming up. Fill in your timetable on the More tab 🗓️"
    }

    private fun periodsOf(st: Student.State, d: LocalDate, subject: String): Int =
        Student.classesOn(st, d).count { Student.parts(it.third).any { p -> p.equals(subject, true) } || it.third.equals(subject, true) }

    /** Can you skip everything on [d]? Subject by subject, counting how many periods you'd miss. */
    fun bunkDayText(st: Student.State, d: LocalDate, today: LocalDate): String {
        val classes = Student.classesOn(st, d)
        if (classes.isEmpty()) return title(d, today) + "\n" + none(d, today)
        val subjects = classes.flatMap { Student.parts(it.third) }.distinct().filter { Student.isTracked(st, it) }
        if (subjects.isEmpty()) return title(d, today) + "\nNothing on that day is tracked for attendance, so nothing to lose 🎒"
        var allSafe = true
        val lines = subjects.map { s ->
            val key = st.att.keys.firstOrNull { it.equals(s, true) }
            val r = key?.let { st.att[it] }
            val n = periodsOf(st, d, s)
            if (r == null || r[1] == 0) { allSafe = false; "$s: no attendance marked yet ($n class${if (n == 1) "" else "es"} that day) ❓" }
            else {
                val req = Student.reqFor(st, key)
                val p = Student.pct(r[0], r[1])
                val k = Student.canSkip(r[0], r[1], req)
                when {
                    p < req -> { allSafe = false; "$s: ${"%.1f".format(p)}% is under $req%. Don't skip 🚫" }
                    k < n -> { allSafe = false; "$s: ${"%.1f".format(p)}%, can skip only $k more but that day has $n 😬" }
                    else -> "$s: ${"%.1f".format(p)}%, can skip $k more, you'd miss $n ✅"
                }
            }
        }
        return title(d, today) + "\n" + (if (allSafe) "You can bunk the whole day ✅" else "Not everything is safe to skip ⚠️") + "\n\n" + lines.joinToString("\n")
    }

    /** Every tracked subject with how many classes can still be skipped, safest first. */
    fun bunkOverview(st: Student.State): String {
        val subs = SubjectTidy.attendanceSubjects(st)
        if (subs.isEmpty()) return "No attendance to check yet. Set up your timetable on the More tab and answer \"Did you attend?\" after classes 📋"
        fun room(s: String): Int { val r = st.att.keys.firstOrNull { it.equals(s, true) }?.let { st.att[it] } ?: return -2; return if (r[1] == 0) -1 else if (Student.pct(r[0], r[1]) < Student.reqFor(st, s)) -3 else Student.canSkip(r[0], r[1], Student.reqFor(st, s)) }
        val sorted = subs.sortedByDescending { room(it) }
        return "Bunk check 🎒\n" + sorted.joinToString("\n") { s ->
            val k = room(s)
            val line = Student.attendanceLine(st, st.att.keys.firstOrNull { it.equals(s, true) } ?: s)
            (when { k >= 1 -> "✅ "; k == 0 -> "😬 "; k == -3 -> "🚫 "; else -> "❓ " }) + line
        }
    }

    fun lowAttendance(st: Student.State): String {
        val low = st.att.entries.filter { it.value[1] > 0 && Student.pct(it.value[0], it.value[1]) < Student.reqFor(st, it.key) && Student.isTracked(st, it.key) }
        if (st.att.isEmpty()) return "No attendance marked yet 📋"
        if (low.isEmpty()) return "Nothing is below the limit right now ✅ Say \"bunk status\" to see how many classes you can skip in each subject."
        return "Below the limit ⚠️\n" + low.sortedBy { Student.pct(it.value[0], it.value[1]) }.joinToString("\n") { Student.attendanceLine(st, it.key) }
    }
}
