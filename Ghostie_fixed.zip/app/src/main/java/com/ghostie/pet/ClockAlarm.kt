package com.ghostie.pet

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock

/** Sets alarms in the phone's own Clock app instead of Ghostie's built-in ringer. */
object ClockAlarm {
    /** Ghostie day mask (bit 0 = Monday ... bit 6 = Sunday) to java.util.Calendar day numbers (Sunday = 1, Monday = 2). */
    fun calendarDays(mask: Int): ArrayList<Int> {
        val out = ArrayList<Int>()
        for (i in 0..6) if (mask and (1 shl i) != 0) out.add(if (i == 6) 1 else i + 2)
        return out
    }

    fun setIntent(hour: Int, minute: Int, days: Int, label: String): Intent {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (days != 0) i.putExtra(AlarmClock.EXTRA_DAYS, calendarDays(days))
        return i
    }

    fun showIntent(): Intent = Intent(AlarmClock.ACTION_SHOW_ALARMS)

    /** Opens the Clock app's alarm list so the person can edit, turn off or delete alarms there. */
    fun open(ctx: Context): Boolean = try {
        ctx.startActivity(showIntent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }
}
