package com.ghostie.pet

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle

/** Appears in WhatsApp's share sheet: share a group's exported chat (or one message) to Ghostie. */
class ShareReceiverActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val intent = intent
        if (intent?.action != Intent.ACTION_SEND) {
            finish()
            return
        }
        Thread {
            var group = "Shared message"
            val text: String = try {
                @Suppress("DEPRECATION")
                val uri = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                if (uri != null) {
                    val (g, t) = ChatImporter.read(this, uri)
                    group = g
                    t
                } else {
                    intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString() ?: ""
                }
            } catch (e: Exception) {
                ""
            }
            val message = if (text.isBlank()) {
                "I couldn't read what was shared."
            } else {
                try {
                    val report = ChatImporter.importText(this, group, text)
                    ChatImporter.describe(group, report)
                } catch (e: Exception) {
                    "Something went wrong while scanning."
                }
            }
            runOnUiThread { show(message) }
        }.start()
    }

    private fun show(message: String) {
        AlertDialog.Builder(this)
            .setTitle("Ghostie")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .setNeutralButton("Open app") { _, _ -> startActivity(Intent(this, MainActivity::class.java)) }
            .setOnDismissListener { finish() }
            .show()
    }
}
