package com.ghostie.pet

import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView

/**
 * "Symbols instead of emoji": a minimal, single-colour look. When switched on ([on]) every emoji the app shows in its own
 * screens, dialogs, bottom bar and chat is swapped for a simple text symbol, and emoji without a hand-picked match become a smiley, a heart, a steady geometric symbol (at the start of a label) or nothing (inside a sentence).
 * Pure Kotlin for the mapping ([t]) so it can be tested; the view subclasses below apply it wherever text is set.
 */
object Sym {
    /** Set from the saved setting when the app or the service starts, and when the switch is flipped. */
    @Volatile var on = false

    private val map: Map<String, String> = linkedMapOf(
        // objects and places
        "👻" to "◍", "⏰" to "◷", "⏱" to "◔", "📚" to "▤", "📖" to "▤", "📋" to "▤",
        "🎓" to "◆", "📝" to "✎", "🗓" to "▦", "📅" to "▦", "🏠" to "⌂",
        "⚙" to "⚙", "📂" to "▣", "📁" to "▣", "🧠" to "◈", "✨" to "✦", "📞" to "✆",
        "📱" to "▯", "🔔" to "♪", "🔒" to "▣", "🔗" to "∞", "💧" to "◦",
        "🎯" to "◎", "🤝" to "⇄", "👥" to "◉", "🗑" to "✕", "📷" to "◉",
        "🔍" to "⌕", "🧳" to "▤", "💸" to "₹", "💰" to "₹", "🍽" to "●", "🍛" to "●",
        "☕" to "♨", "🎧" to "♫", "🎵" to "♪", "🎶" to "♫", "🌙" to "☾", "☀" to "☀",
        "🌆" to "◐", "🔋" to "▮", "📶" to "▂▄▆", "💡" to "○", "🏏" to "●",
        "🎮" to "◈", "🍿" to "●", "🎂" to "△", "🏖" to "△", "📌" to "●", "📎" to "∥",
        "📊" to "▥", "📈" to "▲", "🧮" to "▦", "🔍" to "⌕", "✉" to "✉", "📩" to "✉",
        // marks
        "✅" to "✓", "❌" to "✕", "✔" to "✓", "⚠" to "!", "❗" to "!", "❓" to "?", "⭐" to "★", "🌟" to "★",
        "🎉" to "✦", "🥳" to "✦", "🎊" to "✦", "💥" to "✦", "⚡" to "ϟ",
        // hearts and faces
        "💜" to "♥", "❤" to "♥", "💙" to "♥", "💛" to "♥", "🥹" to "☺",
        "😄" to "☺", "😊" to "☺", "😅" to "☺", "😃" to "☺", "😁" to "☺", "😂" to "☺",
        "🙂" to "☺", "😎" to "☺", "😴" to "z", "😵" to "☻", "🥱" to "☻", "🥺" to "☹",
        "😢" to "☹", "😭" to "☹", "🫂" to "♥", "👍" to "▲", "👎" to "▼", "💪" to "▲",
        "👀" to "◎", "🤔" to "?", "💃" to "♪", "🎤" to "♪", "🦆" to "●", "🌼" to "✿",
        "🌬" to "∿", "🐶" to "●", "🎃" to "●", "😈" to "●", "🤫" to "○", "✨" to "✦"
    )

    private val strip = Regex("[️‍⃣]")
    /** Plain geometric symbols handed out (the same one every time) to emoji that have no hand-picked symbol but start a label. */
    private val pool = "\u25C6\u25C7\u25CB\u25CF\u25D0\u25D1\u25B2\u25B3\u25BC\u25A0\u25A1\u25A3\u25A4\u25A5\u25A6\u25A7\u2726\u2727\u2605\u2606\u2666\u2663\u2660\u2318\u2756\u271A\u2731\u2B22\u2B21\u25C8\u25CE\u25C9".toCharArray()

    private fun isEmojiCp(cp: Int) = cp in 0x1F000..0x1FBFF || cp in 0x2B50..0x2B55 || cp in 0x231A..0x231B || cp in 0x23E9..0x23FA ||
        cp == 0x2B1B || cp == 0x2B1C || cp == 0x2614 || cp in 0x2648..0x2653 || cp == 0x267F || cp == 0x2693 || cp == 0x26AA || cp == 0x26AB ||
        cp == 0x26BD || cp == 0x26BE || cp == 0x26C4 || cp == 0x26C5 || cp == 0x26CE || cp == 0x26D4 || cp == 0x26EA || cp == 0x26F2 || cp == 0x26F3 ||
        cp == 0x26F5 || cp == 0x26FA || cp == 0x26FD || cp == 0x270A || cp == 0x270B || cp == 0x274E || cp in 0x2753..0x2755 || cp in 0x2795..0x2797 ||
        cp == 0x27B0 || cp == 0x27BF

    /**
     * Emoji the table has no entry for: faces become a smiley, hearts a heart, skin tones vanish; any other emoji that starts a label
     * (a card title or button, nothing readable before it) gets a steady geometric symbol so the label still has an icon,
     * and one in the middle of a sentence is simply dropped.
     */
    private fun fallbackEmoji(x: String): String {
        val sb = StringBuilder(x.length)
        var i = 0
        var seenText = false
        while (i < x.length) {
            val cp = x.codePointAt(i)
            when {
                cp in 0x1F3FB..0x1F3FF -> {}
                !isEmojiCp(cp) -> { sb.appendCodePoint(cp); if (Character.isLetterOrDigit(cp)) seenText = true }
                cp in 0x1F600..0x1F64F || cp in 0x1F910..0x1F92F || cp in 0x1F970..0x1F97F || cp in 0x1FAE0..0x1FAE7 -> sb.append('\u263A')
                cp in 0x1F493..0x1F49F || cp in 0x1F90D..0x1F90F || cp == 0x1F5A4 -> sb.append('\u2665')
                !seenText -> sb.append(pool[cp % pool.size])
                else -> {}
            }
            i += Character.charCount(cp)
        }
        return sb.toString()
    }

    fun t(s: CharSequence?): CharSequence? {
        if (!on || s == null || s.isEmpty()) return s
        return convert(s.toString())
    }

    fun convert(input: String): String {
        var x = strip.replace(input, "")
        for ((k, v) in map) if (x.contains(k)) x = x.replace(k, v)
        x = fallbackEmoji(x)
        // a dropped emoji can leave a double space or a space before punctuation
        return x.replace(Regex("[ \\t]{2,}"), " ").replace(Regex(" +([.,!?])"), "$1").replace(Regex("(?m)^[ \\t]+(?=\\S)"), "").trimEnd(' ')
            .let { if (it.isEmpty() && input.isNotEmpty()) "●" else it }
    }
}

/** TextView that shows symbols instead of emoji when [Sym.on]. Text set later (counters, status lines) is converted too. */
open class SymText(ctx: Context) : TextView(ctx) {
    override fun setText(text: CharSequence?, type: BufferType?) = super.setText(Sym.t(text), type)
}

class SymButton(ctx: Context) : Button(ctx) {
    override fun setText(text: CharSequence?, type: BufferType?) = super.setText(Sym.t(text), type)
}

class SymCheck(ctx: Context) : CheckBox(ctx) {
    override fun setText(text: CharSequence?, type: BufferType?) = super.setText(Sym.t(text), type)
}

/** Drop-in for AlertDialog.Builder that converts emoji in titles, messages, lists and buttons. */
class SymBuilder(ctx: Context) : AlertDialog.Builder(ctx) {
    override fun setTitle(title: CharSequence?): AlertDialog.Builder = super.setTitle(Sym.t(title))
    override fun setMessage(message: CharSequence?): AlertDialog.Builder = super.setMessage(Sym.t(message))
    override fun setPositiveButton(text: CharSequence?, listener: DialogInterface.OnClickListener?): AlertDialog.Builder = super.setPositiveButton(Sym.t(text), listener)
    override fun setNegativeButton(text: CharSequence?, listener: DialogInterface.OnClickListener?): AlertDialog.Builder = super.setNegativeButton(Sym.t(text), listener)
    override fun setNeutralButton(text: CharSequence?, listener: DialogInterface.OnClickListener?): AlertDialog.Builder = super.setNeutralButton(Sym.t(text), listener)
    override fun setItems(items: Array<out CharSequence>?, listener: DialogInterface.OnClickListener?): AlertDialog.Builder =
        super.setItems(items?.map { Sym.t(it) ?: "" }?.toTypedArray(), listener)
    override fun setMultiChoiceItems(items: Array<out CharSequence>?, checkedItems: BooleanArray?, listener: DialogInterface.OnMultiChoiceClickListener?): AlertDialog.Builder =
        super.setMultiChoiceItems(items?.map { Sym.t(it) ?: "" }?.toTypedArray(), checkedItems, listener)
}

class SymSwitch(ctx: Context) : androidx.appcompat.widget.SwitchCompat(ctx) {
    override fun setText(text: CharSequence?, type: BufferType?) = super.setText(Sym.t(text), type)
}
