package com.ghostie.pet

import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView

/**
 * "Symbols instead of emoji": a minimal, single-colour look. When switched on ([on]) every emoji the app shows in its own
 * screens, dialogs, bottom bar and chat is swapped for a simple text symbol, and emoji without a match are dropped.
 * Pure Kotlin for the mapping ([t]) so it can be tested; the view subclasses below apply it wherever text is set.
 */
object Sym {
    /** Set from the saved setting when the app or the service starts, and when the switch is flipped. */
    @Volatile var on = false

    private val map: Map<String, String> = linkedMapOf(
        // objects and places
        "👻" to "◍", "⏰" to "◷", "⏱" to "◔", "📚" to "▤", "📖" to "▤", "📋" to "▤",
        "🎓" to "◆", "📝" to "✎", "🗓" to "▦", "📅" to "▦", "🏠" to "⌂",
        "⚙" to "⚙", "📂" to "▣", "📁" to "▣", "🧠" to "◈", "✨" to "✦", "📞" to "✆",
        "📱" to "▯", "🔔" to "♪", "🔒" to "▣", "🔗" to "∞", "💧" to "◦",
        "🎯" to "◎", "🤝" to "⇄", "👥" to "◉", "🗑" to "✕", "📷" to "◉",
        "🔍" to "⌕", "🧳" to "▤", "💸" to "₹", "💰" to "₹", "🍽" to "●", "🍛" to "●",
        "☕" to "♨", "🎧" to "♫", "🎵" to "♪", "🎶" to "♫", "🌙" to "☾", "☀" to "☀",
        "🌆" to "◐", "🔋" to "▮", "📶" to "▂▄▆", "💡" to "○", "🏏" to "●",
        "🎮" to "◈", "🍿" to "●", "🎂" to "△", "🏖" to "△", "📌" to "●", "📎" to "∥",
        "📊" to "▥", "📈" to "▲", "🧮" to "▦", "🔍" to "⌕", "✉" to "✉", "📩" to "✉",
        // marks
        "✅" to "✓", "❌" to "✕", "✔" to "✓", "⚠" to "!", "❗" to "!", "❓" to "?", "⭐" to "★", "🌟" to "★",
        "🎉" to "✦", "🥳" to "✦", "🎊" to "✦", "💥" to "✦", "⚡" to "ϟ",
        // hearts and faces
        "💜" to "♥", "❤" to "♥", "💙" to "♥", "💛" to "♥", "🥹" to "☺",
        "😄" to "☺", "😊" to "☺", "😅" to "☺", "😃" to "☺", "😁" to "☺", "😂" to "☺",
        "🙂" to "☺", "😎" to "☺", "😴" to "z", "😵" to "☻", "🥱" to "☻", "🥺" to "☹",
        "😢" to "☹", "😭" to "☹", "🫂" to "♥", "👍" to "▲", "👎" to "▼", "💪" to "▲",
        "👀" to "◎", "🤔" to "?", "💃" to "♪", "🎤" to "♪", "🦆" to "●", "🌼" to "✿",
        "🌬" to "∿", "🐶" to "●", "🎃" to "●", "😈" to "●", "🤫" to "○", "✨" to "✦"
    )

    private val strip = Regex("[️‍⃣]")
    // BMP emoji not in the table above (supplementary ones are dropped by code point in [dropEmoji])
    private val leftover = Regex("[\u2B50\u2B55\u231A\u231B\u23E9-\u23FA\u2B1B\u2B1C\u2614\u2648-\u2653\u267F\u2693\u26AA\u26AB\u26BD\u26BE\u26C4\u26C5\u26CE\u26D4\u26EA\u26F2\u26F3\u26F5\u26FA\u26FD\u270A\u270B\u274E\u2753-\u2755\u2795-\u2797\u27B0\u27BF]")

    private fun dropEmoji(x: String): String {
        val sb = StringBuilder(x.length)
        var i = 0
        while (i < x.length) {
            val cp = x.codePointAt(i)
            if (cp !in 0x1F000..0x1FBFF) sb.appendCodePoint(cp)
            i += Character.charCount(cp)
        }
        return sb.toString()
    }

    fun t(s: CharSequence?): CharSequence? {
        if (!on || s == null || s.isEmpty()) return s
        return convert(s.toString())
    }

    fun convert(input: String): String {
        var x = strip.replace(input, "")
        for ((k, v) in map) if (x.contains(k)) x = x.replace(k, v)
        x = leftover.replace(dropEmoji(x), "")
        // a dropped emoji can leave a double space or a space before punctuation
        return x.replace(Regex("[ \\t]{2,}"), " ").replace(Regex(" +([.,!?])"), "$1").replace(Regex("(?m)^[ \\t]+(?=\\S)"), "").trimEnd(' ')
            .let { if (it.isEmpty() && input.isNotEmpty()) "●" else it }
    }
}

/** TextView that shows symbols instead of emoji when [Sym.on]. Text set later (counters, status lines) is converted too. */
open class SymText(ctx: Context) : TextView(ctx) {
    override fun setText(text: CharSequence?, type: BufferType?) = super.setText(Sym.t(text), type)
}

class SymButton(ctx: Context) : Button(ctx) {
    override fun setText(text: CharSequence?, type: BufferType?) = super.setText(Sym.t(text), type)
}

class SymCheck(ctx: Context) : CheckBox(ctx) {
    override fun setText(text: CharSequence?, type: BufferType?) = super.setText(Sym.t(text), type)
}

/** Drop-in for AlertDialog.Builder that converts emoji in titles, messages, lists and buttons. */
class SymBuilder(ctx: Context) : AlertDialog.Builder(ctx) {
    override fun setTitle(title: CharSequence?): AlertDialog.Builder = super.setTitle(Sym.t(title))
    override fun setMessage(message: CharSequence?): AlertDialog.Builder = super.setMessage(Sym.t(message))
    override fun setPositiveButton(text: CharSequence?, listener: DialogInterface.OnClickListener?): AlertDialog.Builder = super.setPositiveButton(Sym.t(text), listener)
    override fun setNegativeButton(text: CharSequence?, listener: DialogInterface.OnClickListener?): AlertDialog.Builder = super.setNegativeButton(Sym.t(text), listener)
    override fun setNeutralButton(text: CharSequence?, listener: DialogInterface.OnClickListener?): AlertDialog.Builder = super.setNeutralButton(Sym.t(text), listener)
    override fun setItems(items: Array<out CharSequence>?, listener: DialogInterface.OnClickListener?): AlertDialog.Builder =
        super.setItems(items?.map { Sym.t(it) ?: "" }?.toTypedArray(), listener)
    override fun setMultiChoiceItems(items: Array<out CharSequence>?, checkedItems: BooleanArray?, listener: DialogInterface.OnMultiChoiceClickListener?): AlertDialog.Builder =
        super.setMultiChoiceItems(items?.map { Sym.t(it) ?: "" }?.toTypedArray(), checkedItems, listener)
}

class SymSwitch(ctx: Context) : androidx.appcompat.widget.SwitchCompat(ctx) {
    override fun setText(text: CharSequence?, type: BufferType?) = super.setText(Sym.t(text), type)
}
