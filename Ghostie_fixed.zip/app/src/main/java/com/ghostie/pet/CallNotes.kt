package com.ghostie.pet

import android.content.Context
import android.content.Intent
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.time.LocalDate
import java.util.concurrent.Executors

/** Pure logic (no Android classes): finds deadlines and other things worth noting in call text. */
object CallNoteLogic {
    class Result(val deadlines: List<Pair<String, Submission>>, val notes: List<String>)

    private val noteRe = Regex("\\b(exam|test|quiz|meeting|interview|submit|submission|deadline|assignment|project|fees?|pay|bring|remind|call (?:me )?back|appointment|class|viva|presentation)\\b", RegexOption.IGNORE_CASE)

    fun sentences(text: String): List<String> =
        text.split(Regex("(?<=[.!?])\\s+|\\n+")).map { it.trim() }.filter { it.length >= 8 }

    fun extract(text: String, today: LocalDate, maxNotes: Int = 5): Result {
        val deadlines = ArrayList<Pair<String, Submission>>()
        val notes = ArrayList<String>()
        for (s in sentences(text)) {
            val sub = SubmissionParser.parse(s, today)
            if (sub != null) deadlines.add(s to sub)
            else if (noteRe.containsMatchIn(s) && notes.size < maxNotes) notes.add(s.take(160))
        }
        return Result(deadlines, notes)
    }

    /** Mixes to mono and picks samples down (or up) to 16 kHz. Good enough for speech. */
    fun toMono16k(pcm: ByteArray, rate: Int, channels: Int): ByteArray {
        val frames = pcm.size / (2 * channels)
        val outFrames = (frames.toLong() * 16000 / rate).toInt()
        val out = ByteArray(outFrames * 2)
        for (o in 0 until outFrames) {
            val f = minOf(frames - 1, (o.toLong() * rate / 16000).toInt())
            var sum = 0
            for (c in 0 until channels) {
                val p = (f * channels + c) * 2
                sum += ((pcm[p + 1].toInt() shl 8) or (pcm[p].toInt() and 0xFF)).toShort().toInt()
            }
            val v = sum / channels
            out[o * 2] = (v and 0xFF).toByte(); out[o * 2 + 1] = ((v shr 8) and 0xFF).toByte()
        }
        return out
    }

    fun isAudio(name: String): Boolean = name.substringAfterLast('.', "").lowercase() in setOf("m4a", "mp3", "amr", "wav", "3gp", "aac", "ogg", "opus", "mp4")
}

/**
 * After a call, picks up the new recording from the phone's own call recorder, turns it into text with Android's speech
 * recognizer, saves deadlines as reminders and other points as notes, then deletes the recording.
 * The recording is only deleted after text was obtained; if it could not be read it is kept and you are told.
 * The text itself is never stored.
 */
object CallNotes {
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var busy = false
    private val seen = HashSet<String>()

    /** Folders where phones usually keep call recordings (the person can add their own in the app). */
    fun folders(ctx: Context): List<File> {
        val root = android.os.Environment.getExternalStorageDirectory()
        val list = mutableListOf(
            "MIUI/sound_recorder/call_rec", "MIUI/sound_recorder", "Recordings/Call", "Recordings/Call recordings",
            "Call", "CallRecordings", "Music/Recordings/Call", "Sounds/CallRecord", "Record/Call"
        ).map { File(root, it) }.toMutableList()
        val custom = SettingsStore(ctx).callFolder.trim()
        if (custom.isNotEmpty()) list.add(File(if (custom.startsWith("/")) custom else root.absolutePath + "/" + custom))
        return list.filter { it.isDirectory }.distinctBy { it.absolutePath }
    }

    fun request(ctx: Context, file: File) {
        val app = ctx.applicationContext
        if (!CallNoteLogic.isAudio(file.name)) return
        if (!SettingsStore(app).callNotes) return
        synchronized(seen) { if (!seen.add(file.absolutePath + "|" + file.length())) return }
        main.postDelayed({ worker.execute { run(app, file) } }, 4000) // let the recorder finish writing
    }

    private fun log(ctx: Context, msg: String) = ActivityLog.add(ctx, "Call notes", msg)

    private fun run(ctx: Context, file: File) {
        if (busy) { main.postDelayed({ worker.execute { run(ctx, file) } }, 20_000); return }
        busy = true
        try {
            if (!file.isFile || file.length() < 4000) { busy = false; return }
            if (Build.VERSION.SDK_INT < 33) {
                log(ctx, "Needs Android 13 or newer to read recordings; kept ${file.name}")
                Notifier.post(ctx, "📞 Call notes", "Reading call recordings needs Android 13 or newer. The recording was kept.")
                busy = false; return
            }
            val pcm = decode(file)
            if (pcm == null || pcm.isEmpty()) { fail(ctx, "Couldn't decode ${file.name}; kept it"); return }
            val chunk = 16000 * 2 * 25 // 25 seconds of 16 kHz mono 16-bit
            val chunks = (0 until pcm.size step chunk).map { pcm.copyOfRange(it, minOf(pcm.size, it + chunk)) }
            val sb = StringBuilder()
            fun next(i: Int) {
                if (i >= chunks.size) { worker.execute { finish(ctx, file, sb.toString()) }; return }
                recognize(ctx, chunks[i]) { text -> if (text.isNotBlank()) sb.append(text).append(". "); next(i + 1) }
            }
            main.post { next(0) }
        } catch (e: Exception) {
            fail(ctx, "Error reading ${file.name}: ${e.javaClass.simpleName}")
        }
    }

    private fun fail(ctx: Context, msg: String) {
        busy = false
        log(ctx, msg)
        Notifier.post(ctx, "📞 Call notes", msg)
    }

    private fun finish(ctx: Context, file: File, text: String) {
        try {
            if (text.isBlank()) { fail(ctx, "Couldn't turn the call into text; the recording was kept"); return }
            val s = SettingsStore(ctx)
            val today = LocalDate.now()
            val res = CallNoteLogic.extract(text, today)
            var made = 0
            for ((sentence, sub) in res.deadlines) {
                if (ReminderMaker.isDuplicate(s, sentence, sub, ctx, "Call")) continue
                ReminderMaker.add(ctx, s, "Call", sentence, sub)
                made++
            }
            if (res.notes.isNotEmpty()) s.setNotes(s.notes() + res.notes.map { "📞 $it" })
            val deleted = try { file.delete() } catch (e: Exception) { false }
            log(ctx, "Scanned a call: $made reminder(s), ${res.notes.size} note(s); recording ${if (deleted) "deleted" else "could not be deleted"}")
            Notifier.post(ctx, "📞 Call scanned", "$made reminder(s) and ${res.notes.size} note(s) saved.\nRecording ${if (deleted) "deleted" else "kept (couldn't delete)"}.")
        } finally { busy = false }
    }

    /** Decodes any audio file to 16 kHz mono 16-bit PCM (capped at 20 minutes). */
    private fun decode(file: File): ByteArray? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(file.absolutePath)
            val idx = (0 until ex.trackCount).firstOrNull { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true } ?: return null
            ex.selectTrack(idx)
            val fmt = ex.getTrackFormat(idx)
            codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec.configure(fmt, null, null, 0)
            codec.start()
            val out = ByteArrayOutputStream()
            var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            val cap = 16000 * 2 * 60 * 20
            while (!outputDone && out.size() < cap) {
                if (!inputDone) {
                    val ib = codec.dequeueInputBuffer(10_000)
                    if (ib >= 0) {
                        val buf = codec.getInputBuffer(ib)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) { codec.queueInputBuffer(ib, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputDone = true }
                        else { codec.queueInputBuffer(ib, 0, n, ex.sampleTime, 0); ex.advance() }
                    }
                }
                val ob = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    ob == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = codec.outputFormat
                        rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE); ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                    ob >= 0 -> {
                        val buf = codec.getOutputBuffer(ob)!!
                        val bytes = ByteArray(info.size); buf.get(bytes)
                        out.write(CallNoteLogic.toMono16k(bytes, rate, ch))
                        codec.releaseOutputBuffer(ob, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                    }
                }
            }
            return out.toByteArray()
        } catch (e: Exception) {
            return null
        } finally {
            try { codec?.stop(); codec?.release() } catch (e: Exception) { }
            ex.release()
        }
    }

    /** Feeds one chunk of raw audio to Android's recognizer through a pipe (Android 13+). Must run on the main thread. */
    private fun recognize(ctx: Context, pcm: ByteArray, done: (String) -> Unit) {
        var finished = false
        var rec: SpeechRecognizer? = null
        fun end(text: String) {
            if (finished) return
            finished = true
            try { rec?.destroy() } catch (e: Exception) { }
            done(text)
        }
        try {
            val pipe = ParcelFileDescriptor.createPipe()
            Thread {
                try { FileOutputStream(pipe[1].fileDescriptor).use { it.write(pcm) } } catch (e: Exception) { }
                try { pipe[1].close() } catch (e: Exception) { }
            }.start()
            rec = SpeechRecognizer.createSpeechRecognizer(ctx)
            rec.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onResults(results: Bundle?) { end(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()) }
                override fun onError(error: Int) { end("") }
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, SettingsStore(ctx).speechTag)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
                .putExtra("android.speech.extra.AUDIO_SOURCE", pipe[0])
                .putExtra("android.speech.extra.AUDIO_SOURCE_CHANNEL_COUNT", 1)
                .putExtra("android.speech.extra.AUDIO_SOURCE_ENCODING", 2) // ENCODING_PCM_16BIT
                .putExtra("android.speech.extra.AUDIO_SOURCE_SAMPLING_RATE", 16000)
            rec.startListening(i)
            main.postDelayed({ end("") }, 45_000L)
        } catch (e: Exception) { end("") }
    }
}
