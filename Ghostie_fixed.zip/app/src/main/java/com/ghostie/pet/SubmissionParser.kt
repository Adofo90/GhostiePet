package com.ghostie.pet

import java.time.DateTimeException
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters
import java.util.Locale

enum class DeadlineKind { SUBMISSION, REGISTRATION }

data class Submission(
    val deadline: LocalDate,
    val time: LocalTime?,
    val summary: String,
    val kind: DeadlineKind = DeadlineKind.SUBMISSION,
    /** Event name for registrations, if it could be picked out of the message. */
    val name: String? = null
)

/** Pure logic: finds "submit by <date>" style messages and plans a reminder for the day before. */
object SubmissionParser {
    private val I = RegexOption.IGNORE_CASE

    private val trigger = Regex(
        "\\b(submit|submitted|submission|submissions|deadline|due|last date|last day|hand ?in|upload|" +
            "assignments?|records?|lab reports?|reports?|projects?|viva|presentations?|seminar|journal)\\b", I
    )

    private val regTrigger = Regex(
        "\\b(regist(?:er|ers|ered|ration|rations|ering)|enrol(?:l|ls|ment|ments)?|sign ?-?ups?|apply|applications?|rsvp)\\b", I
    )
    private val closeWord = Regex(
        "\\b(last date|last day|deadline|closes?|closing|closed|till|until|by|before|ends?|due|cut-?off)\\b", I
    )
    private val regName = Regex(
        "(?:regist(?:er|ered|ration|rations)|apply|sign ?-?up|enrol(?:l)?|rsvp)\\s+(?:for|to|in|of)\\s+(?:the\\s+)?(.+?)" +
            "(?=\\s+(?:is|are|will|by|on|before|till|until|closes?|ends?|last|at|deadline)\\b|\\s+[-\u2013:]\\s|[,.!:\\n]|$)", I
    )

    internal const val MONTH = "(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|june?|july?|aug(?:ust)?|sept?(?:ember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)"
    private val monthNum = mapOf(
        "jan" to 1, "feb" to 2, "mar" to 3, "apr" to 4, "may" to 5, "jun" to 6,
        "jul" to 7, "aug" to 8, "sep" to 9, "oct" to 10, "nov" to 11, "dec" to 12
    )
    private val dayNames = mapOf(
        "mon" to DayOfWeek.MONDAY, "tue" to DayOfWeek.TUESDAY, "wed" to DayOfWeek.WEDNESDAY,
        "thu" to DayOfWeek.THURSDAY, "fri" to DayOfWeek.FRIDAY, "sat" to DayOfWeek.SATURDAY, "sun" to DayOfWeek.SUNDAY
    )

    /** Builds a date from day/month and an optional year. Without a year: this year, or next year if it already passed (within ~200 days). */
    private fun resolve(day: Int, month: Int, year: Int?, today: LocalDate): LocalDate? {
        return try {
            if (year != null) {
                LocalDate.of(if (year < 100) 2000 + year else year, month, day)
            } else {
                val thisYear = LocalDate.of(today.year, month, day)
                if (!thisYear.isBefore(today)) thisYear
                else {
                    val next = LocalDate.of(today.year + 1, month, day)
                    if (ChronoUnit.DAYS.between(today, next) <= 200) next else null
                }
            }
        } catch (e: DateTimeException) {
            null
        }
    }

    internal fun monthOf(word: String): Int = monthNum[word.lowercase().take(3)] ?: 0

    /** All dates mentioned in the text, with their position, in no particular order. */
    private fun candidates(text: String, ref: LocalDate, allowRelative: Boolean = true): List<Pair<Int, LocalDate>> {
        val today = ref
        val out = mutableListOf<Pair<Int, LocalDate>>()

        if (allowRelative) {
            Regex("\\b(?:day after tomorrow|day after|overmorrow|parso|parson)\\b", I).findAll(text).forEach { out.add(it.range.first to today.plusDays(2)) }
            Regex("\\bkal\\b", I).findAll(text).forEach { out.add(it.range.first to today.plusDays(1)) }
            Regex("\\b(?:tomorrow|tmrw|tmr|tomo)\\b", I).findAll(text).forEach { out.add(it.range.first to today.plusDays(1)) }
            Regex("\\b(?:today|tonight|aaj)\\b", I).findAll(text).forEach { out.add(it.range.first to today) }
        }

        // 5th Nov, 5 November 2026
        Regex("\\b(\\d{1,2})(?:st|nd|rd|th)?\\s*(?:of\\s+)?$MONTH\\b\\.?(?:,?\\s*(\\d{4}))?", I).findAll(text).forEach { m ->
            resolve(m.groupValues[1].toInt(), monthOf(m.groupValues[2]), m.groupValues[3].toIntOrNull(), today)
                ?.let { out.add(m.range.first to it) }
        }
        // Nov 5, November 5th, 2026
        Regex("\\b$MONTH\\b\\.?\\s*(\\d{1,2})(?:st|nd|rd|th)?\\b(?!\\s*:)(?:,?\\s*(\\d{4}))?", I).findAll(text).forEach { m ->
            resolve(m.groupValues[2].toInt(), monthOf(m.groupValues[1]), m.groupValues[3].toIntOrNull(), today)
                ?.let { out.add(m.range.first to it) }
        }
        // 05/11, 5-11-2026, 5.11.26  (day first, as in India)
        Regex("(?<![\\d/.:-])(\\d{1,2})[/.\\-](\\d{1,2})(?:[/.\\-](\\d{2,4}))?(?![\\d:])").findAll(text).forEach { m ->
            resolve(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toIntOrNull(), today)
                ?.let { out.add(m.range.first to it) }
        }
        // Friday / by fri / next monday
        if (allowRelative) Regex("\\b(?:(by|on|before|till|until|this|next)\\s+)?(monday|tuesday|wednesday|thursday|friday|saturday|sunday|mon|tues?|wed|thur?s?|fri|sat|sun)\\b", I)
            .findAll(text).forEach { m ->
                val lead = m.groupValues[1].lowercase()
                val word = m.groupValues[2].lowercase()
                val full = word.length > 4 || word in setOf("monday", "friday", "sunday")
                if (full || lead.isNotEmpty()) {
                    val dow = dayNames[word.take(3)]!!
                    val date = if (lead == "next") today.with(TemporalAdjusters.next(dow)) else today.with(TemporalAdjusters.nextOrSame(dow))
                    out.add(m.range.first to date)
                }
            }
        return out
    }

    private fun findTime(text: String): LocalTime? {
        Regex("\\b(\\d{1,2})(?::(\\d{2}))?\\s*([ap])\\.?m\\b", I).find(text)?.let { m ->
            var h = m.groupValues[1].toInt()
            val mi = m.groupValues[2].ifEmpty { "0" }.toInt()
            if (h in 1..12 && mi < 60) {
                if (h == 12) h = 0
                if (m.groupValues[3].equals("p", true)) h += 12
                return LocalTime.of(h, mi)
            }
        }
        return null
    }

    /**
     * today = the real date (deadlines before it are ignored).
     * ref = the date the message was written; "tomorrow"/"Monday" are relative to it (matters for old messages in a chat export).
     */
    fun parse(text: String, today: LocalDate = LocalDate.now(), ref: LocalDate = today, allowRelative: Boolean = true): Submission? {
        val registration = regTrigger.containsMatchIn(text) && closeWord.containsMatchIn(text)
        if (!registration && !trigger.containsMatchIn(text)) return null
        val date = candidates(text, ref, allowRelative)
            .sortedBy { it.first }
            .firstOrNull { !it.second.isBefore(today) }?.second ?: return null
        val summary = text.replace(Regex("\\s+"), " ").trim().let { if (it.length > 140) it.take(137) + "..." else it }
        val name = if (registration) regName.find(text)?.groupValues?.get(1)?.trim()?.take(50)?.takeIf { it.length >= 3 } else null
        return Submission(
            date, findTime(text), summary,
            if (registration) DeadlineKind.REGISTRATION else DeadlineKind.SUBMISSION, name
        )
    }

    data class ReminderSet(val times: List<LocalDateTime>, val dayBeforePassed: Boolean)

    /** When the deadline itself happens: the stated time, or 5 pm if none was given. */
    fun eventStart(sub: Submission): LocalDateTime = LocalDateTime.of(sub.deadline, sub.time ?: LocalTime.of(17, 0))

    /**
     * Alerts that are still in the future: 9:00 the day before (always), 9:00 two days before (optional),
     * and the morning of the deadline (optional; 2 hours before if a time was given).
     */
    fun reminderTimes(sub: Submission, now: LocalDateTime, twoDay: Boolean, morning: Boolean): ReminderSet {
        val start = eventStart(sub)
        val dayBefore = LocalDateTime.of(sub.deadline.minusDays(1), LocalTime.of(9, 0))
        val all = mutableListOf(dayBefore)
        if (twoDay) all.add(LocalDateTime.of(sub.deadline.minusDays(2), LocalTime.of(9, 0)))
        if (morning) all.add(if (sub.time != null) start.minusHours(2) else LocalDateTime.of(sub.deadline, LocalTime.of(8, 0)))
        val soon = now.plusMinutes(1)
        val future = all.filter { it.isAfter(soon) && it.isBefore(start) }.distinct().sorted()
        return ReminderSet(future, !dayBefore.isAfter(soon))
    }

    /** "today", "tomorrow" or "on Fri 6 Nov" relative to now. */
    fun dueText(sub: Submission, now: LocalDateTime): String {
        val gap = ChronoUnit.DAYS.between(now.toLocalDate(), sub.deadline)
        return when {
            gap <= 0L -> "today"
            gap == 1L -> "tomorrow"
            else -> "on " + sub.deadline.format(DateTimeFormatter.ofPattern("EEE d MMM", Locale.ENGLISH))
        }
    }
}

/** WhatsApp's date chips between messages: "Today", "Yesterday", "Monday", "28 October 2026". */
object DateDivider {
    private val I = RegexOption.IGNORE_CASE

    fun parse(text: String, today: LocalDate): LocalDate? {
        val t = text.trim()
        if (t.length > 20) return null
        if (t.equals("today", true)) return today
        if (t.equals("yesterday", true)) return today.minusDays(1)
        Regex("^(monday|tuesday|wednesday|thursday|friday|saturday|sunday)$", I).find(t)?.let {
            return today.with(TemporalAdjusters.previous(DayOfWeek.valueOf(it.groupValues[1].uppercase())))
        }
        Regex("^(\\d{1,2})\\s+${SubmissionParser.MONTH}\\w*\\s+(\\d{4})$", I).find(t)?.let {
            return try { LocalDate.of(it.groupValues[3].toInt(), SubmissionParser.monthOf(it.groupValues[2]), it.groupValues[1].toInt()) } catch (e: DateTimeException) { null }
        }
        Regex("^${SubmissionParser.MONTH}\\w*\\s+(\\d{1,2}),?\\s+(\\d{4})$", I).find(t)?.let {
            return try { LocalDate.of(it.groupValues[3].toInt(), SubmissionParser.monthOf(it.groupValues[1]), it.groupValues[2].toInt()) } catch (e: DateTimeException) { null }
        }
        Regex("^(\\d{1,2})/(\\d{1,2})/(\\d{2,4})$").find(t)?.let {
            val y = it.groupValues[3].toInt().let { v -> if (v < 100) 2000 + v else v }
            return try { LocalDate.of(y, it.groupValues[2].toInt(), it.groupValues[1].toInt()) } catch (e: DateTimeException) { null }
        }
        return null
    }
}
