package com.ghostie.pet

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && SettingsStore(context).enabled) {
            context.startForegroundService(Intent(context, PetOverlayService::class.java))
        }
    }
}
