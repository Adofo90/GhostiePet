package com.ghostie.pet

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Buttons on the "Ghostie calling" notification. */
class CallActionReceiver : BroadcastReceiver() {
    companion object {
        const val DISMISS = "com.ghostie.pet.CALL_DISMISS"
        const val TRASH = "com.ghostie.pet.CALL_TRASH"
        const val DONE = "com.ghostie.pet.CALL_DONE"
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        val chat = intent.getStringExtra("chat") ?: ""
        if (intent.action == TRASH && chat.isNotEmpty()) CallAlerts.mute(ctx, chat)
        val id = intent.getLongExtra("eventId", 0L)
        if (intent.action == DONE && id > 0) ctx.sendBroadcast(Intent(ctx, ReminderReceiver::class.java).setAction(ReminderAlarms.DONE).putExtra("id", id))
        CallAlerts.cancel(ctx)
        ctx.sendBroadcast(Intent("com.ghostie.pet.CALL_CLOSED").setPackage(ctx.packageName))
    }
}
