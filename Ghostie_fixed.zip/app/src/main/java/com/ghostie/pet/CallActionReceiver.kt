package com.ghostie.pet

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Buttons on the "Ghostie calling" notification. */
class CallActionReceiver : BroadcastReceiver() {
    companion object {
        const val DISMISS = "com.ghostie.pet.CALL_DISMISS"
        const val TRASH = "com.ghostie.pet.CALL_TRASH"
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        val chat = intent.getStringExtra("chat") ?: ""
        if (intent.action == TRASH && chat.isNotEmpty()) CallAlerts.mute(ctx, chat)
        CallAlerts.cancel(ctx)
        ctx.sendBroadcast(Intent("com.ghostie.pet.CALL_CLOSED").setPackage(ctx.packageName))
    }
}
