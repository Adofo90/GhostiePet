package com.ghostie.pet

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

/** Reads incoming bank/UPI SMS (needs the SMS permission). Only amount, merchant and category are kept; the text is dropped. */
class MoneySmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        try {
            if (!SettingsStore(ctx).moneyAuto) return
            val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
            val body = msgs.joinToString("") { it.messageBody ?: "" }
            MoneyParser.parse(body, System.currentTimeMillis(), "sms")?.let { ExpenseStore.add(ctx, it) }
        } catch (e: Exception) { }
    }

    companion object {
        /** One-off: reads the last [days] days of the inbox and adds transactions it finds. Returns how many were new. */
        fun scanInbox(ctx: Context, days: Int = 30): Int {
            var added = 0
            try {
                val since = System.currentTimeMillis() - days * 86_400_000L
                ctx.contentResolver.query(Telephony.Sms.Inbox.CONTENT_URI, arrayOf(Telephony.Sms.BODY, Telephony.Sms.DATE), "date > ?", arrayOf(since.toString()), "date ASC")?.use { c ->
                    while (c.moveToNext()) {
                        MoneyParser.parse(c.getString(0) ?: continue, c.getLong(1), "sms")?.let { if (ExpenseStore.add(ctx, it)) added++ }
                    }
                }
            } catch (e: Exception) { }
            return added
        }
    }
}
