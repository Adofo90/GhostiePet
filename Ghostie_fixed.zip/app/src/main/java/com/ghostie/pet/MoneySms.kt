package com.ghostie.pet

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

/** Reads incoming bank/UPI SMS (needs the SMS permission). Only amount, merchant and category are kept; the text is dropped. */
class MoneySmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        try {
            if (!SettingsStore(ctx).moneyAuto) return
            val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
            val body = msgs.joinToString("") { it.messageBody ?: "" }
            val from = msgs.firstOrNull()?.originatingAddress?.trim().orEmpty()
            MoneyParser.parse(body, System.currentTimeMillis(), if (from.isEmpty()) "sms" else "sms:$from")?.let { ExpenseStore.add(ctx, it) }
        } catch (e: Exception) { }
    }

    companion object {
        /** For finding out what an old entry was: the texts in the inbox within 10 minutes of it that mention its amount. Read live, never saved. */
        fun findTexts(ctx: Context, t: Txn): List<Pair<String, String>> {
            val out = ArrayList<Pair<String, String>>()
            try {
                val amt = if (t.amount == Math.floor(t.amount)) t.amount.toLong().toString() else "%.2f".format(t.amount)
                ctx.contentResolver.query(Telephony.Sms.Inbox.CONTENT_URI, arrayOf(Telephony.Sms.BODY, Telephony.Sms.ADDRESS),
                    "date > ? AND date < ?", arrayOf((t.time - 600_000L).toString(), (t.time + 600_000L).toString()), "date ASC")?.use { c ->
                    while (c.moveToNext()) {
                        val body = c.getString(0) ?: continue
                        if (body.replace(",", "").contains(amt)) out.add((c.getString(1) ?: "?") to body)
                    }
                }
            } catch (e: Exception) { }
            return out
        }

        /** One-off: reads the last [days] days of the inbox and adds transactions it finds. Returns how many were new. */
        fun scanInbox(ctx: Context, days: Int = 30): Int {
            var added = 0
            try {
                val since = System.currentTimeMillis() - days * 86_400_000L
                ctx.contentResolver.query(Telephony.Sms.Inbox.CONTENT_URI, arrayOf(Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.ADDRESS), "date > ?", arrayOf(since.toString()), "date ASC")?.use { c ->
                    while (c.moveToNext()) {
                        MoneyParser.parse(c.getString(0) ?: continue, c.getLong(1), c.getString(2)?.trim()?.takeIf { it.isNotEmpty() }?.let { "sms:$it" } ?: "sms")?.let { if (ExpenseStore.add(ctx, it)) added++ }
                    }
                }
            } catch (e: Exception) { }
            return added
        }
    }
}
