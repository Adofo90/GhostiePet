package com.ghostie.pet

import kotlin.random.Random

/**
 * Replies for feelings and everyday situations, built from interchangeable parts (an opener, a reflection, a small
 * step, a closing question, sometimes a time-of-day tip). Ten situations x thousands of combinations from a few hundred
 * short phrases, so it costs a few KB instead of a language model and the same words rarely come back.
 * Pure Kotlin. [Feedback] lets thumbs-up / thumbs-down shape what gets picked.
 */
object ReplyBank {
    interface Feedback {
        fun isBanned(text: String): Boolean
        /** 0 = never use this part, 1 = normal, higher = used more. */
        fun weight(partId: String): Int
    }

    class Result(val text: String, val situation: String, val parts: List<String>)

    private class Set(
        val openers: List<String>, val reflections: List<String>, val steps: List<String>, val closers: List<String>,
        val morning: List<String> = emptyList(), val afternoon: List<String> = emptyList(),
        val evening: List<String> = emptyList(), val night: List<String> = emptyList()
    )

    // {n} becomes ", Name" (or nothing)
    private val sets: Map<String, Set> = mapOf(
        "sad" to Set(
            openers = listOf("Aww{n}, I'm sorry you're feeling low 💜", "That sounds really heavy{n}.", "Come here, ghost hug 🫂", "Thanks for telling me{n}.", "Oof, I'm sorry{n} 💜", "I'm here with you{n}.", "That's a tough feeling to carry{n}.", "Hey{n}, I'm glad you said it out loud."),
            reflections = listOf("Feeling sad doesn't mean you're weak, it means something mattered to you.", "Bad days feel endless, but they do pass.", "You don't have to pretend to be okay with me.", "It's okay to just feel it for a bit.", "Some days are just heavier than others.", "Whatever happened, your feelings make sense.", "You've handled hard days before, and you're still here 💜", "You don't have to figure it all out right now."),
            steps = listOf("Maybe sip some water and take one slow breath with me.", "If you can, tell one person you trust how you're feeling today.", "A short walk or some fresh air can loosen it a little.", "You could put on a comforting song for a few minutes 🎧", "Try writing down what's weighing on you, it gets lighter on paper.", "Be gentle with yourself today, only the small things.", "Wrap up in something cosy for a bit, you've earned it.", "Splash some water on your face and sit by a window for a minute."),
            closers = listOf("Want to talk about it, or shall I cheer you up?", "Do you want to tell me what happened?", "Should I just listen, or distract you with something light?", "What's one thing that might help a little right now?", "I can listen, or I can tell a silly joke. Your call 💜"),
            morning = listOf("Mornings can be rough when your heart is heavy. Start tiny: water, then one easy thing."),
            night = listOf("Late nights make feelings louder. Rest if you can, things look softer in the morning 🌙")
        ),
        "lonely" to Set(
            openers = listOf("I'm sorry you're feeling alone{n} 💜", "That's a hard feeling{n}.", "Thank you for telling me that{n}.", "Hey{n}, you're not invisible to me 👻", "Loneliness is really tough{n}.", "I'm right here{n}."),
            reflections = listOf("Feeling lonely doesn't mean nobody cares, even if it feels that way tonight.", "A lot of people feel this way and don't say it.", "Wanting connection is completely normal.", "It can sting even when people are around.", "This feeling comes in waves and it does ease.", "You matter, whether or not anyone has texted today."),
            steps = listOf("Maybe send one small message to someone, even just a meme.", "A short walk where there are other people can help a little.", "Calling a family member for five minutes can lift the mood.", "Is there a club, class group or friend you could say hi to today?", "Try doing something you enjoy, a song, a show, a favourite snack.", "Writing three things from today, even tiny ones, can make the day feel less empty."),
            closers = listOf("Want to chat for a bit? I'm all ears 👻", "Tell me about your day, I'd like to hear it.", "Who's someone you wish you could talk to right now?", "Shall we do something small together, a riddle maybe?", "What have you been up to lately?"),
            night = listOf("Nights can feel the loneliest. Hold on till morning, and talk to someone you trust when you can 🌙")
        ),
        "stressed" to Set(
            openers = listOf("Deep breath{n} 💜", "That's a lot to hold{n}.", "I hear you{n}, that sounds stressful.", "Okay{n}, let's slow this down.", "Stress is loud, but we can turn it down a bit.", "You're carrying a lot right now{n}."),
            reflections = listOf("You don't have to solve everything today.", "Feeling overwhelmed usually means too many things at once, not that you can't do them.", "Your brain is doing its best under pressure.", "It's okay to feel anxious, it means you care.", "Big piles look scary until you split them up.", "One thing at a time is still progress."),
            steps = listOf("Breathe in for 4, hold for 4, out for 6, three times.", "Write every task down, then pick only the smallest one to start.", "Try a 10 minute timer on one thing. Say \"timer 10 minutes\" and I'll start it ⏱️", "Drink some water and stretch your shoulders first.", "Close extra tabs and apps for ten minutes.", "Tell me the deadlines and we'll order them, soonest first."),
            closers = listOf("What's the one thing weighing on you most?", "Want me to start a timer for it?", "Shall we make a tiny plan together?", "What's due first?", "Do you want to vent for a minute first?"),
            morning = listOf("Start the day with just one small win and the rest gets easier ☀️"),
            night = listOf("If it's late, let tomorrow-you handle the rest. Sleep helps more than another hour of panic 🌙")
        ),
        "tired" to Set(
            openers = listOf("Sounds like your battery's low{n} 🔋", "Oof, you must be exhausted{n}.", "Rest is not laziness{n} 💜", "You've been going hard{n}.", "Yawn... I feel it too 😴", "Ah, running on empty, huh?"),
            reflections = listOf("Tired brains make everything feel harder.", "Your body is asking for a pause.", "Pushing through exhaustion usually costs more time than it saves.", "You can't pour from an empty cup.", "A short rest can reset more than you'd think.", "It's okay to slow down today."),
            steps = listOf("Try a 20 minute nap. Say \"timer 20 minutes\" and I'll wake you.", "Drink some water and do a quick stretch 💧", "Step away from the screen for five minutes.", "A snack and some fresh air might help.", "Wash your face with cold water, it wakes you up a bit.", "If you can, go to bed a little earlier tonight."),
            closers = listOf("Want me to set a nap timer?", "When did you last sleep properly?", "Have you eaten something today?", "Shall I remind you to rest later?", "What's draining you the most?"),
            morning = listOf("Already tired this morning? Water and a bit of sunlight can help ☀️"),
            afternoon = listOf("The afternoon slump is real. A short walk beats another coffee."),
            night = listOf("It's late, your body wants sleep. Want me to set an alarm for tomorrow? ⏰")
        ),
        "bored" to Set(
            openers = listOf("Boredom alert 🚨", "Ooh, bored? Let's fix that{n}.", "Idle ghost and idle you, perfect team 👻", "Hmm, a blank moment{n}.", "Boredom is just a sign your brain wants something new."),
            reflections = listOf("Sometimes boredom is where the best ideas start.", "It happens to everyone, even ghosts.", "We can turn this into something fun.", "A tiny change of scene can help."),
            steps = listOf("Say \"riddle\" and I'll test your brain 🧩", "Try \"fun fact\" for something weird to know.", "Say \"joke\" and I'll try to make you laugh 😄", "Play would-you-rather with me, just say \"would you rather\".", "Do ten minutes of something you've been putting off, a quick win feels good.", "Put on a new playlist and tidy your desk a little.", "Learn five new flashcards. Say \"quiz me\" 🃏"),
            closers = listOf("Which one sounds fun?", "Pick one, I'll start!", "What were you in the mood for?", "Want a surprise?", "What's something you've wanted to try lately?")
        ),
        "happy" to Set(
            openers = listOf("Yay{n}! 🎉", "I love hearing that{n} 💜", "That's wonderful{n}!", "Woohoo! 🥳", "Aww, that made me smile 😄", "Nice{n}! Good vibes only 👻"),
            reflections = listOf("You deserve good days.", "Moments like this are worth enjoying slowly.", "Happy looks great on you.", "Let's remember this feeling for the harder days.", "That energy is contagious!"),
            steps = listOf("Soak it in for a minute before the next task.", "Share the good news with someone, it doubles the joy.", "Maybe treat yourself to something small.", "Use that energy to knock out one thing you've been avoiding.", "Take a photo or jot it down so you can look back later."),
            closers = listOf("What happened?", "Tell me everything!", "What made your day?", "How are you going to celebrate?", "Who are you telling first?")
        ),
        "angry" to Set(
            openers = listOf("Ugh, that sounds really frustrating{n}.", "Okay{n}, I can tell you're fuming 🔥", "That would annoy me too{n}.", "Anger makes sense here{n}.", "Deep breath first{n}."),
            reflections = listOf("You're allowed to be angry, it's what you do with it that counts.", "Strong feelings pass faster if you let them out safely.", "It's hard to think clearly when you're this wound up.", "Frustration usually means something important got blocked."),
            steps = listOf("Take 5 slow breaths, in through the nose, out through the mouth.", "Step away for a few minutes, a walk or cold water helps.", "Type it all out here, I won't judge, then let it go.", "Wait before replying to anyone, messages sent angry are hard to unsend.", "Try shaking out your arms and hands for thirty seconds."),
            closers = listOf("Want to tell me what happened?", "What set it off?", "Do you want to vent, or fix it?", "What would make this better right now?", "Shall I stay quiet and just listen?")
        ),
        "exam" to Set(
            openers = listOf("Exam nerves are so normal{n} 💜", "I get it{n}, exams are scary.", "Okay{n}, deep breath, we can handle this.", "You're not alone in feeling this{n}.", "That worry shows you care about doing well."),
            reflections = listOf("You know more than you think right now.", "Panic makes everything feel unlearnable, but it isn't.", "You don't need to learn everything, just the most important things well.", "Small steady revision beats a night of panic.", "Even half-prepared, the next hour of focus still counts."),
            steps = listOf("Write the topics down and tick the ones you know. Then pick the weakest.", "Do a 25 minute focus block. Say \"study 25\" and I'll guard it 📚", "Test yourself with flashcards instead of re-reading. Say \"quiz me\" 🃏", "Practise past questions, they show what actually gets asked.", "Sleep properly the night before, tired brains forget more.", "Revise the high-weightage topics first."),
            closers = listOf("Which subject is worrying you most?", "How many days are left?", "Want me to help plan the days?", "Which topic feels the shakiest?", "Shall I start a focus timer?"),
            morning = listOf("A calm morning revision session works better than you'd think ☀️"),
            night = listOf("If it's very late, a short revision and sleep beats an all-nighter 🌙")
        ),
        "lazy" to Set(
            openers = listOf("Ha, I know that feeling{n} 😄", "Motivation is overrated{n}.", "Everyone hits this wall{n}.", "No judgement here{n} 👻", "Starting is always the hardest part."),
            reflections = listOf("You don't have to feel like it, you only have to start.", "Five minutes is enough to break the spell.", "Big tasks feel scary, tiny ones don't.", "Discipline is just doing it a little before you're ready.", "Distractions win when the next step is unclear."),
            steps = listOf("Make a deal: just five minutes, then you can stop.", "Put your phone in another room for one focus block.", "Say \"study 25\" and I'll block the distracting apps 📚", "Open the book to the first page and read just one paragraph.", "Pick the easiest task and do it first for momentum.", "Clear your desk, then start with a single question."),
            closers = listOf("What's the smallest thing you could do right now?", "Shall I start a timer?", "What are you avoiding the most?", "Ready for five minutes?", "What would make starting easier?"),
            night = listOf("It's late, if you're wiped, rest and make a plan for the morning instead 🌙")
        ),
        "proud" to Set(
            openers = listOf("Congratulations{n}!! 🎉", "That's amazing{n}! 🥳", "Look at you go{n}! 👏", "I'm so proud of you{n} 💜", "Yesss! Well done{n}!"),
            reflections = listOf("All that effort paid off.", "You earned this, truly.", "That took hard work, and it shows.", "This is a big deal, don't shrink it.", "Not everyone finishes what they start, and you did."),
            steps = listOf("Take a moment to enjoy it properly.", "Tell someone who supported you, they'll love hearing it.", "Treat yourself to something nice today.", "Write it down, you'll want to remember this on tougher days.", "Take a short break before the next thing, you've earned it."),
            closers = listOf("How are you celebrating?", "Tell me how it went!", "What was the best part?", "Who's the first person you told?", "What's next on your list?")
        )
    )

    // ---- detecting the situation ----

    private val I = RegexOption.IGNORE_CASE
    private val detectors: List<Pair<String, Regex>> = listOf(
        "lonely" to Regex("\\b(lonely|so alone|feel alone|feeling alone|no friends|have no one|nobody (cares|talks|likes)|left out|isolated)\\b", I),
        "sad" to Regex("\\b(i'?m|im|i am|feeling|feel|so|really|very|am)\\s+(sad|upset|down|low|unhappy|hurt|heartbroken|miserable)\\b|^sad$|\\b(cried|crying|bad day|rough day|not (okay|ok|fine|good))\\b", I),
        "proud" to Regex("\\b(i (got|passed|cleared|topped|scored|won|finished|completed|submitted|made it)|got (selected|placed|promoted)|good news|i did it|top(ped)? the class)\\b", I),
        "exam" to Regex("\\b(scared|afraid|nervous|worried|panic|panicking|anxious|dar lag|not prepared|unprepared|haven'?t studied|didn'?t study|can'?t study|will fail|going to fail)\\b.*\\b(exam|test|viva|paper|quiz|finals?|backlog|semester)\\b|\\b(exam|test|viva|paper|quiz|finals?)\\b.*\\b(scared|afraid|nervous|worried|panic|anxious|not prepared|unprepared|fail)\\b", I),
        "lazy" to Regex("\\b(procrastinat\\w*|lazy|can'?t focus|cant focus|no motivation|unmotivated|don'?t feel like (studying|working|doing)|not in the mood to study|distracted|aalas|can'?t concentrate)\\b", I),
        "angry" to Regex("\\b(i'?m|im|i am|so|really|very|feeling)\\s+(angry|annoyed|irritated|frustrated|furious|mad|fed up)\\b|\\b(pissed off|so annoying|irritating|gussa|fed up)\\b", I),
        "stressed" to Regex("\\b(stress(ed)?|anxious|anxiety|overwhelm(ed)?|panic|worried|nervous|pressure|tension|too much to do)\\b", I),
        "tired" to Regex("\\b(tired|sleepy|exhausted|drained|no energy|thak(a|i)?)\\b", I),
        "bored" to Regex("\\b(bored|boring|nothing to do|bore ho)\\b", I),
        "happy" to Regex("^(yay+|woo+hoo+)\\b|\\b(i'?m|im|i am|feeling|so|really|very)\\s+(happy|excited|great|awesome|amazing)\\b|\\b(good news|celebrate)\\b", I)
    )

    /** Which situation a short message describes, or null. Long messages are left to the normal chat. */
    fun detect(lower: String): String? {
        if (lower.split(Regex("\\s+")).size > 18) return null
        return detectors.firstOrNull { it.second.containsMatchIn(lower) }?.first
    }

    fun situations(): List<String> = sets.keys.toList()

    // ---- building ----

    private fun pickIndex(list: List<String>, sit: String, kind: String, fb: Feedback?, rnd: Random, avoid: kotlin.collections.Set<Int>): Int {
        val w = list.indices.map { i -> if (i in avoid) 0 else (fb?.weight("$sit:$kind:$i") ?: 1) }
        val total = w.sum()
        if (total <= 0) return rnd.nextInt(list.size)
        var r = rnd.nextInt(total)
        for (i in w.indices) { r -= w[i]; if (r < 0) return i }
        return 0
    }

    private fun fill(s: String, name: String) = s.replace("{n}", if (name.isNotBlank()) ", $name" else "")

    /** [part] is "morning" / "afternoon" / "evening" / "night". */
    fun build(sit: String, name: String, part: String, rnd: Random = Random.Default, fb: Feedback? = null): Result {
        val set = sets[sit] ?: sets["stressed"]!!
        val tip = when (part) { "morning" -> set.morning; "afternoon" -> set.afternoon; "evening" -> set.evening; else -> set.night }
        var last: Result? = null
        repeat(12) {
            val parts = ArrayList<String>()
            val sb = StringBuilder()
            val o = pickIndex(set.openers, sit, "o", fb, rnd, emptySet()); parts.add("$sit:o:$o"); sb.append(fill(set.openers[o], name))
            val r = pickIndex(set.reflections, sit, "r", fb, rnd, emptySet()); parts.add("$sit:r:$r"); sb.append(' ').append(fill(set.reflections[r], name))
            if (tip.isNotEmpty() && rnd.nextInt(100) < 35) {
                sb.append(' ').append(fill(tip[rnd.nextInt(tip.size)], name))
            } else {
                val s = pickIndex(set.steps, sit, "s", fb, rnd, emptySet()); parts.add("$sit:s:$s"); sb.append(' ').append(fill(set.steps[s], name))
            }
            val c = pickIndex(set.closers, sit, "c", fb, rnd, emptySet()); parts.add("$sit:c:$c"); sb.append('\n').append(fill(set.closers[c], name))
            val res = Result(sb.toString(), sit, parts)
            last = res
            if (fb == null || !fb.isBanned(res.text)) return res
        }
        return last!!
    }

    /** [n] different replies for the same situation, none equal to [not] or each other. */
    fun alternatives(sit: String, name: String, part: String, n: Int, not: String, rnd: Random = Random.Default, fb: Feedback? = null): List<Result> {
        val out = ArrayList<Result>()
        var tries = 0
        while (out.size < n && tries++ < 40) {
            val r = build(sit, name, part, rnd, fb)
            if (r.text != not && out.none { it.text == r.text }) out.add(r)
        }
        return out
    }

    fun combinations(sit: String): Long {
        val s = sets[sit] ?: return 0
        return s.openers.size.toLong() * s.reflections.size * s.steps.size * s.closers.size
    }
}
