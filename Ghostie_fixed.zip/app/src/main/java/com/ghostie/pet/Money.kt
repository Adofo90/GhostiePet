package com.ghostie.pet

import android.content.Context
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId

data class Txn(val time: Long, val amount: Double, val debit: Boolean, val merchant: String, val category: String, val source: String)

/** Pure logic (no Android classes): turns a bank/UPI message into a transaction, and does the budget sums. */
object MoneyParser {
    private val amountRe = Regex("(?:rs\\.?|inr|\u20B9)\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)", RegexOption.IGNORE_CASE)
    private val debitRe = Regex("\\b(?:debited|spent|paid|payment|sent|purchase|withdrawn|transferred|dr)\\b", RegexOption.IGNORE_CASE)
    private val creditRe = Regex("\\b(?:credited|received|deposited|refund(?:ed)?)\\b", RegexOption.IGNORE_CASE)
    private val toRe = Regex("\\b(?:to|at|towards)\\s+(?:vpa\\s+)?(.{2,40}?)(?=\\s+(?:on|via|ref|upi|using|from|a/c|acct|txn|utr|has|is|was)\\b|\\s*[(,]|\\.\\s|\\.$|$)", RegexOption.IGNORE_CASE)
    private val fromRe = Regex("\\bfrom\\s+(?:vpa\\s+)?(.{2,40}?)(?=\\s+(?:on|via|ref|upi|using|a/c|acct|txn|utr|has|is|was)\\b|\\s*[(,]|\\.\\s|\\.$|$)", RegexOption.IGNORE_CASE)

    val categories: Map<String, List<String>> = linkedMapOf(
        "Food" to listOf("swiggy", "zomato", "domino", "kfc", "mcdonald", "pizza", "burger", "cafe", "canteen", "restaurant", "bakery", "eatsure", "popeyes", "starbucks", "chai", "tea", "juice", "mess"),
        "Travel" to listOf("uber", "ola", "rapido", "irctc", "redbus", "metro", "fuel", "petrol", "indigo", "makemytrip", "railway", "bus", "auto"),
        "Shopping" to listOf("amazon", "flipkart", "myntra", "meesho", "ajio", "nykaa", "decathlon", "dmart", "blinkit", "zepto", "bigbasket", "instamart", "store", "mart"),
        "Subscriptions" to listOf("netflix", "spotify", "hotstar", "prime", "youtube", "google play", "apple", "jio", "airtel", "recharge", "vodafone"),
        "College" to listOf("fee", "college", "university", "xerox", "print", "stationery", "book", "library", "hostel", "exam"),
        "Bills" to listOf("electricity", "bill", "rent", "wifi", "broadband", "gas")
    )

    fun categorize(merchant: String): String {
        val m = merchant.lowercase()
        for ((cat, keys) in categories) if (keys.any { Regex("\\b" + Regex.escape(it)).containsMatchIn(m) }) return cat
        return "Other"
    }

    private fun cleanMerchant(raw: String): String {
        var m = raw.trim().trimEnd('.', ',', ';', '-')
        val at = m.indexOf('@')
        if (at > 0) m = m.substring(0, at)
        m = m.replace(Regex("[^A-Za-z0-9&' .-]"), " ").replace(Regex("\\s+"), " ").trim()
        return m.take(30)
    }

    /** Messages that mention an amount but are not a payment that happened: bills due, reminders, requests, offers. */
    private val notAPayment = Regex(
        "\\b(?:is due|are due|due on|due today|due by|due date|bill reminder|payment reminder|reminder:|overdue|over due|pay now|pay on|pay via|pay before|to pay|please pay|" +
        "ignore if already paid|ignore if paid|minimum (?:amount )?due|total (?:amount )?due|amount due|bill (?:of|for) rs|bill generated|statement|" +
        "will be debited|will be deducted|scheduled|upcoming|mandate|autopay|auto-pay|requested|requesting|collect request|payment request|" +
        "offer|cashback of|claim|win |won |reward|voucher|coupon|pre-approved|preapproved|eligible|apply now|loan of|get up to|earn )",
        RegexOption.IGNORE_CASE)

    fun parse(text: String, now: Long, source: String): Txn? {
        val t = text.replace('\n', ' ').trim()
        val low = t.lowercase()
        if ("otp" in low || "one time password" in low || "do not share" in low || "verification code" in low) return null
        if (notAPayment.containsMatchIn(t)) return null
        val amount = amountRe.findAll(t).firstOrNull { m ->
            val before = low.substring(maxOf(0, m.range.first - 28), m.range.first)
            !(before.contains("bal") || before.contains("avl") || before.contains("available") || before.contains("limit"))
        }?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() ?: return null
        if (amount <= 0.0) return null
        val debit = debitRe.containsMatchIn(t)
        val credit = creditRe.containsMatchIn(t)
        if (!debit && !credit) return null
        val isDebit = if (debit && credit) (low.contains("debited") || debitRe.find(t)!!.range.first < creditRe.find(t)!!.range.first) else debit
        val raw = (if (isDebit) toRe.find(t) else fromRe.find(t))?.groupValues?.get(1) ?: ""
        val merchant = cleanMerchant(raw).ifBlank { "Unknown" }
        return Txn(now, amount, isDebit, merchant, if (isDebit) categorize(merchant) else "Income", source)
    }

    /** Short "where did this come from" text for a saved source: "sms:VM-KOTAKB" -> "text from VM-KOTAKB". */
    fun sourceText(source: String): String = when {
        source.startsWith("sms:") -> "text from " + source.substring(4)
        source == "sms" -> "a text (sender wasn't saved)"
        source.startsWith("notification:") -> "notification from " + source.substring(13)
        source == "notification" -> "a notification (app wasn't saved)"
        source == "manual" -> "added by you"
        else -> source
    }
    /** Just the sender/app part for tight lists ("VM-KOTAKB"); empty when unknown. */
    fun senderOf(source: String): String = source.substringAfter(':', "").replace('\t', ' ').trim()

    fun format(a: Double): String = if (a == Math.floor(a)) "\u20B9" + a.toLong() else "\u20B9" + "%.2f".format(a)
}

/** Pure budget maths. */
object MoneyMath {
    fun ym(time: Long, zone: ZoneId = ZoneId.systemDefault()): YearMonth = YearMonth.from(Instant.ofEpochMilli(time).atZone(zone))

    fun monthSpent(list: List<Txn>, month: YearMonth, zone: ZoneId = ZoneId.systemDefault()): Double =
        list.filter { it.debit && ym(it.time, zone) == month }.sumOf { it.amount }

    fun byCategory(list: List<Txn>, month: YearMonth, zone: ZoneId = ZoneId.systemDefault()): List<Pair<String, Double>> =
        list.filter { it.debit && ym(it.time, zone) == month }.groupBy { it.category }.map { it.key to it.value.sumOf { t -> t.amount } }.sortedByDescending { it.second }

    /** Category lines for a month: "Food  ₹1,240  42%  ████░░░░░░", biggest first. Empty when nothing was spent. */
    fun breakdown(list: List<Txn>, month: YearMonth, zone: ZoneId = ZoneId.systemDefault()): List<String> {
        val cats = byCategory(list, month, zone)
        val total = cats.sumOf { it.second }
        if (total <= 0) return emptyList()
        return cats.map { (c, v) ->
            val pct = Math.round(v * 100 / total).toInt()
            val bar = "\u2588".repeat((pct / 10).coerceIn(0, 10)) + "\u2591".repeat(10 - (pct / 10).coerceIn(0, 10))
            "$c  ${MoneyParser.format(v)}  $pct%  $bar"
        }
    }

    /** The month's payments in one category (or all when category is null), newest first. */
    fun payments(list: List<Txn>, month: YearMonth, category: String?, zone: ZoneId = ZoneId.systemDefault()): List<Txn> =
        list.filter { it.debit && ym(it.time, zone) == month && (category == null || it.category == category) }.sortedByDescending { it.time }

    /** What is safe to spend per remaining day this month (including today); null with no budget. */
    fun safePerDay(budget: Int, spent: Double, today: java.time.LocalDate): Double? {
        if (budget <= 0) return null
        val daysLeft = today.lengthOfMonth() - today.dayOfMonth + 1
        return maxOf(0.0, budget - spent) / daysLeft
    }

    /** 0 = fine, 80 = passed 80%, 100 = over budget. */
    fun alertLevel(budget: Int, spent: Double): Int = when {
        budget <= 0 -> 0
        spent >= budget -> 100
        spent >= budget * 0.8 -> 80
        else -> 0
    }

    /** Same amount and merchant within 3 minutes counts as the same payment (SMS plus notification). */
    fun isDuplicate(list: List<Txn>, t: Txn): Boolean =
        list.any { it.debit == t.debit && it.amount == t.amount && Math.abs(it.time - t.time) < 3 * 60_000L && (it.merchant.equals(t.merchant, true) || it.merchant == "Unknown" || t.merchant == "Unknown") }
}

/** On-phone list of transactions (amount, merchant, category only; the original message text is never saved). */
object ExpenseStore {
    private const val MAX = 600
    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("ghostie_money", Context.MODE_PRIVATE)

    @Synchronized
    fun all(ctx: Context): List<Txn> = (prefs(ctx).getString("txns", "") ?: "").lines().mapNotNull {
        val p = it.split('\t')
        if (p.size < 6) null else try { Txn(p[0].toLong(), p[1].toDouble(), p[2] == "D", p[4], p[3], p[5]) } catch (e: Exception) { null }
    }

    @Synchronized
    private fun save(ctx: Context, list: List<Txn>) {
        val s = list.takeLast(MAX).joinToString("\n") { listOf(it.time, it.amount, if (it.debit) "D" else "C", it.category, it.merchant.replace('\t', ' '), it.source).joinToString("\t") }
        prefs(ctx).edit().putString("txns", s).apply()
    }

    /** Returns true if saved (false for a duplicate). Raises a budget alert when a limit is crossed. */
    @Synchronized
    fun add(ctx: Context, t: Txn): Boolean {
        val list = all(ctx)
        if (MoneyMath.isDuplicate(list, t)) {
            // already have it: if the saved one doesn't know its sender and this copy does, fill it in
            if (MoneyParser.senderOf(t.source).isNotEmpty()) {
                val i = list.indexOfFirst { it.debit == t.debit && it.amount == t.amount && Math.abs(it.time - t.time) < 3 * 60_000L && MoneyParser.senderOf(it.source).isEmpty() }
                if (i >= 0) save(ctx, list.toMutableList().also { it[i] = it[i].copy(source = t.source) })
            }
            return false
        }
        save(ctx, (list + t).sortedBy { it.time })
        if (t.debit) checkBudget(ctx, list + t)
        return true
    }

    /** Removes one entry (used when something that isn't a payment got in). */
    @Synchronized
    fun remove(ctx: Context, t: Txn) {
        val list = all(ctx).toMutableList()
        val i = list.indexOfFirst { it.time == t.time && it.amount == t.amount && it.merchant == t.merchant && it.debit == t.debit }
        if (i >= 0) { list.removeAt(i); save(ctx, list) }
    }

    @Synchronized
    fun clear(ctx: Context) { prefs(ctx).edit().remove("txns").apply() }

    private fun checkBudget(ctx: Context, list: List<Txn>) {
        val budget = SettingsStore(ctx).monthlyBudget
        val month = YearMonth.now()
        val spent = MoneyMath.monthSpent(list, month)
        val level = MoneyMath.alertLevel(budget, spent)
        val key = "$month:$level"
        if (level == 0 || prefs(ctx).getString("alerted", "") == key) return
        prefs(ctx).edit().putString("alerted", key).apply()
        val left = MoneyParser.format(maxOf(0.0, budget - spent))
        Notifier.post(ctx, if (level == 100) "\uD83D\uDCB8 Over budget" else "\uD83D\uDCB8 80% of your budget used",
            "Spent ${MoneyParser.format(spent)} of ${MoneyParser.format(budget.toDouble())} this month. Left: $left.")
    }

    fun summaryText(ctx: Context): String {
        val s = SettingsStore(ctx)
        val list = all(ctx)
        val month = YearMonth.now()
        val spent = MoneyMath.monthSpent(list, month)
        val sb = StringBuilder("This month you've spent ${MoneyParser.format(spent)}")
        if (s.monthlyBudget > 0) {
            sb.append(" of ${MoneyParser.format(s.monthlyBudget.toDouble())}")
            MoneyMath.safePerDay(s.monthlyBudget, spent, java.time.LocalDate.now())?.let { sb.append(". Safe to spend today: ${MoneyParser.format(Math.floor(it))}") }
        }
        val cats = MoneyMath.byCategory(list, month).take(3)
        if (cats.isNotEmpty()) sb.append("\nTop: " + cats.joinToString(", ") { it.first + " " + MoneyParser.format(it.second) })
        return sb.toString()
    }
}
