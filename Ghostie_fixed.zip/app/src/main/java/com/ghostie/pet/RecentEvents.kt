package com.ghostie.pet

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Events Ghostie added from chat, kept so they can be edited, undone or thrown in the bin. */
object RecentEvents {
    data class Rec(val id: Long, val title: String, val kind: EventKind, val start: Long, val allDay: Boolean, val repeat: String, val durationMin: Int)

    private fun read(ctx: Context): List<Rec> = try {
        val a = JSONArray(SettingsStore(ctx).recentEventsJson)
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Rec(o.getLong("i"), o.getString("t"), EventKind.parse(o.optString("k")) ?: EventKind.EVENT, o.getLong("s"), o.optBoolean("a"), o.optString("r"), o.optInt("d", 60))
        }
    } catch (e: Exception) { emptyList() }

    private fun write(ctx: Context, list: List<Rec>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("i", it.id).put("t", it.title).put("k", it.kind.name).put("s", it.start).put("a", it.allDay).put("r", it.repeat).put("d", it.durationMin)) }
        SettingsStore(ctx).recentEventsJson = a.toString()
    }

    fun list(ctx: Context): List<Rec> = read(ctx)

    fun add(ctx: Context, ev: Command.Event, id: Long) {
        write(ctx, (listOf(Rec(id, ev.title, ev.kind, ev.startMillis, ev.allDay, ev.repeat, ev.durationMin)) + read(ctx)).take(12))
    }

    fun remove(ctx: Context, id: Long) = write(ctx, read(ctx).filter { it.id != id })

    fun toEvent(r: Rec): Command.Event = Command.Event(r.title, r.start, r.kind, r.allDay, r.repeat, r.durationMin, if (r.kind == EventKind.EVENT) listOf(10) else listOf(10))
}
