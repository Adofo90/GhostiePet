package com.ghostie.pet

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator

/**
 * Bottom navigation: a rounded glass bar with a short rounded underline that slides beneath the selected icon.
 * The style constants are kept so saved settings still work, but every style now draws the same clean bar.
 */
class GlassNavBar(
    ctx: Context,
    private val items: List<Pair<String, String>>, // icon, label
    private val style: Int,
    private val pal: Palette,
    private val onSelect: (Int) -> Unit
) : View(ctx) {
    companion object { const val NEON = 1; const val DIP = 2; const val POP = 3 }

    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d
    private var selected = 0
    private var cx = -1f
    private var anim: ValueAnimator? = null

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val icon = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), dp(92f).toInt())

    private fun margin() = dp(14f)
    private fun itemW() = (width - 2 * margin()) / items.size
    private fun centerOf(i: Int) = margin() + itemW() * (i + 0.5f)
    private fun barRect(): RectF {
        val bottom = height - dp(8f)
        return RectF(margin(), bottom - dp(58f), width - margin(), bottom)
    }

    fun select(i: Int, animate: Boolean = true) {
        if (i == selected && cx >= 0) return
        selected = i
        if (width == 0) { cx = -1f; invalidate(); return }
        val from = if (cx < 0) centerOf(i) else cx
        val to = centerOf(i)
        anim?.cancel()
        if (!animate) { cx = to; invalidate(); return }
        anim = ValueAnimator.ofFloat(from, to).apply {
            duration = 240; interpolator = DecelerateInterpolator(1.4f)
            addUpdateListener { cx = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val b = barRect()
            if (e.y >= b.top - dp(8f)) {
                val i = ((e.x - margin()) / itemW()).toInt().coerceIn(0, items.size - 1)
                select(i); onSelect(i); performClick()
            }
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }

    private fun alpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    override fun onDraw(c: Canvas) {
        if (cx < 0) cx = centerOf(selected)
        val b = barRect()
        val rad = b.height() / 2
        val accent = pal.accent
        // Panel colour: the theme's card, kept see-through for glass.
        fill.color = if (pal.glass) pal.card else alpha(pal.card, 0xEE)
        line.strokeWidth = dp(1.2f)
        line.color = if (pal.glass) pal.stroke else alpha(pal.stroke, 0xAA)
        line.clearShadowLayer()

        // One clean rounded bar (the old wavy dip / arch / bubble shapes are gone)
        val path = Path().apply { addRoundRect(b, rad, rad, Path.Direction.CW) }
        c.drawPath(path, fill)
        c.drawPath(path, line)

        // short rounded underline that slides beneath the selected icon
        val uw = dp(22f); val uh = dp(3.5f)
        val uy = b.top + dp(36.5f)
        fill.color = accent
        c.drawRoundRect(RectF(cx - uw / 2, uy - uh / 2, cx + uw / 2, uy + uh / 2), uh / 2, uh / 2, fill)

        // icons and labels
        for ((i, it) in items.withIndex()) {
            val x = centerOf(i)
            val active = i == selected
            icon.textSize = dp(20f)
            icon.color = if (active) accent else pal.text
            icon.alpha = if (active) 255 else 190
            c.drawText(it.first, x, b.top + dp(29f), icon)
            label.textSize = dp(10.5f)
            label.color = if (active) pal.text else pal.sub
            c.drawText(it.second, x, b.bottom - dp(8f), label)
        }
    }
}
