package com.ghostie.pet

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator

/**
 * Bottom navigation drawn in three glassy styles:
 *  NEON - glass pill with a glowing arch and underline over the active tab
 *  DIP  - the bar dips under the active tab and a bubble sits in the dip
 *  POP  - frosted bar with the active tab popping out as a bubble
 */
class GlassNavBar(
    ctx: Context,
    private val items: List<Pair<String, String>>, // icon, label
    private val style: Int,
    private val pal: Palette,
    private val onSelect: (Int) -> Unit
) : View(ctx) {
    companion object { const val NEON = 1; const val DIP = 2; const val POP = 3 }

    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d
    private var selected = 0
    private var cx = -1f
    private var anim: ValueAnimator? = null

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val icon = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), dp(92f).toInt())

    private fun margin() = dp(14f)
    private fun itemW() = (width - 2 * margin()) / items.size
    private fun centerOf(i: Int) = margin() + itemW() * (i + 0.5f)
    private fun barRect(): RectF {
        val bottom = height - dp(8f)
        return RectF(margin(), bottom - dp(58f), width - margin(), bottom)
    }

    fun select(i: Int, animate: Boolean = true) {
        if (i == selected && cx >= 0) return
        selected = i
        if (width == 0) { cx = -1f; invalidate(); return }
        val from = if (cx < 0) centerOf(i) else cx
        val to = centerOf(i)
        anim?.cancel()
        if (!animate) { cx = to; invalidate(); return }
        anim = ValueAnimator.ofFloat(from, to).apply {
            duration = 280; interpolator = DecelerateInterpolator()
            addUpdateListener { cx = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val b = barRect()
            if (e.y >= b.top - dp(30f)) {
                val i = ((e.x - margin()) / itemW()).toInt().coerceIn(0, items.size - 1)
                select(i); onSelect(i); performClick()
            }
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }

    private fun alpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    override fun onDraw(c: Canvas) {
        if (cx < 0) cx = centerOf(selected)
        val b = barRect()
        val rad = b.height() / 2
        val accent = pal.accent
        // Panel colour: the theme's card, kept see-through for glass.
        fill.color = if (pal.glass) pal.card else alpha(pal.card, 0xEE)
        line.strokeWidth = dp(1.2f)
        line.color = if (pal.glass) pal.stroke else alpha(pal.stroke, 0xAA)
        line.clearShadowLayer()

        val path = Path()
        when (style) {
            DIP -> {
                val r = dp(24f); val depth = dp(13f)
                path.moveTo(b.left + rad, b.top)
                path.lineTo(cx - r * 1.7f, b.top)
                path.cubicTo(cx - r, b.top, cx - r, b.top + depth, cx, b.top + depth)
                path.cubicTo(cx + r, b.top + depth, cx + r, b.top, cx + r * 1.7f, b.top)
                path.lineTo(b.right - rad, b.top)
                path.arcTo(RectF(b.right - 2 * rad, b.top, b.right, b.bottom), -90f, 180f)
                path.lineTo(b.left + rad, b.bottom)
                path.arcTo(RectF(b.left, b.top, b.left + 2 * rad, b.bottom), 90f, 180f)
                path.close()
            }
            POP -> {
                val bar = Path().apply { addRoundRect(b, rad, rad, Path.Direction.CW) }
                val bubble = Path().apply { addCircle(cx, b.top - dp(4f), dp(27f), Path.Direction.CW) }
                val neck = Path().apply { addRoundRect(RectF(cx - dp(18f), b.top - dp(6f), cx + dp(18f), b.top + dp(16f)), dp(10f), dp(10f), Path.Direction.CW) }
                path.op(bar, bubble, Path.Op.UNION); path.op(neck, Path.Op.UNION)
            }
            else -> path.addRoundRect(b, rad, rad, Path.Direction.CW)
        }
        c.drawPath(path, fill)
        c.drawPath(path, line)

        if (style == NEON) {
            // glowing arch over the active tab + underline
            val w = itemW() * 0.52f
            val arch = Path().apply {
                moveTo(cx - w, b.top + dp(1f))
                cubicTo(cx - w * 0.5f, b.top + dp(1f), cx - w * 0.6f, b.top - dp(9f), cx, b.top - dp(9f))
                cubicTo(cx + w * 0.6f, b.top - dp(9f), cx + w * 0.5f, b.top + dp(1f), cx + w, b.top + dp(1f))
            }
            glow.color = accent; glow.strokeWidth = dp(2.2f); glow.setShadowLayer(dp(9f), 0f, 0f, accent)
            c.drawPath(arch, glow)
            val ly = b.bottom - dp(7f)
            c.drawLine(cx - itemW() * 0.22f, ly, cx + itemW() * 0.22f, ly, glow)
        }

        // icons and labels
        for ((i, it) in items.withIndex()) {
            val x = centerOf(i)
            val active = i == selected
            val moving = Math.abs(x - cx) < itemW() * 0.5f
            val bubbled = (style == DIP || style == POP) && moving
            if (bubbled) {
                val r = if (style == POP) dp(23f) else dp(20f)
                val cy = if (style == POP) b.top - dp(4f) else b.top - dp(3f)
                fill.color = accent
                fill.setShadowLayer(dp(8f), 0f, dp(2f), alpha(accent, 0x99))
                c.drawCircle(cx, cy, r, fill)
                fill.clearShadowLayer()
                icon.textSize = dp(21f); icon.color = pal.onAccent
                c.drawText(it.first, cx, cy + dp(7f), icon)
            } else {
                icon.textSize = dp(20f)
                icon.color = if (active && style == NEON) accent else pal.text
                icon.alpha = if (active && style == NEON) 255 else 190
                c.drawText(it.first, x, b.top + dp(31f), icon)
            }
            if (!bubbled) {
                label.textSize = dp(10.5f)
                label.color = if (active && style == NEON) pal.text else pal.sub
                c.drawText(it.second, x, b.bottom - dp(9f) - (if (style == NEON) dp(2f) else 0f), label)
            }
        }
    }
}
