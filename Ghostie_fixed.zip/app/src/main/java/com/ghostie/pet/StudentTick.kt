package com.ghostie.pet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.LocalDateTime

/** Runs about every 30 s from the overlay service: silences the phone during class, asks about attendance, nudges about exams. */
object StudentTick {
    private var lastRun = 0L
    private const val CH = "ghostie_student"

    fun tick(ctx: Context) {
        val nowMs = System.currentTimeMillis()
        if (nowMs - lastRun < 30_000L) return
        lastRun = nowMs
        val st = Student.load(ctx)
        val now = LocalDateTime.now()
        var dirty = false

        // Do Not Disturb during class
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.isNotificationPolicyAccessGranted) {
                val inClass = st.dnd && Student.slotAt(st, now) != null
                val cur = nm.currentInterruptionFilter
                if (inClass && !st.dndWeSet && cur == NotificationManager.INTERRUPTION_FILTER_ALL) {
                    st.dndPrev = cur; st.dndWeSet = true; dirty = true
                    nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                } else if (!inClass && st.dndWeSet) {
                    // only undo our own change
                    if (cur == NotificationManager.INTERRUPTION_FILTER_PRIORITY) nm.setInterruptionFilter(st.dndPrev)
                    st.dndWeSet = false; dirty = true
                }
            }
        } catch (e: Exception) { }

        // "Did you attend?" after each class slot
        if (st.autoAsk) {
            for ((i, p, subject) in Student.finishedUnasked(st, now)) {
                st.asked.add("${now.toLocalDate()}|$i"); dirty = true
                ask(ctx, subject, "${now.toLocalDate()}|$i", p.start + "-" + p.end)
            }
        }

        // daily study nudge at 8 am
        val today = now.toLocalDate().toString()
        if (st.nudgeDay != today && now.hour >= 8) {
            st.nudgeDay = today; dirty = true
            Student.studyToday(st, now.toLocalDate())?.let { post(ctx, "Study plan", it, 5001) }
        }
        if (dirty) Student.save(ctx)
    }

    private fun channel(ctx: Context): NotificationManager {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Ghostie student", NotificationManager.IMPORTANCE_DEFAULT))
        return nm
    }

    fun post(ctx: Context, title: String, text: String, id: Int) {
        try {
            val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            channel(ctx).notify(id, Notification.Builder(ctx, CH).setSmallIcon(R.drawable.ghost_pet).setContentTitle(title)
                .setContentText(text).setStyle(Notification.BigTextStyle().bigText(text)).setContentIntent(open).setAutoCancel(true).build())
        } catch (e: Exception) { }
    }

    private fun ask(ctx: Context, subject: String, slot: String, time: String) {
        try {
            val nid = 6000 + (slot.hashCode() and 0xFFF)
            fun act(a: String, code: Int) = PendingIntent.getBroadcast(
                ctx, nid * 4 + code,
                Intent(ctx, AttendanceReceiver::class.java).setAction(a).putExtra("subject", subject).putExtra("nid", nid),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(ctx, CH).setSmallIcon(R.drawable.ghost_pet)
                .setContentTitle("Did you attend $subject?").setContentText("Class $time is over")
                .setContentIntent(open).setAutoCancel(true)
                .addAction(Notification.Action.Builder(null, "Present", act(AttendanceReceiver.PRESENT, 0)).build())
                .addAction(Notification.Action.Builder(null, "Absent", act(AttendanceReceiver.ABSENT, 1)).build())
                .addAction(Notification.Action.Builder(null, "No class", act(AttendanceReceiver.NONE, 2)).build())
                .build()
            channel(ctx).notify(nid, n)
        } catch (e: Exception) { }
    }
}

class AttendanceReceiver : BroadcastReceiver() {
    companion object {
        const val PRESENT = "com.ghostie.pet.ATT_PRESENT"
        const val ABSENT = "com.ghostie.pet.ATT_ABSENT"
        const val NONE = "com.ghostie.pet.ATT_NONE"
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        val subject = intent.getStringExtra("subject") ?: return
        val st = Student.load(ctx)
        when (intent.action) {
            PRESENT -> Student.mark(st, subject, true)
            ABSENT -> Student.mark(st, subject, false)
            else -> { }
        }
        Student.save(ctx)
        try { ctx.getSystemService(NotificationManager::class.java).cancel(intent.getIntExtra("nid", 0)) } catch (e: Exception) { }
    }
}
