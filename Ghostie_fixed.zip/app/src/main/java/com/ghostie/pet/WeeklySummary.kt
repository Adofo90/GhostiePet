package com.ghostie.pet

import android.content.Context
import java.time.LocalDate
import java.time.LocalDateTime

/** Attendance risk and the Sunday summary. The builders are pure (tested on the JVM); [text] and [tick] gather real data. */
object WeeklySummary {
    class Risk(val subject: String, val attended: Int, val total: Int, val pct: Double, val req: Int, val canSkip: Int, val mustAttend: Int)

    /** Subjects that are under the required percentage or exactly on the line, worst first. */
    fun risks(st: Student.State): List<Risk> = st.att.entries.mapNotNull { (sub, r) ->
        if (r[1] == 0) return@mapNotNull null
        val req = Student.reqFor(st, sub)
        val skip = Student.canSkip(r[0], r[1], req)
        if (Student.pct(r[0], r[1]) < req || skip == 0)
            Risk(sub, r[0], r[1], Student.pct(r[0], r[1]), req, skip, Student.mustAttend(r[0], r[1], req))
        else null
    }.sortedBy { it.pct - it.req }

    /** One-line nudge to show shortly before a class of [subject], or null when attendance is comfortable. */
    fun warnLine(st: Student.State, subject: String): String? {
        val r = risks(st).firstOrNull { it.subject.equals(subject, true) } ?: return null
        val subject = r.subject
        val p = "%.0f".format(r.pct)
        return if (r.pct < r.req) "$subject is at $p% (need ${r.req}%). Attend this class and the next ${maxOf(0, r.mustAttend - 1)} in a row to get back."
        else "$subject is right on the line at $p% (need ${r.req}%). Skipping this class would drop you under."
    }

    fun build(
        studyMin: Int, streak: Int, topSubjects: List<Pair<String, Int>>, risks: List<Risk>,
        spent: Double, budget: Int, deadlines: List<Pair<String, Long>>, exams: List<String>, unanswered: Int
    ): String {
        val sb = StringBuilder("📊 Your week\n")
        sb.append("\n📚 Study: ").append(if (studyMin == 0) "no focus time logged" else StudyLog.format(studyMin))
        if (streak > 1) sb.append(" · $streak-day streak")
        if (topSubjects.isNotEmpty()) sb.append("\n   Most: ").append(topSubjects.take(3).joinToString(", ") { it.first.replaceFirstChar { c -> c.uppercase() } + " " + StudyLog.format(it.second) })
        sb.append("\n\n🎓 Attendance: ")
        if (risks.isEmpty()) sb.append("all subjects are safe") else sb.append(risks.take(4).joinToString("; ") { "${it.subject} ${"%.0f".format(it.pct)}% (need ${it.req}%)" })
        if (unanswered > 0) sb.append("\n   $unanswered class(es) still need Present/Absent")
        sb.append("\n\n💸 Spending this month: ").append(MoneyParser.format(spent))
        if (budget > 0) sb.append(" of ").append(MoneyParser.format(budget.toDouble()))
        sb.append("\n\n📅 Coming up: ")
        val items = deadlines.take(4).map { "${it.first} (${dayWord(it.second)})" } + exams.take(3)
        sb.append(if (items.isEmpty()) "nothing due in the next 7 days" else "\n   • " + items.joinToString("\n   • "))
        return sb.toString()
    }

    private fun dayWord(d: Long) = when (d) { 0L -> "today"; 1L -> "tomorrow"; else -> "in $d days" }

    /** The summary with this phone's real data. */
    fun text(ctx: Context, today: LocalDate = LocalDate.now()): String {
        val s = SettingsStore(ctx)
        val st = Student.load(ctx)
        val deadlines = ReminderLog.upcoming(s.logs(), today).map { ReminderLog.label(it) to ReminderLog.daysLeft(it, today) }.filter { it.second <= 7 }
        val exams = Student.upcoming(st, today).filter { Student.daysLeft(it, today) <= 14 }.map { Student.examLine(it, today) }
        val spent = MoneyMath.monthSpent(ExpenseStore.all(ctx), java.time.YearMonth.from(today))
        val unanswered = try { Student.pending(st, LocalDateTime.now()).size } catch (e: Exception) { 0 }
        return build(
            StudyLog.week(s.studyLog, today), StudyLog.streak(s.studyLog, today),
            SubjectLog.bySubject(s.subjectLog, 7, today).entries.sortedByDescending { it.value }.map { it.key to it.value },
            risks(st), spent, s.monthlyBudget, deadlines, exams, unanswered
        )
    }

    /** Called from the student tick: sends the Sunday-evening summary once a week. */
    fun tick(ctx: Context, now: LocalDateTime) {
        val s = SettingsStore(ctx)
        if (!s.weeklySummary || now.dayOfWeek != java.time.DayOfWeek.SUNDAY || now.hour < 18) return
        val key = now.toLocalDate().toString()
        if (s.weeklySent == key) return
        s.weeklySent = key
        StudentTick.post(ctx, "📊 Your week", text(ctx, now.toLocalDate()), 5002)
    }
}
