package com.ghostie.pet

/** Chat apps besides WhatsApp whose messages Ghostie can scan for deadlines (each one is switched on by the user). */
object ChatApps {
    val apps: Map<String, Set<String>> = linkedMapOf(
        "Instagram" to setOf("com.instagram.android"),
        "Telegram" to setOf("org.telegram.messenger", "org.telegram.messenger.web", "org.telegram.plus"),
        "Discord" to setOf("com.discord")
    )

    /** App name for a package, or null if it is not one of the supported chat apps. */
    fun nameFor(pkg: String?): String? = apps.entries.firstOrNull { pkg in it.value }?.key

    fun allPackages(): Set<String> = apps.values.flatten().toSet()

    fun parse(text: String): Set<String> = text.split(',').map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    /** The group label used in reminders, e.g. "Telegram: CSE 3A". */
    fun label(app: String, title: String?): String = if (title.isNullOrBlank()) app else "$app: ${title.trim().take(40)}"
}
