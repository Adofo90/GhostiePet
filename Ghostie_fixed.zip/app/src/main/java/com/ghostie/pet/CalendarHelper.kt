package com.ghostie.pet

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import java.time.Instant
import java.time.ZoneId
import java.util.TimeZone

/** Adds and removes events directly (no calendar form). */
object CalendarHelper {
    fun hasPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED &&
            ctx.checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED

    private fun calendarId(ctx: Context): Long? {
        val cal = CalendarContract.Calendars.CONTENT_URI
        val projection = arrayOf(CalendarContract.Calendars._ID)
        val selection = "${CalendarContract.Calendars.VISIBLE}=1 AND " +
            "${CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL}>=${CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR}"
        ctx.contentResolver.query(cal, projection, selection, null, "${CalendarContract.Calendars.IS_PRIMARY} DESC")?.use { c ->
            if (c.moveToFirst()) return c.getLong(0)
        }
        return null
    }

    /** Returns the new event id, or null if there is no permission or no writable calendar. */
    fun insert(
        ctx: Context, title: String, description: String, startMillis: Long,
        durationMinutes: Int = 30, remindMinutesBefore: List<Int> = listOf(10)
    ): Long? {
        if (!hasPermission(ctx)) return null
        return try {
            val calId = calendarId(ctx) ?: return null
            val values = ContentValues().apply {
                put(CalendarContract.Events.CALENDAR_ID, calId)
                put(CalendarContract.Events.TITLE, title)
                put(CalendarContract.Events.DESCRIPTION, description)
                put(CalendarContract.Events.DTSTART, startMillis)
                put(CalendarContract.Events.DTEND, startMillis + durationMinutes * 60_000L)
                put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
                put(CalendarContract.Events.HAS_ALARM, if (remindMinutesBefore.isEmpty()) 0 else 1)
            }
            val uri = ctx.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values) ?: return null
            val id = ContentUris.parseId(uri)
            for (m in remindMinutesBefore.distinct()) addReminder(ctx, id, m)
            id
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Creates an event the way the phone's own calendar form would: category-specific all-day events,
     * repeat rules (birthdays and anniversaries repeat yearly) and several reminders.
     * Returns the new event id, or null if there is no permission or no writable calendar.
     */
    fun insertEvent(ctx: Context, e: Command.Event, extraDescription: String = ""): Long? {
        if (!hasPermission(ctx)) return null
        return try {
            val calId = calendarId(ctx) ?: return null
            val desc = listOf(e.description, extraDescription).filter { it.isNotBlank() }.joinToString("\n")
            val values = ContentValues().apply {
                put(CalendarContract.Events.CALENDAR_ID, calId)
                put(CalendarContract.Events.TITLE, e.title)
                put(CalendarContract.Events.DESCRIPTION, desc)
                if (e.allDay) {
                    val day = Instant.ofEpochMilli(e.startMillis).atZone(ZoneId.systemDefault()).toLocalDate()
                    val start = day.atStartOfDay(ZoneId.of("UTC")).toInstant().toEpochMilli()
                    put(CalendarContract.Events.DTSTART, start)
                    put(CalendarContract.Events.ALL_DAY, 1)
                    put(CalendarContract.Events.EVENT_TIMEZONE, "UTC")
                    if (e.repeat.isEmpty()) put(CalendarContract.Events.DTEND, start + 86_400_000L)
                    else put(CalendarContract.Events.DURATION, "P1D")
                } else {
                    put(CalendarContract.Events.DTSTART, e.startMillis)
                    put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
                    if (e.repeat.isEmpty()) put(CalendarContract.Events.DTEND, e.startMillis + e.durationMin * 60_000L)
                    else put(CalendarContract.Events.DURATION, "PT${e.durationMin}M")
                }
                if (e.repeat.isNotEmpty()) put(CalendarContract.Events.RRULE, "FREQ=${e.repeat}")
                put(CalendarContract.Events.HAS_ALARM, if (e.remind.isEmpty()) 0 else 1)
            }
            val uri = ctx.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values) ?: return null
            val id = ContentUris.parseId(uri)
            for (m in e.remind.distinct()) addReminder(ctx, id, m)
            id
        } catch (ex: Exception) {
            null
        }
    }

    /** Adds one more alert to an existing event (used for snooze). */
    fun addReminder(ctx: Context, eventId: Long, minutesBefore: Int): Boolean = try {
        val reminder = ContentValues().apply {
            put(CalendarContract.Reminders.EVENT_ID, eventId)
            put(CalendarContract.Reminders.MINUTES, minutesBefore)
            put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
        }
        ctx.contentResolver.insert(CalendarContract.Reminders.CONTENT_URI, reminder) != null
    } catch (e: Exception) {
        false
    }

    fun delete(ctx: Context, eventId: Long) {
        try {
            ctx.contentResolver.delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, eventId), null, null)
        } catch (e: Exception) {
            // ignore: already gone or no permission
        }
    }
}
