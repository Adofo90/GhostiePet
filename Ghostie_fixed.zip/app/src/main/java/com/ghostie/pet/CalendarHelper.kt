package com.ghostie.pet

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import java.util.TimeZone

/** Adds and removes events directly (no calendar form). */
object CalendarHelper {
    fun hasPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED &&
            ctx.checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED

    private fun calendarId(ctx: Context): Long? {
        val cal = CalendarContract.Calendars.CONTENT_URI
        val projection = arrayOf(CalendarContract.Calendars._ID)
        val selection = "${CalendarContract.Calendars.VISIBLE}=1 AND " +
            "${CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL}>=${CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR}"
        ctx.contentResolver.query(cal, projection, selection, null, "${CalendarContract.Calendars.IS_PRIMARY} DESC")?.use { c ->
            if (c.moveToFirst()) return c.getLong(0)
        }
        return null
    }

    /** Returns the new event id, or null if there is no permission or no writable calendar. */
    fun insert(
        ctx: Context, title: String, description: String, startMillis: Long,
        durationMinutes: Int = 30, remindMinutesBefore: Int = 10
    ): Long? {
        if (!hasPermission(ctx)) return null
        return try {
            val calId = calendarId(ctx) ?: return null
            val values = ContentValues().apply {
                put(CalendarContract.Events.CALENDAR_ID, calId)
                put(CalendarContract.Events.TITLE, title)
                put(CalendarContract.Events.DESCRIPTION, description)
                put(CalendarContract.Events.DTSTART, startMillis)
                put(CalendarContract.Events.DTEND, startMillis + durationMinutes * 60_000L)
                put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
                put(CalendarContract.Events.HAS_ALARM, 1)
            }
            val uri = ctx.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values) ?: return null
            val id = ContentUris.parseId(uri)
            val reminder = ContentValues().apply {
                put(CalendarContract.Reminders.EVENT_ID, id)
                put(CalendarContract.Reminders.MINUTES, remindMinutesBefore)
                put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
            }
            ctx.contentResolver.insert(CalendarContract.Reminders.CONTENT_URI, reminder)
            id
        } catch (e: Exception) {
            null
        }
    }

    fun delete(ctx: Context, eventId: Long) {
        try {
            ctx.contentResolver.delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, eventId), null, null)
        } catch (e: Exception) {
            // ignore: already gone or no permission
        }
    }
}
