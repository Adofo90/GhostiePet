package com.ghostie.pet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator

/** "Ghostie calls me": rings like an incoming call when a chosen person/group keeps messaging or says something urgent. */
object CallAlerts {
    const val NOTIF_ID = 4242
    const val CHANNEL = "ghostie_call"
    private var detector: RepeatDetector? = null
    private var ringtone: Ringtone? = null
    private val main = Handler(Looper.getMainLooper())
    private val stopper = Runnable { stopRing(appCtx) }
    private var appCtx: Context? = null

    @Synchronized
    private fun detector(s: SettingsStore): RepeatDetector {
        val d = detector ?: RepeatDetector().also { detector = it }
        d.count = s.callCount
        d.windowMin = s.callWindow
        d.urgent = RepeatDetector.parseWords(s.callUrgent)
        return d
    }

    /** True if this chat or sender is on the user's list. */
    fun isVip(s: SettingsStore, chat: String, sender: String): Boolean = s.callVipList().any { v ->
        chat.contains(v, true) || v.contains(chat, true) && chat.length > 2 || sender.isNotEmpty() && sender.contains(v, true)
    }

    data class Msg(val sender: String, val text: String, val time: Long)

    /** Called by the notification watcher for every WhatsApp notification. */
    fun onMessages(ctx: Context, s: SettingsStore, chat: String, msgs: List<Msg>) {
        if (!s.callEnabled || msgs.isEmpty()) return
        if (LearnStore.get(ctx).isBlocked("call", chat)) return
        for (m in msgs) {
            if (!isVip(s, chat, m.sender)) continue
            if (!s.markSeen(("call|" + chat + "|" + m.sender + "|" + m.text + "|" + m.time).hashCode())) continue
            val who = m.sender.ifBlank { chat }
            val hit = synchronized(this) { detector(s).onMessage("$chat|$who", m.text, System.currentTimeMillis()) } ?: continue
            ring(ctx, chat, who, m.text, hit)
            return
        }
    }

    fun reasonText(chat: String, who: String, hit: RepeatDetector.Hit): String {
        val name = if (who == chat || who.isBlank()) chat else "$who in $chat"
        return if (hit.reason == RepeatDetector.Reason.URGENT) "$name sent something urgent"
        else "$name has messaged you ${hit.messages} times"
    }

    fun ring(ctx: Context, chat: String, who: String, preview: String, hit: RepeatDetector.Hit) {
        val headline = reasonText(chat, who, hit)
        ActivityLog.add(ctx, "Call", headline)
        show(ctx, chat, headline, preview)
    }

    /** Shows the incoming-call screen + notification and starts ringing. */
    fun show(ctx: Context, chat: String, headline: String, preview: String) {
        appCtx = ctx.applicationContext
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL, "Ghostie calls", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        ch.enableVibration(false)
        nm.createNotificationChannel(ch)

        fun screen(answer: Boolean, code: Int) = PendingIntent.getActivity(
            ctx, code,
            Intent(ctx, CallAlertActivity::class.java)
                .putExtra("chat", chat).putExtra("headline", headline).putExtra("preview", preview).putExtra("answer", answer)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        fun act(action: String, code: Int) = PendingIntent.getBroadcast(
            ctx, code,
            Intent(ctx, CallActionReceiver::class.java).setAction(action).putExtra("chat", chat),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ghost_pet)
            .setContentTitle("👻 Ghostie calling")
            .setContentText(headline)
            .setStyle(Notification.BigTextStyle().bigText(headline + "\n" + preview.take(200)))
            .setCategory(Notification.CATEGORY_CALL)
            .setOngoing(true)
            .setTimeoutAfter(50_000)
            .setFullScreenIntent(screen(false, 1), true)
            .setContentIntent(screen(false, 2))
            .addAction(Notification.Action.Builder(null, "Answer", screen(true, 3)).build())
            .addAction(Notification.Action.Builder(null, "Dismiss", act(CallActionReceiver.DISMISS, 4)).build())
            .addAction(Notification.Action.Builder(null, "🗑 Never", act(CallActionReceiver.TRASH, 5)).build())
            .build()
        nm.notify(NOTIF_ID, n)
        startRing(ctx)
        // Also try to open the call screen directly (works when Ghostie's overlay permission lets it start from the background).
        try {
            ctx.startActivity(
                Intent(ctx, CallAlertActivity::class.java)
                    .putExtra("chat", chat).putExtra("headline", headline).putExtra("preview", preview)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
        } catch (e: Exception) { }
    }

    @Synchronized
    fun startRing(ctx: Context) {
        stopRing(ctx)
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val r = RingtoneManager.getRingtone(ctx, uri)
            r.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            r.isLooping = true
            r.play()
            ringtone = r
        } catch (e: Exception) { }
        try {
            val v = ctx.getSystemService(Vibrator::class.java)
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 500, 700, 1200), 0))
        } catch (e: Exception) { }
        main.removeCallbacks(stopper)
        main.postDelayed(stopper, 45_000)
    }

    @Synchronized
    fun stopRing(ctx: Context?) {
        main.removeCallbacks(stopper)
        try { ringtone?.stop() } catch (e: Exception) { }
        ringtone = null
        try { ctx?.getSystemService(Vibrator::class.java)?.cancel() } catch (e: Exception) { }
    }

    fun cancel(ctx: Context) {
        stopRing(ctx)
        ctx.getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
    }

    /** Teaches Ghostie never to ring for this chat again. */
    fun mute(ctx: Context, chat: String) {
        LearnStore.get(ctx).block("call", chat)
        LearnStore.save(ctx)
        ActivityLog.add(ctx, "Call", "Won't ring for \"$chat\" any more")
    }
}
