package com.ghostie.pet

import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.Inflater
import java.util.zip.ZipInputStream

/** Pulls the first few lines of text out of PDF / Word / PowerPoint / text files, with no libraries. */
object DocText {
    private const val MAX_BYTES = 12 * 1024 * 1024

    fun sample(file: File, maxChars: Int = 2500): String = try {
        if (!file.isFile || file.length() > MAX_BYTES) ""
        else when (file.extension.lowercase()) {
            "pdf" -> PdfText.extract(file.readBytes(), maxChars)
            "docx" -> zipXmlText(file, listOf("word/document.xml"), Regex("<w:t[^>]*>(.*?)</w:t>"), maxChars)
            "pptx" -> zipXmlText(file, (1..4).map { "ppt/slides/slide$it.xml" }, Regex("<a:t>(.*?)</a:t>"), maxChars)
            "txt" -> file.readText().take(maxChars)
            else -> ""
        }
    } catch (e: Exception) {
        ""
    }

    private fun decodeXml(s: String) =
        s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'")

    private fun zipXmlText(file: File, names: List<String>, textTag: Regex, maxChars: Int): String {
        val out = StringBuilder()
        ZipInputStream(file.inputStream().buffered()).use { zin ->
            while (out.length < maxChars) {
                val e = zin.nextEntry ?: break
                if (e.name !in names) continue
                val xml = String(zin.readBytes(), Charsets.UTF_8).replace("</w:p>", "\n").replace("</a:p>", "\n")
                textTag.findAll(xml).forEach { out.append(decodeXml(it.groupValues[1])).append(' ') }
            }
        }
        return out.toString().take(maxChars)
    }
}

object PdfText {
    private val textOps = Regex(
        "\\[((?:[^\\]\\\\]|\\\\.)*)\\]\\s*TJ|\\(((?:\\\\.|[^\\\\()])*)\\)\\s*(?:Tj|'|\")|\\b(?:T\\*|Td|TD|ET)\\b"
    )
    private val piece = Regex("\\(((?:\\\\.|[^\\\\()])*)\\)|(-?\\d+(?:\\.\\d+)?)")

    private fun unescape(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                val n = s[i + 1]
                when {
                    n == 'n' -> { sb.append('\n'); i += 2 }
                    n == 'r' || n == 't' -> { sb.append(' '); i += 2 }
                    n in '0'..'7' -> {
                        var j = i + 1
                        var v = 0
                        while (j < s.length && j < i + 4 && s[j] in '0'..'7') { v = v * 8 + (s[j] - '0'); j++ }
                        sb.append(v.toChar()); i = j
                    }
                    else -> { sb.append(n); i += 2 }
                }
            } else { sb.append(c); i++ }
        }
        return sb.toString()
    }

    private fun ascii85(data: ByteArray): ByteArray? = try {
        val out = ByteArrayOutputStream()
        val grp = LongArray(5)
        var n = 0
        var done = false
        for (b in data) {
            val c = b.toInt() and 0xFF
            if (done) break
            when {
                c == '~'.code -> done = true
                c <= 32 || c == '<'.code && false -> {}
                c == 'z'.code && n == 0 -> out.write(ByteArray(4))
                c in 33..117 -> {
                    grp[n++] = (c - 33).toLong()
                    if (n == 5) {
                        var v = 0L
                        for (g in grp) v = v * 85 + g
                        for (k in 3 downTo 0) out.write(((v shr (8 * k)) and 0xFF).toInt())
                        n = 0
                    }
                }
            }
        }
        if (n > 1) {
            for (k in n until 5) grp[k] = 84
            var v = 0L
            for (g in grp) v = v * 85 + g
            for (k in 3 downTo (5 - n)) out.write(((v shr (8 * k)) and 0xFF).toInt())
        }
        out.toByteArray()
    } catch (e: Exception) {
        null
    }

    private fun inflate(data: ByteArray): ByteArray? = try {
        val inf = Inflater()
        inf.setInput(data)
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (!inf.finished() && out.size() < 4_000_000) {
            val n = inf.inflate(buf)
            if (n == 0 && (inf.needsInput() || inf.needsDictionary())) break
            out.write(buf, 0, n)
        }
        inf.end()
        out.toByteArray()
    } catch (e: Exception) {
        null
    }

    private fun readText(content: String): String {
        val sb = StringBuilder()
        for (m in textOps.findAll(content)) {
            val arr = m.groups[1]?.value
            val str = m.groups[2]?.value
            when {
                arr != null -> for (p in piece.findAll(arr)) {
                    val s = p.groups[1]?.value
                    if (s != null) sb.append(unescape(s))
                    else if ((p.groups[2]?.value?.toDoubleOrNull() ?: 0.0) < -200) sb.append(' ')
                }
                str != null -> sb.append(unescape(str))
                else -> sb.append(' ')
            }
        }
        return sb.toString()
    }

    fun extract(bytes: ByteArray, maxChars: Int = 2500): String {
        val s = String(bytes, Charsets.ISO_8859_1)
        if (s.contains("/Encrypt")) return ""
        val out = StringBuilder()
        var pos = 0
        var streams = 0
        while (out.length < maxChars && streams < 60) {
            val si = s.indexOf("stream", pos)
            if (si < 0) break
            if (si >= 3 && s.startsWith("end", si - 3)) { pos = si + 6; continue }
            var ds = si + 6
            if (s.startsWith("\r\n", ds)) ds += 2 else if (ds < s.length && (s[ds] == '\n' || s[ds] == '\r')) ds += 1
            val ei = s.indexOf("endstream", ds)
            if (ei < 0) break
            val dict = s.substring(maxOf(0, s.lastIndexOf("obj", si)), si)
            pos = ei + 9
            streams++
            if (dict.contains("/Image") || dict.contains("DCTDecode") || dict.contains("/XRef") || dict.contains("/ObjStm") || dict.contains("/FontFile")) continue
            var raw: ByteArray? = bytes.copyOfRange(ds, ei)
            if (dict.contains("ASCII85Decode")) raw = raw?.let { ascii85(it) }
            val content = if (raw != null && dict.contains("FlateDecode")) inflate(raw) else raw
            if (content == null) continue
            val text = String(content, Charsets.ISO_8859_1)
            if (!text.contains("BT") || !(text.contains("Tj") || text.contains("TJ"))) continue
            out.append(readText(text)).append('\n')
        }
        val result = out.toString().replace(Regex("[ \\t]+"), " ").replace(Regex("\\n\\s*\\n+"), "\n").trim().take(maxChars)
        return if (result.count { it.isLetter() } < 20) "" else result
    }
}
