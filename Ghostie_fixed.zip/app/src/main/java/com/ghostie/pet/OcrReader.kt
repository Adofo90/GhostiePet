package com.ghostie.pet

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** Reads the text in a photo on the phone (Google ML Kit, bundled model, no internet). Only place that touches ML Kit. */
object OcrReader {
    fun read(ctx: Context, uri: Uri, done: (List<TimetableOcr.Box>?) -> Unit) {
        try {
            val image = InputImage.fromFilePath(ctx, uri)
            val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            rec.process(image)
                .addOnSuccessListener { res ->
                    val boxes = ArrayList<TimetableOcr.Box>()
                    for (b in res.textBlocks) for (l in b.lines) {
                        val r = l.boundingBox ?: continue
                        if (l.text.isNotBlank()) boxes.add(TimetableOcr.Box(l.text, r.left, r.top, r.right, r.bottom))
                    }
                    rec.close(); done(boxes)
                }
                .addOnFailureListener { rec.close(); done(null) }
        } catch (e: Exception) {
            done(null)
        }
    }
}
