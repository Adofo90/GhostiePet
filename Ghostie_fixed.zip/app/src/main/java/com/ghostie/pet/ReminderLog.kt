package com.ghostie.pet

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject

data class LogEntry(val time: Long, val group: String, val title: String, val due: String, val eventId: Long, val start: Long = 0L, val msg: String = "")

object ReminderLog {
    fun read(json: String): List<LogEntry> = try {
        val a = JSONArray(json)
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            LogEntry(o.getLong("t"), o.getString("g"), o.getString("ti"), o.getString("d"), o.getLong("e"), o.optLong("s", 0L), o.optString("m", ""))
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun write(list: List<LogEntry>): String {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("t", it.time).put("g", it.group).put("ti", it.title).put("d", it.due).put("e", it.eventId).put("s", it.start).put("m", it.msg)) }
        return a.toString()
    }

    fun dueDate(e: LogEntry): LocalDate? = try { LocalDate.parse(e.due) } catch (ex: Exception) { null }

    fun isRegistration(e: LogEntry): Boolean = e.title.startsWith("📝")

    /** The subject / summary part of the saved title ("📌 Submission due tomorrow: DBMS" -> "DBMS"). */
    fun label(e: LogEntry): String = e.title.substringAfter(": ", e.title)

    /** Entries whose deadline hasn't passed, soonest first. */
    fun upcoming(all: List<LogEntry>, today: LocalDate = LocalDate.now()): List<LogEntry> =
        all.filter { val d = dueDate(it); d != null && !d.isBefore(today) }.sortedBy { dueDate(it) }

    fun daysLeft(e: LogEntry, today: LocalDate = LocalDate.now()): Long =
        dueDate(e)?.let { ChronoUnit.DAYS.between(today, it) } ?: 999L

    fun dueLabel(e: LogEntry, today: LocalDate = LocalDate.now()): String {
        val d = dueDate(e) ?: return e.due
        val days = ChronoUnit.DAYS.between(today, d)
        val date = d.format(DateTimeFormatter.ofPattern("EEE d MMM", Locale.ENGLISH))
        return when (days) {
            0L -> "Due TODAY"
            1L -> "Due tomorrow ($date)"
            else -> "Due $date - in $days days"
        }
    }
}
