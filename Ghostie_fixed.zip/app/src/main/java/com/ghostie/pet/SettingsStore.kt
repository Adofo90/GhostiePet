package com.ghostie.pet

import android.content.Context

class SettingsStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("ghostie", Context.MODE_PRIVATE)
    private val secure = CryptoStore(ctx)

    var enabled: Boolean
        get() = p.getBoolean("enabled", true)
        set(v) = p.edit().putBoolean("enabled", v).apply()
    var visitMinutes: Int
        get() = p.getInt("visit", 5)
        set(v) = p.edit().putInt("visit", v).apply()
    var waterMinutes: Int
        get() = p.getInt("water", 30)
        set(v) = p.edit().putInt("water", v).apply()
    var checkins: Boolean
        get() = p.getBoolean("checkins", true)
        set(v) = p.edit().putBoolean("checkins", v).apply()
    var sound: Boolean
        get() = p.getBoolean("sound", false)
        set(v) = p.edit().putBoolean("sound", v).apply()
    var animSpeed: Float
        get() = p.getFloat("speed", 1f)
        set(v) = p.edit().putFloat("speed", v).apply()
    var petSize: Int
        get() = p.getInt("size", 260)
        set(v) = p.edit().putInt("size", v).apply()
    var ai: Boolean
        get() = p.getBoolean("ai", false)
        set(v) = p.edit().putBoolean("ai", v).apply()
    var key: String
        get() = secure.read()
        set(v) = secure.save(v)
    var alwaysTop: Boolean
        get() = p.getBoolean("top", true)
        set(v) = p.edit().putBoolean("top", v).apply()
    var quietUntil: Long
        get() = p.getLong("quiet", 0L)
        set(v) = p.edit().putLong("quiet", v).apply()
    var x: Int
        get() = p.getInt("x", -1)
        set(v) = p.edit().putInt("x", v).apply()
    var y: Int
        get() = p.getInt("y", -1)
        set(v) = p.edit().putInt("y", v).apply()

    var subjects: String
        get() = p.getString("subjects", null)?.takeIf { it.isNotBlank() } ?: SubjectMatcher.DEFAULT_SUBJECTS
        set(v) = p.edit().putString("subjects", v.trim()).apply()

    var userName: String
        get() = p.getString("uname", "") ?: ""
        set(v) = p.edit().putString("uname", v).apply()
    var watchEnabled: Boolean
        get() = p.getBoolean("watch", true)
        set(v) = p.edit().putBoolean("watch", v).apply()
    /** One group name per line. A notification matches if its title contains the name (ignoring case). */
    var watchedGroups: String
        get() = p.getString("groups", "") ?: ""
        set(v) = p.edit().putString("groups", v.trim()).apply()
    private var logJson: String
        get() = p.getString("rlog", "[]") ?: "[]"
        set(v) = p.edit().putString("rlog", v).apply()

    fun watchedGroupList(): List<String> = watchedGroups.lines().map { it.trim() }.filter { it.isNotEmpty() }

    fun addWatchedGroup(name: String) {
        if (watchedGroupList().none { it.equals(name, true) }) {
            watchedGroups = (watchedGroups + "\n" + name).trim()
        }
    }

    fun logs(): List<LogEntry> = ReminderLog.read(logJson)
    fun addLog(e: LogEntry) {
        logJson = ReminderLog.write((listOf(e) + logs()).take(20))
    }
    fun removeLog(eventId: Long) {
        logJson = ReminderLog.write(logs().filter { it.eventId != eventId })
    }

    /** Remembers message fingerprints so the same WhatsApp message is only handled once. Returns false if already seen. */
    fun markSeen(hash: Int): Boolean {
        val seen = (p.getString("seen", "") ?: "").split(',').filter { it.isNotEmpty() }
        if (seen.contains(hash.toString())) return false
        p.edit().putString("seen", (seen + hash.toString()).takeLast(300).joinToString(",")).apply()
        return true
    }

    fun resetPosition() {
        p.edit().remove("x").remove("y").apply()
    }
}
