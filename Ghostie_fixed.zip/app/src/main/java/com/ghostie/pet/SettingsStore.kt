package com.ghostie.pet

import android.content.Context

class SettingsStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("ghostie", Context.MODE_PRIVATE)
    private val secure = CryptoStore(ctx)

    var enabled: Boolean
        get() = p.getBoolean("enabled", true)
        set(v) = p.edit().putBoolean("enabled", v).apply()
    var visitMinutes: Int
        get() = p.getInt("visit", 5)
        set(v) = p.edit().putInt("visit", v).apply()
    var waterMinutes: Int
        get() = p.getInt("water", 30)
        set(v) = p.edit().putInt("water", v).apply()
    var checkins: Boolean
        get() = p.getBoolean("checkins", true)
        set(v) = p.edit().putBoolean("checkins", v).apply()
    var sound: Boolean
        get() = p.getBoolean("sound", true)
        set(v) = p.edit().putBoolean("sound", v).apply()
    var animSpeed: Float
        get() = p.getFloat("speed", 1f)
        set(v) = p.edit().putFloat("speed", v).apply()
    var petSize: Int
        get() = p.getInt("size", 260)
        set(v) = p.edit().putInt("size", v).apply()
    var ai: Boolean
        get() = p.getBoolean("ai", false)
        set(v) = p.edit().putBoolean("ai", v).apply()
    var key: String
        get() = secure.read()
        set(v) = secure.save(v)
    var alwaysTop: Boolean
        get() = p.getBoolean("top", true)
        set(v) = p.edit().putBoolean("top", v).apply()
    var quietUntil: Long
        get() = p.getLong("quiet", 0L)
        set(v) = p.edit().putLong("quiet", v).apply()
    var x: Int
        get() = p.getInt("x", -1)
        set(v) = p.edit().putInt("x", v).apply()
    var y: Int
        get() = p.getInt("y", -1)
        set(v) = p.edit().putInt("y", v).apply()

    var subjects: String
        get() = p.getString("subjects", null)?.takeIf { it.isNotBlank() } ?: SubjectMatcher.DEFAULT_SUBJECTS
        set(v) = p.edit().putString("subjects", v.trim()).apply()

    var userName: String
        get() = p.getString("uname", "") ?: ""
        set(v) = p.edit().putString("uname", v).apply()
    /** Ghost size in dp. */
    var petDp: Int
        get() = p.getInt("size_dp", 96)
        set(v) = p.edit().putInt("size_dp", v).apply()
    var sleepEnabled: Boolean
        get() = p.getBoolean("sleep", true)
        set(v) = p.edit().putBoolean("sleep", v).apply()
    var remind2d: Boolean
        get() = p.getBoolean("rem2d", false)
        set(v) = p.edit().putBoolean("rem2d", v).apply()
    var remindMorning: Boolean
        get() = p.getBoolean("remam", true)
        set(v) = p.edit().putBoolean("remam", v).apply()
    var autoOrganize: Boolean
        get() = p.getBoolean("autoorg", true)
        set(v) = p.edit().putBoolean("autoorg", v).apply()

    /** file name -> WhatsApp chat it arrived in (learned from notifications / open chats). */
    fun rememberDoc(file: String, group: String) {
        val key = file.trim().lowercase()
        val lines = (p.getString("docgroups", "") ?: "").lines().filter { it.isNotBlank() && it.substringBefore('\t') != key }
        p.edit().putString("docgroups", (lines + (key + "\t" + group)).takeLast(400).joinToString("\n")).apply()
    }

    fun groupOfDoc(file: String): String? {
        val key = file.trim().lowercase()
        val plain = key.replace(Regex(" \\(\\d+\\)(?=\\.[^.]+$)"), "")
        val lines = (p.getString("docgroups", "") ?: "").lines()
        return lines.lastOrNull { it.substringBefore('\t') == key || it.substringBefore('\t') == plain }?.substringAfter('\t', "")?.ifEmpty { null }
    }

    fun loadProcessedDocs(): MutableSet<String> =
        (p.getString("docsdone", "") ?: "").split('\n').filter { it.isNotEmpty() }.toMutableSet()

    fun saveProcessedDocs(set: Set<String>) {
        p.edit().putString("docsdone", set.toList().takeLast(5000).joinToString("\n")).apply()
    }

    var watchEnabled: Boolean
        get() = p.getBoolean("watch", true)
        set(v) = p.edit().putBoolean("watch", v).apply()
    /** One group name per line. A notification matches if its title contains the name (ignoring case). */
    var watchedGroups: String
        get() = p.getString("groups", "") ?: ""
        set(v) = p.edit().putString("groups", v.trim()).apply()
    private var logJson: String
        get() = p.getString("rlog", "[]") ?: "[]"
        set(v) = p.edit().putString("rlog", v).apply()

    fun watchedGroupList(): List<String> = watchedGroups.lines().map { it.trim() }.filter { it.isNotEmpty() }

    fun addWatchedGroup(name: String) {
        if (watchedGroupList().none { it.equals(name, true) }) {
            watchedGroups = (watchedGroups + "\n" + name).trim()
        }
    }

    fun logs(): List<LogEntry> = ReminderLog.read(logJson)
    fun addLog(e: LogEntry) {
        logJson = ReminderLog.write((listOf(e) + logs()).take(20))
    }
    fun removeLog(eventId: Long) {
        logJson = ReminderLog.write(logs().filter { it.eventId != eventId })
    }

    /** Remembers message fingerprints so the same WhatsApp message is only handled once. Returns false if already seen. */
    fun markSeen(hash: Int): Boolean {
        val seen = (p.getString("seen", "") ?: "").split(',').filter { it.isNotEmpty() }
        if (seen.contains(hash.toString())) return false
        p.edit().putString("seen", (seen + hash.toString()).takeLast(300).joinToString(",")).apply()
        return true
    }

    fun resetPosition() {
        p.edit().remove("x").remove("y").apply()
    }

    var speak: Boolean
        get() = p.getBoolean("speak", true)
        set(v) = p.edit().putBoolean("speak", v).apply()

    /** Voice pitch x10: 18 squeaky, 14 cute, 10 normal. */
    var voicePitch: Int
        get() = p.getInt("voice_pitch", 14)
        set(v) = p.edit().putInt("voice_pitch", v).apply()

    /** Last open tab in the app. */
    var tab: String
        get() = p.getString("tab", "home") ?: "home"
        set(v) = p.edit().putString("tab", v).apply()

    /** Learn words from watched groups and shared chats (other people's words stay on this phone). */
    var learnGroups: Boolean
        get() = p.getBoolean("learn_groups", true)
        set(v) = p.edit().putBoolean("learn_groups", v).apply()

    /** Everything the learner remembers (kept on this phone only). */
    var learnData: String
        get() = p.getString("learn_data", "") ?: ""
        set(v) = p.edit().putString("learn_data", v).apply()

    /** "en" or "hi": spoken/typed language for voice input and Ghostie's voice. */
    var language: String
        get() = p.getString("lang", "en") ?: "en"
        set(v) = p.edit().putString("lang", v).apply()
    val speechTag: String get() = if (language == "hi") "hi-IN" else "en-IN"

    var chatCount: Int
        get() = p.getInt("chat_count", 0)
        set(v) = p.edit().putInt("chat_count", v).apply()
    var skin: String
        get() = p.getString("skin", "classic") ?: "classic"
        set(v) = p.edit().putString("skin", v).apply()

    /** One rule per line: "CS Group: ignore lunch, party, trip". Messages with those words are never turned into deadlines. */
    var groupRules: String
        get() = p.getString("group_rules", "") ?: ""
        set(v) = p.edit().putString("group_rules", v.trim()).apply()
    fun isIgnoredByRule(group: String, text: String): Boolean {
        val l = text.lowercase()
        for (line in groupRules.lines()) {
            val name = line.substringBefore(':').trim()
            val rest = line.substringAfter(':', "").trim()
            if (name.isEmpty() || rest.isEmpty()) continue
            if (!(group.contains(name, true) || name == "*" || name.equals("all", true))) continue
            val words = rest.removePrefix("ignore").trim().split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            if (words.any { l.contains(it) }) return true
        }
        return false
    }

    var recentEventsJson: String
        get() = p.getString("recent_events", "[]") ?: "[]"
        set(v) = p.edit().putString("recent_events", v).apply()

    var aiProvider: String
        get() = p.getString("ai_provider", "groq") ?: "groq"
        set(v) = p.edit().putString("ai_provider", v).apply()
    var aiBase: String
        get() = p.getString("ai_base", null)?.takeIf { it.isNotBlank() } ?: ChatEngine.provider(aiProvider).base
        set(v) = p.edit().putString("ai_base", v.trim()).apply()
    var aiModel: String
        get() = p.getString("ai_model", null)?.takeIf { it.isNotBlank() } ?: ChatEngine.provider(aiProvider).model
        set(v) = p.edit().putString("ai_model", v.trim()).apply()

    // ---- "Ghostie calls me" ----
    var callEnabled: Boolean
        get() = p.getBoolean("call_on", false)
        set(v) = p.edit().putBoolean("call_on", v).apply()
    /** One person or group per line - only these can ring. */
    var callVips: String
        get() = p.getString("call_vips", "") ?: ""
        set(v) = p.edit().putString("call_vips", v.trim()).apply()
    var callCount: Int
        get() = p.getInt("call_count", 3)
        set(v) = p.edit().putInt("call_count", v).apply()
    var callWindow: Int
        get() = p.getInt("call_window", 5)
        set(v) = p.edit().putInt("call_window", v).apply()
    var callUrgent: String
        get() = p.getString("call_urgent", null)?.takeIf { it.isNotBlank() } ?: RepeatDetector.DEFAULT_URGENT
        set(v) = p.edit().putString("call_urgent", v.trim()).apply()
    fun callVipList(): List<String> = callVips.lines().map { it.trim() }.filter { it.isNotEmpty() }

    /** Documents thrown in the bin: automatic sorting will not copy them back. */
    fun binnedDocs(): Set<String> = (p.getString("binned_docs", "") ?: "").split('\n').filter { it.isNotEmpty() }.toSet()
    fun addBinnedDoc(name: String) {
        p.edit().putString("binned_docs", (binnedDocs() + name).toList().takeLast(300).joinToString("\n")).apply()
    }
}
