package com.ghostie.pet

import android.content.Context

class SettingsStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("ghostie", Context.MODE_PRIVATE)
    private val secure = CryptoStore(ctx)

    var enabled: Boolean
        get() = p.getBoolean("enabled", true)
        set(v) = p.edit().putBoolean("enabled", v).apply()
    var visitMinutes: Int
        get() = p.getInt("visit", 5)
        set(v) = p.edit().putInt("visit", v).apply()
    var waterMinutes: Int
        get() = p.getInt("water", 30)
        set(v) = p.edit().putInt("water", v).apply()
    var checkins: Boolean
        get() = p.getBoolean("checkins", true)
        set(v) = p.edit().putBoolean("checkins", v).apply()
    var sound: Boolean
        get() = p.getBoolean("sound", true)
        set(v) = p.edit().putBoolean("sound", v).apply()
    var animSpeed: Float
        get() = p.getFloat("speed", 1f)
        set(v) = p.edit().putFloat("speed", v).apply()
    var petSize: Int
        get() = p.getInt("size", 260)
        set(v) = p.edit().putInt("size", v).apply()
    var ai: Boolean
        get() = p.getBoolean("ai", false)
        set(v) = p.edit().putBoolean("ai", v).apply()
    var key: String
        get() = secure.read()
        set(v) = secure.save(v)
    var alwaysTop: Boolean
        get() = p.getBoolean("top", true)
        set(v) = p.edit().putBoolean("top", v).apply()
    var quietUntil: Long
        get() = p.getLong("quiet", 0L)
        set(v) = p.edit().putLong("quiet", v).apply()
    var x: Int
        get() = p.getInt("x", -1)
        set(v) = p.edit().putInt("x", v).apply()
    var y: Int
        get() = p.getInt("y", -1)
        set(v) = p.edit().putInt("y", v).apply()

    var subjects: String
        get() = p.getString("subjects", null)?.takeIf { it.isNotBlank() } ?: SubjectMatcher.DEFAULT_SUBJECTS
        set(v) = p.edit().putString("subjects", v.trim()).apply()

    var userName: String
        get() = p.getString("uname", "") ?: ""
        set(v) = p.edit().putString("uname", v).apply()
    /** Ghost size in dp. */
    var petDp: Int
        get() = p.getInt("size_dp", 96)
        set(v) = p.edit().putInt("size_dp", v).apply()
    var sleepEnabled: Boolean
        get() = p.getBoolean("sleep", true)
        set(v) = p.edit().putBoolean("sleep", v).apply()
    var remind2d: Boolean
        get() = p.getBoolean("rem2d", false)
        set(v) = p.edit().putBoolean("rem2d", v).apply()
    var remindMorning: Boolean
        get() = p.getBoolean("remam", true)
        set(v) = p.edit().putBoolean("remam", v).apply()
    var autoOrganize: Boolean
        get() = p.getBoolean("autoorg", false)
        set(v) = p.edit().putBoolean("autoorg", v).apply()

    /** file name -> WhatsApp chat it arrived in (learned from notifications / open chats). */
    fun rememberDoc(file: String, group: String) {
        val key = file.trim().lowercase()
        val lines = (p.getString("docgroups", "") ?: "").lines().filter { it.isNotBlank() && it.substringBefore('\t') != key }
        p.edit().putString("docgroups", (lines + (key + "\t" + group)).takeLast(400).joinToString("\n")).apply()
    }

    fun groupOfDoc(file: String): String? {
        val key = file.trim().lowercase()
        val plain = key.replace(Regex(" \\(\\d+\\)(?=\\.[^.]+$)"), "")
        val lines = (p.getString("docgroups", "") ?: "").lines()
        return lines.lastOrNull { it.substringBefore('\t') == key || it.substringBefore('\t') == plain }?.substringAfter('\t', "")?.ifEmpty { null }
    }

    fun loadProcessedDocs(): MutableSet<String> =
        (p.getString("docsdone", "") ?: "").split('\n').filter { it.isNotEmpty() }.toMutableSet()

    fun saveProcessedDocs(set: Set<String>) {
        p.edit().putString("docsdone", set.toList().takeLast(5000).joinToString("\n")).apply()
    }

    var watchEnabled: Boolean
        get() = p.getBoolean("watch", true)
        set(v) = p.edit().putBoolean("watch", v).apply()
    /** One group name per line. A notification matches if its title contains the name (ignoring case). */
    var watchedGroups: String
        get() = p.getString("groups", "") ?: ""
        set(v) = p.edit().putString("groups", v.trim()).apply()
    private var logJson: String
        get() = p.getString("rlog", "[]") ?: "[]"
        set(v) = p.edit().putString("rlog", v).apply()

    fun watchedGroupList(): List<String> = watchedGroups.lines().map { it.trim() }.filter { it.isNotEmpty() }

    fun addWatchedGroup(name: String) {
        if (watchedGroupList().none { it.equals(name, true) }) {
            watchedGroups = (watchedGroups + "\n" + name).trim()
        }
    }

    fun logs(): List<LogEntry> = ReminderLog.read(logJson)
    fun addLog(e: LogEntry) {
        logJson = ReminderLog.write((listOf(e) + logs()).take(20))
    }
    fun removeLog(eventId: Long) {
        logJson = ReminderLog.write(logs().filter { it.eventId != eventId })
    }

    /** Remembers message fingerprints so the same WhatsApp message is only handled once. Returns false if already seen. */
    fun markSeen(hash: Int): Boolean {
        val seen = (p.getString("seen", "") ?: "").split(',').filter { it.isNotEmpty() }
        if (seen.contains(hash.toString())) return false
        p.edit().putString("seen", (seen + hash.toString()).takeLast(300).joinToString(",")).apply()
        return true
    }

    fun resetPosition() {
        p.edit().remove("x").remove("y").apply()
    }

    var speak: Boolean
        get() = p.getBoolean("speak", true)
        set(v) = p.edit().putBoolean("speak", v).apply()

    /** Voice pitch x10: 18 squeaky, 14 cute, 10 normal. */
    var voicePitch: Int
        get() = p.getInt("voice_pitch", 14)
        set(v) = p.edit().putInt("voice_pitch", v).apply()

    /** Last open tab in the app. */
    var tab: String
        get() = p.getString("tab", "home") ?: "home"
        set(v) = p.edit().putString("tab", v).apply()

    /** Learn words from watched groups and shared chats (other people's words stay on this phone). */
    var learnGroups: Boolean
        get() = p.getBoolean("learn_groups", true)
        set(v) = p.edit().putBoolean("learn_groups", v).apply()

    /** Everything the learner remembers (kept on this phone only). */
    var learnData: String
        get() = p.getString("learn_data", "") ?: ""
        set(v) = p.edit().putString("learn_data", v).apply()

    /** "en" or "hi": spoken/typed language for voice input and Ghostie's voice. */
    var language: String
        get() = p.getString("lang", "en") ?: "en"
        set(v) = p.edit().putString("lang", v).apply()
    val speechTag: String get() = if (language == "hi") "hi-IN" else "en-IN"

    var chatCount: Int
        get() = p.getInt("chat_count", 0)
        set(v) = p.edit().putInt("chat_count", v).apply()
    var skin: String
        get() = p.getString("skin", "classic") ?: "classic"
        set(v) = p.edit().putString("skin", v).apply()

    /** One rule per line: "CS Group: ignore lunch, party, trip". Messages with those words are never turned into deadlines. */
    var groupRules: String
        get() = p.getString("group_rules", "") ?: ""
        set(v) = p.edit().putString("group_rules", v.trim()).apply()
    fun isIgnoredByRule(group: String, text: String): Boolean {
        val l = text.lowercase()
        for (line in groupRules.lines()) {
            val name = line.substringBefore(':').trim()
            val rest = line.substringAfter(':', "").trim()
            if (name.isEmpty() || rest.isEmpty()) continue
            if (!(group.contains(name, true) || name == "*" || name.equals("all", true))) continue
            val words = rest.removePrefix("ignore").trim().split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            if (words.any { l.contains(it) }) return true
        }
        return false
    }

    /** Show a "tap to open" notification whenever Ghostie opens another app (some phones block background launches). */
    var openFallback: Boolean
        get() = p.getBoolean("open_fallback", false)
        set(v) = p.edit().putBoolean("open_fallback", v).apply()

    /** Food apps to compare, as comma-separated ids from [FoodApps]. */
    var foodApps: String
        get() = p.getString("food_apps", "zomato,swiggy,dominos,popeyes,eatsure") ?: ""
        set(v) = p.edit().putString("food_apps", v).apply()
    /** The last food price check result, so it can be shown again. */
    var lastFood: String
        get() = p.getString("last_food", "") ?: ""
        set(v) = p.edit().putString("last_food", v).apply()
    /** Delivery fee (rupees) assumed when an app doesn't show one in the results. */
    var foodFee: Int
        get() = p.getInt("food_fee", 40)
        set(v) = p.edit().putInt("food_fee", v).apply()

    var theme: String
        get() = p.getString("theme", "midnight") ?: "midnight"
        set(v) = p.edit().putString("theme", v).apply()
    var glass: Boolean
        get() = p.getBoolean("glass", false)
        set(v) = p.edit().putBoolean("glass", v).apply()
    /** Simple mode shows only the essential cards; Advanced shows everything. */
    var simpleMode: Boolean
        get() = p.getBoolean("simple_mode", true)
        set(v) = p.edit().putBoolean("simple_mode", v).apply()
    /** Navigation: 0 classic top tabs, 1 neon glass bar, 2 dip bubble bar, 3 pop bubble bar. */
    var navStyle: Int
        get() = p.getInt("nav_style", 1)
        set(v) = p.edit().putInt("nav_style", v).apply()
    /** How glassy the glass look is, 0..100. */
    var glassLevel: Int
        get() = p.getInt("glass_level", 50)
        set(v) = p.edit().putInt("glass_level", v).apply()
    /** Which cards the user opened/closed: "title=1" or "title=0". */
    var cardState: Set<String>
        get() = p.getStringSet("card_state", emptySet()) ?: emptySet()
        set(v) = p.edit().putStringSet("card_state", v).apply()

    /** Index into Themes.accentLabels (0 = the theme's own colour). */
    var accentChoice: Int
        get() = p.getInt("accent_choice", 0)
        set(v) = p.edit().putInt("accent_choice", v).apply()

    /** Tapping the ghost opens the chat box straight away (no big-ghost visit first). */
    var directChat: Boolean
        get() = p.getBoolean("direct_chat", false)
        set(v) = p.edit().putBoolean("direct_chat", v).apply()

    /** Chat box size in dp (width, message-area height) and position in px (-1 = automatic). */
    var chatW: Int
        get() = p.getInt("chat_w", 320)
        set(v) = p.edit().putInt("chat_w", v).apply()
    var chatH: Int
        get() = p.getInt("chat_h", 200)
        set(v) = p.edit().putInt("chat_h", v).apply()
    var chatX: Int
        get() = p.getInt("chat_x", -1)
        set(v) = p.edit().putInt("chat_x", v).apply()
    var chatY: Int
        get() = p.getInt("chat_y", -1)
        set(v) = p.edit().putInt("chat_y", v).apply()

    /** Long explanations under settings. Off by default - the tutorial covers them. */
    var showHints: Boolean
        get() = p.getBoolean("show_hints", false)
        set(v) = p.edit().putBoolean("show_hints", v).apply()
    /** Show the tutorial after Ghostie is installed or updated. */
    var tutorialAuto: Boolean
        get() = p.getBoolean("tutorial_auto", true)
        set(v) = p.edit().putBoolean("tutorial_auto", v).apply()
    /** Install/update stamp the tutorial was last shown for. */
    var tutorialStamp: Long
        get() = p.getLong("tutorial_stamp", 0L)
        set(v) = p.edit().putLong("tutorial_stamp", v).apply()

    /** Ring like a call in the last hour before a deadline that isn't marked done. */
    var finalCall: Boolean
        get() = p.getBoolean("final_call", true)
        set(v) = p.edit().putBoolean("final_call", v).apply()
    var finalCallMin: Int
        get() = p.getInt("final_call_min", 60)
        set(v) = p.edit().putInt("final_call_min", v).apply()

    var classAlerts: Boolean
        get() = p.getBoolean("class_alerts", true)
        set(v) = p.edit().putBoolean("class_alerts", v).apply()

    // ---- Study mode ----
    var studyActive: Boolean
        get() = p.getBoolean("study_on", false)
        set(v) = p.edit().putBoolean("study_on", v).apply()
    /** "focus" or "break". */
    var studyPhase: String
        get() = p.getString("study_phase", "focus") ?: "focus"
        set(v) = p.edit().putString("study_phase", v).apply()
    var studyPhaseEnd: Long
        get() = p.getLong("study_end", 0L)
        set(v) = p.edit().putLong("study_end", v).apply()
    var studyPhaseStart: Long
        get() = p.getLong("study_start", 0L)
        set(v) = p.edit().putLong("study_start", v).apply()
    var studyFocus: Int
        get() = p.getInt("study_focus", 25)
        set(v) = p.edit().putInt("study_focus", v).apply()
    var studyBreak: Int
        get() = p.getInt("study_break", 5)
        set(v) = p.edit().putInt("study_break", v).apply()
    var studyDnd: Boolean
        get() = p.getBoolean("study_dnd", false)
        set(v) = p.edit().putBoolean("study_dnd", v).apply()
    var studyBlock: Boolean
        get() = p.getBoolean("study_block", true)
        set(v) = p.edit().putBoolean("study_block", v).apply()
    /** Package names, one per line. */
    var studyApps: String
        get() = p.getString("study_apps", "") ?: ""
        set(v) = p.edit().putString("study_apps", v).apply()
    fun studyAppSet(): Set<String> = studyApps.lines().map { it.trim() }.filter { it.isNotEmpty() }.toSet()
    var studyPrevFilter: Int
        get() = p.getInt("study_prev_filter", -1)
        set(v) = p.edit().putInt("study_prev_filter", v).apply()
    var studyLog: String
        get() = p.getString("study_log", "") ?: ""
        set(v) = p.edit().putString("study_log", v).apply()
    var studyCycles: Int
        get() = p.getInt("study_cycles", 0)
        set(v) = p.edit().putInt("study_cycles", v).apply()

    var shareLink: String
        get() = p.getString("share_link", "") ?: ""
        set(v) = p.edit().putString("share_link", v.trim()).apply()

    var habitData: String
        get() = p.getString("habit_data", "") ?: ""
        set(v) = p.edit().putString("habit_data", v).apply()
    var subjectLog: String
        get() = p.getString("subject_log", "") ?: ""
        set(v) = p.edit().putString("subject_log", v).apply()
    var suggestions: Boolean
        get() = p.getBoolean("suggestions", true)
        set(v) = p.edit().putBoolean("suggestions", v).apply()
    /** Hours (0-23, comma separated) when the ghost should not visit, learned or chosen. */
    var quietHoursList: String
        get() = p.getString("quiet_hours", "") ?: ""
        set(v) = p.edit().putString("quiet_hours", v).apply()
    fun quietHourSet(): Set<Int> = quietHoursList.split(',').mapNotNull { it.trim().toIntOrNull() }.toSet()
    var lastSuggestionAt: Long
        get() = p.getLong("sugg_at", 0L)
        set(v) = p.edit().putLong("sugg_at", v).apply()
    /** "date|count" for the daily cap, and recent suggestion keys. */
    var suggestionDay: String
        get() = p.getString("sugg_day", "") ?: ""
        set(v) = p.edit().putString("sugg_day", v).apply()
    var suggestionKeys: String
        get() = p.getString("sugg_keys", "") ?: ""
        set(v) = p.edit().putString("sugg_keys", v).apply()

    /** Send a short summary of deadlines and habits (no message text) with AI chat, so answers fit the user. */
    var aiContext: Boolean
        get() = p.getBoolean("ai_context", true)
        set(v) = p.edit().putBoolean("ai_context", v).apply()
    var studySubject: String
        get() = p.getString("study_subject", "") ?: ""
        set(v) = p.edit().putString("study_subject", v).apply()

    var mood: String
        get() = p.getString("mood", "classic") ?: "classic"
        set(v) = p.edit().putString("mood", v).apply()

    var tricks: Boolean
        get() = p.getBoolean("tricks", true)
        set(v) = p.edit().putBoolean("tricks", v).apply()
    var batteryReacts: Boolean
        get() = p.getBoolean("battery_reacts", true)
        set(v) = p.edit().putBoolean("battery_reacts", v).apply()
    var customTint: String
        get() = p.getString("custom_tint", "#C9B8FF") ?: "#C9B8FF"
        set(v) = p.edit().putString("custom_tint", v.trim()).apply()

    fun notes(): List<String> = (p.getString("notes", "") ?: "").split('\n').filter { it.isNotBlank() }
    fun setNotes(l: List<String>) = p.edit().putString("notes", l.takeLast(100).joinToString("\n")).apply()
    /** To-dos stored as "0|text" (open) or "1|text" (done). */
    fun todos(): List<Pair<Boolean, String>> = (p.getString("todos", "") ?: "").split('\n').filter { it.length > 2 }.map { (it[0] == '1') to it.substring(2) }
    fun setTodos(l: List<Pair<Boolean, String>>) = p.edit().putString("todos", l.takeLast(100).joinToString("\n") { (if (it.first) "1|" else "0|") + it.second }).apply()

    var recentEventsJson: String
        get() = p.getString("recent_events", "[]") ?: "[]"
        set(v) = p.edit().putString("recent_events", v).apply()

    var aiProvider: String
        get() = p.getString("ai_provider", "groq") ?: "groq"
        set(v) = p.edit().putString("ai_provider", v).apply()
    var aiBase: String
        get() = p.getString("ai_base", null)?.takeIf { it.isNotBlank() } ?: ChatEngine.provider(aiProvider).base
        set(v) = p.edit().putString("ai_base", v.trim()).apply()
    var aiModel: String
        get() = p.getString("ai_model", null)?.takeIf { it.isNotBlank() } ?: ChatEngine.provider(aiProvider).model
        set(v) = p.edit().putString("ai_model", v.trim()).apply()

    // ---- "Ghostie calls me" ----
    var callEnabled: Boolean
        get() = p.getBoolean("call_on", false)
        set(v) = p.edit().putBoolean("call_on", v).apply()
    /** One person or group per line - only these can ring. */
    var callVips: String
        get() = p.getString("call_vips", "") ?: ""
        set(v) = p.edit().putString("call_vips", v.trim()).apply()
    var callCount: Int
        get() = p.getInt("call_count", 3)
        set(v) = p.edit().putInt("call_count", v).apply()
    var callWindow: Int
        get() = p.getInt("call_window", 5)
        set(v) = p.edit().putInt("call_window", v).apply()
    var callUrgent: String
        get() = p.getString("call_urgent", null)?.takeIf { it.isNotBlank() } ?: RepeatDetector.DEFAULT_URGENT
        set(v) = p.edit().putString("call_urgent", v.trim()).apply()
    fun callVipList(): List<String> = callVips.lines().map { it.trim() }.filter { it.isNotEmpty() }

    /** Documents thrown in the bin: automatic sorting will not copy them back. */
    fun binnedDocs(): Set<String> = (p.getString("binned_docs", "") ?: "").split('\n').filter { it.isNotEmpty() }.toSet()
    fun addBinnedDoc(name: String) {
        p.edit().putString("binned_docs", (binnedDocs() + name).toList().takeLast(300).joinToString("\n")).apply()
    }
}
