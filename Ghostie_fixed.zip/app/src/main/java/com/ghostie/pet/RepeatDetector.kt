package com.ghostie.pet

/**
 * Decides when messages from a chat are worth ringing the user for: several messages in a short time,
 * or one with an urgent word. Pure Kotlin so it can be tested without a phone.
 */
class RepeatDetector(
    var count: Int = 3,
    var windowMin: Int = 5,
    var urgent: List<String> = parseWords(DEFAULT_URGENT),
    var cooldownMin: Int = 10
) {
    enum class Reason { REPEATS, URGENT }
    data class Hit(val reason: Reason, val messages: Int)

    private val stamps = HashMap<String, ArrayDeque<Long>>()
    private val lastAlert = HashMap<String, Long>()

    companion object {
        const val DEFAULT_URGENT = "urgent, emergency, asap, call me, please reply, pls reply, important, reply fast, are you there, help me"

        fun parseWords(csv: String): List<String> = csv.split(',', '\n').map { it.trim().lowercase() }.filter { it.isNotEmpty() }
    }

    fun isUrgent(text: String): Boolean {
        val l = text.lowercase()
        return urgent.any { w -> Regex("(?<![\\p{L}\\p{N}])" + Regex.escape(w) + "(?![\\p{L}\\p{N}])").containsMatchIn(l) }
    }

    /** Feed one new message. Returns a Hit when the user should be rung, otherwise null. */
    fun onMessage(key: String, text: String, now: Long): Hit? {
        val q = stamps.getOrPut(key) { ArrayDeque() }
        q.addLast(now)
        val cutoff = now - windowMin * 60_000L
        while (q.isNotEmpty() && q.first() < cutoff) q.removeFirst()
        val last = lastAlert[key]
        if (last != null && now - last < cooldownMin * 60_000L) return null
        val hit = when {
            isUrgent(text) -> Hit(Reason.URGENT, q.size)
            q.size >= count -> Hit(Reason.REPEATS, q.size)
            else -> null
        } ?: return null
        lastAlert[key] = now
        q.clear()
        return hit
    }
}
