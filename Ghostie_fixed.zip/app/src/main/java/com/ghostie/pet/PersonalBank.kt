package com.ghostie.pet

/**
 * Listening replies for personal talk. Each topic has hand-written openers (an acknowledgement) and follow-up questions;
 * a reply is one opener plus one question, so 10 topics x 18 openers x 20 questions is 3,600 different replies
 * while the text stored in the app stays a few kilobytes. Nothing here is learned from the user.
 */
object PersonalBank {
    class Topic(val acks: List<String>, val asks: List<String>)

    val topics: Map<String, Topic> by lazy { baseTopics + relationTopics }

    /** Relationship kinds besides a plain crush; their wording uses neutral "they" so PersonalTalk can swap in he/she. */
    val relationKeys = listOf("ex", "partner", "situation", "distance", "onesided", "friendfeel")

    private val baseTopics: Map<String, Topic> = mapOf(
        "crush" to Topic(
            listOf(
                "That sounds sweet.", "I can tell they matter to you.", "Aww, I like hearing this.", "That's a lovely thing to feel.",
                "Crushes can make the whole day feel different.", "Thank you for telling me.", "Okay, I'm all ears.", "That's really nice to hear.",
                "Mixed-up feelings like these are completely normal.", "You light up when you talk about this.", "I get it, small things can mean a lot.",
                "It's okay to take your time with this.", "Feelings like this can be exciting and scary at once.", "No rush, tell me at your own pace.",
                "I'm glad you feel you can share this.", "That makes sense.", "Interesting, go on.", "It sounds like it's on your mind a lot."
            ),
            listOf(
                "What's the first thing you noticed about them?", "What's your favourite thing about them?", "How do you feel when you see them?",
                "When did you start feeling this way?", "What do you two usually talk about?", "Do they know how you feel?",
                "What's the nicest thing they've done for you?", "What makes them different from other people you know?", "What would a perfect day with them look like?",
                "Is there something you're afraid might happen?", "What do you hope happens next?", "How do you act around them?",
                "Do you have friends who know about this?", "What's the hardest part right now?", "What made you smile about them recently?",
                "Do you see them every day?", "What do you wish you could say to them?", "Has anything made you doubt it?",
                "How do you think they see you?", "What would make you feel braver about this?"
            )
        ),
        "friends" to Topic(
            listOf(
                "That sounds painful, friendships matter a lot.", "I'm sorry, that must hurt.", "Thank you for telling me.", "That's a tough spot to be in.",
                "It makes sense that you're upset.", "I'm listening, take your time.", "Fights with friends can feel really heavy.", "That doesn't sound easy.",
                "I can hear this matters to you.", "Sometimes friends hurt each other without meaning to.", "Okay, let's go through it together.",
                "You care about this friendship, I can tell.", "It's okay to feel angry and sad at the same time.", "I'm here, no judgement.",
                "That would bother me too.", "Misunderstandings happen even between the best of friends.", "Thank you for trusting me with this.", "That's a lot to carry."
            ),
            listOf(
                "What happened, from the start?", "How long have you been friends?", "What did they say that hurt the most?",
                "How did it end the last time you spoke?", "Do you want to fix it or take some space?", "Have you talked to them since?",
                "What do you think they were feeling?", "Has something like this happened before?", "Is anyone else involved?",
                "What would you like them to understand?", "What would make things feel okay again?", "How are you feeling about it right now?",
                "Do you miss them?", "What did you want to say but didn't?", "Was there a moment when it started going wrong?",
                "Is it one thing or has it been building up?", "Who else could you talk to about it?", "What do you value most about this friend?",
                "What part feels most unfair?", "Would a short honest message help, or is it too soon?"
            )
        ),
        "family" to Topic(
            listOf(
                "Family pressure can feel heavy, especially when you love them.", "That sounds stressful.", "I'm sorry, that's a lot to deal with.",
                "Thank you for telling me.", "It's hard when the people you love don't seem to listen.", "That makes sense.", "I can hear how tired this makes you.",
                "Wanting to make them proud is a big weight.", "Your feelings about this are valid.", "That's a tough one.", "I'm listening, no judgement.",
                "Many students go through this.", "It's okay to feel stuck between what they want and what you want.", "I can tell this isn't easy.",
                "Families usually care, even when it comes out as pressure.", "You don't have to solve this tonight.", "Okay, tell me more.", "That sounds exhausting."
            ),
            listOf(
                "What are they expecting from you?", "How is it affecting your sleep and studies?", "Do they know how you feel?",
                "Is it mostly about marks, a career, or something else?", "What would you like them to understand?", "Who in the family do you feel closest to?",
                "Have you ever tried telling them calmly how it feels?", "What do you think worries them most?", "What do you want for yourself?",
                "Is there someone older you trust who could help?", "What does a normal day at home feel like right now?", "When did this start feeling so heavy?",
                "Do they compare you with others?", "What would make home feel lighter?", "What's one thing they do that you appreciate?",
                "How do you feel after these talks?", "What do you do to cope when it gets too much?", "Is there anything you've been afraid to tell them?",
                "What would you say if you knew they'd listen?", "What would a good outcome look like for you?"
            )
        ),
        "confidence" to Topic(
            listOf(
                "Thank you for saying that, it takes courage.", "Lots of people feel this way and hide it.", "I'm sorry you feel like this.",
                "That sounds really hard.", "Your mind can be harsh on you.", "I'm listening, no judgement.", "You matter here, even if your mind says otherwise.",
                "Feelings aren't facts, even when they feel loud.", "That's a heavy thought to carry around.", "Okay, I'm right here.", "It's okay to not feel okay.",
                "Being so hard on yourself is exhausting.", "I'm glad you told me.", "Many people feel this way, even ones who look confident.",
                "That can really weigh on you.", "Thank you for being honest.", "I hear you.", "That's not an easy thing to admit."
            ),
            listOf(
                "When did you start feeling this way?", "What triggered it today?", "What's the loudest thought right now?",
                "What would you say to a friend who felt like this?", "Is there a time you felt proud of yourself recently?", "What do you wish you believed about yourself?",
                "Is it worse around certain people or places?", "What's something small you did well this week?", "Who is someone who sees the best in you?",
                "What do you compare yourself to?", "What would feel different if you felt more confident?", "Do you feel this more at night, or all day?",
                "What's one thing you like about yourself, even a tiny one?", "How long has this been going on?", "Have you told anyone how you feel?",
                "What helps even a little when the thoughts get loud?", "What are you most afraid people think?", "What's something you'd try if you weren't afraid?",
                "How do you talk to yourself when you make a mistake?", "What would a kinder voice say right now?"
            )
        ),
        "vent" to Topic(
            listOf(
                "I hear you.", "That sounds like a lot to carry.", "Thank you for saying that out loud.", "Take your time.", "I'm still listening.",
                "That makes sense.", "It's okay to let it all out.", "No judgement here.", "I'm right here with you.", "That sounds really heavy.",
                "Thank you for trusting me.", "You don't have to hold it in.", "Say it however it comes.", "I'm not going anywhere.", "That must be exhausting.",
                "It's safe to say it here.", "Okay, keep going.", "I'm glad you're letting it out."
            ),
            listOf(
                "What's the hardest part of it?", "How long has it been like this?", "Do you want advice, or just to be heard?",
                "What would feel like a relief right now?", "What's been on your mind the most?", "Is there something you haven't said yet?",
                "How are you feeling in your body right now?", "What do you need most at the moment?", "Has anyone else heard this, or is it only me?",
                "What happened today?", "What would you tell someone who felt this way?", "Is it getting better or worse?",
                "What part would you like to talk about first?", "What do you wish was different?", "Is there anything that makes it a little easier?",
                "How long have you been keeping this in?", "Do you feel safe right now?", "What's one small thing that might help tonight?",
                "Would it help to write it down afterwards?", "What do you want to let go of?"
            )
        ),
        "lonely" to Topic(
            listOf(
                "I'm sorry you feel alone.", "Loneliness hurts, even in a crowd.", "Thank you for telling me.", "That sounds really hard.", "I'm here with you right now.",
                "Lots of students feel this, even if nobody says it.", "It's okay to feel this.", "That's a heavy feeling.", "I'm listening.", "You're not a burden for saying this.",
                "It can feel like everyone else has someone.", "I'm glad you told me.", "That makes sense.", "Feeling alone doesn't mean you are unlovable.",
                "I hear you.", "That must be tiring.", "Okay, tell me more.", "Thank you for being honest."
            ),
            listOf(
                "When do you feel it the most?", "Is there anyone you'd like to be closer to?", "How long have you felt this way?", "What did you enjoy doing with others before?",
                "Is there one person you could message today, even a small hello?", "What kind of company do you miss?", "Do you feel lonely at college, at home, or both?",
                "What helps even a little when it gets quiet?", "Is there a club, class or group you feel curious about?", "Has anyone made you feel welcome recently?",
                "What would a good evening look like for you?", "Do you want to talk about what changed?", "Who used to be around that isn't now?",
                "What are you hoping for in friendships?", "Is it more about missing people or feeling misunderstood?", "What's one thing you could do for yourself this week?",
                "Is there an old friend you think of?", "What do you usually do when it hits?", "How is your sleep and appetite?", "Would a walk or some fresh air feel okay right now?"
            )
        ),
        "homesick" to Topic(
            listOf(
                "Missing home is so normal.", "That sounds like it really hurts.", "I'm sorry you're feeling this.", "It's hard being away from the people you love.",
                "Thank you for telling me.", "Home feelings can hit suddenly.", "That makes sense.", "It means you love them.", "I'm listening.", "It's okay to miss it.",
                "Many students feel this, especially at the start.", "That's a heavy kind of missing.", "You're doing something brave by being away.", "I hear you.",
                "Those little things from home matter.", "Okay, tell me more.", "It can come in waves.", "I'm glad you shared it."
            ),
            listOf(
                "What do you miss most?", "Who do you miss the most?", "How often do you get to talk to them?", "What does home smell or sound like?",
                "When does it hit the hardest?", "How long have you been away?", "Is there a food you're craving from home?", "What's one thing here that feels a little like home?",
                "Do your family know how you're feeling?", "When can you next go home?", "What would you tell them if they were here?", "Is there a routine from home you could bring here?",
                "Have you made any friends where you are?", "What did you like about your life back home?", "Do you want to plan a call tonight?", "What's something you're proud of since you left?",
                "Is it the people, the place, or the comfort?", "What helps a little when it gets bad?", "How are you sleeping?", "What small thing could make today softer?"
            )
        ),
        "breakup" to Topic(
            listOf(
                "I'm so sorry, that really hurts.", "Heartbreak is real pain.", "Thank you for telling me.", "That sounds incredibly hard.", "Take all the time you need.",
                "It's okay to cry or feel numb.", "I'm here, no judgement.", "That's a lot to lose at once.", "Feelings after a breakup come in waves.", "I hear you.",
                "You loved, and that's not a mistake.", "It's normal to replay everything.", "That must feel so empty.", "I'm listening.", "That makes sense.",
                "Healing isn't a straight line.", "You don't have to be okay right now.", "Okay, tell me whatever you need to."
            ),
            listOf(
                "How long were you together?", "What happened, if you want to share?", "How are you holding up today?", "What do you miss the most?",
                "Are you still in touch with them?", "Is it fresh, or has some time passed?", "What would help you most right now?", "Do your friends know?",
                "Are you eating and sleeping okay?", "What are you telling yourself about it?", "Is there anything you wish you'd said?", "What was the best thing about it?",
                "What do you want to remember about yourself from this?", "Is it hard to see them around?", "Do you want to talk, or would a distraction be better?",
                "What small thing could feel kind to yourself today?", "Who has been supportive?", "What are you most afraid of now?", "How are your studies going through this?", "What does tonight look like for you?"
            )
        ),
        "anxious" to Topic(
            listOf(
                "That sounds stressful.", "I'm sorry your mind feels so busy.", "Thank you for telling me.", "Overthinking is exhausting.", "You're not alone in this.",
                "Take a slow breath with me.", "That makes sense.", "Anxious thoughts can feel very real.", "I'm listening.", "It's okay to feel nervous.",
                "Your body and mind are working overtime.", "That's a lot going on inside.", "I hear you.", "Let's take this one piece at a time.", "That can really wear you down.",
                "It's good that you're putting it into words.", "Okay, tell me more.", "You're doing your best."
            ),
            listOf(
                "What is your mind worried about most?", "Is it about something coming up, or something that already happened?", "How long has it felt like this?",
                "What does it feel like in your body?", "What's the worst thing you're imagining?", "How likely do you think that really is?", "What would you tell a friend who thought this?",
                "Is it worse at night?", "What helps even a little?", "Is there something small you could do about it today?", "Have you slept and eaten okay?",
                "Who could you share this with?", "What's one thing that is going well right now?", "Do you want to try a slow breathing minute together?",
                "What would feel like relief?", "Is it exams, people, or the future?", "Has it been like this for a while?", "What is in your control right now?",
                "What would help you feel safe?", "Would writing the worries down help?"
            )
        ),
        "anger" to Topic(
            listOf(
                "That sounds really frustrating.", "It's okay to feel angry.", "Thank you for telling me.", "That would make me upset too.", "I'm listening.",
                "Anger often means something mattered.", "Let it out, I'm here.", "That doesn't sound fair.", "That makes sense.", "It's a lot to hold in.",
                "I hear you.", "No judgement here.", "Strong feelings need somewhere to go.", "That sounds like it really got to you.", "Okay, tell me what happened.",
                "It's good that you're talking instead of bottling it up.", "That must have been hard to deal with.", "Take a breath, then say it all."
            ),
            listOf(
                "What happened?", "Who or what are you angry at?", "What part made you the angriest?", "How long has this been building?",
                "What do you wish you had said or done?", "How is your body feeling right now?", "Is it about this one thing, or a lot of things?",
                "What would help you cool down?", "Do you want to just vent, or think about what to do?", "What do you need from the other person?",
                "Is there something underneath the anger, like hurt or worry?", "Would a walk or some water help right now?", "Have you felt like this before?",
                "What would feel fair here?", "What is the first thing you'd like to change?", "How do you usually calm down?", "Are you safe and okay right now?",
                "Would it help to wait before replying to them?", "What do you need most right now?", "What would you tell a friend in this situation?"
            )
        )
    )

    private val relAcks = listOf(
        "Thank you for telling me.", "That sounds like a lot to carry.", "I'm listening.", "That makes sense.", "I hear you.", "Feelings like these are real.",
        "No rush, take your time.", "It's okay to feel this way.", "Okay, tell me more.", "That says a lot about how much it matters.",
        "I'm glad you can say this out loud.", "That can be confusing.", "Mixed feelings like these are normal.", "I'm here, go on.",
        "Thanks for trusting me with this.", "That sounds meaningful to you."
    )
    private fun rel(vararg asks: String) = Topic(relAcks, asks.toList())
    private val relationTopics: Map<String, Topic> = mapOf(
        "ex" to rel(
            "How long ago did it end?", "Who ended it, if you don't mind sharing?", "What do you miss most about them?", "Do you two still talk?",
            "What was the best part of being together?", "What made it hard to keep going?", "How do you feel when you think about them now?",
            "What brings the memories back most?", "Do you wish you could go back, or do you miss how it felt?", "What did you learn from that relationship?",
            "Do you see them around, or is there no contact?", "What would you say to them if you could say anything?", "Are you taking care of yourself these days?",
            "Who do you talk to when it feels heavy?", "Does it feel better or worse than a few months ago?", "What would help you feel lighter this week?"
        ),
        "partner" to rel(
            "How long have you two been together?", "What do you love most about them?", "How are things between you lately?", "How do you two usually spend time together?",
            "What do you two disagree about most?", "Do you feel heard by them?", "What made you smile about them recently?", "What do you wish was different?",
            "How do you handle fights?", "Do you feel like yourself around them?", "What are you looking forward to together?", "Do your friends and family know about them?",
            "How often do you get to meet?", "What is the hardest part right now?", "What would make this week better between you?", "Is there something you've been wanting to tell them?"
        ),
        "situation" to rel(
            "How long have you two been talking?", "What is unclear right now?", "Have you talked about what you are to each other?", "How do they act when you're together?",
            "How do they act when you're apart?", "What do you want it to become?", "Do you feel secure, or are you often guessing?", "Who usually texts first?",
            "What would you ask them if you felt brave?", "How does this uncertainty feel in your body?", "What is one thing that is clear to you?",
            "What do you need from them to feel okay?", "Is the waiting getting harder?", "What would you tell a friend in this spot?", "What would a clear answer change for you?",
            "Do you feel you can be honest with them?"
        ),
        "distance" to rel(
            "How far apart are you?", "How often do you talk or call?", "When did you last meet?", "When will you see each other next?", "What is the hardest part of the distance?",
            "How do you two stay close day to day?", "Do you feel secure, or does the distance make you worry?", "What do you like about how you two communicate?",
            "Is there an end to the distance in sight?", "What time of day do you miss them most?", "Do you have little rituals together, like calls or shows?",
            "How do you handle busy or quiet days?", "What would make the distance easier right now?", "Do your friends know how you feel about it?",
            "What is one thing you want to do together when you meet?", "How are you looking after yourself meanwhile?"
        ),
        "onesided" to rel(
            "How long have you felt this way?", "How do you know how they feel?", "Have they said anything about it, or is it a guess?", "What hurts the most about it?",
            "Do you see them often?", "Have you thought about telling them?", "What are you afraid would happen if you did?", "Does it affect your days or your sleep?",
            "What do you want most, honest answers or a way to move on?", "Who do you lean on when it hurts?", "What did you hope would happen?", "Is it easier when you keep some distance?",
            "What do you like about yourself that has nothing to do with them?", "What would moving forward look like for you?", "What would you tell a friend who felt this?",
            "What would help you most this week?"
        ),
        "friendfeel" to rel(
            "How long have you been friends?", "When did your feelings start to change?", "What do you love about the friendship?", "What are you afraid of losing?",
            "Do they act differently with you than with others?", "Does anyone else know?", "How do you feel when you hang out?", "Have you hinted at it, or kept it to yourself?",
            "What would you want if it went well?", "If it stays a friendship, could you be okay with that?", "What do your other friends say?",
            "Are you getting what you need from the friendship right now?", "What scares you most about telling them?", "Is there a calm moment you might talk?",
            "What does your gut say?", "What would help you decide?"
        )
    )

    /** One opener plus one question. Openers and questions are tracked separately, so the same question never comes back until the whole list has been used. */
    fun listenParts(topic: String, pick: (List<String>) -> String, avoid: List<String> = emptyList()): Pair<String, String> {
        val t = topics[topic] ?: return Pair(pick(listOf("I'm listening.", "Tell me more.")), "")
        return Pair(pick(freshest(t.acks, avoid)), pick(freshest(t.asks, avoid)))
    }

    /** Lines not used yet; when all have been used, the half used longest ago. */
    private fun freshest(all: List<String>, history: List<String>): List<String> {
        val fresh = all.filter { it !in history }
        if (fresh.isNotEmpty()) return fresh
        return all.sortedBy { history.lastIndexOf(it) }.take(maxOf(1, all.size / 2))
    }

    fun listen(topic: String, pick: (List<String>) -> String, avoid: List<String> = emptyList()): String {
        val (a, q) = listenParts(topic, pick, avoid)
        return if (q.isEmpty()) a else "$a $q"
    }

    /** How many different replies the bank can produce. */
    fun combinations(): Int = topics.values.sumOf { it.acks.size * it.asks.size }
}
