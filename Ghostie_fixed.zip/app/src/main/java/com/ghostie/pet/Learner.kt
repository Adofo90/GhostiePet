package com.ghostie.pet

import android.content.Context
import kotlin.math.exp

/**
 * Ghostie's on-device memory. It is not a big language model: it is a small, transparent learner that
 * remembers what you correct and teach it, and stores everything on the phone.
 *  - which words go with which subject (document sorting)
 *  - which words go with which calendar category (Event / Birthday / Anniversary / Countdown)
 *  - phrases you teach it ("when I say study mode, timer 25 minutes")
 *  - deadlines you threw in the bin (so similar ones are ignored next time)
 *  - which kinds of messages you answer or ignore (so it talks about what you like)
 * Pure Kotlin so it can be tested without a phone.
 */
class Learner {
    private val subjectVotes = HashMap<String, HashMap<String, Int>>()
    private val kindVotes = HashMap<String, HashMap<String, Int>>()
    val aliases = LinkedHashMap<String, String>()
    private val blocked = LinkedHashSet<String>()
    private val topics = HashMap<String, Double>()

    companion object {
        private val STOP = setOf(
            "pdf", "doc", "docx", "ppt", "pptx", "xls", "xlsx", "txt", "jpg", "jpeg", "png", "img", "final", "copy", "new", "the", "and", "for",
            "with", "from", "event", "add", "create", "set", "make", "schedule", "calendar", "reminder", "please", "title", "called", "named",
            "unit", "chapter", "module", "notes", "note", "file", "whatsapp", "document", "image", "video", "audio", "scan", "scanned", "page",
            "tomorrow", "today", "tonight", "next", "this", "week", "month", "year", "morning", "evening", "night", "for", "at", "on"
        )

        fun norm(s: String): String = s.lowercase().replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()

        fun tokens(s: String): List<String> =
            norm(s.substringBeforeLast('.', s)).split(' ').filter { it.length >= 3 && it !in STOP && !it.all { c -> c.isDigit() } }.distinct()

        fun fromText(text: String): Learner {
            val l = Learner()
            for (line in text.lines()) {
                val p = line.split('\t')
                try {
                    when (p[0]) {
                        "S" -> l.subjectVotes.getOrPut(p[1]) { HashMap() }[p[2]] = p[3].toInt()
                        "K" -> l.kindVotes.getOrPut(p[1]) { HashMap() }[p[2]] = p[3].toInt()
                        "A" -> l.aliases[p[1]] = p[2]
                        "B" -> l.blocked.add(p[1])
                        "T" -> l.topics[p[1]] = p[2].toDouble()
                    }
                } catch (e: Exception) {
                    // skip a damaged line
                }
            }
            return l
        }
    }

    private fun clean(s: String) = s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ')

    fun toText(): String {
        val sb = StringBuilder()
        for ((tok, m) in subjectVotes) for ((sub, c) in m) sb.append("S\t").append(clean(tok)).append('\t').append(clean(sub)).append('\t').append(c).append('\n')
        for ((tok, m) in kindVotes) for ((k, c) in m) sb.append("K\t").append(clean(tok)).append('\t').append(clean(k)).append('\t').append(c).append('\n')
        for ((p, a) in aliases) sb.append("A\t").append(clean(p)).append('\t').append(clean(a)).append('\n')
        for (b in blocked) sb.append("B\t").append(clean(b)).append('\n')
        for ((t, v) in topics) sb.append("T\t").append(clean(t)).append('\t').append(v).append('\n')
        return sb.toString()
    }

    fun isEmpty() = subjectVotes.isEmpty() && kindVotes.isEmpty() && aliases.isEmpty() && blocked.isEmpty() && topics.isEmpty()

    // ---- voting helper ----------------------------------------------------------------------

    private fun vote(map: HashMap<String, HashMap<String, Int>>, keys: List<String>, label: String, weight: Int = 1) {
        for (k in keys) {
            val m = map.getOrPut(k) { HashMap() }
            m[label] = (m[label] ?: 0) + weight
        }
        // keep memory small
        if (map.size > 600) map.keys.take(100).forEach { map.remove(it) }
    }

    private fun best(map: HashMap<String, HashMap<String, Int>>, keys: List<String>, weights: Map<String, Double> = emptyMap()): Pair<String, Double>? {
        val score = HashMap<String, Double>()
        for (k in keys) {
            val m = map[k] ?: continue
            val total = m.values.sum().toDouble()
            for ((label, c) in m) score[label] = (score[label] ?: 0.0) + (c / total) * (weights[k] ?: 1.0) * minOf(1.0, 0.6 + 0.2 * c)
        }
        return score.maxByOrNull { it.value }?.let { it.key to it.value }
    }

    // ---- subjects -----------------------------------------------------------------------------

    fun teachSubject(fileName: String, group: String?, subject: String) {
        val keys = tokens(fileName).toMutableList()
        if (!group.isNullOrBlank()) keys.add("g:" + norm(group))
        vote(subjectVotes, keys, subject, 2)
    }

    fun suggestSubject(fileName: String, group: String?): String? {
        val keys = tokens(fileName).toMutableList()
        val w = HashMap<String, Double>()
        if (!group.isNullOrBlank()) { val g = "g:" + norm(group); keys.add(g); w[g] = 1.2 }
        val b = best(subjectVotes, keys, w) ?: return null
        return if (b.second >= 0.9) b.first else null
    }

    // ---- calendar categories ------------------------------------------------------------------

    fun teachKind(title: String, kind: String) = vote(kindVotes, tokens(title), kind, 2)

    fun suggestKind(title: String): String? {
        val b = best(kindVotes, tokens(title)) ?: return null
        return if (b.second >= 0.9) b.first else null
    }

    // ---- taught phrases -----------------------------------------------------------------------

    fun addAlias(phrase: String, meaning: String) {
        val p = norm(phrase)
        if (p.isNotEmpty() && meaning.isNotBlank()) aliases[p] = clean(meaning.trim())
        while (aliases.size > 60) aliases.remove(aliases.keys.first())
    }

    fun findAlias(text: String): String? = aliases[norm(text)]
    fun removeAlias(phrase: String): Boolean = aliases.remove(norm(phrase)) != null

    /** "remember cs means computer science": swaps taught words inside what the user typed. */
    fun applyWords(text: String): String {
        var out = text
        for ((phrase, meaning) in aliases) {
            if (!meaning.startsWith("word:")) continue
            out = out.replace(Regex("\\b" + Regex.escape(phrase) + "\\b", RegexOption.IGNORE_CASE), meaning.removePrefix("word:"))
        }
        return out
    }

    // ---- deadlines thrown in the bin ----------------------------------------------------------

    private fun blockKey(group: String, label: String) = norm(group) + "|" + norm(label)

    fun block(group: String, label: String) {
        blocked.add(blockKey(group, label))
        while (blocked.size > 80) blocked.remove(blocked.first())
    }

    /** Forgets every muted item for one group (e.g. "call" = chats muted from call-me alerts). */
    fun clearBlocked(group: String): Int {
        val g = norm(group)
        val gone = blocked.filter { it.substringBefore('|') == g }
        blocked.removeAll(gone.toSet())
        return gone.size
    }

    fun isBlocked(group: String, label: String): Boolean {
        val g = norm(group)
        val l = norm(label)
        if (l.isEmpty()) return false
        return blocked.any { b ->
            val g2 = b.substringBefore('|')
            val l2 = b.substringAfter('|')
            g2 == g && l2.isNotEmpty() && (l2 == l || l.contains(l2) || l2.contains(l))
        }
    }

    // ---- what the user likes to talk about ----------------------------------------------------

    fun bumpTopic(topic: String, delta: Double) {
        topics[topic] = ((topics[topic] ?: 0.0) + delta).coerceIn(-3.0, 3.0)
    }

    /** 1.0 = neutral; liked topics come up more often, ignored ones less. */
    fun topicWeight(topic: String): Double = exp((topics[topic] ?: 0.0) * 0.6).coerceIn(0.15, 4.0)

    // ---- summary for the app ------------------------------------------------------------------

    fun summary(): String {
        val subjects = subjectVotes.values.flatMap { it.keys }.toSet().size
        val kinds = kindVotes.size
        return "Words linked to subjects: ${subjectVotes.size} (across $subjects subjects)\n" +
            "Words linked to event categories: $kinds\n" +
            "Phrases you taught me: ${aliases.size}\n" +
            "Deadlines I'll ignore: ${blocked.size}\n" +
            "Topics I've adapted to: ${topics.size}"
    }
}

/** Keeps one shared Learner per process and saves it to private storage. */
object LearnStore {
    private var cached: Learner? = null

    @Synchronized
    fun get(ctx: Context): Learner {
        cached?.let { return it }
        val l = Learner.fromText(SettingsStore(ctx).learnData)
        cached = l
        return l
    }

    @Synchronized
    fun save(ctx: Context) {
        cached?.let { SettingsStore(ctx).learnData = it.toText() }
    }

    @Synchronized
    fun reset(ctx: Context) {
        cached = Learner()
        SettingsStore(ctx).learnData = ""
    }
}
