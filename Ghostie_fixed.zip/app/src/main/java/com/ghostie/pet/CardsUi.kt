package com.ghostie.pet

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.time.LocalDate

/** Colours the card screens use (taken from the app's current theme). */
class CardsTheme(val bg: Int, val card: Int, val stroke: Int, val main: Int, val sub: Int, val accent: Int, val onAccent: Int, val field: Int, val good: Int)

/** Pure list logic for the card screens (JVM tested). */
object CardList {
    /** Cards grouped by subject (A-Z, "General" last), newest first inside a group; [query] filters question, answer and subject. */
    fun group(cards: List<Student.Card>, query: String): List<Pair<String, List<Student.Card>>> {
        val q = query.trim().lowercase()
        val hit = if (q.isEmpty()) cards else cards.filter { it.q.lowercase().contains(q) || it.a.lowercase().contains(q) || it.subject.lowercase().contains(q) }
        return hit.groupBy { it.subject.ifBlank { "General" }.lowercase() }.values
            .map { l -> l.first().subject.ifBlank { "General" } to l.sortedByDescending { it.id } }
            .sortedWith(compareBy({ it.first.equals("General", true) }, { it.first.lowercase() }))
    }

    /** What to review: due cards, or every card when [all]; limited to one subject when [subject] is not null. Weakest first. */
    fun queue(cards: List<Student.Card>, today: LocalDate, subject: String?, all: Boolean): List<Student.Card> =
        cards.filter { (all || it.due <= today.toEpochDay()) && (subject == null || it.subject.equals(subject, true)) }
            .sortedWith(compareBy({ it.box }, { it.due }))

    fun dueText(c: Student.Card, today: LocalDate): String {
        val d = c.due - today.toEpochDay()
        return when { d <= 0 -> "due now"; d == 1L -> "due tomorrow"; else -> "due in $d days" }
    }
}

/**
 * Full-screen card screens: flip-card review, "My cards" browser (grouped by subject, tick / edit / move / delete) and a tick-list
 * for cards a file produced. Built in code like the rest of the app, no layout files.
 */
class CardsUi(private val act: Activity, private val th: CardsTheme) {
    private fun dp(v: Int) = (v * act.resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat(); if (stroke != null) setStroke(dp(1), stroke) }
    private fun toast(m: String) = Toast.makeText(act, Sym.t(m), Toast.LENGTH_SHORT).show()
    private fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false): TextView = SymText(act).apply {
        text = t; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun btn(t: String, filled: Boolean, color: Int = th.accent, onClick: () -> Unit): TextView = SymText(act).apply {
        text = t; textSize = 15f; gravity = Gravity.CENTER; setTypeface(typeface, Typeface.BOLD)
        setTextColor(if (filled) th.onAccent else color)
        background = if (filled) rounded(color, 14) else rounded(Color.TRANSPARENT, 14, color)
        setPadding(dp(12), dp(13), dp(12), dp(13)); minHeight = dp(48)
        isClickable = true; setOnClickListener { onClick() }
    }

    private fun chip(t: String, selected: Boolean, onClick: () -> Unit): TextView = SymText(act).apply {
        text = t; textSize = 13f; gravity = Gravity.CENTER
        setTextColor(if (selected) th.onAccent else th.main)
        background = if (selected) rounded(th.accent, 20) else rounded(th.card, 20, th.stroke)
        setPadding(dp(14), dp(7), dp(14), dp(7)); isClickable = true; setOnClickListener { onClick() }
    }

    private fun screen(build: (LinearLayout, Dialog) -> Unit): Dialog {
        val d = Dialog(act, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val root = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(th.bg); setPadding(dp(14), dp(34), dp(14), dp(14)) }
        build(root, d)
        d.setContentView(root)
        return d
    }

    private fun topBar(root: LinearLayout, d: Dialog, title: String, right: View? = null): TextView {
        val bar = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bar.addView(tv("✕", 22f, th.main, true).apply { setPadding(dp(6), dp(4), dp(16), dp(4)); isClickable = true; setOnClickListener { d.dismiss() } })
        val t = tv(title, 18f, th.main, true)
        bar.addView(t, lp(0, weight = 1f))
        if (right != null) bar.addView(right)
        root.addView(bar, lp())
        return t
    }

    // ------------------------------------------------------------------------------------------ review

    /** Flip-card review. [onDone] runs when the screen closes (the caller refreshes its counts). */
    fun review(st: Student.State, save: () -> Unit, onDone: () -> Unit) {
        val today = LocalDate.now()
        if (st.cards.isEmpty()) { toast("No cards yet. Add some first."); return }
        var subject: String? = null
        var all = false
        screen { root, d ->
            d.setOnDismissListener { onDone() }
            val counter = tv("", 14f, th.sub)
            topBar(root, d, "Review", counter)
            val bar = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            val barFill = View(act).apply { setBackgroundColor(th.accent) }
            val barRest = View(act).apply { setBackgroundColor(th.stroke) }
            bar.addView(barFill, lp(0, dp(5), 0f)); bar.addView(barRest, lp(0, dp(5), 1f))
            root.addView(bar, lp().apply { topMargin = dp(10); bottomMargin = dp(8) })
            val chipsHolder = HorizontalScrollView(act).apply { isHorizontalScrollBarEnabled = false }
            val chipRow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            chipsHolder.addView(chipRow); root.addView(chipsHolder, lp())
            val face = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(22), dp(22), dp(22), dp(22)); cameraDistance = 9000f }
            val faceTag = tv("", 12f, th.accent, true)
            val faceMain = tv("", 22f, th.main, true).apply { gravity = Gravity.CENTER }
            val faceSub = tv("", 14f, th.sub).apply { gravity = Gravity.CENTER; setPadding(0, dp(14), 0, 0) }
            val scroll = ScrollView(act).apply { isFillViewport = true }
            face.addView(faceTag, lp().apply { bottomMargin = dp(10) }); face.addView(faceMain, lp()); face.addView(faceSub, lp())
            scroll.addView(face, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            val faceBox = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; background = rounded(th.card, 22, th.stroke) }
            faceBox.addView(scroll, lp(h = 0, weight = 1f))
            root.addView(faceBox, lp(h = 0, weight = 1f).apply { topMargin = dp(10); bottomMargin = dp(12) })
            val actions = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            root.addView(actions, lp())

            var queue = ArrayList<Student.Card>()
            var total = 0; var index = 0; var gotIt = 0; val missed = ArrayList<Student.Card>()
            var flipped = false

            fun progress() {
                counter.text = if (total == 0) "" else "${minOf(index + 1, total)} / $total"
                val w = if (total == 0) 0f else index.toFloat() / total
                (barFill.layoutParams as LinearLayout.LayoutParams).weight = w
                (barRest.layoutParams as LinearLayout.LayoutParams).weight = 1f - w
                bar.requestLayout()
            }

            lateinit var start: () -> Unit
            lateinit var showCard: () -> Unit
            fun grade(c: Student.Card, good: Boolean, easy: Boolean) {
                var n = Student.graded(c, good, LocalDate.now())
                if (good && easy) n = Student.graded(n, true, LocalDate.now())
                st.cards = st.cards.map { if (it.id == c.id) n else it }.toMutableList()
                save()
                if (good) gotIt++ else missed.add(n)
                index++
            }
            fun finish() {
                actions.removeAllViews()
                faceTag.text = "ALL DONE"
                faceMain.text = if (total == 0) "Nothing due 🎉" else "Done 🎉"
                faceSub.text = if (total == 0) "No cards are due right now. Tap \"Practice all cards\" above to go through everything anyway." else "You went through $total card${if (total == 1) "" else "s"}: $gotIt got it, ${missed.size} to see again."
                faceBox.background = rounded(th.card, 22, th.good)
                progress()
                if (missed.isNotEmpty()) actions.addView(btn("Again: missed ones", true) { queue = ArrayList(missed); missed.clear(); total = queue.size; index = 0; gotIt = 0; faceBox.background = rounded(th.card, 22, th.stroke); showCard() }, lp(0, weight = 1f).apply { marginEnd = dp(6) })
                actions.addView(btn("Close", missed.isEmpty()) { d.dismiss() }, lp(0, weight = 1f))
            }
            fun flip() {
                if (flipped || index >= queue.size) return
                flipped = true
                val c = queue[index]
                faceBox.animate().rotationY(90f).setDuration(130).withEndAction {
                    faceTag.text = "ANSWER"; faceMain.text = c.a; faceMain.textSize = if (c.a.length > 160) 17f else 21f
                    faceSub.text = c.q; faceBox.background = rounded(th.card, 22, th.accent)
                    faceBox.rotationY = -90f; faceBox.animate().rotationY(0f).setDuration(130).start()
                }.start()
                actions.removeAllViews()
                actions.addView(btn("Again", false, Color.parseColor("#E5707E")) { grade(c, false, false); showCard() }, lp(0, weight = 1f).apply { marginEnd = dp(6) })
                actions.addView(btn("Got it", true) { grade(c, true, false); showCard() }, lp(0, weight = 1.2f).apply { marginEnd = dp(6) })
                actions.addView(btn("Easy", false, th.good) { grade(c, true, true); showCard() }, lp(0, weight = 1f))
            }
            showCard = {
                flipped = false
                faceBox.rotationY = 0f
                if (index >= queue.size) finish() else {
                    val c = queue[index]
                    progress()
                    faceTag.text = (c.subject.ifBlank { "General" }).uppercase()
                    faceMain.text = c.q; faceMain.textSize = if (c.q.length > 140) 18f else 22f
                    faceSub.text = "Tap the card to see the answer"
                    faceBox.background = rounded(th.card, 22, th.stroke)
                    actions.removeAllViews()
                    actions.addView(btn("Show answer", true) { flip() }, lp(0, weight = 1f))
                }
            }
            scroll.setOnClickListener { flip() }
            faceBox.setOnClickListener { flip() }
            face.setOnClickListener { flip() }
            faceMain.setOnClickListener { flip() }
            start = {
                queue = ArrayList(CardList.queue(st.cards, today, subject, all))
                total = queue.size; index = 0; gotIt = 0; missed.clear()
                showCard()
            }
            fun chips() {
                chipRow.removeAllViews()
                val subs = st.cards.map { it.subject.ifBlank { "General" } }.distinct().sortedBy { it.lowercase() }
                fun add(t: String, sel: Boolean, f: () -> Unit) = chipRow.addView(chip(t, sel) { f(); chips(); start() }, lp().apply { marginEnd = dp(6) })
                add("All subjects", subject == null) { subject = null }
                for (s in subs) { val due = CardList.queue(st.cards, today, s, false).size; add("$s ($due)", subject == s) { subject = s } }
                chipRow.addView(chip(if (all) "✔ Practice all" else "Practice all cards", all) { all = !all; chips(); start() }, lp().apply { marginEnd = dp(6) })
            }
            chips()
            start()
        }.show()
    }

    // ------------------------------------------------------------------------------------------ browse

    /** "My cards": grouped by subject with tick boxes, search, edit, move and delete. */
    fun browse(st: Student.State, save: () -> Unit, onDone: () -> Unit) {
        val today = LocalDate.now()
        val ticked = HashSet<Long>()
        val closed = HashSet<String>()
        var query = ""
        screen { root, d ->
            d.setOnDismissListener { onDone() }
            val selAll = tv("Select all", 14f, th.accent, true).apply { setPadding(dp(8), dp(6), dp(4), dp(6)); isClickable = true }
            val title = topBar(root, d, "My cards", selAll)
            val search = EditText(act).apply {
                hint = "Search cards"; setHintTextColor(th.sub); setTextColor(th.main); textSize = 14f; setSingleLine()
                background = rounded(th.field, 12, th.stroke); setPadding(dp(12), dp(9), dp(12), dp(9))
                inputType = InputType.TYPE_CLASS_TEXT
            }
            root.addView(search, lp().apply { topMargin = dp(8); bottomMargin = dp(8) })
            val scroll = ScrollView(act)
            val list = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
            scroll.addView(list)
            root.addView(scroll, lp(h = 0, weight = 1f))
            val action = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, 0); visibility = View.GONE }
            val selText = tv("", 14f, th.main, true)
            action.addView(selText, lp(0, weight = 1f))
            root.addView(action, lp())
            lateinit var render: () -> Unit

            fun editDialog(c: Student.Card) {
                val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0) }
                fun field(h: String, v: String, lines: Int) = EditText(act).apply { hint = h; setText(v); minLines = lines; gravity = Gravity.TOP; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
                val fs = field("Subject", c.subject, 1); val fq = field("Question", c.q, 2); val fa = field("Answer", c.a, 3)
                col.addView(fs); col.addView(fq); col.addView(fa)
                SymBuilder(act).setTitle("Edit card").setView(ScrollView(act).apply { addView(col) })
                    .setPositiveButton("Save") { _, _ ->
                        val q = fq.text.toString().trim(); val a = fa.text.toString().trim()
                        if (q.isEmpty() || a.isEmpty()) { toast("Question and answer can't be empty"); return@setPositiveButton }
                        st.cards = st.cards.map { if (it.id == c.id) it.copy(subject = fs.text.toString().trim().ifEmpty { "General" }, q = q, a = a) else it }.toMutableList()
                        save(); render()
                    }.setNegativeButton("Cancel", null).show()
            }

            fun updateAction() {
                action.removeViews(1, action.childCount - 1)
                if (ticked.isEmpty()) { action.visibility = View.GONE; selAll.text = "Select all"; return }
                action.visibility = View.VISIBLE
                selText.text = "${ticked.size} selected"
                selAll.text = "Clear"
                action.addView(btn("Move", false) {
                    val box = EditText(act).apply { hint = "Subject name"; setSingleLine() }
                    val known = st.cards.map { it.subject }.distinct().sortedBy { it.lowercase() }
                    SymBuilder(act).setTitle("Move ${ticked.size} card(s) to a subject")
                        .setMessage(if (known.isEmpty()) "" else "Existing: " + known.joinToString(", ")).setView(box)
                        .setPositiveButton("Move") { _, _ ->
                            val s = box.text.toString().trim().ifEmpty { return@setPositiveButton }
                            st.cards = st.cards.map { if (it.id in ticked) it.copy(subject = s) else it }.toMutableList()
                            ticked.clear(); save(); render()
                        }.setNegativeButton("Cancel", null).show()
                }, lp().apply { marginEnd = dp(8) })
                action.addView(btn("Delete", true, Color.parseColor("#E5707E")) {
                    SymBuilder(act).setTitle("Delete ${ticked.size} card(s)?").setMessage("This can't be undone.")
                        .setPositiveButton("Delete") { _, _ ->
                            st.cards = st.cards.filter { it.id !in ticked }.toMutableList()
                            ticked.clear(); save(); render()
                        }.setNegativeButton("Cancel", null).show()
                })
            }

            render = {
                list.removeAllViews()
                val groups = CardList.group(st.cards, query)
                title.text = "My cards (${st.cards.size})"
                if (groups.isEmpty()) list.addView(tv(if (st.cards.isEmpty()) "No cards yet. Add some in the Flashcards card, or make them from a notes file." else "No card matches \"$query\".", 14f, th.sub).apply { setPadding(dp(4), dp(24), dp(4), 0) })
                for ((subject, cards) in groups) {
                    val allOn = cards.all { it.id in ticked }
                    val head = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(14), dp(4), dp(6)) }
                    val open = subject !in closed || query.isNotBlank()
                    head.addView(tv((if (open) "▾ " else "▸ ") + subject + "  (${cards.size})", 15f, th.accent, true), lp(0, weight = 1f))
                    head.addView(tv(if (allOn) "Untick all" else "Tick all", 12f, th.sub).apply { setPadding(dp(10), dp(4), dp(4), dp(4)); isClickable = true
                        setOnClickListener { if (allOn) cards.forEach { ticked.remove(it.id) } else cards.forEach { ticked.add(it.id) }; render() } })
                    head.setOnClickListener { if (subject in closed) closed.remove(subject) else closed.add(subject); render() }
                    list.addView(head, lp())
                    if (!open) continue
                    for (c in cards) {
                        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = rounded(th.card, 14, if (c.id in ticked) th.accent else th.stroke); setPadding(dp(8), dp(10), dp(12), dp(10)) }
                        val cb = android.widget.CheckBox(act).apply { isChecked = c.id in ticked; buttonTintList = android.content.res.ColorStateList.valueOf(th.accent)
                            setOnCheckedChangeListener { _, on -> if (on) ticked.add(c.id) else ticked.remove(c.id); updateAction(); (row.background as GradientDrawable).setStroke(dp(1), if (on) th.accent else th.stroke) } }
                        row.addView(cb)
                        val txt = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
                        val q = tv(c.q.lines().first(), 14f, th.main, true).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }
                        val a = tv("A: " + c.a.replace("\n", " "), 12f, th.sub).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }
                        val meta = tv("Box ${c.box + 1} of 5 · ${CardList.dueText(c, today)}", 11f, th.sub)
                        txt.addView(q); txt.addView(a); txt.addView(meta)
                        row.addView(txt, lp(0, weight = 1f))
                        row.addView(tv("✎", 18f, th.accent).apply { setPadding(dp(12), dp(6), dp(4), dp(6)); isClickable = true; setOnClickListener { editDialog(c) } })
                        list.addView(row, lp().apply { bottomMargin = dp(8) })
                    }
                }
                updateAction()
            }
            selAll.setOnClickListener {
                if (ticked.isNotEmpty()) ticked.clear() else CardList.group(st.cards, query).forEach { g -> g.second.forEach { ticked.add(it.id) } }
                render()
            }
            search.addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) { query = s?.toString().orEmpty(); render() }
                override fun beforeTextChanged(s: CharSequence?, st0: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st0: Int, b: Int, c: Int) {}
            })
            render()
        }.show()
    }

    // ------------------------------------------------------------------------------------------ cards made from a file

    class Draft(var q: String, var a: String, var on: Boolean = true)

    /** Tick-list for cards a file produced: untick the bad ones, fix wording, choose the subject, then add. */
    fun pickDrafts(title: String, intro: String, drafts: List<Draft>, defaultSubject: String, onAdd: (List<Draft>, String) -> Unit) {
        screen { root, d ->
            val selAll = tv("None", 14f, th.accent, true).apply { setPadding(dp(8), dp(6), dp(4), dp(6)); isClickable = true }
            topBar(root, d, title, selAll)
            root.addView(tv(intro, 13f, th.sub).apply { setPadding(dp(2), dp(8), dp(2), dp(8)) }, lp())
            val subject = EditText(act).apply { hint = "Subject for these cards"; setText(defaultSubject); setHintTextColor(th.sub); setTextColor(th.main); textSize = 14f; setSingleLine(); background = rounded(th.field, 12, th.stroke); setPadding(dp(12), dp(9), dp(12), dp(9)) }
            root.addView(subject, lp().apply { bottomMargin = dp(8) })
            val scroll = ScrollView(act); val list = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
            scroll.addView(list); root.addView(scroll, lp(h = 0, weight = 1f))
            val bottom = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, 0) }
            root.addView(bottom, lp())
            lateinit var render: () -> Unit
            fun addBtn() {
                bottom.removeAllViews()
                bottom.addView(btn("Cancel", false) { d.dismiss() }, lp(0, weight = 1f).apply { marginEnd = dp(8) })
                val n = drafts.count { it.on }
                bottom.addView(btn(if (n == 0) "Nothing ticked" else "Add $n card${if (n == 1) "" else "s"}", n > 0) {
                    if (n == 0) return@btn
                    onAdd(drafts.filter { it.on }, subject.text.toString().trim().ifEmpty { "General" }); d.dismiss()
                }, lp(0, weight = 1.6f))
                selAll.text = if (n == drafts.size) "None" else "All"
            }
            fun edit(dr: Draft) {
                val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0) }
                val fq = EditText(act).apply { setText(dr.q); minLines = 2; gravity = Gravity.TOP; hint = "Question"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
                val fa = EditText(act).apply { setText(dr.a); minLines = 3; gravity = Gravity.TOP; hint = "Answer"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
                col.addView(fq); col.addView(fa)
                SymBuilder(act).setTitle("Fix this card").setView(ScrollView(act).apply { addView(col) })
                    .setPositiveButton("Save") { _, _ -> if (fq.text.isNotBlank() && fa.text.isNotBlank()) { dr.q = fq.text.toString().trim(); dr.a = fa.text.toString().trim(); render() } }
                    .setNegativeButton("Cancel", null).show()
            }
            render = {
                list.removeAllViews()
                for (dr in drafts) {
                    val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = rounded(th.card, 14, if (dr.on) th.accent else th.stroke); setPadding(dp(8), dp(10), dp(12), dp(10)) }
                    row.addView(android.widget.CheckBox(act).apply { isChecked = dr.on; buttonTintList = android.content.res.ColorStateList.valueOf(th.accent)
                        setOnCheckedChangeListener { _, on -> dr.on = on; (row.background as GradientDrawable).setStroke(dp(1), if (on) th.accent else th.stroke); addBtn() } })
                    val txt = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
                    txt.addView(tv(dr.q, 14f, th.main, true).apply { maxLines = 3; ellipsize = android.text.TextUtils.TruncateAt.END })
                    txt.addView(tv(dr.a.replace("\n", " "), 12f, th.sub).apply { maxLines = 3; ellipsize = android.text.TextUtils.TruncateAt.END })
                    row.addView(txt, lp(0, weight = 1f))
                    row.addView(tv("✎", 18f, th.accent).apply { setPadding(dp(12), dp(6), dp(4), dp(6)); isClickable = true; setOnClickListener { edit(dr) } })
                    list.addView(row, lp().apply { bottomMargin = dp(8) })
                }
                addBtn()
            }
            selAll.setOnClickListener { val on = drafts.any { !it.on }; drafts.forEach { it.on = on }; render() }
            render()
        }.show()
    }
}
