package com.ghostie.pet

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Food price reader. READ-ONLY by design.
 *
 *  - It only works on the food apps listed in res/xml/food_accessibility_config.xml.
 *  - It does nothing unless you asked for a price check ("cheapest chicken biryani") - [active] is false otherwise,
 *    and events are ignored.
 *  - The only things it ever does inside an app: open it, tap the search box, type your item, press search,
 *    scroll, and read the text on screen. [FORBIDDEN] words make it refuse to touch anything that could add to a
 *    cart, pay or place an order, and it never opens a cart or checkout.
 *  - Nothing is saved or sent anywhere except the result Ghostie tells you.
 */
class FoodScanService : AccessibilityService() {
    private val worker = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    companion object {
        @Volatile var instance: FoodScanService? = null
        @Volatile var active = false
        @Volatile private var cancel = false

        private val FORBIDDEN = Regex("(?i)\\b(pay|payment|place order|order now|checkout|check out|proceed|cart|buy|add|subscribe|confirm|upi|wallet|bill|login|log in|sign in|otp)\\b")

        fun isEnabled(ctx: Context): Boolean {
            val e = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            return e.contains("FoodScanService")
        }

        /** Installed food apps (by known id, or by the app's name for brand apps). */
        fun resolve(ctx: Context, app: FoodApp): String? {
            val pm = ctx.packageManager
            app.packages.firstOrNull { pm.getLaunchIntentForPackage(it) != null }?.let { return it }
            val key = (app.brand ?: app.label).lowercase()
            return try {
                pm.getInstalledApplications(0).firstOrNull { a ->
                    pm.getLaunchIntentForPackage(a.packageName) != null && pm.getApplicationLabel(a).toString().lowercase().contains(key)
                }?.packageName
            } catch (e: Exception) { null }
        }

        fun stop() { cancel = true }

        /** Starts a price check; [done] is called on the main thread with the finished report. */
        fun start(ctx: Context, items: List<WantedItem>, appIds: List<String>, defaultFee: Int, progress: (String) -> Unit, done: (String) -> Unit): String? {
            val svc = instance ?: return "off"
            if (active) return "busy"
            svc.run(ctx.applicationContext, items, appIds, defaultFee, progress, done)
            return null
        }
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* nothing is read unless a check is running */ }
    override fun onInterrupt() { cancel = true }
    override fun onDestroy() { if (instance === this) instance = null; cancel = true; worker.shutdown(); super.onDestroy() }

    private fun run(ctx: Context, items: List<WantedItem>, appIds: List<String>, defaultFee: Int, progress: (String) -> Unit, done: (String) -> Unit) {
        active = true; cancel = false; reasons.clear(); dbg.setLength(0); peekedRest.clear(); feeByRest.clear(); avoidLabels.clear(); peekCount = 0; cartNotes.clear()
        worker.execute {
            val offers = mutableListOf<Offer>()
            val read = mutableListOf<String>()
            val failed = mutableListOf<String>()
            val started = System.currentTimeMillis()
            val budget = 360_000L // up to 6 minutes in total
            progressCb = progress
            try {
                for ((idx, id) in appIds.withIndex()) {
                    val app = FoodApps.byId(id) ?: continue
                    if (cancel || System.currentTimeMillis() - started > budget) { failed += app.label + " (stopped)"; continue }
                    val pkg = resolve(ctx, app)
                    if (pkg == null) { failed += app.label + " (not installed)"; continue }
                    if (!FoodApps.ALL.any { pkg in it.packages } && !allowedPackages().contains(pkg)) { failed += app.label + " (not allowed - ask me to add it)"; continue }
                    val left = started + budget - System.currentTimeMillis()
                    deadline = System.currentTimeMillis() + maxOf(60_000L, left / (appIds.size - idx).coerceAtLeast(1))
                    ui.post { progress("Checking ${app.label}…") }
                    var got = false
                    for (it in items) {
                        if (cancel) break
                        val found = scanApp(ctx, pkg, app, it.name)
                        if (found != null) { got = true; offers += found }
                    }
                    if (got) read += app.label else failed += app.label + (reasons[app.label]?.let { " ($it)" } ?: "")
                }
            } catch (e: Exception) {
                failed += "error: ${e.message}"
            } finally {
                active = false
                try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (e: Exception) {}
            }
            try { SettingsStore(ctx).foodDebug = dbg.toString() } catch (e: Exception) { }
            val fee = defaultFee
            var report = FoodCompare.report(items, offers, failed, read, fee)
            if (cartNotes.isNotEmpty()) report += "\n\n⚠️ " + cartNotes.joinToString("\n⚠️ ")
            ui.post { done(report) }
        }
    }

    /** The window of [pkg] - not "the active window", which can be Ghostie's own chat box while it is open. */
    private fun appRoot(pkg: String): AccessibilityNodeInfo? {
        val active = rootInActiveWindow
        if (active?.packageName?.toString() == pkg) return active
        try {
            for (w in windows) {
                val r = w.root ?: continue
                if (r.packageName?.toString() == pkg) return r
            }
        } catch (e: Exception) { }
        return null
    }

    private val reasons = HashMap<String, String>()
    /** Plain-text trace of the last check (what each app showed), so a failure can be diagnosed. Stays on the phone until you share it. */
    private val dbg = StringBuilder()
    private fun log(t: String) { if (dbg.length < 60_000) dbg.append(t).append('\n') }

    private fun dumpNodes(root: AccessibilityNodeInfo?, limit: Int = 160) {
        if (root == null) { log("  (no window)"); return }
        var n = 0
        walk(root) { node ->
            if (n < limit) {
                val t = listOfNotNull(node.text?.toString()?.take(50), node.contentDescription?.toString()?.take(50)?.let { "desc=$it" },
                    node.viewIdResourceName?.substringAfterLast('/')?.let { "id=$it" }).joinToString(" | ")
                if (t.isNotBlank() || node.isEditable || node.isClickable) {
                    log("  ${node.className?.toString()?.substringAfterLast('.')}${if (node.isClickable) " [click]" else ""}${if (node.isEditable) " [edit]" else ""}: $t")
                    n++
                }
            }
        }
    }

    /** Words that mean a popup is in the way. */
    private val BLOCKERS = Regex("(?i)service paused|isn't available right now|not available right now|update available|allow .* (?:location|access)|while using the app|sorry, we are closed|temporarily unavailable|select a delivery slot|log ?in|sign in|enter (?:your )?(?:phone|mobile)|verify")
    private fun blockerHint(root: AccessibilityNodeInfo?): String? {
        var hit: String? = null
        walk(root) { n -> if (hit == null) BLOCKERS.find(label(n))?.let { hit = it.value } }
        return hit
    }
    private fun fail(app: FoodApp, why: String): List<Offer>? { reasons[app.label] = why; return null }

    private fun allowedPackages(): Set<String> = FoodApps.ALL.flatMap { it.packages }.toSet()

    private var deadline = 0L
    private var progressCb: (String) -> Unit = {}
    private fun timeUp() = cancel || System.currentTimeMillis() > deadline
    private fun say(m: String) { val cb = progressCb; ui.post { cb(m) } }

    private fun editableShown(pkg: String): Boolean = findInput(appRoot(pkg)) != null
    private fun pricesShown(pkg: String): Boolean {
        val l = readScreen(appRoot(pkg), pkg)
        return l != null && l.count { FoodCompare.priceOf(it) != null } >= 2
    }

    private fun scrollToTop(pkg: String) {
        repeat(4) { findScrollable(appRoot(pkg))?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD); sleep(500) }
    }

    private fun tapFraction(fx: Float, fy: Float): Boolean {
        val m = resources.displayMetrics
        val path = Path().apply { moveTo(m.widthPixels * fx, m.heightPixels * fy) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build()
        val latch = CountDownLatch(1)
        var ok = false
        if (!dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
                override fun onCancelled(d: GestureDescription?) { latch.countDown() }
            }, null)) return false
        latch.await(3, TimeUnit.SECONDS)
        return ok
    }

    /** Opens the app's search page. Returns false (with a reason logged) if it can't. */
    private var lastSearchLabel: String? = null
    private fun openSearch(pkg: String, app: FoodApp): Boolean {
        var found: AccessibilityNodeInfo? = null
        waitFor(20_000) { found = findSearch(appRoot(pkg)); if (found == null) dismissPopups(pkg); found != null }
        sleep(600)
        val box = found ?: findSearch(appRoot(pkg))
        if (box != null) {
            lastSearchLabel = label(box).trim()
            if (tap(box)) { waitFor(8_000) { editableShown(pkg) }; if (editableShown(pkg)) return true }
            log("tapped search node ${label(box).take(60)} but no text box opened")
        } else {
            log("no search node; screen nodes:"); dumpNodes(appRoot(pkg))
        }
        // The app doesn't expose its search bar: scroll to the top and touch where it normally sits.
        for ((fx, fy) in app.searchTaps) {
            scrollToTop(pkg)
            log("touching ($fx, $fy)")
            tapFraction(fx, fy)
            waitFor(5_000) { editableShown(pkg) }
            if (editableShown(pkg)) return true
        }
        return false
    }

    /** Types the item and gets a results page, trying the keyboard key, a suggestion, the search button, then a category tile. */
    private fun submitSearch(pkg: String, item: String): Boolean {
        if (wrongScreen(pkg)) return false
        val input = findInput(appRoot(pkg)) ?: return false
        if (!typeInto(input, item)) return false
        sleep(600)
        val entered = try { input.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id) } catch (e: Throwable) { false }
        log("typed \"$item\"; keyboard search pressed=$entered")
        if (!entered) findSearchButton(appRoot(pkg))?.let { tap(it) }
        waitFor(10_000) { pricesShown(pkg) }
        if (!pricesShown(pkg)) {
            val words = item.lowercase().split(' ').filter { it.isNotBlank() }
            var sug: AccessibilityNodeInfo? = null
            walk(appRoot(pkg)) { n ->
                val t = n.text?.toString()?.lowercase()
                if (sug == null && t != null && n.isVisibleToUser && !n.isEditable && words.all { t.contains(it) } && !FORBIDDEN.containsMatchIn(t)) sug = n
            }
            sug?.let { log("tapping suggestion: ${it.text}"); tap(it) }
            waitFor(10_000) { pricesShown(pkg) }
        }
        if (!pricesShown(pkg)) {
            findSearchButton(appRoot(pkg))?.let { log("tapping search button"); tap(it) }
            waitFor(8_000) { pricesShown(pkg) }
        }
        if (!pricesShown(pkg)) {
            val head = item.lowercase().split(' ').filter { it.isNotBlank() }.lastOrNull()
            if (head != null) {
                var tile: AccessibilityNodeInfo? = null
                walk(appRoot(pkg)) { n -> if (tile == null && n.isVisibleToUser && !n.isEditable && n.text?.toString()?.trim()?.equals(head, true) == true) tile = n }
                tile?.let { log("tapping category tile: ${it.text}"); tap(it); waitFor(9_000) { pricesShown(pkg) } }
            }
        }
        return true // even without prices: restaurant lists are handled by the caller
    }

    /** Reads up to [maxPages] screens (scrolling), stopping when nothing new appears. */
    private fun readPages(pkg: String, app: FoodApp, item: String, maxPages: Int, rest: String?, logPages: Int = 2): List<Offer> {
        val out = mutableListOf<Offer>()
        val seen = HashSet<String>()
        var stale = 0
        // loading screens ("Hold tight...", splash logos) show only a line or two: wait for real content
        waitFor(15_000) { dismissPopups(pkg); (readScreen(appRoot(pkg), pkg)?.size ?: 0) >= 6 }
        for (page in 0 until maxPages) {
            if (timeUp()) break
            if (page > 0) dismissPopups(pkg)
            val lines = readScreen(appRoot(pkg), pkg) ?: break
            val fresh = lines.count { seen.add(it) }
            val got = FoodCompare.offersFromScreen(app.label, item, lines, rest ?: app.brand?.let { app.label })
            log("page $page: ${lines.size} lines ($fresh new), ${got.size} offers")
            if (page < logPages) lines.take(60).forEach { log("  | $it") }
            out += got
            // delivery fee only shows in the cart: add one item, read the fee, take it out again (never orders)
            val cand = got.firstOrNull { it.fee == null && feeByRest[it.restaurant.lowercase()] == null && it.restaurant.lowercase() !in peekedRest }
            if (cand != null && peekCount < 6 && deadline - System.currentTimeMillis() > 45_000 && !timeUp()) {
                peekedRest += cand.restaurant.lowercase()
                say("${app.label}: checking the delivery fee…")
                cartFee(pkg, cand.item)?.let { feeByRest[cand.restaurant.lowercase()] = it }
            }
            if (fresh == 0) { if (++stale >= 2) break } else stale = 0
            val sc = findScrollable(appRoot(pkg)) ?: break
            if (!sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) break
            sleep(1500)
        }
        return out.map { o -> if (o.fee == null) feeByRest[o.restaurant.lowercase()]?.let { o.copy(fee = it) } ?: o else o }
            .distinctBy { Triple(it.restaurant.lowercase(), it.item.lowercase(), it.price) }
    }

    // ---- delivery fee via the cart (adds ONE item, reads the fee, removes it; never pays or orders) ----

    private val peekedRest = HashSet<String>()
    private val feeByRest = HashMap<String, Int>()
    private var peekCount = 0
    private val cartNotes = LinkedHashSet<String>()
    private val NEVER = Regex("(?i)\\b(pay|payment|place order|order now|checkout|check out|proceed|confirm|upi|wallet|login|log in|sign in|otp|subscribe|buy now)\\b")
    private val CART_OPEN = Regex("(?i)\\b(view cart|go to cart|view basket|my cart|cart)\\b")
    private val REMOVE = Regex("(?i)^(remove|remove item|clear cart|clear|delete|decrease quantity|decrease|minus|[-\u2212\u2013])$")
    private val SHEET_ADD = Regex("(?i)^(add item.*|add to cart.*|add \\d+ item.*|add for.*)$")

    /** Click that refuses anything about paying/ordering; unlike [tap] it may press Add and cart buttons. */
    private fun safeClick(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        var d = 0
        while (cur != null && d < 5) {
            val l = label(cur)
            if (l.length < 100 && NEVER.containsMatchIn(l)) return false
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent; d++
        }
        return if (NEVER.containsMatchIn(label(n))) false else tapAt(n)
    }

    /** The "ADD" button that belongs to the dish called [item] on the current screen. */
    private fun findAddFor(root: AccessibilityNodeInfo?, item: String): AccessibilityNodeInfo? {
        val words = item.lowercase().split(' ').filter { it.length > 2 }
        if (words.isEmpty()) return null
        var nameNode: AccessibilityNodeInfo? = null
        walk(root) { n ->
            val t = n.text?.toString()?.lowercase()
            if (nameNode == null && t != null && n.isVisibleToUser && t.length < 80 && words.all { t.contains(it) }) nameNode = n
        }
        var cur: AccessibilityNodeInfo? = nameNode ?: return null
        var d = 0
        while (cur != null && d < 7) {
            var add: AccessibilityNodeInfo? = null
            walk(cur) { n -> if (add == null && n.isVisibleToUser && n.text?.toString()?.trim().equals("add", true)) add = n }
            if (add != null) return add
            cur = cur.parent; d++
        }
        return null
    }

    private fun findLabel(pkg: String, re: Regex, exclude: Regex? = null): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        walk(appRoot(pkg)) { n ->
            val l = label(n).trim()
            if (best == null && n.isVisibleToUser && l.length < 80 && re.containsMatchIn(l) && (exclude == null || !exclude.containsMatchIn(l)) && !NEVER.containsMatchIn(l)) best = n
        }
        return best
    }

    private fun deliveryFeeIn(lines: List<String>): Int? {
        for ((i, l) in lines.withIndex()) {
            if (!l.contains("delivery", true) || Regex("(?i)delivery (time|in|address|to)\\b|\\d+\\s*mins?").containsMatchIn(l)) continue
            FoodCompare.feeOf(l)?.let { return it }
            for (j in 1..2) {
                val nx = lines.getOrNull(i + j) ?: break
                if (Regex("(?i)^free\\b").containsMatchIn(nx.trim())) return 0
                if (FoodCompare.isPriceLine(nx.trim())) return FoodCompare.priceOf(nx)
            }
        }
        return null
    }

    /** Adds [item] to the cart, reads the delivery fee, empties the cart again. Null when anything looks unsafe or unclear. */
    private fun cartFee(pkg: String, item: String): Int? {
        val add = findAddFor(appRoot(pkg), item) ?: run { log("cart: no Add button next to $item"); return null }
        peekCount++
        log("cart: adding \"$item\"")
        if (!safeClick(add)) { log("cart: Add refused"); return null }
        sleep(2000)
        findLabel(pkg, SHEET_ADD)?.let { log("cart: confirming options sheet"); safeClick(it); sleep(1800) }
        var cartBtn: AccessibilityNodeInfo? = null
        waitFor(7_000) { cartBtn = findLabel(pkg, CART_OPEN, Regex("(?i)\\badd\\b")); cartBtn != null }
        var fee: Int? = null
        if (cartBtn != null && safeClick(cartBtn!!)) {
            sleep(2500)
            waitFor(10_000) { readScreen(appRoot(pkg), pkg)?.any { it.contains("delivery", true) || it.contains("item total", true) } == true }
            for (pg in 0..2) {
                val lines = readScreen(appRoot(pkg), pkg) ?: break
                if (pg == 0) { log("cart screen:"); lines.take(50).forEach { log("  | $it") } }
                fee = deliveryFeeIn(lines)
                if (fee != null) break
                val sc = findScrollable(appRoot(pkg)) ?: break
                if (!sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) break
                sleep(1200)
            }
            log("cart: delivery fee = $fee")
        } else log("cart: no cart button found")
        // take everything out again
        var cleaned = false
        for (i in 0 until 8) {
            if (timeUp()) break
            val rm = findLabel(pkg, REMOVE)
            if (rm == null) { cleaned = true; break }
            safeClick(rm); sleep(1100)
        }
        val onCart = readScreen(appRoot(pkg), pkg)?.any { it.contains("item total", true) || it.contains("bill details", true) } == true
        if (onCart) { performGlobalAction(GLOBAL_ACTION_BACK); sleep(1200) }
        val still = findLabel(pkg, CART_OPEN, Regex("(?i)\\badd\\b"))
        if ((still != null && label(still).contains("view", true)) || !cleaned) {
            val an = FoodApps.ALL.firstOrNull { pkg in it.packages }?.label ?: pkg
            cartNotes += "I couldn't fully empty the cart in $an - please clear it yourself (I did not order anything)."
        }
        return fee
    }

    // ---- restaurant cards (Zomato / Swiggy) -------------------------------------------------

    private class Card(val node: AccessibilityNodeInfo, val name: String, val rating: Double?)
    private val RATING = Regex("^([1-5]\\.\\d)(?:\\s|\\(|$)")
    private val MINS = Regex("\\d+\\s*(?:-\\s*\\d+)?\\s*mins?\\b", RegexOption.IGNORE_CASE)
    private val NOT_NAMES = Regex("(?i)^(?:items?|ad|ads|promoted|bestseller|free|new|pure veg|veg|non-?veg)$")

    private fun texts(n: AccessibilityNodeInfo): List<String> {
        val out = mutableListOf<String>()
        walk(n) { d -> d.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { out += it } }
        return out
    }

    /** Restaurant cards on screen: a tappable block that shows a rating and a delivery time. */
    private fun findCards(root: AccessibilityNodeInfo?): List<Card> {
        val out = mutableListOf<Card>()
        val names = HashSet<String>()
        walk(root) { n ->
            val t = n.text?.toString()?.trim()
            if (t != null && n.isVisibleToUser && RATING.containsMatchIn(t)) {
                var cur: AccessibilityNodeInfo? = n.parent
                var d = 0
                while (cur != null && d < 8 && !cur.isClickable) { cur = cur.parent; d++ }
                val card = cur
                if (card != null && card.isClickable) {
                    val tx = texts(card)
                    if (tx.any { MINS.containsMatchIn(it) }) {
                        val desc = card.contentDescription?.toString()
                        val name = if (desc != null && desc.contains(", serving ")) desc.substringBefore(", serving ").trim()
                        else tx.firstOrNull { FoodCompare.looksLikeName(it) && !NOT_NAMES.matches(it) }
                        if (name != null && (RATING.find(t)?.groupValues?.get(1)?.toDoubleOrNull() ?: 9.0) <= 5.0 && names.add(name.lowercase())) out += Card(card, name, RATING.find(t)?.groupValues?.get(1)?.toDoubleOrNull())
                    }
                }
            }
        }
        return out
    }

    /** Opens the top few restaurants (well rated ones first), reads each menu for the item, and backs out. */
    private fun drill(pkg: String, app: FoodApp, item: String, maxRestaurants: Int = 5): List<Offer> {
        val out = mutableListOf<Offer>()
        val visited = HashSet<String>()
        var n = 0
        while (n < maxRestaurants && !timeUp()) {
            var card: Card? = null
            for (attempt in 0..5) {
                val cards = findCards(appRoot(pkg)).filter { it.name.lowercase() !in visited }
                card = cards.firstOrNull { (it.rating ?: 0.0) >= 4.0 } ?: cards.firstOrNull()
                if (card != null) break
                val sc = findScrollable(appRoot(pkg)) ?: break
                if (!sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) break
                sleep(1500)
            }
            val c = card ?: break
            visited += c.name.lowercase()
            n++
            say("${app.label}: looking through ${c.name} ($n/$maxRestaurants)…")
            log("opening restaurant ${c.name} (rating ${c.rating})")
            if (!tap(c.node)) { log("couldn't tap ${c.name}"); continue }
            waitFor(14_000) { (readScreen(appRoot(pkg), pkg)?.size ?: 0) >= 10 }
            sleep(1500)
            val first = readScreen(appRoot(pkg), pkg)
            val fee = first?.firstNotNullOfOrNull { FoodCompare.feeOf(it) }
            val got = readPages(pkg, app, item, 9, c.name, logPages = 1).map { if (it.fee == null && fee != null) it.copy(fee = fee) else it }
            log("restaurant ${c.name}: ${got.size} offers, fee=$fee")
            out += got
            performGlobalAction(GLOBAL_ACTION_BACK)
            sleep(1800)
        }
        return out
    }

    private fun tapDishesTab(pkg: String): Boolean {
        var tab: AccessibilityNodeInfo? = null
        walk(appRoot(pkg)) { n -> if (tab == null && n.isVisibleToUser && label(n).trim().equals("Dishes", true)) tab = n }
        val t = tab ?: return false
        log("tapping Dishes tab")
        if (!tap(t)) return false
        waitFor(8_000) { pricesShown(pkg) }
        return true
    }

    /** Apps with no search box (Popeyes): read the menu by scrolling, plus category tiles that share a word with the item. */
    private fun scanMenuOnly(pkg: String, app: FoodApp, item: String): List<Offer>? {
        val blocker = blockerHint(appRoot(pkg))
        val offers = mutableListOf<Offer>()
        offers += readPages(pkg, app, item, 10, app.label)
        val words = item.lowercase().split(' ').filter { it.length > 2 }
        val seenTiles = HashSet<String>()
        var tiles = 0
        while (tiles < 3 && !timeUp()) {
            var tile: AccessibilityNodeInfo? = null
            walk(appRoot(pkg)) { n ->
                val t = n.text?.toString()?.trim()?.lowercase()
                if (tile == null && t != null && n.isVisibleToUser && t.length in 3..24 && t !in seenTiles && words.any { w -> t.contains(w) || w.contains(t) } && !FORBIDDEN.containsMatchIn(t)) {
                    var cur: AccessibilityNodeInfo? = n
                    var d = 0
                    while (cur != null && d < 4 && !cur.isClickable) { cur = cur.parent; d++ }
                    if (cur != null && cur.isClickable) { tile = cur; seenTiles += t }
                }
            }
            val tl = tile ?: break
            tiles++
            log("opening category: ${label(tl).take(40)}")
            if (!tap(tl)) continue
            sleep(2500)
            offers += readPages(pkg, app, item, 8, app.label, logPages = 1)
            performGlobalAction(GLOBAL_ACTION_BACK)
            sleep(1500)
        }
        if (offers.isEmpty() && blocker != null) return fail(app, "\"$blocker\" - delivery isn't available in this app right now")
        return offers.distinctBy { Triple(it.restaurant.lowercase(), it.item.lowercase(), it.price) }
    }

    /** Opens [pkg], searches [item] and returns offers read from the results, or null if the app could not be read. */
    private fun scanApp(ctx: Context, pkg: String, app: FoodApp, item: String): List<Offer>? {
        val launch = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return fail(app, "can't open it")
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try { startActivity(launch) } catch (e: Exception) { return fail(app, "Android blocked opening it") }
        if (!waitFor(25_000) { appRoot(pkg) != null }) return fail(app, "it didn't come to the front")
        log("=== ${app.label} ($pkg) \"$item\"")
        sleep(2000)
        dismissPopups(pkg)
        if (app.noSearch) return scanMenuOnly(pkg, app, item)

        var typed = false
        for (attempt in 0..1) {
            if (!openSearch(pkg, app)) {
                var count = 0
                walk(appRoot(pkg)) { count++ }
                return fail(app, blockerHint(appRoot(pkg))?.let { "\"$it\" is showing - clear it in the app, or it may not be usable right now" }
                    ?: if (count <= 8) "the app shows Ghostie an empty screen (it hides its content from screen readers)" else "couldn't open its search")
            }
            if (wrongScreen(pkg)) {
                log("wrong screen (train/PNR/login) after opening search - going back")
                lastSearchLabel?.let { avoidLabels += it }
                repeat(3) { if (wrongScreen(pkg)) { performGlobalAction(GLOBAL_ACTION_BACK); sleep(1300) } }
                dismissPopups(pkg)
                continue
            }
            typed = submitSearch(pkg, item)
            break
        }
        if (!typed) return fail(app, "couldn't open a real search box (it kept landing on another page)")
        sleep(800)

        val offers = mutableListOf<Offer>()
        offers += readPages(pkg, app, item, 10, null)
        if (app.id == "zomato" || app.id == "swiggy") {
            if (offers.size < 3) {
                // results are restaurants: try a Dishes tab, then open the top restaurants' menus
                if (tapDishesTab(pkg)) offers += readPages(pkg, app, item, 6, null)
                if (offers.size < 3 && !timeUp()) offers += drill(pkg, app, item)
            }
        }
        // back out so the app is left on a normal screen
        repeat(4) { if (findSearch(appRoot(pkg)) == null || editableShown(pkg)) { performGlobalAction(GLOBAL_ACTION_BACK); sleep(600) } }
        if (offers.isEmpty()) reasons[app.label] = "read the results but found no matching price"
        return offers.distinctBy { Triple(it.restaurant.lowercase(), it.item.lowercase(), it.price) }
    }

    // ---- screen helpers ----------------------------------------------------------------------

    /** Types [text] into [input]: focus + set text; if the app ignores that, paste it (the clipboard is put back afterwards). */
    private fun typeInto(input: AccessibilityNodeInfo, text: String): Boolean {
        input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        input.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        sleep(300)
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        val set = input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        sleep(500)
        input.refresh()
        var has = input.text?.toString()?.contains(text, true) == true
        if (!has) {
            try {
                val cm = getSystemService(ClipboardManager::class.java)
                val prev = cm.primaryClip
                cm.setPrimaryClip(ClipData.newPlainText("ghostie", text))
                input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                input.performAction(AccessibilityNodeInfo.ACTION_PASTE)
                sleep(600)
                input.refresh()
                has = input.text?.toString()?.contains(text, true) == true
                if (prev != null) cm.setPrimaryClip(prev)
            } catch (e: Exception) { }
        }
        log("typing: set=$set, field now='${input.text}'")
        return set || has
    }

    private fun sleep(ms: Long) { try { Thread.sleep(ms) } catch (e: InterruptedException) {} }

    private fun waitFor(ms: Long, cond: () -> Boolean): Boolean {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) { if (cancel) return false; if (cond()) return true; sleep(400) }
        return false
    }

    private fun label(n: AccessibilityNodeInfo): String =
        listOfNotNull(n.text, n.contentDescription, if (android.os.Build.VERSION.SDK_INT >= 26) n.hintText else null).joinToString(" ")

    private fun walk(root: AccessibilityNodeInfo?, depth: Int = 0, f: (AccessibilityNodeInfo) -> Unit) {
        if (root == null || depth > 40) return
        f(root)
        for (i in 0 until root.childCount) walk(root.getChild(i), depth + 1, f)
    }

    /** The search entry: nodes mentioning "search" win, clickable ones first; an id like "search_edit_text" counts only if it can be tapped. */
    private fun findSearch(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestScore = 0
        walk(root) { n ->
            if (n.isVisibleToUser) {
                val l = label(n)
                if (!FORBIDDEN.containsMatchIn(l) && l.trim() !in avoidLabels) {
                    val said = l.contains("search", true)
                    val idHit = n.viewIdResourceName?.substringAfterLast('/')?.contains("search", true) == true && n.isClickable &&
                        n.viewIdResourceName?.contains("location", true) != true
                    var sc = 0
                    if (said) sc += 2
                    if (said && l.contains("open search", true)) sc += 2
                    if ((said || idHit) && n.isClickable) sc += 2
                    if (idHit) sc += 1
                    if (sc > bestScore) { bestScore = sc; best = n }
                }
            }
        }
        if (best == null) walk(root) { n -> if (best == null && n.isVisibleToUser && n.isEditable && !NOT_SEARCH_FIELD.containsMatchIn(label(n) + " " + (n.hintText ?: ""))) best = n }
        return best
    }

    /** Labels of nodes that already led somewhere wrong (e.g. Domino's train/PNR page); not tried again in this run. */
    private val avoidLabels = HashSet<String>()
    private val NOT_SEARCH_FIELD = Regex("(?i)pnr|phone|mobile|otp|email|pincode|coupon|promo")
    private val WRONG_SCREEN = Regex("(?i)\\b(pnr|deliver on train|order on train|enter your mobile|enter otp|verify otp|log ?in|sign ?in)\\b")

    private fun wrongScreen(pkg: String): Boolean =
        readScreen(appRoot(pkg), pkg)?.take(40)?.any { WRONG_SCREEN.containsMatchIn(it) } == true

    /** Closes harmless popups ("Not now", "Skip"...). Never presses Allow/Enable/Update/Yes or anything about orders. */
    private val POPUP_SAFE = setOf("not now", "skip", "skip for now", "maybe later", "later", "remind me later", "no thanks", "no, thanks", "not interested", "dismiss", "close", "cancel", "got it", "okay", "ok", "x", "\u2715", "\u2716", "no", "deny", "don't allow", "don\u2019t allow", "continue without login", "continue as guest", "skip login", "i'll do it later")

    /** Closes the harmless pop-ups apps like to show (offers, rate us, notification/location asks); never accepts anything. */
    private fun dismissPopups(pkg: String): Boolean {
        var did = false
        repeat(4) {
            var target: AccessibilityNodeInfo? = null
            // permission / system dialogs live in their own window
            try {
                for (w in windows) {
                    val r = w.root ?: continue
                    val wp = r.packageName?.toString() ?: continue
                    if (wp.contains("permissioncontroller") || wp.contains("packageinstaller")) {
                        walk(r) { n -> val t = label(n).trim().lowercase(); if (target == null && n.isVisibleToUser && (t == "don't allow" || t == "don\u2019t allow" || t == "deny" || t == "not now")) target = n }
                    }
                }
            } catch (e: Exception) { }
            if (target == null) walk(appRoot(pkg)) { n ->
                val t = label(n).trim().lowercase()
                if (target == null && n.isVisibleToUser && t.length <= 40 && t in POPUP_SAFE && (n.isClickable || n.parent?.isClickable == true)) target = n
            }
            val t = target ?: return did
            log("dismissing popup: ${label(t).take(40)}")
            if (!t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) { val par = t.parent; if (par == null || !par.performAction(AccessibilityNodeInfo.ACTION_CLICK)) tapAt(t) }
            did = true
            sleep(900)
        }
        return did
    }

    private fun findSearchButton(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        walk(root) { n ->
            if (best == null && n.isVisibleToUser && n.className?.toString()?.contains("EditText") != true) {
                val l = (n.contentDescription ?: "").toString()
                if (l.equals("search", true) && !FORBIDDEN.containsMatchIn(l)) best = n
            }
        }
        return best
    }

    private fun findInput(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        walk(root) { n -> if (best == null && n.isVisibleToUser && n.isEditable && !NOT_SEARCH_FIELD.containsMatchIn(label(n) + " " + (n.hintText ?: ""))) best = n }
        return best
    }

    private fun findScrollable(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        walk(root) { n -> if (best == null && n.isScrollable && n.isVisibleToUser) best = n }
        return best
    }

    /** Taps [n]: click it or its nearest clickable parent, else a plain touch at its centre. Refuses anything about paying, carts or ordering. */
    private fun tap(n: AccessibilityNodeInfo): Boolean {
        if (FORBIDDEN.containsMatchIn(label(n))) return false
        var cur: AccessibilityNodeInfo? = n
        var depth = 0
        while (cur != null && depth < 6) {
            val l = label(cur)
            if (l.length < 80 && FORBIDDEN.containsMatchIn(l)) return false
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent; depth++
        }
        return tapAt(n)
    }

    /** Touch at the centre of [n] (works for custom views that don't report as clickable). */
    private fun tapAt(n: AccessibilityNodeInfo): Boolean {
        val r = Rect(); n.getBoundsInScreen(r)
        if (r.isEmpty) return false
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build()
        val latch = CountDownLatch(1)
        var ok = false
        val sent = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        if (!sent) return false
        latch.await(3, TimeUnit.SECONDS)
        return ok
    }

    /** Visible text on screen, top to bottom. Null if the screen is not [pkg] any more. */
    private fun readScreen(root: AccessibilityNodeInfo?, pkg: String): List<String>? {
        if (root == null || root.packageName?.toString() != pkg) return null
        class It(val t: String, val top: Int, val left: Int)
        val items = mutableListOf<It>()
        walk(root) { n ->
            val t = n.text?.toString()
            if (!t.isNullOrBlank() && n.isVisibleToUser && n.className?.toString()?.contains("EditText") != true) {
                val r = Rect(); n.getBoundsInScreen(r)
                items += It(t.trim(), r.top, r.left)
            }
        }
        return items.sortedWith(compareBy({ it.top / 12 }, { it.left })).map { it.t }
    }
}
