package com.ghostie.pet

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Food price reader. READ-ONLY by design.
 *
 *  - It only works on the food apps listed in res/xml/food_accessibility_config.xml.
 *  - It does nothing unless you asked for a price check ("cheapest chicken biryani") - [active] is false otherwise,
 *    and events are ignored.
 *  - The only things it ever does inside an app: open it, tap the search box, type your item, press search,
 *    scroll, and read the text on screen. [FORBIDDEN] words make it refuse to touch anything that could add to a
 *    cart, pay or place an order, and it never opens a cart or checkout.
 *  - Nothing is saved or sent anywhere except the result Ghostie tells you.
 */
class FoodScanService : AccessibilityService() {
    private val worker = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    companion object {
        @Volatile var instance: FoodScanService? = null
        @Volatile var active = false
        @Volatile private var cancel = false

        private val FORBIDDEN = Regex("(?i)\\b(pay|payment|place order|order now|checkout|check out|proceed|cart|buy|add|subscribe|confirm|upi|wallet|bill|login|log in|sign in|otp)\\b")

        fun isEnabled(ctx: Context): Boolean {
            val e = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            return e.contains("FoodScanService")
        }

        /** Installed food apps (by known id, or by the app's name for brand apps). */
        fun resolve(ctx: Context, app: FoodApp): String? {
            val pm = ctx.packageManager
            app.packages.firstOrNull { pm.getLaunchIntentForPackage(it) != null }?.let { return it }
            val key = (app.brand ?: app.label).lowercase()
            return try {
                pm.getInstalledApplications(0).firstOrNull { a ->
                    pm.getLaunchIntentForPackage(a.packageName) != null && pm.getApplicationLabel(a).toString().lowercase().contains(key)
                }?.packageName
            } catch (e: Exception) { null }
        }

        fun stop() { cancel = true }

        /** Starts a price check; [done] is called on the main thread with the finished report. */
        fun start(ctx: Context, items: List<WantedItem>, appIds: List<String>, defaultFee: Int, progress: (String) -> Unit, done: (String) -> Unit): String? {
            val svc = instance ?: return "off"
            if (active) return "busy"
            svc.run(ctx.applicationContext, items, appIds, defaultFee, progress, done)
            return null
        }
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* nothing is read unless a check is running */ }
    override fun onInterrupt() { cancel = true }
    override fun onDestroy() { if (instance === this) instance = null; cancel = true; worker.shutdown(); super.onDestroy() }

    private fun run(ctx: Context, items: List<WantedItem>, appIds: List<String>, defaultFee: Int, progress: (String) -> Unit, done: (String) -> Unit) {
        active = true; cancel = false; reasons.clear(); dbg.setLength(0)
        worker.execute {
            val offers = mutableListOf<Offer>()
            val read = mutableListOf<String>()
            val failed = mutableListOf<String>()
            val started = System.currentTimeMillis()
            try {
                for (id in appIds) {
                    val app = FoodApps.byId(id) ?: continue
                    if (cancel || System.currentTimeMillis() - started > 240_000L) { failed += app.label + " (stopped)"; continue }
                    val pkg = resolve(ctx, app)
                    if (pkg == null) { failed += app.label + " (not installed)"; continue }
                    if (!FoodApps.ALL.any { pkg in it.packages } && !allowedPackages().contains(pkg)) { failed += app.label + " (not allowed - ask me to add it)"; continue }
                    ui.post { progress("Checking ${app.label}…") }
                    var got = false
                    for (it in items) {
                        if (cancel) break
                        val found = scanApp(ctx, pkg, app, it.name)
                        if (found != null) { got = true; offers += found }
                    }
                    if (got) read += app.label else failed += app.label + (reasons[app.label]?.let { " ($it)" } ?: "")
                }
            } catch (e: Exception) {
                failed += "error: ${e.message}"
            } finally {
                active = false
                try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (e: Exception) {}
            }
            try { SettingsStore(ctx).foodDebug = dbg.toString() } catch (e: Exception) { }
            val fee = defaultFee
            val report = FoodCompare.report(items, offers, failed, read, fee)
            ui.post { done(report) }
        }
    }

    /** The window of [pkg] - not "the active window", which can be Ghostie's own chat box while it is open. */
    private fun appRoot(pkg: String): AccessibilityNodeInfo? {
        val active = rootInActiveWindow
        if (active?.packageName?.toString() == pkg) return active
        try {
            for (w in windows) {
                val r = w.root ?: continue
                if (r.packageName?.toString() == pkg) return r
            }
        } catch (e: Exception) { }
        return null
    }

    private val reasons = HashMap<String, String>()
    /** Plain-text trace of the last check (what each app showed), so a failure can be diagnosed. Stays on the phone until you share it. */
    private val dbg = StringBuilder()
    private fun log(t: String) { if (dbg.length < 60_000) dbg.append(t).append('\n') }

    private fun dumpNodes(root: AccessibilityNodeInfo?, limit: Int = 70) {
        if (root == null) { log("  (no window)"); return }
        var n = 0
        walk(root) { node ->
            if (n < limit) {
                val t = listOfNotNull(node.text?.toString()?.take(50), node.contentDescription?.toString()?.take(50)?.let { "desc=$it" },
                    node.viewIdResourceName?.substringAfterLast('/')?.let { "id=$it" }).joinToString(" | ")
                if (t.isNotBlank() || node.isEditable || node.isClickable) {
                    log("  ${node.className?.toString()?.substringAfterLast('.')}${if (node.isClickable) " [click]" else ""}${if (node.isEditable) " [edit]" else ""}: $t")
                    n++
                }
            }
        }
    }

    /** Words that mean a popup is in the way. */
    private val BLOCKERS = Regex("(?i)service paused|isn't available right now|not available right now|update available|allow .* (?:location|access)|while using the app|sorry, we are closed|temporarily unavailable|select a delivery slot|log ?in|sign in|enter (?:your )?(?:phone|mobile)|verify")
    private fun blockerHint(root: AccessibilityNodeInfo?): String? {
        var hit: String? = null
        walk(root) { n -> if (hit == null) BLOCKERS.find(label(n))?.let { hit = it.value } }
        return hit
    }
    private fun fail(app: FoodApp, why: String): List<Offer>? { reasons[app.label] = why; return null }

    private fun allowedPackages(): Set<String> = FoodApps.ALL.flatMap { it.packages }.toSet()

    /** Opens [pkg], searches [item] and returns offers read from the results, or null if the app could not be read. */
    private fun scanApp(ctx: Context, pkg: String, app: FoodApp, item: String): List<Offer>? {
        val launch = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return fail(app, "can't open it")
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try { startActivity(launch) } catch (e: Exception) { return fail(app, "Android blocked opening it") }
        if (!waitFor(15_000) { appRoot(pkg) != null }) return fail(app, "it didn't come to the front")
        log("=== ${app.label} ($pkg) \"$item\"")
        // splash / festival screens can take a while: wait until a search box shows up (max ~14 s)
        var found: AccessibilityNodeInfo? = null
        sleep(1500)
        dismissPopups(pkg)
        waitFor(14_000) { found = findSearch(appRoot(pkg)); if (found == null) dismissPopups(pkg); found != null }
        sleep(600)

        // 1. tap the search box
        val box = (found ?: findSearch(appRoot(pkg))) ?: run {
            log("no search box; home screen nodes:"); dumpNodes(appRoot(pkg))
            var count = 0
            walk(appRoot(pkg)) { count++ }
            return fail(app, blockerHint(appRoot(pkg))?.let { "\"$it\" is showing - clear it in the app, or it may not be usable right now" }
                ?: if (count <= 8) "the app shows Ghostie an empty screen (it hides its content from screen readers)" else "no search box found")
        }
        if (!tap(box)) {
            log("couldn't tap search node: ${label(box).take(80)}"); dumpNodes(appRoot(pkg), 40)
            return fail(app, "couldn't tap search")
        }
        // 2. type the item and press search (the search page can take a moment to open)
        var inputNode: AccessibilityNodeInfo? = null
        waitFor(7_000) { inputNode = findInput(appRoot(pkg)); inputNode != null }
        val input = inputNode ?: run {
            log("no text box after tapping search; nodes:"); dumpNodes(appRoot(pkg))
            return fail(app, "no text box opened")
        }
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, item) }
        if (!input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return fail(app, "couldn't type")
        sleep(600)
        fun pricesShown(): Boolean {
            val l = readScreen(appRoot(pkg), pkg)
            return l != null && l.count { FoodCompare.priceOf(it) != null } >= 2
        }
        val entered = try {
            input.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        } catch (e: Throwable) { false }
        log("typed \"$item\"; keyboard search pressed=$entered")
        if (!entered) findSearchButton(appRoot(pkg))?.let { tap(it) }
        waitFor(7_000) { pricesShown() }
        if (!pricesShown()) {
            // Some apps ignore the keyboard's search key: pick the matching suggestion instead.
            val words = item.lowercase().split(' ').filter { it.isNotBlank() }
            var sug: AccessibilityNodeInfo? = null
            walk(appRoot(pkg)) { n ->
                val t = n.text?.toString()?.lowercase()
                if (sug == null && t != null && n.isVisibleToUser && !n.isEditable && words.all { t.contains(it) } && !FORBIDDEN.containsMatchIn(t)) sug = n
            }
            sug?.let { log("tapping suggestion: ${it.text}"); tap(it) }
            waitFor(8_000) { pricesShown() }
        }
        if (!pricesShown()) {
            findSearchButton(appRoot(pkg))?.let { log("tapping search button"); tap(it) }
            waitFor(8_000) { pricesShown() }
        }
        sleep(800)

        // 3. read the results, scrolling a few times
        val offers = mutableListOf<Offer>()
        var seen = 0
        for (page in 0 until 4) {
            if (cancel) break
            val lines = readScreen(appRoot(pkg), pkg) ?: break
            seen += lines.size
            val got = FoodCompare.offersFromScreen(app.label, item, lines, app.brand?.let { app.label })
            log("page $page: ${lines.size} lines, ${got.size} offers")
            lines.take(80).forEach { log("  | $it") }
            offers += got
            val sc = findScrollable(appRoot(pkg)) ?: break
            if (!sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) break
            sleep(1600)
        }
        // back out of the search so the app is left on its normal screen
        repeat(2) { performGlobalAction(GLOBAL_ACTION_BACK); sleep(500) }
        if (seen == 0) return fail(app, "results screen unreadable")
        if (offers.isEmpty()) reasons[app.label] = "read the results but found no matching price"
        return offers
    }

    // ---- screen helpers ----------------------------------------------------------------------

    private fun sleep(ms: Long) { try { Thread.sleep(ms) } catch (e: InterruptedException) {} }

    private fun waitFor(ms: Long, cond: () -> Boolean): Boolean {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) { if (cancel) return false; if (cond()) return true; sleep(400) }
        return false
    }

    private fun label(n: AccessibilityNodeInfo): String =
        listOfNotNull(n.text, n.contentDescription, if (android.os.Build.VERSION.SDK_INT >= 26) n.hintText else null).joinToString(" ")

    private fun walk(root: AccessibilityNodeInfo?, depth: Int = 0, f: (AccessibilityNodeInfo) -> Unit) {
        if (root == null || depth > 40) return
        f(root)
        for (i in 0 until root.childCount) walk(root.getChild(i), depth + 1, f)
    }

    /** The search entry: nodes mentioning "search" win, clickable ones first; an id like "search_edit_text" counts only if it can be tapped. */
    private fun findSearch(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestScore = 0
        walk(root) { n ->
            if (n.isVisibleToUser) {
                val l = label(n)
                if (!FORBIDDEN.containsMatchIn(l)) {
                    val said = l.contains("search", true)
                    val idHit = n.viewIdResourceName?.substringAfterLast('/')?.contains("search", true) == true && n.isClickable &&
                        n.viewIdResourceName?.contains("location", true) != true
                    var sc = 0
                    if (said) sc += 2
                    if (said && l.contains("open search", true)) sc += 2
                    if ((said || idHit) && n.isClickable) sc += 2
                    if (idHit) sc += 1
                    if (sc > bestScore) { bestScore = sc; best = n }
                }
            }
        }
        if (best == null) walk(root) { n -> if (best == null && n.isVisibleToUser && n.isEditable) best = n }
        return best
    }

    /** Closes harmless popups ("Not now", "Skip"...). Never presses Allow/Enable/Update/Yes or anything about orders. */
    private fun dismissPopups(pkg: String): Boolean {
        val safe = setOf("not now", "skip", "maybe later", "later", "no thanks", "dismiss", "close", "cancel", "got it", "okay", "ok")
        var did = false
        repeat(3) {
            var target: AccessibilityNodeInfo? = null
            walk(appRoot(pkg)) { n ->
                val t = n.text?.toString()?.trim()?.lowercase()
                if (target == null && n.isVisibleToUser && n.isClickable && t != null && t in safe) target = n
            }
            val t = target ?: return did
            log("dismissing popup: ${t.text}")
            t.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            did = true
            sleep(900)
        }
        return did
    }

    private fun findSearchButton(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        walk(root) { n ->
            if (best == null && n.isVisibleToUser && n.className?.toString()?.contains("EditText") != true) {
                val l = (n.contentDescription ?: "").toString()
                if (l.equals("search", true) && !FORBIDDEN.containsMatchIn(l)) best = n
            }
        }
        return best
    }

    private fun findInput(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        walk(root) { n -> if (best == null && n.isVisibleToUser && n.isEditable) best = n }
        return best
    }

    private fun findScrollable(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        walk(root) { n -> if (best == null && n.isScrollable && n.isVisibleToUser) best = n }
        return best
    }

    /** Taps [n]: click it or its nearest clickable parent, else a plain touch at its centre. Refuses anything about paying, carts or ordering. */
    private fun tap(n: AccessibilityNodeInfo): Boolean {
        if (FORBIDDEN.containsMatchIn(label(n))) return false
        var cur: AccessibilityNodeInfo? = n
        var depth = 0
        while (cur != null && depth < 6) {
            val l = label(cur)
            if (l.length < 80 && FORBIDDEN.containsMatchIn(l)) return false
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent; depth++
        }
        return tapAt(n)
    }

    /** Touch at the centre of [n] (works for custom views that don't report as clickable). */
    private fun tapAt(n: AccessibilityNodeInfo): Boolean {
        val r = Rect(); n.getBoundsInScreen(r)
        if (r.isEmpty) return false
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build()
        val latch = CountDownLatch(1)
        var ok = false
        val sent = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        if (!sent) return false
        latch.await(3, TimeUnit.SECONDS)
        return ok
    }

    /** Visible text on screen, top to bottom. Null if the screen is not [pkg] any more. */
    private fun readScreen(root: AccessibilityNodeInfo?, pkg: String): List<String>? {
        if (root == null || root.packageName?.toString() != pkg) return null
        class It(val t: String, val top: Int, val left: Int)
        val items = mutableListOf<It>()
        walk(root) { n ->
            val t = n.text?.toString()
            if (!t.isNullOrBlank() && n.isVisibleToUser && n.className?.toString()?.contains("EditText") != true) {
                val r = Rect(); n.getBoundsInScreen(r)
                items += It(t.trim(), r.top, r.left)
            }
        }
        return items.sortedWith(compareBy({ it.top / 12 }, { it.left })).map { it.t }
    }
}
