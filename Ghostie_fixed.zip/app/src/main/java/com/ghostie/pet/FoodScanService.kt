package com.ghostie.pet

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Food price reader. READ-ONLY by design.
 *
 *  - It only works on the food apps listed in res/xml/food_accessibility_config.xml.
 *  - It does nothing unless you asked for a price check ("cheapest chicken biryani") - [active] is false otherwise,
 *    and events are ignored.
 *  - The only things it ever does inside an app: open it, tap the search box, type your item, press search,
 *    scroll, and read the text on screen. [FORBIDDEN] words make it refuse to touch anything that could add to a
 *    cart, pay or place an order, and it never opens a cart or checkout.
 *  - Nothing is saved or sent anywhere except the result Ghostie tells you.
 */
class FoodScanService : AccessibilityService() {
    private val worker = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    companion object {
        @Volatile var instance: FoodScanService? = null
        @Volatile var active = false
        @Volatile private var cancel = false

        private val FORBIDDEN = Regex("(?i)\\b(pay|payment|place order|order now|checkout|check out|proceed|cart|buy|add|subscribe|confirm|upi|wallet|bill|login|log in|sign in|otp)\\b")

        fun isEnabled(ctx: Context): Boolean {
            val e = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            return e.contains("FoodScanService")
        }

        /** Installed food apps (by known id, or by the app's name for brand apps). */
        fun resolve(ctx: Context, app: FoodApp): String? {
            val pm = ctx.packageManager
            app.packages.firstOrNull { pm.getLaunchIntentForPackage(it) != null }?.let { return it }
            val key = (app.brand ?: app.label).lowercase()
            return try {
                pm.getInstalledApplications(0).firstOrNull { a ->
                    pm.getLaunchIntentForPackage(a.packageName) != null && pm.getApplicationLabel(a).toString().lowercase().contains(key)
                }?.packageName
            } catch (e: Exception) { null }
        }

        fun stop() { cancel = true }

        /** Starts a price check; [done] is called on the main thread with the finished report. */
        fun start(ctx: Context, items: List<WantedItem>, appIds: List<String>, defaultFee: Int, progress: (String) -> Unit, done: (String) -> Unit): String? {
            val svc = instance ?: return "off"
            if (active) return "busy"
            svc.run(ctx.applicationContext, items, appIds, defaultFee, progress, done)
            return null
        }
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* nothing is read unless a check is running */ }
    override fun onInterrupt() { cancel = true }
    override fun onDestroy() { if (instance === this) instance = null; cancel = true; worker.shutdown(); super.onDestroy() }

    private fun run(ctx: Context, items: List<WantedItem>, appIds: List<String>, defaultFee: Int, progress: (String) -> Unit, done: (String) -> Unit) {
        active = true; cancel = false; reasons.clear(); dbg.setLength(0); peekedRest.clear(); feeByRest.clear(); avoidLabels.clear(); avoidNodes.clear(); peekCount = 0; peekDiag = 0; cartNotes.clear(); noAddMisses.clear()
        worker.execute {
            val offers = mutableListOf<Offer>()
            val read = mutableListOf<String>()
            val failed = mutableListOf<String>()
            val started = System.currentTimeMillis()
            val budget = 360_000L // up to 6 minutes in total
            progressCb = progress
            try {
                for ((idx, id) in appIds.withIndex()) {
                    val app = FoodApps.byId(id) ?: continue
                    if (cancel || System.currentTimeMillis() - started > budget) { failed += app.label + " (stopped)"; continue }
                    val pkg = resolve(ctx, app)
                    if (pkg == null) { failed += app.label + " (not installed)"; continue }
                    if (!FoodApps.ALL.any { pkg in it.packages } && !allowedPackages().contains(pkg)) { failed += app.label + " (not allowed - ask me to add it)"; continue }
                    val left = started + budget - System.currentTimeMillis()
                    deadline = System.currentTimeMillis() + maxOf(60_000L, left / (appIds.size - idx).coerceAtLeast(1))
                    ui.post { progress("Checking ${app.label}…") }
                    var got = false
                    for (it in items) {
                        if (cancel) break
                        val found = scanApp(ctx, pkg, app, it.name)
                        if (found != null) { got = true; offers += found }
                    }
                    if (got) read += app.label else failed += app.label + (reasons[app.label]?.let { " ($it)" } ?: "")
                }
            } catch (e: Exception) {
                failed += "error: ${e.message}"
            } finally {
                active = false
                try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (e: Exception) {}
            }
            try { SettingsStore(ctx).foodDebug = dbg.toString() } catch (e: Exception) { }
            val fee = defaultFee
            var report = FoodCompare.report(items, offers, failed, read, fee)
            if (cartNotes.isNotEmpty()) report += "\n\n⚠️ " + cartNotes.joinToString("\n⚠️ ")
            ui.post { done(report) }
        }
    }

    /** The window of [pkg] - not "the active window", which can be Ghostie's own chat box while it is open. */
    private fun appRoot(pkg: String): AccessibilityNodeInfo? {
        val active = rootInActiveWindow
        if (active?.packageName?.toString() == pkg) return active
        try {
            for (w in windows) {
                val r = w.root ?: continue
                if (r.packageName?.toString() == pkg) return r
            }
        } catch (e: Exception) { }
        return null
    }

    private val reasons = HashMap<String, String>()
    /** Plain-text trace of the last check (what each app showed), so a failure can be diagnosed. Stays on the phone until you share it. */
    private val dbg = StringBuilder()
    private fun log(t: String) { if (dbg.length < 60_000) dbg.append(t).append('\n') }

    private fun dumpNodes(root: AccessibilityNodeInfo?, limit: Int = 160) {
        if (root == null) { log("  (no window)"); return }
        var n = 0
        walk(root) { node ->
            if (n < limit) {
                val t = listOfNotNull(node.text?.toString()?.take(50), node.contentDescription?.toString()?.take(50)?.let { "desc=$it" },
                    node.viewIdResourceName?.substringAfterLast('/')?.let { "id=$it" }).joinToString(" | ")
                if (t.isNotBlank() || node.isEditable || node.isClickable) {
                    log("  ${node.className?.toString()?.substringAfterLast('.')}${if (node.isClickable) " [click]" else ""}${if (node.isEditable) " [edit]" else ""}: $t")
                    n++
                }
            }
        }
    }

    /**
     * Full diagnostic dump for an app whose search bar can't be found: every node in the top 45% of the screen
     * (labelled or not, with its position as a fraction of the screen), then every clickable node elsewhere.
     * Lines look like: #12 FrameLayout C V (0.50,0.19) size 0.80x0.06 id=... text=... desc=...
     * so the right one can be picked and a touch on it hard-coded.
     */
    private fun dumpFull(pkg: String) {
        val root = appRoot(pkg) ?: run { log("  (no window)"); return }
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat(); val h = dm.heightPixels.toFloat()
        log("--- FULL NODE LIST (screen ${dm.widthPixels}x${dm.heightPixels}). Flags: C=clickable E=editable V=visible F=focusable ---")
        var idx = 0
        var top = 0; var rest = 0
        fun line(n: AccessibilityNodeInfo, depth: Int, i: Int) {
            val r = Rect(); n.getBoundsInScreen(r)
            val cx = (r.centerX() / w).coerceIn(-1f, 2f); val cy = (r.centerY() / h).coerceIn(-1f, 2f)
            val flags = (if (n.isClickable) "C" else "-") + (if (n.isEditable) "E" else "-") + (if (n.isVisibleToUser) "V" else "-") + (if (n.isFocusable) "F" else "-")
            log("  #$i d$depth ${n.className?.toString()?.substringAfterLast('.')} $flags (%.2f,%.2f) %.2fx%.2f".format(cx, cy, r.width() / w, r.height() / h) +
                (n.viewIdResourceName?.substringAfterLast('/')?.let { " id=$it" } ?: "") +
                (n.text?.toString()?.takeIf { it.isNotBlank() }?.let { " text=${it.take(40)}" } ?: "") +
                (n.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { " desc=${it.take(40)}" } ?: "") +
                (if (android.os.Build.VERSION.SDK_INT >= 26) n.hintText?.toString()?.takeIf { it.isNotBlank() }?.let { " hint=${it.take(30)}" } ?: "" else ""))
        }
        fun go(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 40 || idx > 3000) return
            idx++
            val r = Rect(); n.getBoundsInScreen(r)
            val inTop = r.centerY() < h * 0.45f && r.centerY() > 0 && r.width() > 0
            if (inTop && n.isVisibleToUser && top < 140) { line(n, depth, idx); top++ }
            else if (n.isClickable && n.isVisibleToUser && !inTop && rest < 60) { line(n, depth, idx); rest++ }
            for (i in 0 until n.childCount) go(n.getChild(i), depth + 1)
        }
        go(root, 0)
        log("--- end of node list ($top near the top, $rest other clickable, $idx nodes in total) ---")
    }

    /** Every node whose text, description or id mentions "search", wherever it sits in the tree (the node dump is cut short). */
    private fun logSearchLike(pkg: String) {
        var n = 0
        walk(appRoot(pkg)) { d ->
            val id = d.viewIdResourceName?.substringAfterLast('/') ?: ""
            val l = label(d)
            if (n < 15 && (l.contains("search", true) || id.contains("search", true))) {
                val r = Rect(); d.getBoundsInScreen(r)
                log("  search-like: ${d.className?.toString()?.substringAfterLast('.')} id=$id label=${l.take(40)} click=${d.isClickable} vis=${d.isVisibleToUser} at ${r.flattenToString()}")
                n++
            }
        }
        if (n == 0) log("  (nothing on the screen mentions search)")
    }

    /** Words that mean a popup is in the way. */
    private val NOT_HERE = Regex("(?i)delivery isn.t available here|online ordering isn.t available at your location|not deliverable|we don.t deliver (?:here|to)|doesn.t deliver to|not delivering here|we.re not delivering")
    private val BLOCKERS = Regex("(?i)service paused|isn't available right now|not available right now|update available|allow .* (?:location|access)|while using the app|sorry, we are closed|temporarily unavailable|select a delivery slot|log ?in|sign in|enter (?:your )?(?:phone|mobile)|verify")
    private fun blockerHint(root: AccessibilityNodeInfo?): String? {
        var hit: String? = null
        walk(root) { n -> if (hit == null) BLOCKERS.find(label(n))?.let { hit = it.value } }
        return hit
    }
    private fun fail(app: FoodApp, why: String): List<Offer>? { reasons[app.label] = why; return null }

    private fun allowedPackages(): Set<String> = FoodApps.ALL.flatMap { it.packages }.toSet()

    private var deadline = 0L
    private var progressCb: (String) -> Unit = {}
    private fun timeUp() = cancel || System.currentTimeMillis() > deadline
    private fun say(m: String) { val cb = progressCb; ui.post { cb(m) } }

    private fun editableShown(pkg: String): Boolean = findInput(appRoot(pkg)) != null
    private fun pricesShown(pkg: String): Boolean {
        val l = readScreen(appRoot(pkg), pkg)
        return l != null && l.count { FoodCompare.priceOf(it) != null } >= 2
    }

    private fun scrollToTop(pkg: String, times: Int = 4) {
        for (i in 0 until times) {
            val sc = findScrollable(appRoot(pkg))
            if (sc == null || !sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) {
                // not scrollable through accessibility (Swiggy's feed): swipe the screen instead
                swipeDown(); sleep(450); continue
            }
            sleep(450)
        }
    }

    private fun tapFraction(fx: Float, fy: Float): Boolean {
        val m = resources.displayMetrics
        val path = Path().apply { moveTo(m.widthPixels * fx, m.heightPixels * fy) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build()
        val latch = CountDownLatch(1)
        var ok = false
        if (!dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
                override fun onCancelled(d: GestureDescription?) { latch.countDown() }
            }, null)) return false
        latch.await(3, TimeUnit.SECONDS)
        return ok
    }

    /** Drags a finger down the screen (shows what is above). Used when the app's list can't be scrolled through accessibility. */
    private fun swipeDown(): Boolean {
        val dm = resources.displayMetrics
        val x = dm.widthPixels * 0.5f
        val path = Path().apply { moveTo(x, dm.heightPixels * 0.30f); lineTo(x, dm.heightPixels * 0.80f) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 350)).build()
        val latch = CountDownLatch(1)
        var ok = false
        if (!dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)) return false
        latch.await(3, TimeUnit.SECONDS)
        return ok
    }

    private fun tapFractionPx(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build()
        val latch = CountDownLatch(1)
        var ok = false
        if (!dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)) return false
        latch.await(3, TimeUnit.SECONDS)
        return ok
    }

    /** Opens the app's search page. Returns false (with a reason logged) if it can't. */
    private var lastSearchLabel: String? = null

    /** Re-launches [pkg] when its window disappeared (splash restarts, the app closing itself). */
    private fun bringToFront(pkg: String): Boolean {
        val it = packageManager.getLaunchIntentForPackage(pkg) ?: return false
        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try { startActivity(it); waitFor(15_000) { appRoot(pkg) != null }; sleep(2500); true } catch (e: Exception) { false }
    }
    private fun openSearch(pkg: String, app: FoodApp): Boolean {
        var found: AccessibilityNodeInfo? = null
        val taught0 = try { SettingsStore(this).foodTapFor(app.id) } catch (e: Exception) { null }
        if (taught0 != null) {
            waitFor(15_000) { appRoot(pkg) != null }
            sleep(1500); dismissPopups(pkg)
            log("touching the taught spot (${taught0.first}, ${taught0.second}) first")
            tapFraction(taught0.first, taught0.second)
            waitFor(6_000) { editableShown(pkg) }
            if (editableShown(pkg) && !wrongScreen(pkg)) return true
            if (wrongScreen(pkg)) repeat(3) { if (wrongScreen(pkg)) { performGlobalAction(GLOBAL_ACTION_BACK); sleep(1300) } }
            log("the taught spot didn't open a search box")
        }
        var gone = 0
        waitFor(20_000) {
            if (appRoot(pkg) == null) { if (++gone >= 8) { gone = 0; log("app window vanished - opening it again"); bringToFront(pkg) } }
            else gone = 0
            found = findSearch(appRoot(pkg)); if (found == null) dismissPopups(pkg); found != null
        }
        sleep(600)
        var backedOnce = false
        var dumpedFull = false
        for (attempt in 0..3) {
            val box = (if (attempt == 0) found else null) ?: findSearch(appRoot(pkg))
            if (box == null) {
                log("no search node; screen nodes:"); dumpNodes(appRoot(pkg), 80); logSearchLike(pkg)
                if (!dumpedFull) { dumpedFull = true; dumpFull(pkg) }
                // maybe we are on a sub-page (a restaurant list, an offer page) with no search bar: go back once and look again
                if (!backedOnce) {
                    backedOnce = true
                    log("trying Back once to reach the app's main page")
                    performGlobalAction(GLOBAL_ACTION_BACK); sleep(1800)
                    if (appRoot(pkg) == null) bringToFront(pkg)
                    dismissPopups(pkg); scrollToTop(pkg, 8); sleep(700)
                    found = null
                    continue
                }
                break
            }
            lastSearchLabel = label(box).trim()
            if (tap(box)) { waitFor(8_000) { editableShown(pkg) }; if (editableShown(pkg) && !wrongScreen(pkg)) return true }
            if (wrongScreen(pkg)) {
                log("that search icon (${box.viewIdResourceName?.substringAfterLast('/')}) opened a train/login page - ignoring it and trying another")
                avoidNodes += nodeKey(box)
                repeat(3) { if (wrongScreen(pkg)) { performGlobalAction(GLOBAL_ACTION_BACK); sleep(1500) } }
                dismissPopups(pkg)
                continue
            }
            log("tapped search node ${label(box).take(60)} but no text box opened; screen now:")
            readScreen(appRoot(pkg), pkg)?.take(30)?.forEach { log("  | $it") }
            dumpNodes(appRoot(pkg), 60)
            break
        }
        // The app doesn't expose its search bar: scroll to the top and touch where it normally sits.
        var misses = 0
        val taught = try { SettingsStore(this).foodTapFor(app.id) } catch (e: Exception) { null }
        val fallbackTaps = if (app.searchTaps.isEmpty()) listOf(0.5f to 0.17f, 0.5f to 0.12f, 0.5f to 0.22f) else app.searchTaps
        val taps = (if (taught != null) listOf(taught) else emptyList()) + fallbackTaps
        for ((idx, pair) in taps.withIndex()) {
            val (fx, fy) = pair
            if (timeUp()) break
            val before = (readScreen(appRoot(pkg), pkg) ?: emptyList()).toSet()
            if (misses == 0 && !(taught != null && idx == 0)) scrollToTop(pkg)
            log("touching ($fx, $fy)" + if (taught != null && idx == 0) " (taught)" else "")
            tapFraction(fx, fy)
            waitFor(4_000) { editableShown(pkg) }
            if (editableShown(pkg) && !wrongScreen(pkg)) return true
            sleep(800)
            val now = (readScreen(appRoot(pkg), pkg) ?: emptyList()).toSet()
            // the touch opened something else (a restaurant, an offer): go back so the next touch starts from the same screen
            if (before.isNotEmpty() && now.isNotEmpty() && now.intersect(before).size < before.size / 2) {
                log("that touch opened another page - going back")
                performGlobalAction(GLOBAL_ACTION_BACK); sleep(1500); dismissPopups(pkg)
            }
            misses++
        }
        return false
    }

    /** Types the item and gets a results page, trying the keyboard key, a suggestion, the search button, then a category tile. */
    private fun submitSearch(pkg: String, item: String): Boolean {
        if (wrongScreen(pkg)) return false
        val input = findInput(appRoot(pkg)) ?: return false
        if (!typeInto(input, item)) return false
        sleep(600)
        val entered = try { input.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id) } catch (e: Throwable) { false }
        log("typed \"$item\"; keyboard search pressed=$entered")
        if (!entered) findSearchButton(appRoot(pkg))?.let { tap(it) }
        waitFor(10_000) { pricesShown(pkg) }
        if (!pricesShown(pkg)) {
            val words = item.lowercase().split(' ').filter { it.isNotBlank() }
            var sug: AccessibilityNodeInfo? = null
            walk(appRoot(pkg)) { n ->
                val t = n.text?.toString()?.lowercase()
                if (sug == null && t != null && n.isVisibleToUser && !n.isEditable && words.all { t.contains(it) } && !FORBIDDEN.containsMatchIn(t)) sug = n
            }
            sug?.let { log("tapping suggestion: ${it.text}"); tap(it) }
            waitFor(10_000) { pricesShown(pkg) }
        }
        if (!pricesShown(pkg)) {
            findSearchButton(appRoot(pkg))?.let { log("tapping search button"); tap(it) }
            waitFor(8_000) { pricesShown(pkg) }
        }
        if (!pricesShown(pkg)) {
            val head = item.lowercase().split(' ').filter { it.isNotBlank() }.lastOrNull()
            if (head != null) {
                var tile: AccessibilityNodeInfo? = null
                walk(appRoot(pkg)) { n -> if (tile == null && n.isVisibleToUser && !n.isEditable && n.text?.toString()?.trim()?.equals(head, true) == true) tile = n }
                tile?.let { log("tapping category tile: ${it.text}"); tap(it); waitFor(9_000) { pricesShown(pkg) } }
            }
        }
        return true // even without prices: restaurant lists are handled by the caller
    }

    /** Reads up to [maxPages] screens (scrolling), stopping when nothing new appears. */
    private fun readPages(pkg: String, app: FoodApp, item: String, maxPages: Int, rest: String?, logPages: Int = 2, peek: Boolean = true): List<Offer> {
        val out = mutableListOf<Offer>()
        val seen = HashSet<String>()
        var stale = 0
        // loading screens ("Hold tight...", splash logos) show only a line or two: wait for real content
        waitFor(15_000) { dismissPopups(pkg); (readScreen(appRoot(pkg), pkg)?.size ?: 0) >= 6 }
        for (page in 0 until maxPages) {
            if (timeUp()) break
            if (page > 0) dismissPopups(pkg)
            val lines = readScreen(appRoot(pkg), pkg) ?: break
            val fresh = lines.count { seen.add(it) }
            val got = FoodCompare.offersFromScreen(app.label, item, lines, rest ?: app.brand?.let { app.label })
            log("page $page: ${lines.size} lines ($fresh new), ${got.size} offers")
            if (page < logPages) lines.take(60).forEach { log("  | $it") }
            out += got
            // delivery fee only shows in the cart: add one item, read the fee, take it out again (never orders)
            val cand = got.firstOrNull { it.fee == null && feeByRest[it.restaurant.lowercase()] == null && it.restaurant.lowercase() !in peekedRest }
            if (peek && cand != null && peekCount < 6 && (noAddMisses[pkg] ?: 0) < 2 && deadline - System.currentTimeMillis() > 45_000 && !timeUp()) {
                peekedRest += cand.restaurant.lowercase()
                say("${app.label}: checking the delivery fee…")
                cartFee(pkg, cand.item, cand.price)?.let { feeByRest[cand.restaurant.lowercase()] = it }
            }
            if (fresh == 0) { if (++stale >= 2) break } else stale = 0
            val sc = findScrollable(appRoot(pkg)) ?: break
            if (!sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) break
            sleep(1500)
        }
        return out.map { o -> if (o.fee == null) feeByRest[o.restaurant.lowercase()]?.let { o.copy(fee = it) } ?: o else o }
            .distinctBy { Triple(it.restaurant.lowercase(), it.item.lowercase(), it.price) }
    }

    // ---- delivery fee via the cart (adds ONE item, reads the fee, removes it; never pays or orders) ----

    private val peekedRest = HashSet<String>()
    private val feeByRest = HashMap<String, Int>()
    private var peekCount = 0
    private var peekDiag = 0
    private val noAddMisses = HashMap<String, Int>()
    private val cartNotes = LinkedHashSet<String>()
    private val NEVER = Regex("(?i)\\b(pay|payment|place order|order now|checkout|check out|proceed|confirm|upi|wallet|login|log in|sign in|otp|subscribe|buy now)\\b")
    private val CART_OPEN = Regex("(?i)\\b(view cart|go to cart|view basket|my cart|cart)\\b")
    private val REMOVE = Regex("(?i)^(remove|remove item|clear cart|clear|delete|decrease quantity|decrease|minus|[-\u2212\u2013])$")
    private val SHEET_ADD = Regex("(?i)^(add item.*|add to cart.*|add \\d+ item.*|add for.*)$")

    /** Click that refuses anything about paying/ordering; unlike [tap] it may press Add and cart buttons. */
    private fun safeClick(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        var d = 0
        while (cur != null && d < 5) {
            val l = label(cur)
            if (l.length < 100 && NEVER.containsMatchIn(l)) return false
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent; d++
        }
        return if (NEVER.containsMatchIn(label(n))) false else tapAt(n)
    }

    private val ADD_LABEL = Regex("(?i)^(?:\\+\\s*)?(?:add|add item|add to cart|add \\d+.*|add for .*|add\\s*[^a-z]*₹.*)(?:\\s*\\+)?$")

    private fun isAddNode(n: AccessibilityNodeInfo, words: List<String>): Boolean {
        val l = label(n).trim().lowercase()
        if (l.isEmpty() || l.length > 90 || l.contains("address") || l.contains("instruction")) return false
        return ADD_LABEL.matches(l) || (l.startsWith("add ") && words.any { w -> l.contains(w) })
    }

    /** The "ADD" button that belongs to the dish called [item] on the current screen: the nearest Add node to the dish name. */
    private fun findAddFor(root: AccessibilityNodeInfo?, item: String): AccessibilityNodeInfo? {
        val words = item.lowercase().split(' ').filter { it.length > 2 }
        if (words.isEmpty()) return null
        var nameNode: AccessibilityNodeInfo? = null
        val adds = mutableListOf<AccessibilityNodeInfo>()
        walk(root) { n ->
            if (!n.isVisibleToUser) return@walk
            val t = n.text?.toString()?.lowercase()
            if (nameNode == null && t != null && t.length < 90 && words.all { t.contains(it) }) nameNode = n
            if (isAddNode(n, words)) adds += n
        }
        val nm = nameNode ?: return null
        val nr = Rect(); nm.getBoundsInScreen(nr)
        var best: AccessibilityNodeInfo? = null
        var bestD = Float.MAX_VALUE
        for (a in adds) {
            val r = Rect(); a.getBoundsInScreen(r)
            val dy = (r.centerY() - nr.centerY()).toFloat()
            val dx = (r.centerX() - nr.centerX()).toFloat()
            val d = (if (dy < -40f) -dy * 3f else Math.abs(dy)) + Math.abs(dx) * 0.3f
            if (d < bestD) { bestD = d; best = a }
        }
        if (best != null && bestD > 1100f) { log("cart: nearest Add is too far from the dish name"); return null }
        return best
    }

    private fun findLabel(pkg: String, re: Regex, exclude: Regex? = null): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        walk(appRoot(pkg)) { n ->
            val l = label(n).trim()
            if (best == null && n.isVisibleToUser && l.length < 80 && re.containsMatchIn(l) && (exclude == null || !exclude.containsMatchIn(l)) && !NEVER.containsMatchIn(l)) best = n
        }
        return best
    }

    /**
     * What the cart adds on top of the dish: "To Pay" minus the dish price when both are shown (delivery + platform fee + taxes,
     * i.e. the real extra cost); otherwise the delivery line. "FREE delivery above ₹N" banners only count if the dish reaches N.
     */
    private fun deliveryFeeIn(lines: List<String>, itemPrice: Int, totalOnly: Boolean = false): Int? {
        for (l in lines) {
            if (!Regex("(?i)^(?:to pay|grand total|total payable|total)\\b").containsMatchIn(l.trim())) continue
            val v = FoodCompare.priceOf(l)
            if (v != null && v >= itemPrice && v - itemPrice <= 250) return v - itemPrice
        }
        if (totalOnly) return null
        for ((i, l) in lines.withIndex()) {
            if (!l.contains("delivery", true) || Regex("(?i)delivery (time|in|address|to)\\b|\\d+\\s*mins?|\\btip\\b|assistant|partner").containsMatchIn(l)) continue
            val tail = lines.subList(i + 1, minOf(lines.size, i + 4))
            val above = tail.firstNotNullOfOrNull { t -> Regex("(?i)^above\\s*₹\\s*(\\d+)").find(t.trim())?.groupValues?.get(1)?.toIntOrNull() }
            val f = FoodCompare.feeOf(l)
            if (f != null) { if (f == 0 && above != null && itemPrice < above) continue; return f }
            for (j in 1..2) {
                val nx = lines.getOrNull(i + j) ?: break
                if (FoodCompare.isPriceLine(nx.trim())) return FoodCompare.priceOf(nx)
            }
        }
        return null
    }

    /** From a results list: open the restaurant that sells [o], find the dish, add it, read the cart, clean up, come back. */
    private fun peekViaRestaurant(pkg: String, o: Offer): Int? {
        scrollToTop(pkg, 10)
        fun norm(x: String?) = (x ?: "").lowercase().replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
        val wantItem = norm(o.item); val wantRest = norm(o.restaurant)
        var target: AccessibilityNodeInfo? = null
        var restNode: AccessibilityNodeInfo? = null
        for (pg in 0..11) {
            walk(appRoot(pkg)) { n ->
                if (n.isVisibleToUser && !n.isEditable) {
                    val tx = norm(n.text?.toString() ?: n.contentDescription?.toString())
                    if (tx.isNotEmpty()) {
                        if (target == null && wantItem.isNotEmpty() && (tx == wantItem || (tx.length <= wantItem.length + 12 && tx.contains(wantItem)))) target = n
                        if (restNode == null && wantRest.isNotEmpty() && tx == wantRest) restNode = n
                    }
                }
            }
            if (target != null) break
            val sc = findScrollable(appRoot(pkg)) ?: break
            if (!sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) break
            sleep(1100)
        }
        if (target == null) target = restNode   // the restaurant's own name opens the same page
        val t = target ?: run { log("fee: couldn't find ${o.item} again"); return null }
        if (!tap(t)) { log("fee: couldn't open ${o.item}"); return null }
        // the results list already has plenty of text, so wait for the restaurant page itself (not just "10 lines")
        if (!waitFor(9_000) { onRestaurantPage(pkg) }) waitFor(5_000) { (readScreen(appRoot(pkg), pkg)?.size ?: 0) >= 10 }
        sleep(1800)
        dismissPopups(pkg)
        var fee: Int? = null
        for (pg in 0..8) {
            if (timeUp()) break
            if (findAddFor(appRoot(pkg), o.item) != null) { fee = cartFee(pkg, o.item, o.price); break }
            val sc = findScrollable(appRoot(pkg)) ?: break
            if (!sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) break
            sleep(1100)
        }
        // the restaurant page doesn't show dish names to accessibility: use the restaurant's own search box instead
        var usedMenuSearch = false
        if (fee == null && !timeUp()) {
            val sb = findById(pkg, "search_bar")
            if (sb != null && tap(sb)) {
                usedMenuSearch = true
                waitFor(6_000) { editableShown(pkg) }
                val input = findInput(appRoot(pkg))
                if (input != null && typeInto(input, o.item)) {
                    sleep(500)
                    try { input.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id) } catch (e: Throwable) { }
                    sleep(2800)
                    var add: AccessibilityNodeInfo? = findAddFor(appRoot(pkg), o.item)
                    if (add == null) walk(appRoot(pkg)) { n -> if (add == null && n.isVisibleToUser && isAddNode(n, emptyList())) add = n }
                    if (add != null) { log("fee: found Add through the restaurant's own search"); fee = cartFee(pkg, o.item, o.price, add) }
                    else log("fee: the restaurant's search showed no Add button")
                }
            }
        }
        if (fee == null && peekDiag++ < 2) {
            log("fee: no Add button found for ${o.item} - what the restaurant page shows:")
            readScreen(appRoot(pkg), pkg)?.take(60)?.forEach { log("  | $it") }
            dumpNodes(appRoot(pkg), 110)
            log("on a restaurant page: ${onRestaurantPage(pkg)}")
            dumpFull(pkg) // every node with its position, so the unlabelled ADD buttons can be told apart
        }
        log("fee via ${o.restaurant}: $fee")
        // back out to the results list (the search box adds one more page)
        repeat(if (usedMenuSearch) 3 else 1) { i ->
            if (i == 0 || onRestaurantPage(pkg) || findById(pkg, "search_bar") != null) { performGlobalAction(GLOBAL_ACTION_BACK); sleep(1500) }
        }
        return fee
    }

    private fun findById(pkg: String, idPart: String): AccessibilityNodeInfo? {
        var hit: AccessibilityNodeInfo? = null
        walk(appRoot(pkg)) { n -> if (hit == null && n.isVisibleToUser && n.isClickable && n.viewIdResourceName?.substringAfterLast('/')?.equals(idPart, true) == true) hit = n }
        return hit
    }

    private fun onRestaurantPage(pkg: String): Boolean {
        var yes = false
        walk(appRoot(pkg)) { n -> if (!yes) { val id = n.viewIdResourceName?.substringAfterLast('/') ?: ""; if (id == "restaurantNameToolbar" || id == "res_info_bar" || id == "menuFragmentRootContainer") yes = true } }
        return yes
    }

    /** True while a cart/checkout page is showing. */
    private fun onCartPage(pkg: String): Boolean =
        readScreen(appRoot(pkg), pkg)?.any { it.contains("proceed to pay", true) || it.contains("item total", true) || it.contains("bill details", true) || it.trim().equals("my cart", true) || it.trim().equals("your cart", true) } == true

    /** Taps the "−" of a quantity stepper: finds a lone digit (the quantity) and clicks the left-most clickable sibling. */
    private fun decrementQty(pkg: String): Boolean {
        // app-specific ids first (EatSure: tvSubProduct)
        var minusById: AccessibilityNodeInfo? = null
        walk(appRoot(pkg)) { n ->
            val id = n.viewIdResourceName?.substringAfterLast('/')?.lowercase()
            if (minusById == null && n.isVisibleToUser && n.isClickable && id != null && Regex("subproduct|minus|decrement|decrease|remove_item|btn_sub|qty_sub").containsMatchIn(id)) minusById = n
        }
        minusById?.let { log("cart: tapping ${it.viewIdResourceName}"); return it.performAction(AccessibilityNodeInfo.ACTION_CLICK) || tapAt(it) }
        var qty: AccessibilityNodeInfo? = null
        walk(appRoot(pkg)) { n -> if (qty == null && n.isVisibleToUser && n.text?.toString()?.trim()?.matches(Regex("^\\d$")) == true) qty = n }
        val q = qty ?: return false
        var cur: AccessibilityNodeInfo? = q.parent
        var d = 0
        while (cur != null && d < 3) {
            val kids = (0 until cur.childCount).mapNotNull { cur!!.getChild(it) }.filter { it.isClickable && it.isVisibleToUser }
            if (kids.size >= 2) {
                val r = Rect()
                val minus = kids.minByOrNull { k -> k.getBoundsInScreen(r); r.left } ?: return false
                log("cart: tapping quantity minus")
                return minus.performAction(AccessibilityNodeInfo.ACTION_CLICK) || tapAt(minus)
            }
            cur = cur.parent; d++
        }
        // last resort: touch just left of the quantity number
        val r = Rect(); q.getBoundsInScreen(r)
        if (r.isEmpty) return false
        log("cart: touching left of quantity")
        return tapFractionPx((r.left - r.width() * 2.2f), r.exactCenterY())
    }

    /** Adds [item] to the cart, reads what the cart adds on top, empties the cart again. Null when anything looks unsafe or unclear. */
    private fun cartFee(pkg: String, item: String, itemPrice: Int, addOverride: AccessibilityNodeInfo? = null): Int? {
        val add = addOverride ?: findAddFor(appRoot(pkg), item) ?: run { log("cart: no Add button next to $item"); noAddMisses[pkg] = (noAddMisses[pkg] ?: 0) + 1; return null }
        peekCount++
        log("cart: adding \"$item\"")
        if (!safeClick(add)) { log("cart: Add refused"); return null }
        sleep(2000)
        findLabel(pkg, SHEET_ADD)?.let { log("cart: confirming options sheet"); safeClick(it); sleep(1800) }
        var cartBtn: AccessibilityNodeInfo? = null
        waitFor(7_000) { cartBtn = findLabel(pkg, CART_OPEN, Regex("(?i)\\badd\\b")); cartBtn != null }
        var fee: Int? = null
        var fallbackFee: Int? = null
        if (cartBtn != null && safeClick(cartBtn!!)) {
            sleep(2500)
            waitFor(10_000) { onCartPage(pkg) }
            for (pg in 0..2) {
                val lines = readScreen(appRoot(pkg), pkg) ?: break
                if (pg == 0) { log("cart screen:"); lines.take(50).forEach { log("  | $it") } }
                fee = deliveryFeeIn(lines, itemPrice, true)
                if (fee != null) break
                if (fallbackFee == null) fallbackFee = deliveryFeeIn(lines, itemPrice)
                val sc = findScrollable(appRoot(pkg)) ?: break
                if (!sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) break
                sleep(1200)
            }
            if (fee == null) fee = fallbackFee
            log("cart: extra charges = $fee")
        } else log("cart: no cart button found")
        // take everything out again, then make sure we are off the cart page
        for (i in 0 until 8) {
            if (timeUp()) break
            scrollToTop(pkg)
            val rm = findLabel(pkg, REMOVE)
            val did = if (rm != null) safeClick(rm) else decrementQty(pkg)
            if (!did) break
            sleep(1300)
            if (!onCartPage(pkg)) break
        }
        repeat(2) { if (onCartPage(pkg)) { performGlobalAction(GLOBAL_ACTION_BACK); sleep(1300) } }
        val an = FoodApps.ALL.firstOrNull { pkg in it.packages }?.label ?: pkg
        val barLeft = findLabel(pkg, Regex("(?i)\\bview (cart|basket)\\b"), Regex("(?i)\\badd\\b")) != null
        if (onCartPage(pkg) || barLeft) {
            cartNotes += "I couldn't empty the cart in $an - please clear it yourself (I did not order anything)."
            log("cart: NOT emptied")
        } else log("cart: emptied")
        return fee
    }

    // ---- restaurant cards (Zomato / Swiggy) -------------------------------------------------

    private class Card(val node: AccessibilityNodeInfo, val name: String, val rating: Double?)
    private val RATING = Regex("^([1-5]\\.\\d)(?:\\s|\\(|$)")
    private val MINS = Regex("\\d+\\s*(?:-\\s*\\d+)?\\s*mins?\\b", RegexOption.IGNORE_CASE)
    private val NOT_NAMES = Regex("(?i)^(?:items?|ad|ads|promoted|bestseller|free|new|pure veg|veg|non-?veg)$")

    private fun texts(n: AccessibilityNodeInfo): List<String> {
        val out = mutableListOf<String>()
        walk(n) { d -> d.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { out += it } }
        return out
    }

    /** Restaurant cards on screen: a tappable block that shows a rating and a delivery time. */
    private fun findCards(root: AccessibilityNodeInfo?): List<Card> {
        val out = mutableListOf<Card>()
        val names = HashSet<String>()
        walk(root) { n ->
            val t = n.text?.toString()?.trim()
            if (t != null && n.isVisibleToUser && RATING.containsMatchIn(t)) {
                var cur: AccessibilityNodeInfo? = n.parent
                var d = 0
                while (cur != null && d < 8 && !cur.isClickable) { cur = cur.parent; d++ }
                val card = cur
                if (card != null && card.isClickable) {
                    val tx = texts(card)
                    if (tx.any { MINS.containsMatchIn(it) }) {
                        val desc = card.contentDescription?.toString()
                        val name = if (desc != null && desc.contains(", serving ")) desc.substringBefore(", serving ").trim()
                        else tx.firstOrNull { FoodCompare.looksLikeName(it) && !NOT_NAMES.matches(it) }
                        if (name != null && (RATING.find(t)?.groupValues?.get(1)?.toDoubleOrNull() ?: 9.0) <= 5.0 && names.add(name.lowercase())) out += Card(card, name, RATING.find(t)?.groupValues?.get(1)?.toDoubleOrNull())
                    }
                }
            }
        }
        return out
    }

    /** Opens the top few restaurants (well rated ones first), reads each menu for the item, and backs out. */
    private fun drill(pkg: String, app: FoodApp, item: String, maxRestaurants: Int = 5): List<Offer> {
        val out = mutableListOf<Offer>()
        val visited = HashSet<String>()
        var n = 0
        while (n < maxRestaurants && !timeUp()) {
            var card: Card? = null
            for (attempt in 0..5) {
                val cards = findCards(appRoot(pkg)).filter { it.name.lowercase() !in visited }
                card = cards.firstOrNull { (it.rating ?: 0.0) >= 4.0 } ?: cards.firstOrNull()
                if (card != null) break
                val sc = findScrollable(appRoot(pkg)) ?: break
                if (!sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) break
                sleep(1500)
            }
            val c = card ?: break
            visited += c.name.lowercase()
            n++
            say("${app.label}: looking through ${c.name} ($n/$maxRestaurants)…")
            log("opening restaurant ${c.name} (rating ${c.rating})")
            if (!tap(c.node)) { log("couldn't tap ${c.name}"); continue }
            waitFor(14_000) { (readScreen(appRoot(pkg), pkg)?.size ?: 0) >= 10 }
            sleep(1500)
            val first = readScreen(appRoot(pkg), pkg)
            val fee = first?.firstNotNullOfOrNull { FoodCompare.feeOf(it) }
            val got = readPages(pkg, app, item, 9, c.name, logPages = 1).map { if (it.fee == null && fee != null) it.copy(fee = fee) else it }
            log("restaurant ${c.name}: ${got.size} offers, fee=$fee")
            out += got
            performGlobalAction(GLOBAL_ACTION_BACK)
            sleep(1800)
        }
        return out
    }

    private fun tapDishesTab(pkg: String): Boolean {
        var tab: AccessibilityNodeInfo? = null
        walk(appRoot(pkg)) { n -> if (tab == null && n.isVisibleToUser && label(n).trim().equals("Dishes", true)) tab = n }
        val t = tab ?: return false
        log("tapping Dishes tab")
        if (!tap(t)) return false
        waitFor(8_000) { pricesShown(pkg) }
        return true
    }

    /** Apps with no search box (Popeyes): read the menu by scrolling, plus category tiles that share a word with the item. */
    private fun scanMenuOnly(pkg: String, app: FoodApp, item: String): List<Offer>? {
        val blocker = blockerHint(appRoot(pkg))
        val offers = mutableListOf<Offer>()
        offers += readPages(pkg, app, item, 10, app.label)
        val words = item.lowercase().split(' ').filter { it.length > 2 }
        val seenTiles = HashSet<String>()
        var tiles = 0
        while (tiles < 3 && !timeUp()) {
            var tile: AccessibilityNodeInfo? = null
            walk(appRoot(pkg)) { n ->
                val t = n.text?.toString()?.trim()?.lowercase()
                if (tile == null && t != null && n.isVisibleToUser && t.length in 3..24 && t !in seenTiles && words.any { w -> t.contains(w) || w.contains(t) } && !FORBIDDEN.containsMatchIn(t)) {
                    var cur: AccessibilityNodeInfo? = n
                    var d = 0
                    while (cur != null && d < 4 && !cur.isClickable) { cur = cur.parent; d++ }
                    if (cur != null && cur.isClickable) { tile = cur; seenTiles += t }
                }
            }
            val tl = tile ?: break
            tiles++
            log("opening category: ${label(tl).take(40)}")
            if (!tap(tl)) continue
            sleep(2500)
            offers += readPages(pkg, app, item, 8, app.label, logPages = 1)
            performGlobalAction(GLOBAL_ACTION_BACK)
            sleep(1500)
        }
        if (offers.isEmpty() && blocker != null) return fail(app, "\"$blocker\" - delivery isn't available in this app right now")
        return offers.distinctBy { Triple(it.restaurant.lowercase(), it.item.lowercase(), it.price) }
    }

    /** Opens [pkg], searches [item] and returns offers read from the results, or null if the app could not be read. */
    private fun scanApp(ctx: Context, pkg: String, app: FoodApp, item: String): List<Offer>? {
        val launch = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return fail(app, "can't open it")
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try { startActivity(launch) } catch (e: Exception) { return fail(app, "Android blocked opening it") }
        if (!waitFor(25_000) { appRoot(pkg) != null }) return fail(app, "it didn't come to the front")
        log("=== ${app.label} ($pkg) \"$item\"")
        // slow starters (Domino's reopens on an old page): wait until the screen really has content, then a little more
        waitFor(15_000) { (readScreen(appRoot(pkg), pkg)?.size ?: 0) >= 6 }
        sleep(3500)
        dismissPopups(pkg)
        // some apps reopen on a page they were left on (Domino's "Deliver on Train"): back out first
        repeat(5) { if (wrongScreen(pkg)) { log("launched on a wrong page (train/PNR/login) - going back"); performGlobalAction(GLOBAL_ACTION_BACK); sleep(2200); dismissPopups(pkg) } }
        if (readScreen(appRoot(pkg), pkg)?.any { NOT_HERE.containsMatchIn(it) } == true) {
            log("${app.label} says it doesn't deliver to the current address")
            return fail(app, "it doesn't deliver to your current address (the app says delivery isn't available there)")
        }
        if (app.noSearch) return scanMenuOnly(pkg, app, item)
        // an app left on its cart page (EatSure after an earlier check): back out without touching anything in it
        repeat(2) { if (onCartPage(pkg)) { log("launched on the cart page - going back"); performGlobalAction(GLOBAL_ACTION_BACK); sleep(1500); dismissPopups(pkg) } }
        app.openTab?.let { tabName ->
            var tab: AccessibilityNodeInfo? = null
            waitFor(10_000) { walk(appRoot(pkg)) { n -> if (tab == null && n.isVisibleToUser && label(n).trim().equals(tabName, true)) tab = n }; tab != null }
            tab?.let { log("opening the $tabName tab"); tap(it); sleep(2500); dismissPopups(pkg) }
        }

        // an app left scrolled down hides its search bar (Swiggy): go to the top, clear popups, and only then look for the search
        repeat(2) { scrollToTop(pkg, 8); sleep(700); dismissPopups(pkg) }
        var typed = false
        for (attempt in 0..1) {
            if (!openSearch(pkg, app)) {
                // the "not available here" banner can appear a few seconds after launch
                if (readScreen(appRoot(pkg), pkg)?.any { NOT_HERE.containsMatchIn(it) } == true) {
                    log("${app.label} says it doesn't deliver to the current address")
                    return fail(app, "it doesn't deliver to your current address (the app says delivery isn't available there)")
                }
                if (app.id == "popeyes") { log("no search box - reading the menu instead"); return scanMenuOnly(pkg, app, item) }
                var count = 0
                walk(appRoot(pkg)) { count++ }
                return fail(app, blockerHint(appRoot(pkg))?.let { "\"$it\" is showing - clear it in the app, or it may not be usable right now" }
                    ?: if (count <= 8) "the app shows Ghostie an empty screen (it hides its content from screen readers)" else "couldn't open its search")
            }
            if (wrongScreen(pkg)) {
                log("wrong screen (train/PNR/login) after opening search - going back")
                lastSearchLabel?.let { avoidLabels += it }
                repeat(3) { if (wrongScreen(pkg)) { performGlobalAction(GLOBAL_ACTION_BACK); sleep(1300) } }
                dismissPopups(pkg)
                continue
            }
            typed = submitSearch(pkg, item)
            break
        }
        if (!typed) return fail(app, "couldn't open a real search box (it kept landing on another page)")
        sleep(800)

        val offers = mutableListOf<Offer>()
        val listApp = app.id == "zomato" || app.id == "swiggy"
        offers += readPages(pkg, app, item, 10, null, peek = !listApp)
        if (listApp) {
            if (offers.size < 3) {
                // results are restaurants: try a Dishes tab, then open the top restaurants' menus
                if (tapDishesTab(pkg)) offers += readPages(pkg, app, item, 6, null, peek = false)
                if (offers.size < 3 && !timeUp()) offers += drill(pkg, app, item)
            }
        }
        // a brand app with only a couple of hits ("fried chicken" -> 2): also search the broader word ("chicken") so wings, tenders etc. are included
        if (!listApp && offers.size < 4 && !timeUp()) {
            val words = item.split(' ').filter { it.length > 2 }
            val broad = words.lastOrNull()
            if (broad != null && words.size > 1) {
                log("only ${offers.size} match(es) - widening the search to \"$broad\"")
                if (findInput(appRoot(pkg)) == null) openSearch(pkg, app)
                if (submitSearch(pkg, broad)) { sleep(800); offers += readPages(pkg, app, broad, 8, null, peek = false) }
            }
        }
        // real delivery fees: open the restaurants of the cheapest dishes and look in their cart
        if (listApp && offers.isNotEmpty()) {
            for (o in offers.sortedBy { it.price }.distinctBy { it.restaurant.lowercase() }.take(3)) {
                if (timeUp() || peekCount >= 6) break
                if (feeByRest[o.restaurant.lowercase()] != null) continue
                say("${app.label}: opening ${o.restaurant} to check the delivery fee…")
                peekedRest += o.restaurant.lowercase()
                peekViaRestaurant(pkg, o)?.let { feeByRest[o.restaurant.lowercase()] = it }
            }
            val mapped = offers.map { o -> feeByRest[o.restaurant.lowercase()]?.let { o.copy(fee = it) } ?: o }
            offers.clear(); offers += mapped
        }
        // back out so the app is left on a normal screen
        repeat(4) { if (findSearch(appRoot(pkg)) == null || editableShown(pkg)) { performGlobalAction(GLOBAL_ACTION_BACK); sleep(600) } }
        if (offers.isEmpty()) reasons[app.label] = "read the results but found no matching price"
        return offers.distinctBy { Triple(it.restaurant.lowercase(), it.item.lowercase(), it.price) }
    }

    // ---- screen helpers ----------------------------------------------------------------------

    /** Types [text] into [input]: focus + set text; if the app ignores that, paste it (the clipboard is put back afterwards). */
    private fun typeInto(input: AccessibilityNodeInfo, text: String): Boolean {
        input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        input.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        sleep(300)
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        val set = input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        sleep(500)
        input.refresh()
        var has = input.text?.toString()?.contains(text, true) == true
        if (!has) {
            try {
                // some apps (Zomato) apply SET_TEXT a moment late: empty the field first so pasting never doubles the words
                input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "") })
                sleep(300)
                val cm = getSystemService(ClipboardManager::class.java)
                val prev = cm.primaryClip
                cm.setPrimaryClip(ClipData.newPlainText("ghostie", text))
                input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                input.performAction(AccessibilityNodeInfo.ACTION_PASTE)
                sleep(600)
                input.refresh()
                has = input.text?.toString()?.contains(text, true) == true
                if (prev != null) cm.setPrimaryClip(prev)
            } catch (e: Exception) { }
        }
        log("typing: set=$set, field now='${input.text}'")
        return set || has
    }

    private fun sleep(ms: Long) { try { Thread.sleep(ms) } catch (e: InterruptedException) {} }

    private fun waitFor(ms: Long, cond: () -> Boolean): Boolean {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) { if (cancel) return false; if (cond()) return true; sleep(400) }
        return false
    }

    private fun label(n: AccessibilityNodeInfo): String =
        listOfNotNull(n.text, n.contentDescription, if (android.os.Build.VERSION.SDK_INT >= 26) n.hintText else null).joinToString(" ")

    private fun walk(root: AccessibilityNodeInfo?, depth: Int = 0, f: (AccessibilityNodeInfo) -> Unit) {
        if (root == null || depth > 40) return
        f(root)
        for (i in 0 until root.childCount) walk(root.getChild(i), depth + 1, f)
    }

    /** The search entry: nodes mentioning "search" win, clickable ones first; an id like "search_edit_text" counts only if it can be tapped. */
    private fun findSearch(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestScore = 0
        walk(root) { n ->
            if (n.isVisibleToUser) {
                val l = label(n)
                if (!FORBIDDEN.containsMatchIn(l) && l.trim() !in avoidLabels && nodeKey(n) !in avoidNodes) {
                    val said = l.contains("search", true)
                    val idHit = n.viewIdResourceName?.substringAfterLast('/')?.contains("search", true) == true && n.isClickable &&
                        n.viewIdResourceName?.contains("location", true) != true
                    var sc = 0
                    if (said) sc += 2
                    if (said && l.contains("open search", true)) sc += 2
                    if ((said || idHit) && n.isClickable) sc += 2
                    if (idHit) sc += 1
                    if (sc > bestScore) { bestScore = sc; best = n }
                }
            }
        }
        if (best == null) walk(root) { n -> if (best == null && n.isVisibleToUser && n.isEditable && !NOT_SEARCH_FIELD.containsMatchIn(label(n) + " " + (n.hintText ?: ""))) best = n }
        return best
    }

    /** Labels of nodes that already led somewhere wrong (e.g. Domino's train/PNR page); not tried again in this run. */
    private val avoidLabels = HashSet<String>()
    /** Search-looking icons that led somewhere wrong, keyed by id + position (Domino's train button). */
    private val avoidNodes = HashSet<String>()
    private fun nodeKey(n: AccessibilityNodeInfo): String { val r = Rect(); n.getBoundsInScreen(r); return "${n.viewIdResourceName}|${r.flattenToString()}" }
    private val NOT_SEARCH_FIELD = Regex("(?i)pnr|phone|mobile|otp|email|pincode|coupon|promo")
    private val WRONG_SCREEN = Regex("(?i)\\b(pnr|deliver on train|order on train|enter your mobile|enter otp|verify otp|log ?in|sign ?in)\\b")

    private fun wrongScreen(pkg: String): Boolean =
        readScreen(appRoot(pkg), pkg)?.take(40)?.any { WRONG_SCREEN.containsMatchIn(it) } == true

    /** Closes harmless popups ("Not now", "Skip"...). Never presses Allow/Enable/Update/Yes or anything about orders. */
    private val POPUP_SAFE = setOf("not now", "skip", "skip for now", "maybe later", "later", "remind me later", "no thanks", "no, thanks", "not interested", "dismiss", "close", "cancel", "got it", "okay", "ok", "x", "\u2715", "\u2716", "no", "deny", "don't allow", "don\u2019t allow", "continue without login", "continue as guest", "skip login", "i'll do it later")

    /** Closes the harmless pop-ups apps like to show (offers, rate us, notification/location asks); never accepts anything. */
    private fun dismissPopups(pkg: String): Boolean {
        var did = false
        repeat(4) {
            var target: AccessibilityNodeInfo? = null
            // permission / system dialogs live in their own window
            try {
                for (w in windows) {
                    val r = w.root ?: continue
                    val wp = r.packageName?.toString() ?: continue
                    if (wp.contains("permissioncontroller") || wp.contains("packageinstaller")) {
                        walk(r) { n -> val t = label(n).trim().lowercase(); if (target == null && n.isVisibleToUser && (t == "don't allow" || t == "don\u2019t allow" || t == "deny" || t == "not now")) target = n }
                    }
                }
            } catch (e: Exception) { }
            if (target == null) walk(appRoot(pkg)) { n ->
                val t = label(n).trim().lowercase()
                if (target == null && n.isVisibleToUser && t.length <= 40 && t in POPUP_SAFE && (n.isClickable || n.parent?.isClickable == true)) target = n
                // image-only close buttons (a bare cross icon) are recognised by their id
                if (target == null && n.isVisibleToUser && (n.isClickable || n.parent?.isClickable == true) && n.text.isNullOrBlank()) {
                    val id = (n.viewIdResourceName ?: "").substringAfter(':').substringAfter('/').lowercase()
                    if (Regex("(^|_)(close|dismiss|cross|cancel|skip)(_|$)|close_?(btn|button|icon)|(btn|iv|img|ic)_?(close|cross|dismiss)").containsMatchIn(id) && !id.contains("cart")) target = n
                }
            }
            val t = target ?: return did
            log("dismissing popup: ${label(t).take(40)}")
            if (!t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) { val par = t.parent; if (par == null || !par.performAction(AccessibilityNodeInfo.ACTION_CLICK)) tapAt(t) }
            did = true
            sleep(900)
        }
        return did
    }

    private fun findSearchButton(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        walk(root) { n ->
            if (best == null && n.isVisibleToUser && n.className?.toString()?.contains("EditText") != true) {
                val l = (n.contentDescription ?: "").toString()
                if (l.equals("search", true) && !FORBIDDEN.containsMatchIn(l)) best = n
            }
        }
        return best
    }

    private fun findInput(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        walk(root) { n -> if (best == null && n.isVisibleToUser && n.isEditable && !NOT_SEARCH_FIELD.containsMatchIn(label(n) + " " + (n.hintText ?: ""))) best = n }
        return best
    }

    private fun findScrollable(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        walk(root) { n -> if (best == null && n.isScrollable && n.isVisibleToUser) best = n }
        return best
    }

    /** Taps [n]: click it or its nearest clickable parent, else a plain touch at its centre. Refuses anything about paying, carts or ordering. */
    private fun tap(n: AccessibilityNodeInfo): Boolean {
        if (FORBIDDEN.containsMatchIn(label(n))) return false
        var cur: AccessibilityNodeInfo? = n
        var depth = 0
        while (cur != null && depth < 6) {
            val l = label(cur)
            if (l.length < 80 && FORBIDDEN.containsMatchIn(l)) return false
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent; depth++
        }
        return tapAt(n)
    }

    /** Touch at the centre of [n] (works for custom views that don't report as clickable). */
    private fun tapAt(n: AccessibilityNodeInfo): Boolean {
        val r = Rect(); n.getBoundsInScreen(r)
        if (r.isEmpty) return false
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build()
        val latch = CountDownLatch(1)
        var ok = false
        val sent = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        if (!sent) return false
        latch.await(3, TimeUnit.SECONDS)
        return ok
    }

    /** Visible text on screen, top to bottom. Null if the screen is not [pkg] any more. */
    private fun readScreen(root: AccessibilityNodeInfo?, pkg: String): List<String>? {
        if (root == null || root.packageName?.toString() != pkg) return null
        class It(val t: String, val top: Int, val left: Int)
        val items = mutableListOf<It>()
        walk(root) { n ->
            val t = n.text?.toString()
            if (!t.isNullOrBlank() && n.isVisibleToUser && n.className?.toString()?.contains("EditText") != true) {
                val r = Rect(); n.getBoundsInScreen(r)
                items += It(t.trim(), r.top, r.left)
            }
        }
        return items.sortedWith(compareBy({ it.top / 12 }, { it.left })).map { it.t }
    }
}
