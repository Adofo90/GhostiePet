package com.ghostie.pet

import java.time.LocalDate

/** Focus minutes per day, stored as lines "2026-11-02|75". Pure Kotlin. */
object StudyLog {
    fun parse(raw: String): Map<LocalDate, Int> = raw.lines().mapNotNull {
        val d = it.substringBefore('|').trim()
        val m = it.substringAfter('|', "").trim().toIntOrNull()
        val date = try { LocalDate.parse(d) } catch (e: Exception) { null }
        if (date != null && m != null) date to m else null
    }.toMap()

    fun add(raw: String, minutes: Int, today: LocalDate = LocalDate.now()): String {
        if (minutes <= 0) return raw
        val m = parse(raw).toMutableMap()
        m[today] = (m[today] ?: 0) + minutes
        return m.entries.sortedBy { it.key }.takeLast(60).joinToString("\n") { "${it.key}|${it.value}" }
    }

    fun today(raw: String, today: LocalDate = LocalDate.now()): Int = parse(raw)[today] ?: 0

    /** Last 7 days including today. */
    fun week(raw: String, today: LocalDate = LocalDate.now()): Int =
        parse(raw).filter { !it.key.isBefore(today.minusDays(6)) && !it.key.isAfter(today) }.values.sum()

    fun format(min: Int): String = if (min >= 60) "${min / 60} h ${min % 60} min" else "$min min"

    /** Study streak: consecutive days (ending today or yesterday) with any focus time. */
    fun streak(raw: String, today: LocalDate = LocalDate.now()): Int {
        val m = parse(raw)
        var d = if ((m[today] ?: 0) > 0) today else today.minusDays(1)
        var n = 0
        while ((m[d] ?: 0) > 0) { n++; d = d.minusDays(1) }
        return n
    }
}

/** Focus minutes per subject per day: lines "2026-11-02|Computer Science|50". Pure Kotlin. */
object SubjectLog {
    private fun rows(raw: String): List<Triple<java.time.LocalDate, String, Int>> = raw.lines().mapNotNull {
        val p = it.split('|')
        if (p.size < 3) return@mapNotNull null
        val d = try { java.time.LocalDate.parse(p[0]) } catch (e: Exception) { return@mapNotNull null }
        val m = p[2].toIntOrNull() ?: return@mapNotNull null
        Triple(d, p[1], m)
    }

    fun add(raw: String, subject: String, minutes: Int, today: java.time.LocalDate = java.time.LocalDate.now()): String {
        if (minutes <= 0 || subject.isBlank()) return raw
        val all = rows(raw).toMutableList()
        val i = all.indexOfFirst { it.first == today && it.second.equals(subject, true) }
        if (i >= 0) all[i] = Triple(today, all[i].second, all[i].third + minutes) else all.add(Triple(today, subject.replace('|', ' '), minutes))
        return all.sortedBy { it.first }.takeLast(200).joinToString("\n") { "${it.first}|${it.second}|${it.third}" }
    }

    /** Minutes per subject over the last [days] days including today. */
    fun bySubject(raw: String, days: Int = 7, today: java.time.LocalDate = java.time.LocalDate.now()): Map<String, Int> =
        rows(raw).filter { !it.first.isBefore(today.minusDays(days - 1L)) && !it.first.isAfter(today) }
            .groupBy { it.second.lowercase() }.mapValues { e -> e.value.sumOf { it.third } }
}
