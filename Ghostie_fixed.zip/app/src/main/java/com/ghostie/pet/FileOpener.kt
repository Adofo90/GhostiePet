package com.ghostie.pet

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File

/** Finds a file by (part of) its name and opens it in the phone's own viewer. */
object FileOpener {
    data class Hit(val file: File, val score: Double)

    private val FILLER = setOf("file", "files", "the", "my", "a", "an", "document", "doc", "docs", "documents", "please", "of", "for", "in", "from", "named", "called")
    private val TYPES = mapOf(
        "pdf" to listOf("pdf"), "ppt" to listOf("ppt", "pptx"), "pptx" to listOf("ppt", "pptx"), "slides" to listOf("ppt", "pptx"),
        "word" to listOf("doc", "docx"), "excel" to listOf("xls", "xlsx", "csv"), "sheet" to listOf("xls", "xlsx", "csv"),
        "image" to listOf("jpg", "jpeg", "png"), "photo" to listOf("jpg", "jpeg", "png"), "video" to listOf("mp4", "mkv", "3gp")
    )

    /** What the user typed -> (words to look for in the name, wanted extensions or empty). */
    fun tokens(query: String): Pair<List<String>, List<String>> {
        var q = query.lowercase().trim().trim('"', '\'', '.')
        var exts = emptyList<String>()
        Regex("\\.([a-z0-9]{2,4})$").find(q)?.let { exts = listOf(it.groupValues[1]); q = q.removeSuffix("." + it.groupValues[1]) }
        val words = q.split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }.toMutableList()
        words.firstOrNull { it in TYPES }?.let { if (exts.isEmpty()) { exts = TYPES[it]!!; if (it != "pdf" || words.size > 1) words.remove(it) } }
        return words.filter { it !in FILLER }.ifEmpty { words.filter { it !in TYPES } } to exts
    }

    /** Share (0..1) of the wanted words found in the file name; 0 if the wanted type doesn't match. */
    fun score(words: List<String>, exts: List<String>, name: String): Double {
        if (words.isEmpty()) return 0.0
        val ext = name.substringAfterLast('.', "").lowercase()
        if (exts.isNotEmpty() && ext !in exts) return 0.0
        val n = name.lowercase().substringBeforeLast('.').replace(Regex("[^a-z0-9]+"), " ")
        return words.count { n.contains(it) }.toDouble() / words.size
    }

    fun roots(): List<File> {
        val ext = Environment.getExternalStorageDirectory()
        return (listOf(
            DocOrganizer.ghostieRoot(),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
            File(ext, "Download")
        ) + DocOrganizer.sourceFolders()).distinctBy { it.absolutePath }.filter { it.isDirectory }
    }

    fun search(query: String, roots: List<File> = roots(), maxDepth: Int = 4): List<Hit> {
        val (words, exts) = tokens(query)
        if (words.isEmpty()) return emptyList()
        val hits = mutableListOf<Hit>()
        var seen = 0
        fun walk(d: File, depth: Int) {
            if (depth > maxDepth || seen > 20_000) return
            for (f in d.listFiles().orEmpty()) {
                if (f.name.startsWith(".")) continue
                if (f.isDirectory) walk(f, depth + 1)
                else {
                    seen++
                    val sc = score(words, exts, f.name)
                    if (sc >= 0.6) hits += Hit(f, sc)
                }
            }
        }
        roots.forEach { walk(it, 0) }
        return hits.distinctBy { it.file.absolutePath }.sortedWith(compareByDescending<Hit> { it.score }.thenByDescending { it.file.lastModified() })
    }

    fun mime(name: String): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "*/*"

    fun viewIntent(ctx: Context, f: File): Intent {
        val uri: Uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        return Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime(f.name))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }
}
