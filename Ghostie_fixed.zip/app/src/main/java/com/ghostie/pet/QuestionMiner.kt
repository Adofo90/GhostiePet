package com.ghostie.pet

/**
 * Finds multiple-choice questions and numerical problems (with their answers) in notes or question-paper text and turns
 * them into flashcards. Pure Kotlin: no Android classes, tested on the JVM.
 * Questions that have no answer in the text are skipped, because a card needs something to check against.
 */
object QuestionMiner {
    enum class Kind { MCQ, NUMERICAL, NOTE }
    data class Mined(val kind: Kind, val q: String, val a: String)
    class Result(val cards: List<Mined>, val skippedNoAnswer: Int)

    private val qStart = Regex("^\\s*(?:q(?:uestion)?\\.?\\s*)?(\\d{1,3})\\s*[.)\\]:\\-]\\s*(.+)$", RegexOption.IGNORE_CASE)
    private val qStartQ = Regex("^\\s*q(?:uestion)?\\s*(\\d{1,3})?\\s*[.:)\\-]\\s*(.+)$", RegexOption.IGNORE_CASE)
    private val optLine = Regex("^\\s*\\(?([A-Da-d])[.)]\\s*(.+)$")
    private val ansLine = Regex("^\\s*(?:ans(?:wer)?|correct\\s+(?:answer|option)|sol(?:ution)?)\\s*[:.\\-)]*\\s*(.*)$", RegexOption.IGNORE_CASE)
    private val keyHead = Regex("^\\s*(?:answer\\s*key|answers?|key)\\s*:?\\s*$", RegexOption.IGNORE_CASE)
    private val keyPair = Regex("(\\d{1,3})\\s*[-.):=]?\\s*\\(?([A-Da-d])\\)?(?=\\s|,|;|$)")
    private val numCue = Regex("\\b(find|calculate|determine|compute|evaluate|solve|how (?:many|much|long|far|fast|old)|what is the|speed|velocity|mass|force|current|voltage|resistance|rate|profit|loss|interest|average|ratio|percent(?:age)?|probability)\\b|%|₹|\\brs\\.?\\b|\\b(?:kg|km|cm|mm|m/s|km/h|volts?|ohms?|amps?|watts?|joules?|hz|mol)\\b", RegexOption.IGNORE_CASE)

    /** PDF text arrives as one long line; put the line breaks back so the patterns below can work. */
    fun restoreLines(text: String): String {
        if (text.count { it == '\n' } * 200 >= text.length) return text
        return text
            .replace(Regex("\\s+(?=(?:Ans(?:wer)?|Solution|Sol)\\s*[:.)])", RegexOption.IGNORE_CASE), "\n")
            .replace(Regex("\\s+(?=\\(?[A-D][.)]\\s+\\S)"), "\n")
            .replace(Regex("\\s+(?=Q\\.?\\s*\\d{1,3}\\s*[.:)])"), "\n")
            .replace(Regex("(?<=[?.:)]|\\b[A-Da-d])\\s+(?=\\d{1,3}[.)]\\s+[A-Z])"), "\n")
    }

    private fun answerKey(lines: List<String>): Map<Int, Char> {
        val key = HashMap<Int, Char>()
        var i = lines.indexOfLast { keyHead.matches(it) }
        if (i < 0) return key
        i++
        while (i < lines.size) {
            val found = keyPair.findAll(lines[i]).toList()
            if (found.isEmpty() && lines[i].isNotBlank()) break
            found.forEach { key[it.groupValues[1].toInt()] = it.groupValues[2].uppercase()[0] }
            i++
        }
        return key
    }

    /** Notes have numbered points and lettered headings that look like questions; only count real questions as "had no answer". */
    private fun looksLikeQuestion(stem: String): Boolean =
        stem.trimEnd().endsWith("?") || stem.contains("_ _") || stem.contains("___") ||
            Regex("\\b(which of the following|choose|select the|correct (?:answer|option|statement)|true or false|fill in|find|calculate|determine|compute|solve)\\b", RegexOption.IGNORE_CASE).containsMatchIn(stem)

    private class Block(val no: Int?, val stem: StringBuilder = StringBuilder(), val options: MutableList<Pair<Char, String>> = mutableListOf(), val ans: StringBuilder = StringBuilder(), var inAns: Boolean = false)

    fun mine(raw: String, maxCards: Int = 300): Result {
        val lines = restoreLines(raw.replace("\r", "")).lines().map { it.trim() }
        val key = answerKey(lines)
        val keyStart = lines.indexOfLast { keyHead.matches(it) }.let { if (it >= 0 && key.isNotEmpty()) it else lines.size }
        val blocks = ArrayList<Block>()
        var cur: Block? = null
        for (idx in 0 until keyStart) {
            val line = lines[idx]
            if (line.isBlank()) continue
            val qm = if (cur?.inAns == true || cur == null || cur.options.isNotEmpty() || cur.ans.isNotEmpty() || true) (qStart.find(line) ?: qStartQ.find(line)) else null
            val isOpt = optLine.matches(line) && cur != null
            val am = ansLine.find(line)
            when {
                am != null && cur != null -> { cur.inAns = true; if (am.groupValues[1].isNotBlank()) cur.ans.append(am.groupValues[1]).append('\n') }
                qm != null && !(isOpt) && !(cur?.inAns == true && cur.ans.isEmpty().not() && qm.groupValues[1].isEmpty()) -> {
                    cur = Block(qm.groupValues[1].toIntOrNull()); blocks.add(cur)
                    cur.stem.append(qm.groupValues[2])
                }
                isOpt -> { val m = optLine.find(line)!!; if (cur!!.inAns) cur.ans.append(line).append('\n') else cur.options.add(m.groupValues[1].uppercase()[0] to m.groupValues[2].trim()) }
                cur != null && cur.inAns -> cur.ans.append(line).append('\n')
                cur != null && cur.options.isEmpty() -> cur.stem.append(' ').append(line)
                cur != null -> { val last = cur.options.removeAt(cur.options.size - 1); cur.options.add(last.first to (last.second + " " + line)) }
            }
        }
        val out = ArrayList<Mined>()
        var skipped = 0
        for (b in blocks) {
            val stem = b.stem.toString().replace(Regex("\\s+"), " ").trim()
            if (stem.length < 8) continue
            val ans = b.ans.toString().trim()
            if (b.options.size >= 2) {
                val letter = Regex("^\\(?([A-Da-d])\\)?(?![A-Za-z])").find(ans)?.groupValues?.get(1)?.uppercase()?.get(0) ?: b.no?.let { key[it] }
                val chosen = b.options.firstOrNull { it.first == letter }
                if (letter == null || chosen == null) { if (looksLikeQuestion(stem)) skipped++; continue }
                val why = ans.replace(Regex("^\\(?[A-Da-d]\\)?[\\s.:)\\-]*"), "").trim()
                val q = stem + "\n" + b.options.joinToString("\n") { "${it.first}) ${it.second}" }
                out.add(Mined(Kind.MCQ, q, "${chosen.first}) ${chosen.second}" + if (why.isNotEmpty()) "\n$why" else ""))
            } else {
                val numeric = stem.any { it.isDigit() } && (numCue.containsMatchIn(stem) || Regex("\\d+(?:\\.\\d+)?").findAll(stem).count() >= 2)
                if (!numeric) continue
                if (ans.isEmpty()) { if (looksLikeQuestion(stem)) skipped++; continue }
                out.add(Mined(Kind.NUMERICAL, stem, ans.replace(Regex("\\s*\\n\\s*"), "\n").trim()))
            }
            if (out.size >= maxCards) break
        }
        return Result(out, skipped)
    }

    /** Turns mined cards into Student cards (skipping ones already there). Returns how many were added. */
    fun addTo(st: Student.State, mined: List<Mined>, subject: String, today: java.time.LocalDate): Int {
        var n = 0
        for (m in mined) {
            if (st.cards.any { it.q.equals(m.q, true) }) continue
            st.cards.add(Student.Card(System.currentTimeMillis() + n, subject, m.q, m.a, 0, today.toEpochDay())); n++
        }
        return n
    }
}
