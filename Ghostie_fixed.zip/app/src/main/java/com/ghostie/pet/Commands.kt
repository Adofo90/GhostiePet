package com.ghostie.pet

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters

/** The four tabs of the phone's calendar form: Event, Birthday, Anniversary, Countdown. */
enum class EventKind(val label: String, val icon: String) {
    EVENT("Event", "📅"), BIRTHDAY("Birthday", "🎂"), ANNIVERSARY("Anniversary", "💍"), COUNTDOWN("Countdown", "⏳");

    companion object {
        fun parse(s: String): EventKind? = values().firstOrNull { it.name.equals(s, true) || it.label.equals(s, true) }
    }
}

sealed class Command {
    object Organize : Command()
    object Help : Command()
    /**
     * [startMillis] is local time. For all-day events only the date matters.
     * [repeat] is "", DAILY, WEEKLY, MONTHLY or YEARLY. [remind] is minutes before the start.
     * [explicit] is true when the user named the category themselves.
     */
    data class Event(
        val title: String, val startMillis: Long, val kind: EventKind = EventKind.EVENT, val allDay: Boolean = false,
        val repeat: String = "", val durationMin: Int = 60, val remind: List<Int> = listOf(10),
        val description: String = "", val explicit: Boolean = false
    ) : Command()
    data class MakeKind(val kind: EventKind) : Command()
    object Undo : Command()
    /** "When I say X, do/say Y" (exact phrase) or "remember X means Y" (word substitution, stored as word:Y). */
    data class Teach(val phrase: String, val meaning: String) : Command()
    data class Forget(val phrase: String) : Command()
    object ForgetAll : Command()
    object Learned : Command()
    data class Timer(val seconds: Int) : Command()
    data class Alarm(val hour: Int, val minute: Int, val label: String = "") : Command()
    data class Call(val target: String) : Command()
    data class OpenApp(val name: String) : Command()
    data class ShowDocs(val subject: String) : Command()
    data class Watch(val group: String) : Command()
    /** Recognised verb but something is missing; message tells the user what. */
    data class Incomplete(val message: String) : Command()
}

/** Turns chat text into a Command. Pure Kotlin so it can be tested without a phone. */
object Commands {
    const val HELP = "I can do these 💜\n" +
        "• organize documents – sorts your WhatsApp files by subject\n" +
        "• show documents of computer science\n" +
        "• add event maths exam tomorrow 10am  (also: add birthday Tikki on 19 October, anniversary, countdown to exams on 5 Dec; add \"every week\", \"for 2 hours\", \"all day\", \"remind me 30 minutes before\")\n" +
        "• make it a birthday – fixes the category of the last event, and I'll remember\n" +
        "• when I say study mode, set timer 25 minutes – teach me your own phrases\n" +
        "• remember cs means computer science\n" +
        "• what have you learned / forget study mode / forget everything\n" +
        "• watch group CSE 3A – I'll remind you the day before any submission or event registration deadline posted there\n" +
        "• Share a group's exported chat (or one message) from WhatsApp to Ghostie to catch up on deadlines\n" +
        "• call Mom  /  call 9876543210\n" +
        "• timer 10 minutes\n" +
        "• alarm 6:30 am\n" +
        "• open WhatsApp"

    private val I = RegexOption.IGNORE_CASE
    private data class TimeHit(val hour: Int, val minute: Int, val range: IntRange)

    fun parse(raw: String, now: LocalDateTime = LocalDateTime.now()): Command? {
        val t = raw.trim()
        if (t.isEmpty()) return null

        if (Regex("^(help|commands|what can you do\\??|what do you do\\??)$", I).matches(t)) return Command.Help

        if (Regex("^(?:what (?:have|did) you (?:learn(?:ed|t)?)|what do you know about me|show (?:what you )?learn(?:ed|ing))\\??$", I).matches(t)) return Command.Learned
        if (Regex("^(?:forget everything(?: you (?:learned|learnt|know))?|reset (?:your )?(?:learning|memory)|clear (?:your )?memory)$", I).matches(t)) return Command.ForgetAll
        Regex("^forget\\s+(?:the\\s+)?(?:phrase\\s+)?[\"“']?(.+?)[\"”']?$", I).find(t)?.let { return Command.Forget(it.groupValues[1].trim()) }
        Regex("^(?:when|if|whenever) i (?:say|type|ask|tell you)\\s+[\"“']?(.+?)[\"”']?\\s*(?:,|then|->|=>|:)?\\s*(?:you\\s+)?(?:should\\s+|please\\s+)?(say|reply|respond|answer|do|run|set|open|call|add|timer|alarm)\\s+(.+)$", I).find(t)?.let { m ->
            val verb = m.groupValues[2].lowercase()
            val rest = m.groupValues[3].trim()
            val meaning = when (verb) {
                "say", "reply", "respond", "answer" -> "say:" + rest.trim('"', '“', '”')
                "do", "run" -> rest
                else -> "$verb $rest"
            }
            return Command.Teach(m.groupValues[1].trim(), meaning)
        }
        Regex("^remember\\s+(?:that\\s+)?[\"“']?(.+?)[\"”']?\\s+(?:means|stands for|is short for|=)\\s+[\"“']?(.+?)[\"”']?$", I).find(t)?.let {
            return Command.Teach(it.groupValues[1].trim(), "word:" + it.groupValues[2].trim())
        }
        if (Regex("^(?:please\\s+)?(undo|undo that|undo it|remove it|delete it|delete that|delete that event|cancel that event)\\s*[.!]?\\s*(?:↩️?)?$", I).containsMatchIn(t)) return Command.Undo
        Regex("^(?:please\\s+)?(?:make|change|turn|set)\\s+(?:it|that|this)\\s+(?:into\\s+|to\\s+|as\\s+|a\\s+|an\\s+|the\\s+)*(event|birthday|bday|anniversary|countdown)\\b", I).find(t)?.let {
            val w = it.groupValues[1].lowercase()
            return Command.MakeKind(if (w == "bday") EventKind.BIRTHDAY else EventKind.parse(w) ?: EventKind.EVENT)
        }

        if (Regex("\\b(organi[sz]e|sort|arrange|clean ?up|group)\\b.*\\b(docs?|documents?|files?|pdfs?|notes)\\b", I).containsMatchIn(t)) {
            return Command.Organize
        }

        val call = Regex("^(?:please\\s+)?(?:call|dial|phone|ring)\\s+(?:up\\s+)?(.+?)(?:\\s+(?:please|now))?$", I).find(t)
        if (call != null) {
            val who = call.groupValues[1].trim()
            if (Regex("^(?:me|it|us|them|back later|a day)\\b", I).containsMatchIn(who)) return null // "call me Anay", "call it a day"
            return if (who.isNotEmpty()) Command.Call(who) else Command.Incomplete("Who should I call? Try: call Mom")
        }

        val watch = Regex("^(?:please\\s+)?(?:watch|monitor|track)\\s+(?:(?:the\\s+)?group\\s+(.+)|(.+?)\\s+group)$", I).find(t)
        if (watch != null) {
            val name = (watch.groupValues[1].ifEmpty { watch.groupValues[2] }).trim().trim('"', '\'')
            return if (name.isNotEmpty()) Command.Watch(name) else Command.Incomplete("Which group? Try: watch group CSE 3A")
        }

        val show = Regex(
            "\\b(?:give|show|list|find|get|send|see|display)\\b.*?\\b(?:docs?|documents?|files?|notes|pdfs?)\\b\\s*(?:belonging to|related to|of|for|in|from|on|about|under)?\\s*(.*)$", I
        ).find(t)
        if (show != null) {
            val subject = show.groupValues[1].replace(Regex("^(?:the|my)\\s+", I), "").trim()
            return if (subject.isNotEmpty()) Command.ShowDocs(subject)
            else Command.Incomplete("Which subject? Try: show documents of computer science")
        }

        val hasDate = findDate(t, now.toLocalDate()) != null
        if (Regex("\\btimer\\b", I).containsMatchIn(t) || (Regex("\\bcountdown\\b", I).containsMatchIn(t) && !hasDate)) {
            val secs = durationSeconds(t)
            return if (secs > 0) Command.Timer(secs) else Command.Incomplete("For how long? Try: timer 10 minutes")
        }

        if (Regex("\\balarm\\b", I).containsMatchIn(t)) {
            val hit = findTime(t)
            val label = Regex("\\b(?:with\\s+)?(?:title|label|name|called|named)\\s+(.+?)(?=\\s+(?:at|for|in|on|tomorrow|today)\\b|$)", I).find(t)?.groupValues?.get(1)?.trim().orEmpty()
            return if (hit != null) Command.Alarm(hit.hour, hit.minute, label) else Command.Incomplete("What time? Try: alarm 6:30 am")
        }

        val ev = Regex(
            "^(?:please\\s+)?(?:add|create|set|make|schedule|new|put|save)\\s+(?:an?\\s+|the\\s+|my\\s+)?(?:new\\s+)?(?:all[- ]day\\s+)?(event|reminder|meeting|class|exam|appointment|birthday|b'?day|anniversary|countdown)\\b(.*)$",
            I
        ).find(t)
        if (ev != null) return parseEvent(ev.groupValues[1].lowercase(), (if (Regex("all[- ]day", I).containsMatchIn(t.substringBefore(ev.groupValues[1]))) " all day " else "") + ev.groupValues[2], now)

        // "Tikki's birthday on 19 October", "countdown to exams 5 dec" (need a date so normal chat isn't hijacked)
        val bare = Regex("^(.+?)\\s+(birthday|b'?day|anniversary)\\b(.*)$", I).find(t)
        if (bare != null && findDate(t, now.toLocalDate()) != null) return parseEvent(bare.groupValues[2].lowercase(), bare.groupValues[1] + " " + bare.groupValues[3], now)
        val cd = Regex("^(?:countdown|days? (?:left )?(?:to|until|till|for))\\s+(?:to\\s+|for\\s+)?(.+)$", I).find(t)
        if (cd != null && findDate(t, now.toLocalDate()) != null) return parseEvent("countdown", cd.groupValues[1], now)

        val open = Regex("^(?:please\\s+)?(?:open|launch|start)\\s+(?:the\\s+)?(.+?)(?:\\s+app)?\\s*$", I).find(t)
        if (open != null) return Command.OpenApp(open.groupValues[1].trim())

        return null
    }

    private fun yearlyDefaults(kind: EventKind) = when (kind) {
        EventKind.BIRTHDAY -> listOf(-540, 900)
        EventKind.ANNIVERSARY -> listOf(-540, 900, 10620)
        EventKind.COUNTDOWN -> listOf(-540, 900, 10620)
        EventKind.EVENT -> listOf(10)
    }

    /** Applies a category's defaults (all-day, yearly repeat, reminders, title style). Used for "make it a birthday". */
    fun withKind(e: Command.Event, kind: EventKind): Command.Event {
        val base = baseTitle(e.title)
        return when (kind) {
            EventKind.EVENT -> e.copy(title = base, kind = kind, allDay = false, repeat = "", remind = listOf(10), durationMin = 60)
            EventKind.BIRTHDAY -> e.copy(title = possessive(base) + " Birthday", kind = kind, allDay = true, repeat = "YEARLY", remind = yearlyDefaults(kind))
            EventKind.ANNIVERSARY -> e.copy(title = (if (base.contains("anniversary", true)) base else "$base Anniversary"), kind = kind, allDay = true, repeat = "YEARLY", remind = yearlyDefaults(kind))
            EventKind.COUNTDOWN -> e.copy(title = "⏳ $base", kind = kind, allDay = true, repeat = "", remind = yearlyDefaults(kind))
        }
    }

    private fun possessive(name: String) = if (name.endsWith("s", true)) "$name'" else "$name's"

    /** The bare subject: "Tikki's Birthday" -> "Tikki". */
    fun baseTitle(title: String): String = title.replace("⏳", "")
        .replace(Regex("[''’]s?\\s+(birthday|anniversary)\\b", I), "")
        .replace(Regex("\\b(birthday|bday|anniversary|countdown)\\b", I), "")
        .replace(Regex("\\s+"), " ").trim().ifEmpty { title }

    private fun titleCase(s: String) = s.split(' ').joinToString(" ") { w -> if (w in setOf("and", "of", "the", "&")) w else w.replaceFirstChar { it.uppercase() } }

    private fun parseEvent(type: String, rest: String, now: LocalDateTime): Command {
        var s = rest
        s = s.replace(Regex("\\b(?:in|on|to|into|at)\\s+(?:my\\s+|the\\s+)?(?:calendar|calender|caly|cal)\\b", I), " ")
        val today = now.toLocalDate()

        // Options from the calendar form: repeat, length, all day, reminder, description.
        var repeat = ""
        Regex("\\b(?:repeat(?:s|ing)?\\s+)?(?:every\\s+(day|week|month|year)|(daily|weekly|monthly|yearly|annually))\\b", I).find(s)?.let { m ->
            val w = (m.groupValues[1].ifEmpty { m.groupValues[2] }).lowercase()
            repeat = when { w.startsWith("d") -> "DAILY"; w.startsWith("w") -> "WEEKLY"; w.startsWith("m") -> "MONTHLY"; else -> "YEARLY" }
            s = s.removeRange(m.range)
        }
        var duration = 60
        Regex("\\bfor\\s+(\\d+(?:\\.\\d+)?)\\s*(hours?|hrs?|h|minutes?|mins?)\\b", I).find(s)?.let { m ->
            val v = m.groupValues[1].toDouble()
            duration = (if (m.groupValues[2].lowercase().startsWith("h")) v * 60 else v).toInt().coerceIn(5, 24 * 60)
            s = s.removeRange(m.range)
        }
        var remind: List<Int>? = null
        Regex("\\b(?:remind(?:er)?(?:\\s+me)?\\s+)?(\\d+)\\s*(minutes?|mins?|hours?|hrs?|days?)\\s+(?:before|earlier|prior)\\b", I).find(s)?.let { m ->
            val v = m.groupValues[1].toInt()
            val u = m.groupValues[2].lowercase()
            remind = listOf(when { u.startsWith("h") -> v * 60; u.startsWith("d") -> v * 1440; else -> v })
            s = s.removeRange(m.range)
        }
        var allDay = false
        Regex("\\ball[- ]?day\\b", I).find(s)?.let { allDay = true; s = s.removeRange(it.range) }
        var description = ""
        Regex("\\b(?:with\\s+)?(?:description|notes?)\\s*[:\\-]?\\s+(.+)$", I).find(s)?.let { m ->
            description = m.groupValues[1].trim()
            s = s.removeRange(m.range)
        }

        // Category: from the verb ("add birthday ...") or from a word in the sentence ("add event birthday tikki ...").
        var kind = when {
            type.startsWith("b") -> EventKind.BIRTHDAY
            type == "anniversary" -> EventKind.ANNIVERSARY
            type == "countdown" -> EventKind.COUNTDOWN
            else -> EventKind.EVENT
        }
        var explicit = kind != EventKind.EVENT
        Regex("\\b(birthday|b'?day|anniversary|countdown)\\b", I).find(s)?.let { m ->
            val w = m.groupValues[1].lowercase()
            kind = when { w.startsWith("b") -> EventKind.BIRTHDAY; w == "anniversary" -> EventKind.ANNIVERSARY; else -> EventKind.COUNTDOWN }
            explicit = true
            s = s.removeRange(m.range)
        }

        val dateHit = findDate(s, today)
        val timeHit = if (kind == EventKind.EVENT || !allDay) findTime(s) else null
        val removals = mutableListOf<IntRange>()
        dateHit?.let { removals.add(it.second) }
        timeHit?.let { removals.add(it.range) }
        for (r in removals.sortedByDescending { it.first }) s = s.removeRange(r)

        for (i in 0..2) {
            s = s.replace(Regex("^[\\s,:;\\-]*(?:title|name|called|named|for|of|about|to|on)\\b[\\s,:;\\-]*", I), " ")
        }
        s = s.replace(Regex("[\\s,:;\\-]*\\b(?:at|on|for|by|called|named|about|of|to|in)\\s*$", I), " ")
            .replace(Regex("[,;]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        var title = when {
            kind != EventKind.EVENT -> titleCase(s.replace(Regex("[''’]s?$", I), "").trim())
            type == "event" || type == "reminder" -> s
            s.isEmpty() -> type
            else -> "$type $s"
        }
        if (kind == EventKind.EVENT) title = title.replaceFirstChar { it.uppercase() }
        if (title.isEmpty()) return Command.Incomplete(
            when (kind) {
                EventKind.BIRTHDAY -> "Whose birthday? Try: add birthday Tikki on 19 October"
                EventKind.ANNIVERSARY -> "Whose anniversary? Try: add anniversary Mom and Dad on 5 June"
                EventKind.COUNTDOWN -> "Counting down to what? Try: countdown to exams on 5 December"
                else -> "What's the event? Try: add event maths exam tomorrow 10am"
            }
        )

        var date = dateHit?.first
        val yearlyKind = kind == EventKind.BIRTHDAY || kind == EventKind.ANNIVERSARY
        if (date == null) {
            if (kind == EventKind.EVENT && timeHit != null) date = today
            else return Command.Incomplete(
                when (kind) {
                    EventKind.BIRTHDAY -> "When is $title's birthday? Try: add birthday $title on 19 October"
                    EventKind.ANNIVERSARY -> "When is the anniversary? Try: add anniversary $title on 5 June"
                    EventKind.COUNTDOWN -> "What date are we counting down to? Try: countdown to $title on 5 December"
                    else -> "When is \"$title\"? Try: add event $title tomorrow 5pm"
                }
            )
        }
        val wholeDay = allDay || kind != EventKind.EVENT
        val h = timeHit?.hour ?: 9
        val m = timeHit?.minute ?: 0
        var dt = LocalDateTime.of(date, java.time.LocalTime.of(if (wholeDay) 0 else h, if (wholeDay) 0 else m))
        if (!wholeDay && dateHit == null && dt.isBefore(now)) dt = dt.plusDays(1)
        val start = dt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

        val base = Command.Event(title, start, kind, wholeDay, repeat, duration, remind ?: listOf(10), description, explicit)
        if (kind == EventKind.EVENT) return base.copy(allDay = wholeDay, remind = remind ?: if (wholeDay) listOf(-540) else listOf(10))
        val styled = withKind(base.copy(title = title), kind)
        return styled.copy(repeat = if (repeat.isNotEmpty()) repeat else styled.repeat, remind = remind ?: styled.remind, description = description, durationMin = duration, explicit = explicit)
    }

    private fun durationSeconds(t: String): Int {
        val total = Regex("(\\d+(?:\\.\\d+)?)\\s*(hours?|hrs?|h|minutes?|mins?|m|seconds?|secs?|s)\\b", I)
            .findAll(t).sumOf { m ->
                val v = m.groupValues[1].toDouble()
                val u = m.groupValues[2].lowercase()
                when {
                    u.startsWith("h") -> v * 3600
                    u.startsWith("m") -> v * 60
                    else -> v
                }
            }
        return total.toInt()
    }

    private fun findTime(s: String): TimeHit? {
        Regex("\\b(?:at\\s+)?(\\d{1,2})(?::(\\d{2}))?\\s*([ap])\\.?m\\b\\.?", I).find(s)?.let { m ->
            var h = m.groupValues[1].toInt()
            val mi = m.groupValues[2].ifEmpty { "0" }.toInt()
            val pm = m.groupValues[3].equals("p", true)
            if (h in 1..12 && mi < 60) {
                if (h == 12) h = 0
                if (pm) h += 12
                return TimeHit(h, mi, m.range)
            }
        }
        Regex("\\b(?:at\\s+)?(\\d{1,2}):(\\d{2})\\b", I).find(s)?.let { m ->
            val h = m.groupValues[1].toInt()
            val mi = m.groupValues[2].toInt()
            if (h < 24 && mi < 60) return TimeHit(h, mi, m.range)
        }
        Regex("\\bat\\s+(\\d{1,2})\\b", I).find(s)?.let { m ->
            var h = m.groupValues[1].toInt()
            if (h in 1..6) h += 12 // "at 5" almost always means 5 pm
            if (h < 24) return TimeHit(h, 0, m.range)
        }
        return null
    }

    private const val MONTHS = "jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|june?|july?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?"
    private val MONTH_KEYS = listOf("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec")

    /** day/month (and optional year) -> the next such date; a past date without a year means next year. */
    private fun resolve(day: Int, month: Int, year: Int?, today: LocalDate): LocalDate? = try {
        if (year != null) LocalDate.of(if (year < 100) 2000 + year else year, month, day)
        else {
            val d = LocalDate.of(today.year, month, day)
            if (d.isBefore(today)) d.plusYears(1) else d
        }
    } catch (e: Exception) {
        null
    }

    private fun findDate(s: String, today: LocalDate): Pair<LocalDate, IntRange>? {
        Regex("\\b(\\d{1,2})\\s*(?:st|nd|rd|th)?\\s*(?:of\\s+)?($MONTHS)\\b\\.?(?:[,\\s]+(\\d{4}))?", I).find(s)?.let { m ->
            val mo = MONTH_KEYS.indexOf(m.groupValues[2].lowercase().take(3)) + 1
            resolve(m.groupValues[1].toInt(), mo, m.groupValues[3].toIntOrNull(), today)?.let { return it to m.range }
        }
        Regex("\\b($MONTHS)\\b\\.?\\s+(\\d{1,2})\\s*(?:st|nd|rd|th)?\\b(?:[,\\s]+(\\d{4}))?", I).find(s)?.let { m ->
            val mo = MONTH_KEYS.indexOf(m.groupValues[1].lowercase().take(3)) + 1
            resolve(m.groupValues[2].toInt(), mo, m.groupValues[3].toIntOrNull(), today)?.let { return it to m.range }
        }
        Regex("\\b(\\d{1,2})[/.-](\\d{1,2})(?:[/.-](\\d{2,4}))?\\b").find(s)?.let { m ->
            resolve(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toIntOrNull(), today)?.let { return it to m.range }
        }
        Regex("\\bin\\s+(\\d{1,3})\\s*(days?|weeks?)\\b", I).find(s)?.let { m ->
            val n = m.groupValues[1].toLong() * (if (m.groupValues[2].lowercase().startsWith("w")) 7 else 1)
            return today.plusDays(n) to m.range
        }
        Regex("\\bday after tomorrow\\b", I).find(s)?.let { return today.plusDays(2) to it.range }
        Regex("\\btomorrow\\b", I).find(s)?.let { return today.plusDays(1) to it.range }
        Regex("\\btoday\\b", I).find(s)?.let { return today to it.range }
        Regex("\\b(?:next\\s+|on\\s+)?(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\\b", I).find(s)?.let {
            val dow = DayOfWeek.valueOf(it.groupValues[1].uppercase())
            return today.with(TemporalAdjusters.next(dow)) to it.range
        }
        return null
    }
}
