package com.ghostie.pet

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters

sealed class Command {
    object Organize : Command()
    object Help : Command()
    data class Event(val title: String, val startMillis: Long) : Command()
    data class Timer(val seconds: Int) : Command()
    data class Alarm(val hour: Int, val minute: Int, val label: String = "") : Command()
    data class Call(val target: String) : Command()
    data class OpenApp(val name: String) : Command()
    data class ShowDocs(val subject: String) : Command()
    data class Watch(val group: String) : Command()
    /** Recognised verb but something is missing; message tells the user what. */
    data class Incomplete(val message: String) : Command()
}

/** Turns chat text into a Command. Pure Kotlin so it can be tested without a phone. */
object Commands {
    const val HELP = "I can do these 💜\n" +
        "• organize documents – sorts your WhatsApp files by subject\n" +
        "• show documents of computer science\n" +
        "• add event maths exam tomorrow 10am\n" +
        "• watch group CSE 3A – I'll remind you the day before any submission or event registration deadline posted there\n" +
        "• Share a group's exported chat (or one message) from WhatsApp to Ghostie to catch up on deadlines\n" +
        "• call Mom  /  call 9876543210\n" +
        "• timer 10 minutes\n" +
        "• alarm 6:30 am\n" +
        "• open WhatsApp"

    private val I = RegexOption.IGNORE_CASE
    private data class TimeHit(val hour: Int, val minute: Int, val range: IntRange)

    fun parse(raw: String, now: LocalDateTime = LocalDateTime.now()): Command? {
        val t = raw.trim()
        if (t.isEmpty()) return null

        if (Regex("^(help|commands|what can you do\\??|what do you do\\??)$", I).matches(t)) return Command.Help

        if (Regex("\\b(organi[sz]e|sort|arrange|clean ?up|group)\\b.*\\b(docs?|documents?|files?|pdfs?|notes)\\b", I).containsMatchIn(t)) {
            return Command.Organize
        }

        val call = Regex("^(?:please\\s+)?(?:call|dial|phone|ring)\\s+(?:up\\s+)?(.+?)(?:\\s+(?:please|now))?$", I).find(t)
        if (call != null) {
            val who = call.groupValues[1].trim()
            if (Regex("^(?:me|it|us|them|back later|a day)\\b", I).containsMatchIn(who)) return null // "call me Anay", "call it a day"
            return if (who.isNotEmpty()) Command.Call(who) else Command.Incomplete("Who should I call? Try: call Mom")
        }

        val watch = Regex("^(?:please\\s+)?(?:watch|monitor|track)\\s+(?:(?:the\\s+)?group\\s+(.+)|(.+?)\\s+group)$", I).find(t)
        if (watch != null) {
            val name = (watch.groupValues[1].ifEmpty { watch.groupValues[2] }).trim().trim('"', '\'')
            return if (name.isNotEmpty()) Command.Watch(name) else Command.Incomplete("Which group? Try: watch group CSE 3A")
        }

        val show = Regex(
            "\\b(?:give|show|list|find|get|send|see|display)\\b.*?\\b(?:docs?|documents?|files?|notes|pdfs?)\\b\\s*(?:belonging to|related to|of|for|in|from|on|about|under)?\\s*(.*)$", I
        ).find(t)
        if (show != null) {
            val subject = show.groupValues[1].replace(Regex("^(?:the|my)\\s+", I), "").trim()
            return if (subject.isNotEmpty()) Command.ShowDocs(subject)
            else Command.Incomplete("Which subject? Try: show documents of computer science")
        }

        if (Regex("\\btimer\\b|\\bcountdown\\b", I).containsMatchIn(t)) {
            val secs = durationSeconds(t)
            return if (secs > 0) Command.Timer(secs) else Command.Incomplete("For how long? Try: timer 10 minutes")
        }

        if (Regex("\\balarm\\b", I).containsMatchIn(t)) {
            val hit = findTime(t)
            val label = Regex("\\b(?:with\\s+)?(?:title|label|name|called|named)\\s+(.+?)(?=\\s+(?:at|for|in|on|tomorrow|today)\\b|$)", I).find(t)?.groupValues?.get(1)?.trim().orEmpty()
            return if (hit != null) Command.Alarm(hit.hour, hit.minute, label) else Command.Incomplete("What time? Try: alarm 6:30 am")
        }

        val ev = Regex(
            "^(?:please\\s+)?(?:add|create|set|make|schedule|new|put)\\s+(?:an?\\s+|the\\s+)?(?:new\\s+)?(event|reminder|meeting|class|exam|appointment)\\b(.*)$",
            I
        ).find(t)
        if (ev != null) return parseEvent(ev.groupValues[1].lowercase(), ev.groupValues[2], now)

        val open = Regex("^(?:please\\s+)?(?:open|launch|start)\\s+(?:the\\s+)?(.+?)(?:\\s+app)?\\s*$", I).find(t)
        if (open != null) return Command.OpenApp(open.groupValues[1].trim())

        return null
    }

    private fun parseEvent(type: String, rest: String, now: LocalDateTime): Command {
        var s = rest
        s = s.replace(Regex("\\b(?:in|on|to|into|at)\\s+(?:my\\s+|the\\s+)?(?:calendar|calender|caly|cal)\\b", I), " ")

        val removals = mutableListOf<IntRange>()
        val today = now.toLocalDate()
        val dateHit = findDate(s, today)
        val timeHit = findTime(s)
        dateHit?.let { removals.add(it.second) }
        timeHit?.let { removals.add(it.range) }
        for (r in removals.sortedByDescending { it.first }) s = s.removeRange(r)

        s = s.replace(Regex("\\b(?:at|on|for|by|called|named|about)\\s*$", I), " ")
            .replace(Regex("^\\s*(?:called|named|for|about|:|-)\\s+", I), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        val title = when {
            type == "event" || type == "reminder" -> s
            s.isEmpty() -> type
            else -> "$type $s"
        }.replaceFirstChar { it.uppercase() }

        var start: Long? = null
        if (dateHit != null || timeHit != null) {
            var date = dateHit?.first ?: today
            val h = timeHit?.hour ?: 9
            val m = timeHit?.minute ?: 0
            var dt = LocalDateTime.of(date, java.time.LocalTime.of(h, m))
            if (dateHit == null && dt.isBefore(now)) dt = dt.plusDays(1)
            start = dt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        }
        if (title.isEmpty()) return Command.Incomplete("What's the event? Try: add event maths exam tomorrow 10am")
        if (start == null) return Command.Incomplete("When is \"$title\"? Try: add event $title tomorrow 5pm")
        return Command.Event(title, start)
    }

    private fun durationSeconds(t: String): Int {
        val total = Regex("(\\d+(?:\\.\\d+)?)\\s*(hours?|hrs?|h|minutes?|mins?|m|seconds?|secs?|s)\\b", I)
            .findAll(t).sumOf { m ->
                val v = m.groupValues[1].toDouble()
                val u = m.groupValues[2].lowercase()
                when {
                    u.startsWith("h") -> v * 3600
                    u.startsWith("m") -> v * 60
                    else -> v
                }
            }
        return total.toInt()
    }

    private fun findTime(s: String): TimeHit? {
        Regex("\\b(?:at\\s+)?(\\d{1,2})(?::(\\d{2}))?\\s*([ap])\\.?m\\b\\.?", I).find(s)?.let { m ->
            var h = m.groupValues[1].toInt()
            val mi = m.groupValues[2].ifEmpty { "0" }.toInt()
            val pm = m.groupValues[3].equals("p", true)
            if (h in 1..12 && mi < 60) {
                if (h == 12) h = 0
                if (pm) h += 12
                return TimeHit(h, mi, m.range)
            }
        }
        Regex("\\b(?:at\\s+)?(\\d{1,2}):(\\d{2})\\b", I).find(s)?.let { m ->
            val h = m.groupValues[1].toInt()
            val mi = m.groupValues[2].toInt()
            if (h < 24 && mi < 60) return TimeHit(h, mi, m.range)
        }
        Regex("\\bat\\s+(\\d{1,2})\\b", I).find(s)?.let { m ->
            var h = m.groupValues[1].toInt()
            if (h in 1..6) h += 12 // "at 5" almost always means 5 pm
            if (h < 24) return TimeHit(h, 0, m.range)
        }
        return null
    }

    private fun findDate(s: String, today: LocalDate): Pair<LocalDate, IntRange>? {
        Regex("\\bday after tomorrow\\b", I).find(s)?.let { return today.plusDays(2) to it.range }
        Regex("\\btomorrow\\b", I).find(s)?.let { return today.plusDays(1) to it.range }
        Regex("\\btoday\\b", I).find(s)?.let { return today to it.range }
        Regex("\\b(?:next\\s+|on\\s+)?(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\\b", I).find(s)?.let {
            val dow = DayOfWeek.valueOf(it.groupValues[1].uppercase())
            return today.with(TemporalAdjusters.next(dow)) to it.range
        }
        return null
    }
}
