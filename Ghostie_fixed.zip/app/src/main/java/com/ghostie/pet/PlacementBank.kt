package com.ghostie.pet

import android.content.Context
import java.time.LocalDate
import kotlin.random.Random

/**
 * Placement practice: a built-in bank of aptitude, reasoning, verbal, programming and core-CS questions, plus the student's own.
 * Pure Kotlin (JVM tested) except [PlacementStore].
 */
object PlacementBank {
    /** [options] empty = an open question (HR); [answer] is then the model approach. */
    data class Q(val cat: String, val text: String, val options: List<String>, val answer: String, val why: String, val own: Boolean = false)

    val categories = listOf("Quantitative", "Logical reasoning", "Verbal", "C programming", "Data structures", "Operating systems", "DBMS & SQL", "Networks", "HR & interview")

    private fun q(cat: String, text: String, options: String, answer: String, why: String = "") = Q(cat, text, options.split("|"), answer, why)
    private fun hr(text: String, tip: String) = Q("HR & interview", text, emptyList(), tip, "")

    val builtIn: List<Q> = listOf(
        // ---- Quantitative ----
        q("Quantitative", "A train 120 m long crosses a pole in 6 seconds. Its speed in km/h is", "60|72|80|90", "72", "120/6 = 20 m/s; 20 x 18/5 = 72 km/h."),
        q("Quantitative", "20% of 250 is", "40|45|50|60", "50"),
        q("Quantitative", "An article bought for Rs 400 is sold for Rs 500. Profit percentage is", "20%|25%|30%|15%", "25%", "Profit 100 on cost 400 = 25%."),
        q("Quantitative", "A can finish a job in 10 days and B in 15 days. Working together they take", "5 days|6 days|7.5 days|8 days", "6 days", "1/10 + 1/15 = 1/6 per day."),
        q("Quantitative", "The average of 5 numbers is 20. Their sum is", "80|90|100|120", "100"),
        q("Quantitative", "Simple interest on Rs 2000 at 5% per year for 3 years is", "Rs 250|Rs 300|Rs 350|Rs 400", "Rs 300", "2000 x 5 x 3 / 100 = 300."),
        q("Quantitative", "Two numbers are in the ratio 3:5 and their sum is 160. The larger number is", "60|80|100|120", "100", "160 x 5/8 = 100."),
        q("Quantitative", "If 15% of a number is 45, the number is", "200|250|300|350", "300", "45 / 0.15 = 300."),
        q("Quantitative", "The LCM of 12 and 18 is", "6|36|72|216", "36"),
        q("Quantitative", "The HCF of 24 and 36 is", "6|8|12|24", "12"),
        q("Quantitative", "A car moves at 60 km/h. Time to cover 150 km is", "2 h|2.5 h|3 h|3.5 h", "2.5 h"),
        q("Quantitative", "A number is increased by 20% and then decreased by 20%. The net change is", "No change|4% decrease|4% increase|2% decrease", "4% decrease", "1.2 x 0.8 = 0.96."),
        q("Quantitative", "Probability of getting two heads in two tosses of a fair coin is", "1/2|1/3|1/4|1/8", "1/4"),
        q("Quantitative", "Probability that the sum is 7 when two dice are rolled is", "1/12|1/6|1/9|5/36", "1/6", "6 favourable outcomes out of 36."),
        q("Quantitative", "Compound interest on Rs 1000 at 10% per year for 2 years is", "Rs 200|Rs 210|Rs 220|Rs 121", "Rs 210", "1000 x 1.1 x 1.1 = 1210, so interest 210."),
        q("Quantitative", "One pipe fills a tank in 12 hours, another empties it in 18 hours. Both open, the tank fills in", "30 h|36 h|24 h|48 h", "36 h", "1/12 - 1/18 = 1/36."),
        q("Quantitative", "Two numbers are in the ratio 2:3 and their LCM is 48. Their sum is", "30|40|45|50", "40", "Numbers 16 and 24."),
        q("Quantitative", "The number of ways to arrange the letters of the word CAT is", "3|6|9|12", "6"),
        q("Quantitative", "5! equals", "24|60|120|720", "120"),
        q("Quantitative", "6C2 equals", "12|15|30|36", "15"),
        q("Quantitative", "A shopkeeper marks goods 25% above cost and gives a 20% discount. His profit is", "5%|0%|10%|20%", "0%", "1.25 x 0.8 = 1.00."),
        q("Quantitative", "Two trains of length 100 m and 150 m run in opposite directions at 30 m/s and 20 m/s. They cross each other in", "4 s|5 s|6 s|10 s", "5 s", "250 m at relative speed 50 m/s."),
        q("Quantitative", "A father is three times as old as his son. The sum of their ages is 48. The son's age is", "10|12|14|16", "12"),
        q("Quantitative", "Next number: 2, 6, 12, 20, ?", "28|30|32|36", "30", "Differences 4, 6, 8, 10."),
        q("Quantitative", "Next number: 1, 4, 9, 16, ?", "20|24|25|36", "25"),
        q("Quantitative", "45 marks out of 60 is", "65%|70%|75%|80%", "75%"),
        q("Quantitative", "Average speed for a trip with equal distances at 40 km/h and 60 km/h is", "50 km/h|48 km/h|52 km/h|45 km/h", "48 km/h", "2 x 40 x 60 / 100 = 48."),
        q("Quantitative", "Area of a circle of radius 7 (take pi = 22/7) is", "44|154|308|49", "154"),
        q("Quantitative", "The angle between the clock hands at 3:00 is", "60 degrees|75 degrees|90 degrees|120 degrees", "90 degrees"),
        q("Quantitative", "If today is Monday, the day after 100 days is", "Tuesday|Wednesday|Thursday|Friday", "Wednesday", "100 mod 7 = 2."),
        q("Quantitative", "A boat goes at 10 km/h in still water and the stream flows at 2 km/h. Downstream speed is", "8 km/h|10 km/h|12 km/h|14 km/h", "12 km/h"),
        q("Quantitative", "6 men finish a job in 12 days. 9 men would take", "6 days|8 days|9 days|10 days", "8 days", "Man-days 72 / 9 = 8."),
        q("Quantitative", "Price Rs 800 with a 15% discount becomes", "Rs 640|Rs 660|Rs 680|Rs 700", "Rs 680"),
        // ---- Logical reasoning ----
        q("Logical reasoning", "Odd one out: Apple, Banana, Carrot, Mango", "Apple|Banana|Carrot|Mango", "Carrot", "The others are fruits."),
        q("Logical reasoning", "If A=1, B=2, C=3..., the value of CAB is", "5|6|7|8", "6"),
        q("Logical reasoning", "A is B's sister and B is C's father. A is C's", "Mother|Aunt|Grandmother|Cousin", "Aunt"),
        q("Logical reasoning", "A walks 5 km north, then 5 km east, then 5 km south. Distance from the start is", "0 km|5 km|10 km|15 km", "5 km"),
        q("Logical reasoning", "All cats are animals. All animals are living things. So", "All living things are cats|All cats are living things|Some animals are not living|None follows", "All cats are living things"),
        q("Logical reasoning", "Next letter: Z, X, V, T, ?", "S|R|Q|P", "R"),
        q("Logical reasoning", "Book : Reading :: Fork : ?", "Eating|Cooking|Spoon|Plate", "Eating"),
        q("Logical reasoning", "In a class of 40, Ravi is 15th from the top. His rank from the bottom is", "24th|25th|26th|27th", "26th", "40 - 15 + 1 = 26."),
        q("Logical reasoning", "Next number: 3, 6, 11, 18, 27, ?", "36|38|40|42", "38", "Differences 3, 5, 7, 9, 11."),
        q("Logical reasoning", "Next number: 1, 1, 2, 3, 5, 8, ?", "11|12|13|15", "13"),
        q("Logical reasoning", "Pointing to a photo, Ravi says, \"He is the son of my father's only son.\" The man in the photo is Ravi's", "Brother|Son|Nephew|Father", "Son", "Father's only son is Ravi himself."),
        q("Logical reasoning", "The day before yesterday was Thursday. Today is", "Friday|Saturday|Sunday|Monday", "Saturday"),
        q("Logical reasoning", "Odd number out: 2, 3, 5, 9, 11", "2|5|9|11", "9", "The others are prime."),
        q("Logical reasoning", "All roses are flowers. Some flowers fade. Conclusion: some roses fade.", "Definitely true|Definitely false|Cannot be determined|Partly true", "Cannot be determined"),
        q("Logical reasoning", "Next number: 7, 14, 28, 56, ?", "84|98|112|120", "112"),
        q("Logical reasoning", "Odd one out: Circle, Triangle, Square, Cube", "Circle|Triangle|Square|Cube", "Cube", "Cube is 3D."),
        // ---- Verbal ----
        q("Verbal", "Synonym of ABUNDANT", "Scarce|Plentiful|Tiny|Hidden", "Plentiful"),
        q("Verbal", "Antonym of BRAVE", "Bold|Cowardly|Strong|Fearless", "Cowardly"),
        q("Verbal", "Choose the correct sentence", "He don't like tea|He doesn't like tea|He not like tea|He didn't liked tea", "He doesn't like tea"),
        q("Verbal", "Neither of the boys ___ present.", "were|was|are|have", "was"),
        q("Verbal", "The idiom \"break the ice\" means", "Break something cold|Start a conversation|End a fight|Feel cold", "Start a conversation"),
        q("Verbal", "Correct spelling", "Accomodate|Acommodate|Accommodate|Acomodate", "Accommodate"),
        q("Verbal", "She is good ___ maths.", "in|at|on|with", "at"),
        q("Verbal", "Plural of ANALYSIS", "Analysises|Analyses|Analysis|Analysees", "Analyses"),
        // ---- C programming ----
        q("C programming", "What does printf(\"%d\", 5/2); print?", "2.5|2|3|0", "2", "Integer division."),
        q("C programming", "Which of these is NOT a C keyword?", "int|float|main|return", "main", "main is a function name, not a keyword."),
        q("C programming", "int x = 10; printf(\"%d\", x++); prints", "10|11|9|Error", "10", "Post-increment uses the old value."),
        q("C programming", "int x = 10; printf(\"%d\", ++x); prints", "10|11|12|Error", "11"),
        q("C programming", "Array indexing in C starts at", "0|1|-1|Depends on the compiler", "0"),
        q("C programming", "The format specifier for a float is", "%d|%f|%c|%s", "%f"),
        q("C programming", "strlen(\"abc\") returns", "2|3|4|Error", "3", "The terminating '\\0' is not counted."),
        q("C programming", "The address-of operator is", "*|&|#|@", "&"),
        q("C programming", "The dereference operator is", "&|*|->|::", "*"),
        q("C programming", "7 % 3 equals", "1|2|0|3", "1"),
        q("C programming", "1 << 3 equals", "3|6|8|16", "8"),
        q("C programming", "Which loop always runs at least once?", "for|while|do-while|None", "do-while"),
        q("C programming", "Accessing a[5] when int a[5] is declared is", "Fine|Undefined behaviour|A compile error always|Returns 0", "Undefined behaviour", "Valid indexes are 0 to 4."),
        q("C programming", "malloc returns a", "int*|char*|void*|float*", "void*"),
        q("C programming", "printf is declared in", "stdlib.h|stdio.h|string.h|math.h", "stdio.h"),
        q("C programming", "The value of (10 > 5 && 3 < 2) is", "1|0|Error|10", "0"),
        q("C programming", "An uninitialised local (auto) variable contains", "0|Garbage value|NULL|1", "Garbage value"),
        q("C programming", "A static local variable", "Is re-created on every call|Keeps its value between calls|Cannot be changed|Is global", "Keeps its value between calls"),
        q("C programming", "int a = 5, b = 2; float c = a / b; printf(\"%.1f\", c); prints", "2.5|2.0|3.0|2", "2.0", "a / b is integer division first."),
        // ---- Data structures ----
        q("Data structures", "A stack follows", "FIFO|LIFO|Random order|Priority order", "LIFO"),
        q("Data structures", "A queue follows", "FIFO|LIFO|Random order|Sorted order", "FIFO"),
        q("Data structures", "Binary search time complexity (sorted array) is", "O(n)|O(log n)|O(n log n)|O(1)", "O(log n)"),
        q("Data structures", "Worst-case time of quick sort is", "O(n log n)|O(n)|O(n^2)|O(log n)", "O(n^2)"),
        q("Data structures", "Merge sort time complexity is", "O(n)|O(n log n)|O(n^2)|O(log n)", "O(n log n)"),
        q("Data structures", "BFS uses a ___ and DFS uses a ___", "stack, queue|queue, stack|queue, queue|stack, stack", "queue, stack"),
        q("Data structures", "In-order traversal of a binary search tree gives", "Random order|Sorted order|Reverse order|Level order", "Sorted order"),
        q("Data structures", "Inserting at the head of a singly linked list takes", "O(1)|O(n)|O(log n)|O(n^2)", "O(1)"),
        q("Data structures", "Average lookup time in a hash table is", "O(1)|O(n)|O(log n)|O(n^2)", "O(1)"),
        q("Data structures", "A tree with n nodes has how many edges?", "n|n-1|n+1|2n", "n-1"),
        q("Data structures", "Maximum nodes in a binary tree of height h (root at height 0) is", "2^h|2^(h+1) - 1|2h + 1|h^2", "2^(h+1) - 1"),
        q("Data structures", "Postfix form of A + B * C is", "ABC*+|AB+C*|+A*BC|ABC+*", "ABC*+"),
        q("Data structures", "In a min-heap the smallest element is at the", "Last leaf|Root|Any leaf|Middle", "Root"),
        q("Data structures", "Which structure suits an undo feature?", "Queue|Stack|Array of arrays|Tree", "Stack"),
        // ---- Operating systems ----
        q("Operating systems", "Which is NOT a necessary condition for deadlock?", "Mutual exclusion|Hold and wait|Preemption|Circular wait", "Preemption", "The condition is NO preemption."),
        q("Operating systems", "Round Robin scheduling uses a", "Priority|Time quantum|Shortest job|Deadline", "Time quantum"),
        q("Operating systems", "Which page replacement algorithm can show Belady's anomaly?", "LRU|Optimal|FIFO|None", "FIFO"),
        q("Operating systems", "Thrashing means", "Too many CPUs|Excessive paging|A deadlock|Disk failure", "Excessive paging"),
        q("Operating systems", "Which scheduling gives the minimum average waiting time?", "FCFS|Round Robin|Shortest Job First|Priority", "Shortest Job First", "SJF is optimal when all jobs are known."),
        q("Operating systems", "Virtual memory lets a program", "Run faster always|Be larger than physical memory|Skip the OS|Avoid paging", "Be larger than physical memory"),
        q("Operating systems", "A semaphore is mainly used for", "Compilation|Synchronisation|Printing|Storage", "Synchronisation"),
        // ---- DBMS & SQL ----
        q("DBMS & SQL", "Which command removes the table structure as well as the data?", "DELETE|TRUNCATE|DROP|REMOVE", "DROP"),
        q("DBMS & SQL", "A primary key can contain NULL values.", "True|False|Only in MySQL|Only for numbers", "False"),
        q("DBMS & SQL", "Which normal form removes partial dependency?", "1NF|2NF|3NF|BCNF", "2NF"),
        q("DBMS & SQL", "In ACID, the A stands for", "Atomicity|Availability|Accuracy|Alignment", "Atomicity"),
        q("DBMS & SQL", "Which clause filters groups after GROUP BY?", "WHERE|HAVING|ORDER BY|LIMIT", "HAVING"),
        q("DBMS & SQL", "Which join returns only matching rows from both tables?", "LEFT JOIN|INNER JOIN|FULL JOIN|CROSS JOIN", "INNER JOIN"),
        q("DBMS & SQL", "A foreign key", "Uniquely identifies a row|References a key in another table|Is always numeric|Cannot be NULL", "References a key in another table"),
        q("DBMS & SQL", "Which function counts rows?", "SUM()|COUNT()|AVG()|MAX()", "COUNT()"),
        // ---- Networks ----
        q("Networks", "The OSI model has how many layers?", "4|5|7|8", "7"),
        q("Networks", "The default port of HTTPS is", "80|21|443|8080", "443"),
        q("Networks", "An IPv4 address has how many bits?", "16|32|64|128", "32"),
        q("Networks", "Which protocol gives reliable delivery?", "UDP|TCP|ICMP|ARP", "TCP"),
        q("Networks", "DNS translates", "IP to MAC|Domain names to IP addresses|Ports to protocols|Bits to bytes", "Domain names to IP addresses"),
        q("Networks", "A router works at the ___ layer", "Physical|Data link|Network|Application", "Network"),
        // ---- HR & interview (open questions: the answer is the approach) ----
        hr("Tell me about yourself.", "Keep it to about a minute: who you are (course, college), one or two strengths shown by a project or achievement, and why this role interests you. Not your life story."),
        hr("What are your strengths and weaknesses?", "Pick strengths that fit the job and back each with an example. For a weakness, name a real one that is not critical and say what you are doing to improve it."),
        hr("Why should we hire you?", "Match your skills and projects to what the job needs, show you learn fast, and end with what you will bring in the first months."),
        hr("Where do you see yourself in five years?", "Say you want to grow in skills and responsibility in this field and with a company like theirs. Avoid naming a specific other job."),
        hr("Describe a challenge you faced and how you handled it.", "Use STAR: Situation, Task, Action (what you did), Result (what changed). A project or team problem works well."),
        hr("Why do you want to join our company?", "Say something you actually looked up: their products, work culture or projects, and how it fits what you want to learn."),
        hr("Do you have any questions for us?", "Always ask one or two: what the first project would be, how new joiners are trained, or what success looks like in the first year."),
        hr("Explain your final-year or best project.", "Say the problem, what you built and your own part, the tools used, one hard bug or decision, and the result. Be ready to be asked about any line of it.")
    )

    fun all(own: List<Q>): List<Q> = builtIn + own

    /** Picks up to [n] questions, optionally from one category, in a random order. HR questions are left out of quick quizzes unless chosen. */
    fun pick(own: List<Q>, n: Int, cat: String?, rnd: Random = Random.Default): List<Q> {
        val pool = all(own).filter { if (cat == null) it.cat != "HR & interview" else it.cat == cat }
        return pool.shuffled(rnd).take(n)
    }

    /** The question for a given day (the same all day), for the daily notification. */
    fun ofTheDay(own: List<Q>, day: LocalDate): Q {
        val pool = all(own).filter { it.options.isNotEmpty() }
        return pool[Math.floorMod(day.toEpochDay().toInt() * 31 + 7, pool.size)]
    }

    /** Options in a shuffled order for showing (the answer text is what gets compared). */
    fun shuffledOptions(q: Q, rnd: Random = Random.Default): List<String> = q.options.shuffled(rnd)

    // ---- own questions: "cat\tquestion\topt1|opt2|opt3|opt4\tanswer" ----
    fun serializeOwn(list: List<Q>): String = list.joinToString("\n") { listOf(it.cat, it.text, it.options.joinToString("|"), it.answer).joinToString("\t") { s -> s.replace(Regex("[\\t\\r\\n]+"), " ") } }
    fun parseOwn(text: String): List<Q> = text.lines().mapNotNull {
        val p = it.split('\t')
        if (p.size < 4 || p[1].isBlank()) null else Q(p[0].ifBlank { "My questions" }, p[1], p[2].split("|").filter { o -> o.isNotBlank() }, p[3], "", true)
    }

    // ---- results: "cat\tright\ttotal" ----
    fun parseStats(text: String): Map<String, IntArray> = text.lines().mapNotNull {
        val p = it.split('\t'); if (p.size == 3) p[0] to intArrayOf(p[1].toIntOrNull() ?: 0, p[2].toIntOrNull() ?: 0) else null
    }.toMap()
    fun serializeStats(m: Map<String, IntArray>): String = m.entries.joinToString("\n") { "${it.key}\t${it.value[0]}\t${it.value[1]}" }
    fun record(m: MutableMap<String, IntArray>, cat: String, right: Boolean) { val a = m.getOrPut(cat) { intArrayOf(0, 0) }; a[1]++; if (right) a[0]++ }
    fun statsText(m: Map<String, IntArray>): String {
        val rows = m.filter { it.value[1] > 0 }
        if (rows.isEmpty()) return "No practice yet. Try 5 questions."
        val total = rows.values.sumOf { it[1] }; val right = rows.values.sumOf { it[0] }
        return "Overall $right/$total (${right * 100 / total}%)\n" + rows.entries.sortedBy { it.value[0] * 1.0 / it.value[1] }.joinToString("\n") { "${it.key}: ${it.value[0]}/${it.value[1]} (${it.value[0] * 100 / it.value[1]}%)" } + "\nWeakest first."
    }
}

object PlacementStore {
    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences("ghostie_placement", Context.MODE_PRIVATE)
    fun own(ctx: Context) = PlacementBank.parseOwn(p(ctx).getString("own", "") ?: "")
    fun addOwn(ctx: Context, q: PlacementBank.Q) { p(ctx).edit().putString("own", PlacementBank.serializeOwn(own(ctx) + q)).apply() }
    fun clearOwn(ctx: Context) { p(ctx).edit().remove("own").apply() }
    fun stats(ctx: Context) = PlacementBank.parseStats(p(ctx).getString("stats", "") ?: "").toMutableMap()
    fun record(ctx: Context, cat: String, right: Boolean) { val m = stats(ctx); PlacementBank.record(m, cat, right); p(ctx).edit().putString("stats", PlacementBank.serializeStats(m)).apply() }
    fun resetStats(ctx: Context) { p(ctx).edit().remove("stats").apply() }
}
