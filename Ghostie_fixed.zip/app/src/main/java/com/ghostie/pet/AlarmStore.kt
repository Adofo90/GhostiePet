package com.ghostie.pet

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Ghostie's own alarms. Asking for a time that already has an alarm switches that one on instead of adding
 * another. [days] is a bit mask (bit0 = Monday ... bit6 = Sunday); 0 means "once, the next time that clock time comes".
 * The phone's Clock app can't be read or switched on by other apps, so these are separate from it.
 */
object AlarmStore {
    const val RING = "com.ghostie.pet.ALARM_RING"
    const val ALL_DAYS = 127
    const val WEEKDAYS = 31
    const val WEEKEND = 96

    data class Alarm(val id: Long, val hour: Int, val minute: Int, val days: Int, val label: String, val enabled: Boolean)
    data class Added(val alarm: Alarm, val existed: Boolean, val wasOn: Boolean, val list: List<Alarm>)

    // ---- pure logic (tested on the JVM) ----

    fun timeText(a: Alarm) = "%02d:%02d".format(a.hour, a.minute)

    fun daysText(days: Int): String = when {
        days == 0 -> "once"
        days == ALL_DAYS -> "every day"
        days == WEEKDAYS -> "weekdays"
        days == WEEKEND -> "weekends"
        else -> listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun").filterIndexed { i, _ -> days and (1 shl i) != 0 }.joinToString(" ")
    }

    /** The next moment this alarm should ring, after [now]. */
    fun next(a: Alarm, now: LocalDateTime): LocalDateTime {
        for (add in 0..7) {
            val d = now.toLocalDate().plusDays(add.toLong())
            val t = d.atTime(a.hour, a.minute)
            if (!t.isAfter(now)) continue
            if (a.days == 0 || a.days and (1 shl (d.dayOfWeek.value - 1)) != 0) return t
        }
        return now.plusDays(1)
    }

    /**
     * For a time said without am/pm ("alarm 3:30"): if the morning reading has already passed today but the
     * afternoon one is still ahead, and it is within 8 hours, use the afternoon one so it rings today.
     */
    fun guessHour(hour: Int, minute: Int, ambiguous: Boolean, now: LocalDateTime): Int {
        if (!ambiguous || hour !in 1..12) return hour
        val am = if (hour == 12) 0 else hour
        val pm = am + 12
        val today = now.toLocalDate()
        val amAt = today.atTime(am, minute)
        val pmAt = today.atTime(pm, minute)
        if (amAt.isAfter(now)) return am
        if (pmAt.isAfter(now) && java.time.Duration.between(now, pmAt).toHours() < 8) return pm
        return am
    }

    /** "03:30 (3:30 am)" - the 24-hour text plus the 12-hour reading, so a wrong am/pm is easy to spot. */
    fun timeTextFull(a: Alarm): String {
        val h12 = if (a.hour % 12 == 0) 12 else a.hour % 12
        return "${timeText(a)} ($h12:%02d ${if (a.hour < 12) "am" else "pm"})".format(a.minute)
    }

    /**
     * Adds an alarm, or turns on the existing one at that time. With [days] = 0 ("alarm 6:30") any alarm at that time
     * matches; with specific days only one with the same days does. A newly given label is kept.
     */
    fun addOrEnable(list: List<Alarm>, hour: Int, minute: Int, days: Int, label: String, newId: Long): Added {
        val hit = list.firstOrNull { it.hour == hour && it.minute == minute && (days == 0 || it.days == days) }
        if (hit != null) {
            val upd = hit.copy(enabled = true, label = if (label.isNotBlank()) label else hit.label)
            return Added(upd, true, hit.enabled, list.map { if (it.id == hit.id) upd else it })
        }
        val a = Alarm(newId, hour, minute, days, label, true)
        return Added(a, false, false, (list + a).sortedWith(compareBy({ it.hour }, { it.minute })))
    }

    fun toJson(list: List<Alarm>): String {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("h", it.hour).put("m", it.minute).put("d", it.days).put("l", it.label).put("e", it.enabled))
        }
        return arr.toString()
    }

    fun fromJson(s: String): List<Alarm> = try {
        val arr = JSONArray(s)
        (0 until arr.length()).map { val o = arr.getJSONObject(it); Alarm(o.getLong("id"), o.getInt("h"), o.getInt("m"), o.getInt("d"), o.optString("l"), o.optBoolean("e", true)) }
    } catch (e: Exception) { emptyList() }

    // ---- storage + scheduling ----

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("ghostie", Context.MODE_PRIVATE)

    fun all(ctx: Context): List<Alarm> = fromJson(prefs(ctx).getString("alarms_json", "[]") ?: "[]")

    private fun save(ctx: Context, list: List<Alarm>) { prefs(ctx).edit().putString("alarms_json", toJson(list)).apply() }

    fun add(ctx: Context, hour: Int, minute: Int, days: Int, label: String): Added {
        val r = addOrEnable(all(ctx), hour, minute, days, label, System.currentTimeMillis())
        save(ctx, r.list); schedule(ctx, r.alarm)
        return r
    }

    fun setEnabled(ctx: Context, id: Long, on: Boolean) {
        val l = all(ctx).map { if (it.id == id) it.copy(enabled = on) else it }
        save(ctx, l); l.firstOrNull { it.id == id }?.let { schedule(ctx, it) }
    }

    fun delete(ctx: Context, id: Long) {
        cancel(ctx, id); save(ctx, all(ctx).filter { it.id != id })
    }

    /** Matches "6:30", "06:30" or a label; returns what it changed. */
    fun find(ctx: Context, hour: Int?, minute: Int?, label: String = ""): List<Alarm> =
        all(ctx).filter { (hour == null || (it.hour == hour && it.minute == minute)) && (label.isBlank() || it.label.contains(label, true)) }

    /** Called when an alarm has rung: a one-off switches itself off, a repeating one is set for its next day. */
    fun rang(ctx: Context, id: Long) {
        val a = all(ctx).firstOrNull { it.id == id } ?: return
        if (a.days == 0) setEnabled(ctx, id, false) else schedule(ctx, a)
    }

    const val TEST_ID = -999L

    // ---- backup path: the always-running overlay service also checks the clock, in case the phone blocks the alarm broadcast ----
    private fun slotKey(a: Alarm, t: LocalDateTime) = "${a.id}|${t.toLocalDate()}|${a.hour}:${a.minute}"

    private fun firedKeys(ctx: Context): MutableList<String> = (prefs(ctx).getString("alarm_fired", "") ?: "").split(';').filter { it.isNotEmpty() }.toMutableList()

    /** True the first time it is called for this alarm and this day/minute; false after (so it never rings twice). */
    fun claim(ctx: Context, a: Alarm, now: LocalDateTime = LocalDateTime.now()): Boolean {
        val k = slotKey(a, now.withHour(a.hour).withMinute(a.minute))
        val l = firedKeys(ctx)
        if (k in l) return false
        l.add(k)
        prefs(ctx).edit().putString("alarm_fired", l.takeLast(20).joinToString(";")).apply()
        return true
    }

    /** Alarms whose time is now (up to 2 minutes late) and which have not rung yet. */
    fun dueNow(ctx: Context, now: LocalDateTime = LocalDateTime.now()): List<Alarm> {
        val out = ArrayList<Alarm>()
        for (a in all(ctx)) {
            if (!a.enabled) continue
            val sched = now.toLocalDate().atTime(a.hour, a.minute)
            val late = java.time.Duration.between(sched, now).toMinutes()
            if (now.isBefore(sched) || late > 2) continue
            if (a.days != 0 && a.days and (1 shl (now.dayOfWeek.value - 1)) == 0) continue
            if (firedKeys(ctx).contains(slotKey(a, sched))) continue
            out.add(a)
        }
        return out
    }

    /** A real alarm ring [seconds] from now, to check that the phone lets Ghostie wake up and ring. */
    fun testIn(ctx: Context, seconds: Int) {
        try {
            val at = System.currentTimeMillis() + seconds * 1000L
            val show = PendingIntent.getActivity(ctx, 1, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            ctx.getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi(ctx, TEST_ID))
        } catch (e: Exception) { }
    }

    /** "Next: today 07:30 (in 2h 5m)", or null if nothing is on. */
    fun nextText(ctx: Context): String? {
        val now = LocalDateTime.now()
        val best = all(ctx).filter { it.enabled }.map { it to next(it, now) }.minByOrNull { it.second } ?: return null
        val mins = java.time.Duration.between(now, best.second).toMinutes()
        val whenText = if (best.second.toLocalDate() == now.toLocalDate()) "today" else if (best.second.toLocalDate() == now.toLocalDate().plusDays(1)) "tomorrow" else best.second.dayOfWeek.name.take(3).lowercase().replaceFirstChar { it.uppercase() }
        return "Next: $whenText ${timeText(best.first)} (in ${mins / 60}h ${mins % 60}m)"
    }

    fun rescheduleAll(ctx: Context) { all(ctx).forEach { schedule(ctx, it) } }

    private fun pi(ctx: Context, id: Long): PendingIntent = PendingIntent.getBroadcast(
        ctx, (id % 1_000_000).toInt() + 700_000,
        Intent(ctx, AlarmReceiver::class.java).setAction(RING).putExtra("id", id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun cancel(ctx: Context, id: Long) {
        try { ctx.getSystemService(AlarmManager::class.java).cancel(pi(ctx, id)) } catch (e: Exception) { }
    }

    fun schedule(ctx: Context, a: Alarm) {
        cancel(ctx, a.id)
        if (!a.enabled) return
        try {
            val at = next(a, LocalDateTime.now()).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            val show = PendingIntent.getActivity(ctx, 1, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            // setAlarmClock is exact and needs no special permission; it also shows the alarm icon in the status bar.
            ctx.getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi(ctx, a.id))
        } catch (e: Exception) { }
    }

    /** Day mask from words like "weekdays", "every monday and friday", "daily". 0 if none are named. */
    fun parseDays(t: String): Int {
        val s = t.lowercase()
        if (Regex("\\b(every ?day|daily|everyday)\\b").containsMatchIn(s)) return ALL_DAYS
        if (Regex("\\bweekdays?\\b").containsMatchIn(s)) return WEEKDAYS
        if (Regex("\\bweekends?\\b").containsMatchIn(s)) return WEEKEND
        val names = listOf("mon", "tue", "wed", "thu", "fri", "sat", "sun")
        var m = 0
        names.forEachIndexed { i, n -> if (Regex("\\b$n(?:day|sday|nesday|rsday|urday)?s?\\b").containsMatchIn(s)) m = m or (1 shl i) }
        return m
    }

}
