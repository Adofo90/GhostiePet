package com.ghostie.pet

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.time.LocalDate
import java.util.concurrent.Executors

/**
 * Optional: while a WATCHED WhatsApp group is open on screen, reads the visible messages and adds
 * reminders for submission dates. This covers the case where WhatsApp posts no notification because
 * the chat is already open. Everything is processed on the phone; only the reminders are saved.
 */
class ChatScreenService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val scanTask = Runnable { scanScreen() }
    private val whatsapp = setOf("com.whatsapp", "com.whatsapp.w4b")

    private class Item(val text: String, val top: Int)

    companion object {
        private var lastLogged = 0L
    }

    override fun onServiceConnected() {
        ActivityLog.add(this, "Open chat", "Chat reader started")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg !in whatsapp) return
        handler.removeCallbacks(scanTask)
        handler.postDelayed(scanTask, 900) // wait for the screen to settle
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        worker.shutdown()
        super.onDestroy()
    }

    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<Item>, depth: Int) {
        if (node == null || depth > 40 || out.size > 600) return
        val isInput = node.className?.toString()?.contains("EditText") == true
        val text = node.text?.toString()
        if (!isInput && !text.isNullOrBlank() && node.isVisibleToUser) {
            val r = Rect()
            node.getBoundsInScreen(r)
            out.add(Item(text, r.top))
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), out, depth + 1)
    }

    private fun scanScreen() {
        try {
            val s = SettingsStore(this)
            if (!s.watchEnabled) return
            val groups = s.watchedGroupList()
            if (groups.isEmpty()) return
            val root = rootInActiveWindow ?: return
            if (root.packageName?.toString() !in whatsapp) return

            val items = mutableListOf<Item>()
            collect(root, items, 0)

            // The group's name sits in the top bar. Only act when it is one of the watched groups.
            val topLimit = (resources.displayMetrics.heightPixels * 0.20).toInt()
            val titleText = items.filter { it.top < topLimit }.map { it.text }
                .firstOrNull { t -> groups.any { g -> t.contains(g, ignoreCase = true) } } ?: return
            val group = groups.first { titleText.contains(it, ignoreCase = true) }

            val body = items.filter { it.top >= topLimit }.sortedBy { it.top }.map { it.text }
            if (System.currentTimeMillis() - lastLogged > 60_000L) {
                lastLogged = System.currentTimeMillis()
                ActivityLog.add(this, "Open chat", "Reading \"$group\" (${body.size} items on screen)")
            }
            val today = LocalDate.now()
            worker.execute { process(s, group, body, today) }
        } catch (e: Exception) {
            // never crash the service
        }
    }

    private fun process(s: SettingsStore, group: String, texts: List<String>, today: LocalDate) {
        try {
            var ref: LocalDate? = null // date of the chat section we are in, from WhatsApp's date chips
            for (t in texts) {
                val chip = DateDivider.parse(t, today)
                if (chip != null) {
                    ref = chip
                    continue
                }
                // Without a date chip above, "tomorrow"/"Monday" can't be resolved, so only explicit dates count.
                DocNotice.fileName(t)?.let { s.rememberDoc(it, group) }
                val sub = SubmissionParser.parse(t, today, ref ?: today, allowRelative = ref != null) ?: continue
                if (ReminderMaker.isDuplicate(s, t, sub, this, group)) continue
                if (!s.markSeen((group + "|" + t).hashCode())) continue
                ReminderMaker.report(this, "Open chat", group, sub, ReminderMaker.add(this, s, group, t, sub))
            }
        } catch (e: Exception) {
            // ignore
        }
    }
}
