package com.ghostie.pet

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.time.LocalDate
import java.util.concurrent.Executors

/**
 * Optional: while a WATCHED WhatsApp group is open on screen, reads the visible messages and adds
 * reminders for submission dates. This covers the case where WhatsApp posts no notification because
 * the chat is already open. Everything is processed on the phone; only the reminders are saved.
 */
class ChatScreenService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val scanTask = Runnable { scanScreen() }
    private val whatsapp = setOf("com.whatsapp", "com.whatsapp.w4b")

    private class Item(val text: String, val top: Int)

    companion object {
        private var lastLogged = 0L
        /** The WhatsApp chat that was last open on screen (name from the top bar), so "watch this group" knows which one. */
        @Volatile var lastOpenTitle: String? = null
        @Volatile var lastOpenAt = 0L
        /** The running reader, so it can switch itself off for payment apps (see PaymentPause). */
        @Volatile var instance: ChatScreenService? = null
        fun openTitle(): String? = lastOpenTitle?.takeIf { System.currentTimeMillis() - lastOpenAt < 15 * 60_000L }
    }

    override fun onServiceConnected() {
        instance = this
        ActivityLog.add(this, "Open chat", "Chat reader started")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg !in whatsapp) {
            val app = ChatApps.nameFor(pkg) ?: return
            if (!SettingsStore(this).otherChatOn(app)) return
        }
        handler.removeCallbacks(scanTask)
        handler.postDelayed(scanTask, 900) // wait for the screen to settle
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        if (instance === this) instance = null
        handler.removeCallbacksAndMessages(null)
        worker.shutdown()
        super.onDestroy()
    }

    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<Item>, depth: Int) {
        if (node == null || depth > 40 || out.size > 600) return
        val isInput = node.className?.toString()?.contains("EditText") == true
        val text = node.text?.toString()
        if (!isInput && !text.isNullOrBlank() && node.isVisibleToUser) {
            val r = Rect()
            node.getBoundsInScreen(r)
            out.add(Item(text, r.top))
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), out, depth + 1)
    }

    private fun scanScreen() {
        try {
            val s = SettingsStore(this)
            val root = rootInActiveWindow ?: return
            val rootPkg = root.packageName?.toString()
            if (rootPkg !in whatsapp) { scanOther(s, root, rootPkg); return }
            run {
                val seen = mutableListOf<Item>()
                collect(root, seen, 0)
                val lim = (resources.displayMetrics.heightPixels * 0.20).toInt()
                ChatTitle.guess(seen.filter { it.top < lim }.sortedBy { it.top }.map { it.text })?.let { lastOpenTitle = it; lastOpenAt = System.currentTimeMillis() }
            }
            if (!s.watchEnabled) return
            val groups = s.watchedGroupList()
            if (groups.isEmpty()) return

            val items = mutableListOf<Item>()
            collect(root, items, 0)

            // The group's name sits in the top bar. Only act when it is one of the watched groups.
            val topLimit = (resources.displayMetrics.heightPixels * 0.20).toInt()
            val titleText = items.filter { it.top < topLimit }.map { it.text }
                .firstOrNull { t -> groups.any { g -> t.contains(g, ignoreCase = true) } } ?: return
            val group = groups.first { titleText.contains(it, ignoreCase = true) }

            val body = items.filter { it.top >= topLimit }.sortedBy { it.top }.map { it.text }
            if (System.currentTimeMillis() - lastLogged > 60_000L) {
                lastLogged = System.currentTimeMillis()
                ActivityLog.add(this, "Open chat", "Reading \"$group\" (${body.size} items on screen)")
            }
            val today = LocalDate.now()
            worker.execute { process(s, group, body, today) }
        } catch (e: Exception) {
            // never crash the service
        }
    }

    /** Instagram / Telegram / Discord: every visible chat (only when that app is switched on), explicit dates only. */
    private fun scanOther(s: SettingsStore, root: AccessibilityNodeInfo, pkg: String?) {
        val app = ChatApps.nameFor(pkg) ?: return
        if (!s.otherChatOn(app)) return
        val items = mutableListOf<Item>()
        collect(root, items, 0)
        val topLimit = (resources.displayMetrics.heightPixels * 0.20).toInt()
        val title = items.filter { it.top < topLimit }.sortedBy { it.top }.map { it.text }.firstOrNull { it.length in 2..40 }
        val body = items.filter { it.top >= topLimit }.sortedBy { it.top }.map { it.text }
        val group = ChatApps.label(app, title)
        val today = LocalDate.now()
        worker.execute { process(s, group, body, today, trusted = false) }
    }

    private fun process(s: SettingsStore, group: String, texts: List<String>, today: LocalDate, trusted: Boolean = true) {
        try {
            var ref: LocalDate? = null // date of the chat section we are in, from WhatsApp's date chips
            for (t in texts) {
                val chip = DateDivider.parse(t, today)
                if (chip != null) {
                    ref = chip
                    continue
                }
                // Without a date chip above, "tomorrow"/"Monday" can't be resolved, so only explicit dates count.
                if (trusted && s.learnGroups) SentenceStore.learn(this, t, 1)
                if (trusted) DocNotice.fileName(t)?.let { s.rememberDoc(it, group) }
                val sub = SubmissionParser.parse(t, today, ref ?: today, allowRelative = ref != null) ?: continue
                if (ReminderMaker.isDuplicate(s, t, sub, this, group)) continue
                if (!s.markSeen((group + "|" + t).hashCode())) continue
                ReminderMaker.report(this, "Open chat", group, sub, ReminderMaker.add(this, s, group, t, sub))
            }
        } catch (e: Exception) {
            // ignore
        }
    }
}

/** Picks the chat name out of the texts in a chat screen's top bar (title first, then "online" / member list). Pure Kotlin. */
object ChatTitle {
    private val notTitle = Regex("^(?:online|typing\\.*|last seen.*|tap here.*|click here.*|whatsapp|search|back|more options|video call|voice call|call|menu|status|chats?|calls?|communities|updates|you|business|tap to .*|today|yesterday)$", RegexOption.IGNORE_CASE)
    fun guess(topTexts: List<String>): String? {
        for (raw in topTexts) {
            val t = raw.trim()
            if (t.length !in 2..60) continue
            if (notTitle.matches(t)) continue
            if (t.count { it == ',' } >= 2) continue          // a member list such as "You, Ravi, Meena"
            if (t.all { it.isDigit() || it in "+ -:" }) continue
            return t
        }
        return null
    }
}
