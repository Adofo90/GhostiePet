package com.ghostie.pet

import java.io.File
import android.content.Context
import kotlin.random.Random

/**
 * Ghostie's word memory. It reads text (what you say to it, text you paste, watched groups, shared chats),
 * remembers which word tends to follow which, and builds NEW sentences from that - in your style.
 * It is a small statistical model (word chains), not a large language model, so sentences can be quirky.
 * Pure Kotlin so it can be tested without a phone. Everything stays on the phone.
 */
class SentenceModel {
    private val tri = HashMap<String, HashMap<String, Int>>()
    private val bi = HashMap<String, HashMap<String, Int>>()
    private val seen = HashSet<Int>()
    var sentences = 0
        private set
    var dirty = false

    companion object {
        const val BOS = "<s>"
        const val EOS = "</s>"
        /** Enough material before Ghostie starts mixing its own sentences into chat. */
        const val READY_AT = 25

        private val TOKEN = Regex("[\\p{L}\\p{N}]+(?:['’][\\p{L}]+)?|[\\p{So}]")
        private val UNSAFE = Regex("https?://|www\\.|@\\w|\\.com\\b|\\b\\d{6,}\\b|\\d{3,}[- ]\\d{3,}|\\bOTP\\b|password", RegexOption.IGNORE_CASE)
        private val RUDE = listOf("fuck", "shit", "bitch", "bastard", "asshole", "dick", "cunt", "slut", "whore", "nigg", "rape", "porn", "sex", "suicide", "kill")
        private val BAD_END = setOf("the", "a", "an", "and", "or", "to", "of", "in", "on", "at", "for", "with", "is", "are", "was", "but", "so", "if", "my", "your", "i", "it", "that", "this", "as", "by", "from", "than", "then", "because")
        private val QUESTION = setOf("what", "why", "how", "who", "when", "where", "do", "did", "are", "is", "can", "will", "should", "which", "have", "does")
        private val STOP = setOf("the", "and", "you", "for", "that", "this", "with", "are", "was", "have", "has", "not", "but", "your", "what", "can", "will", "just", "its", "it's", "i'm", "its", "they", "them", "there", "here", "about", "from")

        fun tokenize(sentence: String): List<String> =
            TOKEN.findAll(sentence.lowercase().replace('’', '\'')).map { it.value }.toList()

        /** Splits a message into sentences and removes WhatsApp noise ("Name: ", *bold*, links...). */
        fun sentencesOf(text: String): List<String> {
            val cleaned = text.replace(Regex("^\\s*[\\[(]?\\d{1,2}[/.]\\d{1,2}[/.]\\d{2,4}.*?[\\])-]\\s*"), "")
                .replace(Regex("^[^:\\n]{1,25}:\\s+(?=.{8,})"), "")
                .replace(Regex("[*_~`]"), "")
            return cleaned.split(Regex("(?<=[.!?])\\s+|\\n+")).map { it.trim() }.filter { it.isNotEmpty() }
        }

        fun acceptable(sentence: String, tokens: List<String>): Boolean {
            if (tokens.size < 3 || tokens.size > 22) return false
            if (UNSAFE.containsMatchIn(sentence)) return false
            if (tokens.count { t -> t.all { it.isDigit() } } > 2) return false
            if (tokens.any { t -> RUDE.any { t.contains(it) } }) return false
            if (tokens.count { it.length == 1 && it[0].isLetter() } > tokens.size / 2) return false
            return true
        }

        fun fromText(text: String): SentenceModel {
            val m = SentenceModel()
            for (line in text.lines()) {
                val p = line.split('\t')
                try {
                    when (p[0]) {
                        "T" -> m.tri.getOrPut(p[1]) { HashMap() }[p[2]] = p[3].toInt()
                        "B" -> m.bi.getOrPut(p[1]) { HashMap() }[p[2]] = p[3].toInt()
                        "H" -> m.seen.add(p[1].toInt())
                        "N" -> m.sentences = p[1].toInt()
                    }
                } catch (e: Exception) {
                    // skip a damaged line
                }
            }
            return m
        }
    }

    val ready: Boolean get() = sentences >= READY_AT
    val vocabulary: Int get() = bi.size

    private fun bump(map: HashMap<String, HashMap<String, Int>>, ctx: String, next: String, by: Int) {
        val m = map.getOrPut(ctx) { HashMap() }
        val v = (m[next] ?: 0) + by
        if (v <= 0) { m.remove(next); if (m.isEmpty()) map.remove(ctx) } else m[next] = v
    }

    /** Reads a message. [weight]: 3 for your own words, 1 for other people's. Returns how many sentences were new. */
    fun learn(text: String, weight: Int = 1): Int {
        var added = 0
        for (s in sentencesOf(text)) {
            val tokens = tokenize(s)
            if (!acceptable(s, tokens)) continue
            val h = tokens.joinToString(" ").hashCode()
            if (!seen.add(h)) continue
            val chain = listOf(BOS) + tokens + EOS
            for (i in 1 until chain.size) {
                bump(bi, chain[i - 1], chain[i], weight)
                if (i >= 2) bump(tri, chain[i - 2] + " " + chain[i - 1], chain[i], weight)
            }
            sentences++
            added++
        }
        if (added > 0) { dirty = true; prune() }
        return added
    }

    private fun prune() {
        if (tri.size <= 20000) return
        val drop = tri.entries.filter { e -> e.value.values.sum() <= 1 }.take(tri.size - 14000).map { it.key }
        drop.forEach { tri.remove(it) }
        if (seen.size > 8000) { val keep = seen.toList().takeLast(5000); seen.clear(); seen.addAll(keep) }
    }

    private fun choose(options: Map<String, Int>, rnd: Random, banned: Set<String> = emptySet()): String? {
        val usable = options.filterKeys { it !in banned }
        if (usable.isEmpty()) return null
        var x = rnd.nextInt(usable.values.sum().coerceAtLeast(1))
        for ((k, v) in usable) { x -= v; if (x < 0) return k }
        return usable.keys.first()
    }

    private class Candidate(val tokens: List<String>, val triRatio: Double)

    private fun walk(rnd: Random): Candidate? {
        val out = ArrayList<String>()
        var prev2 = ""
        var prev1 = BOS
        var triSteps = 0
        var steps = 0
        while (out.size < 20) {
            val triOpts = if (prev2.isNotEmpty()) tri["$prev2 $prev1"] else null
            val opts = triOpts ?: bi[prev1] ?: break
            val banned = HashSet<String>()
            if (out.size < 4) banned.add(EOS)
            if (out.isNotEmpty()) banned.add(prev1)
            val next = choose(opts, rnd, banned) ?: choose(bi[prev1] ?: break, rnd, banned) ?: break
            steps++
            if (triOpts != null) triSteps++
            if (next == EOS) break
            out.add(next)
            prev2 = prev1
            prev1 = next
        }
        if (out.size < 4 || steps == 0) return null
        return Candidate(out, triSteps.toDouble() / steps)
    }

    /** Builds a sentence that is not a copy of anything it has read. [seed] words from the user's message get a bonus. */
    fun generate(rnd: Random = Random.Default, seed: Collection<String> = emptyList(), tries: Int = 14): String? {
        if (bi[BOS].isNullOrEmpty()) return null
        val seedSet = seed.map { it.lowercase() }.filter { it.length > 2 && it !in STOP }.toSet()
        var best: Candidate? = null
        var bestScore = -1.0
        repeat(tries) {
            val c = walk(rnd) ?: return@repeat
            val t = c.tokens
            if (t.last() in BAD_END) return@repeat
            if (t.groupingBy { it }.eachCount().any { it.value >= 3 }) return@repeat
            if (t.joinToString(" ").hashCode() in seen) return@repeat
            val seedBonus = t.count { it in seedSet } * 0.5
            val lenBonus = if (t.size in 5..13) 0.3 else 0.0
            val score = c.triRatio + seedBonus + lenBonus + rnd.nextDouble() * 0.2
            if (score > bestScore) { best = c; bestScore = score }
        }
        return best?.let { format(it.tokens) }
    }

    private fun format(tokens: List<String>): String {
        val words = tokens.map { if (it == "i") "I" else if (it.startsWith("i'")) "I" + it.substring(1) else it }
        val text = words.joinToString(" ").replaceFirstChar { it.uppercase() }
        val last = tokens.last()
        val emoji = !last[0].isLetterOrDigit()
        return when {
            emoji -> text
            tokens.first() in QUESTION -> "$text?"
            else -> "$text."
        }
    }

    /** 👍/👎 on a generated sentence: strengthens or weakens the word chains it used. */
    fun rate(sentence: String, good: Boolean) {
        val chain = listOf(BOS) + tokenize(sentence) + EOS
        val by = if (good) 2 else -3
        for (i in 1 until chain.size) {
            bump(bi, chain[i - 1], chain[i], by)
            if (i >= 2) bump(tri, chain[i - 2] + " " + chain[i - 1], chain[i], by)
        }
        dirty = true
    }

    fun clear() {
        tri.clear(); bi.clear(); seen.clear(); sentences = 0; dirty = true
    }

    fun toText(): String {
        val sb = StringBuilder()
        sb.append("N\t").append(sentences).append('\n')
        for ((c, m) in tri) for ((n, v) in m) sb.append("T\t").append(c).append('\t').append(n).append('\t').append(v).append('\n')
        for ((c, m) in bi) for ((n, v) in m) sb.append("B\t").append(c).append('\t').append(n).append('\t').append(v).append('\n')
        for (h in seen) sb.append("H\t").append(h).append('\n')
        return sb.toString()
    }

    fun summary(): String = "Words I know: $vocabulary · sentences read: $sentences" +
        if (ready) "" else " (I start using my own sentences at $READY_AT)"
}

/** One shared model per process, saved to private storage. */
object SentenceStore {
    private var model: SentenceModel? = null
    private var lastSave = 0L

    @Synchronized
    fun get(ctx: Context): SentenceModel {
        model?.let { return it }
        val f = File(ctx.applicationContext.filesDir, "ghostie_words.txt")
        val m = try { if (f.exists()) SentenceModel.fromText(f.readText()) else SentenceModel() } catch (e: Exception) { SentenceModel() }
        model = m
        return m
    }

    /** Learns from a message; saves at most every 30 seconds. */
    @Synchronized
    fun learn(ctx: Context, text: String, weight: Int = 1): Int {
        val n = get(ctx).learn(text, weight)
        if (n > 0 && System.currentTimeMillis() - lastSave > 30_000L) save(ctx)
        return n
    }

    @Synchronized
    fun save(ctx: Context) {
        val m = model ?: return
        if (!m.dirty) return
        try {
            File(ctx.applicationContext.filesDir, "ghostie_words.txt").writeText(m.toText())
            m.dirty = false
            lastSave = System.currentTimeMillis()
        } catch (e: Exception) {
            // storage full: keep running without saving
        }
    }

    @Synchronized
    fun reset(ctx: Context) {
        get(ctx).clear()
        save(ctx)
    }
}
