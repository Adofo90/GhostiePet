package com.ghostie.pet

import android.content.Context
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

/** Group project tasks with owners and due dates, plus the reminder messages for teammates. Pure logic is tested on the JVM. */
object Projects {
    data class Task(val id: Long, val project: String, val title: String, val owner: String, val due: LocalDate?, val done: Boolean)
    class Data(val tasks: MutableList<Task> = mutableListOf(), val phones: MutableMap<String, String> = mutableMapOf(), val projects: MutableList<String> = mutableListOf())

    fun overdue(tasks: List<Task>, today: LocalDate) = tasks.filter { !it.done && it.due != null && it.due.isBefore(today) }.sortedBy { it.due }
    fun dueSoon(tasks: List<Task>, today: LocalDate, days: Int = 2) =
        tasks.filter { !it.done && it.due != null && !it.due.isBefore(today) && ChronoUnit.DAYS.between(today, it.due) <= days }.sortedBy { it.due }

    private fun dateWord(d: LocalDate?, today: LocalDate): String {
        if (d == null) return "no date"
        val n = ChronoUnit.DAYS.between(today, d)
        return when {
            n == 0L -> "today"; n == 1L -> "tomorrow"; n == -1L -> "yesterday"
            n < 0 -> "${-n} days ago"; n < 7 -> d.format(DateTimeFormatter.ofPattern("EEE", Locale.ENGLISH))
            else -> d.format(DateTimeFormatter.ofPattern("d MMM", Locale.ENGLISH))
        }
    }

    fun status(project: String, tasks: List<Task>, today: LocalDate): String {
        val mine = tasks.filter { it.project.equals(project, true) }
        if (mine.isEmpty()) return "$project: no tasks yet."
        val done = mine.count { it.done }
        val sb = StringBuilder("$project: $done of ${mine.size} done")
        val od = overdue(mine, today)
        if (od.isNotEmpty()) sb.append("\n⚠️ Overdue: ").append(od.joinToString("; ") { "${it.title} (${it.owner.ifBlank { "unassigned" }}, ${dateWord(it.due, today)})" })
        val soon = dueSoon(mine, today)
        if (soon.isNotEmpty()) sb.append("\n⏰ Due soon: ").append(soon.joinToString("; ") { "${it.title} (${it.owner.ifBlank { "unassigned" }}, ${dateWord(it.due, today)})" })
        val rest = mine.filter { !it.done && it !in od && it !in soon }
        if (rest.isNotEmpty()) sb.append("\n• Open: ").append(rest.joinToString("; ") { it.title + (if (it.owner.isNotBlank()) " (${it.owner})" else "") })
        return sb.toString()
    }

    fun statusAll(d: Data, today: LocalDate): String =
        if (d.projects.isEmpty() && d.tasks.isEmpty()) "No group projects yet. Add one in the Group projects card."
        else (d.projects + d.tasks.map { it.project }).distinct().joinToString("\n\n") { status(it, d.tasks, today) }

    /** The nudge to send a teammate about one task. */
    fun reminderFor(t: Task, today: LocalDate): String {
        val who = t.owner.ifBlank { "there" }
        return if (t.due != null && t.due.isBefore(today)) "Hi $who, for our ${t.project} project: \"${t.title}\" was due ${dateWord(t.due, today)}. Where are we on it? 🙂"
        else "Hi $who, a reminder for our ${t.project} project: \"${t.title}\" is due ${dateWord(t.due, today)}. Let me know if you need help 🙂"
    }

    /** One message per teammate covering all their overdue or soon-due tasks (owner -> text). */
    fun reminderMessages(tasks: List<Task>, today: LocalDate): Map<String, String> =
        (overdue(tasks, today) + dueSoon(tasks, today)).filter { it.owner.isNotBlank() }.groupBy { it.owner }.mapValues { (owner, list) ->
            if (list.size == 1) reminderFor(list[0], today)
            else "Hi $owner, reminders for our project:\n" + list.joinToString("\n") { "• ${it.title} (${it.project}): ${dateWord(it.due, today)}" } + "\nCan you update me? 🙂"
        }

    /** Digits only, with the country code 91 added for 10-digit Indian numbers; null if it doesn't look like a number. */
    fun waNumber(raw: String): String? {
        val d = raw.filter { it.isDigit() }
        return when { d.length == 10 -> "91$d"; d.length in 11..14 -> d; else -> null }
    }

    // ---- storage (plain text lines, no JSON) ----
    fun serialize(d: Data): String = buildString {
        d.projects.forEach { append("P\t").append(it).append('\n') }
        d.phones.forEach { append("M\t").append(it.key).append('\t').append(it.value).append('\n') }
        d.tasks.forEach { append("T\t${it.id}\t${it.project}\t${it.title}\t${it.owner}\t${it.due ?: ""}\t${if (it.done) 1 else 0}\n") }
    }

    fun parse(text: String): Data {
        val d = Data()
        for (l in text.lines()) {
            val p = l.split('\t')
            try {
                when (p[0]) {
                    "P" -> d.projects.add(p[1])
                    "M" -> d.phones[p[1]] = p[2]
                    "T" -> d.tasks.add(Task(p[1].toLong(), p[2], p[3], p[4], p[5].takeIf { it.isNotBlank() }?.let { LocalDate.parse(it) }, p[6] == "1"))
                }
            } catch (e: Exception) { }
        }
        return d
    }

    fun clean(s: String) = s.replace(Regex("[\\t\\r\\n]+"), " ").trim().take(80)
}

object ProjectStore {
    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences("ghostie_projects", Context.MODE_PRIVATE)
    @Synchronized fun load(ctx: Context): Projects.Data = Projects.parse(p(ctx).getString("d", "") ?: "")
    @Synchronized fun save(ctx: Context, d: Projects.Data) { p(ctx).edit().putString("d", Projects.serialize(d)).apply() }
}
