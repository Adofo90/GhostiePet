package com.ghostie.pet

/**
 * Food price comparison - the PURE part (no Android): parsing what the user asked for, turning the text
 * Ghostie read on a food app's screen into offers, and finding the cheapest single place or the cheapest
 * combination when several items are wanted. Ghostie only reads prices; it never orders.
 */
data class FoodApp(
    val id: String, val label: String, val packages: List<String>, val brand: String? = null,
    /** App has no search box: Ghostie scrolls its menu and opens matching category tiles instead. */
    val noSearch: Boolean = false,
    /** Last-resort screen positions (fractions of width/height) to tap when the search bar isn't exposed to screen readers. */
    val searchTaps: List<Pair<Float, Float>> = emptyList()
)

object FoodApps {
    // Package ids from the Play Store listings; also matched by app name on the phone (FoodScanService.resolve).
    val ALL = listOf(
        FoodApp("zomato", "Zomato", listOf("com.application.zomato")),
        FoodApp("swiggy", "Swiggy", listOf("in.swiggy.android"), searchTaps = listOf(0.5f to 0.17f, 0.5f to 0.12f)),
        FoodApp("dominos", "Domino's", listOf("com.Dominos"), brand = "domino"),
        FoodApp("popeyes", "Popeyes", listOf("com.jubl.popeyes"), brand = "popeye", noSearch = true),
        FoodApp("eatsure", "EatSure", listOf("com.done.faasos"), brand = "eatsure")
    )
    fun byId(id: String) = ALL.firstOrNull { it.id == id }
}

/** [qty] copies of [name]. */
data class WantedItem(val name: String, val qty: Int = 1)

data class Offer(
    val app: String, val restaurant: String, val item: String, val price: Int,
    /** Delivery fee in rupees if the app showed it, null if not shown. */
    val fee: Int? = null
)

data class PlanLine(val item: WantedItem, val offer: Offer)
data class Plan(
    val app: String, val restaurant: String, val lines: List<PlanLine>,
    val itemsTotal: Int, val fee: Int, val feeEstimated: Boolean
) {
    val total get() = itemsTotal + fee
}
data class Combo(val plans: List<Plan>) {
    val total get() = plans.sumOf { it.total }
    val feeEstimated get() = plans.any { it.feeEstimated }
}

object FoodCompare {
    private val I = RegexOption.IGNORE_CASE

    /** "cheapest chicken biryani", "compare prices of paneer pizza and garlic bread" -> items. Null if not a food-price request. */
    fun parse(raw: String): List<WantedItem>? {
        var t = raw.trim().trimEnd('.', '!', '?')
        val m = Regex(
            "^(?:please\\s+)?(?:(?:find|get|check|show|tell)\\s+(?:me\\s+)?)?(?:the\\s+)?" +
                "(?:cheapest|cheapest price (?:of|for)|lowest price (?:of|for)|best price (?:of|for)|price (?:check|compare|comparison)(?: for| of)?|" +
                "compare (?:the )?(?:food )?prices?(?: of| for)?|compare|food price(?: of| for)?|which app is cheapest for|where(?:'s| is) (?:the )?cheapest)\\s*[:\\-]?\\s*(.+)$", I
        ).find(t) ?: return null
        t = m.groupValues[1].trim()
        t = t.replace(Regex("\\s+(?:near me|today|right now|now|online|on (?:zomato|swiggy)(?: and (?:zomato|swiggy))?|across apps|in all apps)$", I), "").trim()
        t = t.replace(Regex("^(?:the\\s+)?(?:price of|prices of|price for|for|of)\\s+", I), "").trim()
        if (t.isEmpty()) return null
        val items = t.split(Regex("\\s*(?:,|\\+|&|\\band\\b|\\bwith\\b|\\bplus\\b)\\s*", I)).map { it.trim() }.filter { it.isNotEmpty() }
        val out = items.map { part ->
            val q = Regex("^(\\d{1,2})\\s*(?:x\\s*)?(.+)$", I).find(part)
            if (q != null && q.groupValues[2].isNotBlank()) WantedItem(q.groupValues[2].trim().lowercase(), q.groupValues[1].toInt().coerceIn(1, 20))
            else WantedItem(part.lowercase())
        }
        return out.take(5).ifEmpty { null }
    }

    private val STOP = setOf("a", "an", "the", "of", "with", "and", "in")
    private fun tokens(s: String) = s.lowercase().split(Regex("[^a-z0-9]+")).filter { it.length > 1 && it !in STOP }

    /** How well [line] matches [item]: share of the item's words present in the line (0..1). */
    fun match(item: String, line: String): Double {
        val want = tokens(item)
        if (want.isEmpty()) return 0.0
        val have = tokens(line).toSet()
        val hit = want.count { w -> have.any { h -> h == w || h.startsWith(w) || w.startsWith(h) && h.length >= 4 } }
        return hit.toDouble() / want.size
    }

    private val PRICE = Regex("(?:₹|rs\\.?|inr)\\s*(\\d{1,3}(?:,\\d{2,3})+|\\d+)(?:\\.\\d+)?", I)
    private val PRICE_ONLY = Regex("^\\s*(?:₹|rs\\.?|inr)\\s*(\\d{1,3}(?:,\\d{2,3})+|\\d+)(?:\\.\\d+)?\\s*(?:onwards|\\+)?\\s*$", I)
    private val FEE_A = Regex("(?:₹|rs\\.?)\\s*(\\d{1,3})\\s*(?:delivery|del\\b)", I)
    private val FEE_B = Regex("delivery\\s*(?:fee|charges?)?\\s*[:\\-]?\\s*(?:₹|rs\\.?)\\s*(\\d{1,3})", I)
    private val FREE = Regex("free\\s+delivery|delivery\\s*(?:fee)?\\s*[:\\-]?\\s*free|₹\\s*0\\s*delivery", I)
    private val NOISE = Regex("^(?:\\d(?:\\.\\d)?|\\d+\\s*(?:min|mins|ratings?|k)|[\\d.]+\\s*\\(.*\\)|veg|non-?veg|bestseller|must try|add|\\+|ADD|•|off|\\d+%\\s*off.*|items? at.*|promoted|ad|ordered by.*|ready in.*|\\d+(?:\\.\\d+)?\\s*km)$", I)

    private val SKIP_PRICE = Regex("starting at|onwards|for two|per person|avg|min(?:imum)? order|free delivery above|above ₹|off up to|upto|up to", RegexOption.IGNORE_CASE)

    fun priceOf(line: String): Int? = PRICE.find(line)?.groupValues?.get(1)?.replace(",", "")?.toIntOrNull()
    fun isPriceLine(line: String) = PRICE_ONLY.matches(line)
    fun feeOf(line: String): Int? {
        if (FREE.containsMatchIn(line)) return 0
        return (FEE_A.find(line) ?: FEE_B.find(line))?.groupValues?.get(1)?.toIntOrNull()
    }

    fun looksLikeName(l: String): Boolean {
        val s = l.trim()
        return s.length in 3..48 && s.any { it.isLetter() } && !NOISE.matches(s) && PRICE.find(s) == null && feeOf(s) == null &&
            !s.contains("delivery", true) && !Regex("\\d+\\s*(?:min|mins)\\b", I).containsMatchIn(s) && !s.contains("off", true)
    }

    /**
     * Reads one screenful of text (top to bottom) from [appLabel] and returns offers for [item].
     * Heuristic: a price line belongs to the closest earlier line that matches the item; the restaurant is the
     * nearest name-like line around it; a delivery fee line within the same block is attached to it.
     * Layouts differ per app and change over time, so unmatched things are skipped rather than guessed.
     */
    fun offersFromScreen(appLabel: String, item: String, lines0: List<String>, brandName: String? = null): List<Offer> {
        // Zomato writes prices as "· ₹359" and leaves blank/zero-width lines between fields
        val lines = lines0.map { it.trim().trimStart('·', '•', '-', '–', '—', ' ') }.filter { l -> l.any { it.isLetterOrDigit() || it == '₹' } }
        val out = mutableListOf<Offer>()
        for (i in lines.indices) {
            val priceLine = lines[i]
            val price = if (SKIP_PRICE.containsMatchIn(priceLine)) null else if (isPriceLine(priceLine)) priceOf(priceLine) else priceOf(priceLine)?.takeIf { match(item, priceLine) >= 0.6 }
            if (price == null || price < 20 || price > 5000) continue
            // item name: this line (if it names the item and has a price) or the nearest earlier lines
            var itemIdx = -1
            for (j in i downTo maxOf(0, i - 4)) {
                if (j < i && isPriceLine(lines[j])) break // that price belongs to an earlier dish
                // a dish named "Hyderabadi Biryani" with "Chicken" in its description still counts for "chicken biryani"
                val withDesc = lines.subList(j, minOf(lines.size, j + 3)).joinToString(" ")
                if ((match(item, lines[j]) >= 0.6 || (match(item, lines[j]) >= 0.5 && match(item, withDesc) >= 0.99)) && (j != i || !isPriceLine(lines[j]))) { itemIdx = j; break }
            }
            if (itemIdx < 0) continue
            val itemText = lines[itemIdx].replace(PRICE, "").trim().trim('|', '-', '·', ' ')
            // restaurant: brand apps are their own restaurant; otherwise nearest name-like line around the block
            val rest = brandName ?: run {
                var found: String? = null
                // after the price first (dish cards), then above the dish (restaurant headers)
                val order = (i + 1..i + 3).toList() + (itemIdx - 1 downTo itemIdx - 6).toList()
                for (k in order) {
                    if (k !in lines.indices || k == i) continue
                    val l = lines[k]
                    if (match(item, l) >= 0.6) continue
                    if (k + 1 < lines.size && (isPriceLine(lines[k + 1]) || priceOf(l) != null)) continue // that's another dish
                    if (l.contains("search", true) || l.contains("result", true)) continue
                    if (looksLikeName(l)) { found = l.trim().removePrefix("by ").removePrefix("From ").trim(); break }
                }
                found
            } ?: continue
            var fee: Int? = null
            for (k in maxOf(0, itemIdx - 6)..minOf(lines.lastIndex, itemIdx + 8)) {
                val f = feeOf(lines[k]); if (f != null) { fee = f; break }
            }
            out += Offer(appLabel, rest, itemText.ifEmpty { item }, price, fee)
        }
        return out.distinctBy { Triple(it.restaurant.lowercase(), it.item.lowercase(), it.price) }
    }

    // ---- choosing the cheapest -------------------------------------------------------------

    private class Group(val app: String, val restaurant: String, val offers: List<Offer>, val fee: Int, val feeEst: Boolean)

    private fun groups(offers: List<Offer>, defaultFee: Int, feeFor: (String) -> Int = { defaultFee }): List<Group> =
        offers.groupBy { it.app.lowercase() + "|" + it.restaurant.lowercase() }.values.map { g ->
            val known = g.firstNotNullOfOrNull { it.fee }
            Group(g.first().app, g.first().restaurant, g, known ?: feeFor(g.first().app), known == null)
        }

    private fun planFor(g: Group, items: List<WantedItem>): Plan? {
        val lines = items.map { w ->
            val o = g.offers.filter { match(w.name, it.item) >= 0.6 }.maxWithOrNull(compareBy<Offer> { match(w.name, it.item) }.thenByDescending { -it.price }) ?: return null
            // prefer the cheapest among the equally-good matches
            val best = g.offers.filter { match(w.name, it.item) >= match(w.name, o.item) - 1e-9 }.minByOrNull { it.price }!!
            PlanLine(w, best)
        }
        return Plan(g.app, g.restaurant, lines, lines.sumOf { it.offer.price * it.item.qty }, g.fee, g.feeEst)
    }

    /** Every single place that can supply all items, cheapest total (items + delivery) first. */
    fun singleStop(items: List<WantedItem>, offers: List<Offer>, defaultFee: Int = 40, feeFor: (String) -> Int = { defaultFee }): List<Plan> =
        groups(offers, defaultFee, feeFor).mapNotNull { planFor(it, items) }.sortedBy { it.total }

    /**
     * Cheapest way to get all items, allowing the order to be split over up to [maxStops] places
     * (each place charges its own delivery fee once). Returns the best few combos, cheapest first.
     */
    fun combos(items: List<WantedItem>, offers: List<Offer>, defaultFee: Int = 40, maxStops: Int = 3, feeFor: (String) -> Int = { defaultFee }): List<Combo> {
        val gs = groups(offers, defaultFee, feeFor).filter { g -> items.any { w -> g.offers.any { match(w.name, it.item) >= 0.6 } } }
            .sortedBy { it.offers.minOf { o -> o.price } }.take(14)
        val results = mutableListOf<Combo>()
        fun cheapestAt(g: Group, w: WantedItem): Offer? =
            g.offers.filter { match(w.name, it.item) >= 0.6 }.minByOrNull { it.price }
        fun subsets(from: Int, chosen: List<Group>) {
            if (chosen.isNotEmpty()) tryCombo(chosen, items, ::cheapestAt)?.let { results += it }
            if (chosen.size >= maxStops) return
            for (k in from until gs.size) subsets(k + 1, chosen + gs[k])
        }
        subsets(0, emptyList())
        return results.distinctBy { c -> c.plans.map { it.app + it.restaurant + it.lines.map { l -> l.item.name } }.sortedBy { it.toString() } }
            .sortedBy { it.total }.take(3)
    }

    private fun tryCombo(chosen: List<Group>, items: List<WantedItem>, cheapest: (Group, WantedItem) -> Offer?): Combo? {
        val assign = Array(chosen.size) { mutableListOf<PlanLine>() }
        for (w in items) {
            var bi = -1; var bo: Offer? = null
            for ((i, g) in chosen.withIndex()) {
                val o = cheapest(g, w) ?: continue
                if (bo == null || o.price < bo.price) { bo = o; bi = i }
            }
            if (bo == null) return null
            assign[bi] += PlanLine(w, bo)
        }
        if (assign.any { it.isEmpty() }) return null // a place that supplies nothing would only add a fee
        return Combo(chosen.mapIndexed { i, g ->
            Plan(g.app, g.restaurant, assign[i], assign[i].sumOf { it.offer.price * it.item.qty }, g.fee, g.feeEst)
        })
    }

    private fun rs(n: Int) = "₹$n"

    private fun describe(p: Plan, withItems: Boolean): String {
        val items = if (withItems) p.lines.joinToString(", ") { (if (it.item.qty > 1) "${it.item.qty}× " else "") + it.offer.item + " ${rs(it.offer.price)}" } else ""
        val fee = if (p.fee == 0) "free delivery" else "${rs(p.fee)}${if (p.feeEstimated) "~" else ""} delivery"
        return "${p.restaurant} (${p.app}): " + (if (withItems) "$items + $fee" else "${rs(p.itemsTotal)} + $fee") + " = ${rs(p.total)}"
    }

    /** The message Ghostie says. [failed] lists apps that could not be read. */
    fun report(items: List<WantedItem>, offers: List<Offer>, failed: List<String>, readApps: List<String>, defaultFee: Int = 40, feeFor: (String) -> Int = { defaultFee }): String {
        val what = items.joinToString(" + ") { (if (it.qty > 1) "${it.qty}× " else "") + it.name }
        val sb = StringBuilder()
        if (offers.isEmpty()) {
            sb.append("🍽️ I couldn't find \"$what\" with a price")
            sb.append(if (readApps.isEmpty()) " - I couldn't read any app." else " in ${readApps.joinToString(", ")}.")
            if (failed.isNotEmpty()) sb.append("\n⚠️ Couldn't read: ${failed.joinToString(", ")}\n(Setup > \"Share last food-check log\" lets you send me details to fix this.)")
            sb.append("\nTry a simpler name (e.g. \"cheapest veg pizza\").")
            return sb.toString()
        }
        sb.append("🍽️ Cheapest for $what\n")
        if (items.size == 1) {
            val plans = singleStop(items, offers, defaultFee, feeFor).take(4)
            plans.forEachIndexed { i, p -> sb.append(if (i == 0) "🥇 " else "${i + 1}. ").append(describe(p, true)).append('\n') }
            if (plans.size > 1) sb.append("Saves ${rs(plans.last().total - plans.first().total)} vs the dearest of these.\n")
        } else {
            val best = combos(items, offers, defaultFee, 3, feeFor)
            val single = singleStop(items, offers, defaultFee, feeFor).firstOrNull()
            if (best.isEmpty()) sb.append("No place had everything I could read. Try fewer items.\n")
            else {
                val c = best.first()
                sb.append("🥇 Best combination - ${rs(c.total)} total\n")
                c.plans.forEach { sb.append("  • ").append(describe(it, true)).append('\n') }
                if (single != null && (c.plans.size > 1)) sb.append("One place only: ").append(describe(single, false)).append('\n')
                else if (single != null) sb.append("(Everything is cheapest at one place.)\n")
                if (best.size > 1) sb.append("Next best: ${rs(best[1].total)}\n")
            }
        }
        if (offers.any { o -> o.fee == null }) sb.append("~ = delivery fee not shown on screen, so I used an estimate (₹$defaultFee). Check the cart for the real fee.\n")
        if (failed.isNotEmpty()) sb.append("⚠️ Couldn't read: ${failed.joinToString(", ")}\n")
        if (failed.isNotEmpty()) sb.append("(Setup > \"Share last food-check log\" lets you send me details to fix this.)\n")
        sb.append("I only read prices - I never order. You place the order yourself 🛍️")
        return sb.toString()
    }
}
