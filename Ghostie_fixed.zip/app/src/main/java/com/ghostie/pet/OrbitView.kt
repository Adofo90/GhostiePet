package com.ghostie.pet

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * Home navigation: the ghost floats in the middle and the app's features circle around it like a carousel.
 * Swipe sideways to spin it, tap a bubble to jump straight to that feature, tap the ghost for a wiggle.
 */
class OrbitView(
    ctx: Context,
    private val items: List<Pair<String, String>>,   // emoji to label
    private val bubble: Int, private val stroke: Int, private val textColor: Int, private val accent: Int,
    private val onPick: (Int) -> Unit
) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val ghost: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.ghost_pet)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * d }
    private val emoji = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val src = android.graphics.Rect(0, 0, ghost.width, ghost.height)

    private var spin = 0f
    private var vel = 0.35f          // radians per second; decays towards the idle drift after a flick
    private val idle = 0.35f
    private var t = 0f
    private var last = 0L
    private var downX = 0f
    private var lastX = 0f
    private var dragging = false
    private var wiggle = 0f
    private var pulse = -1
    private var pulseT = 0f
    private val rects = Array(items.size) { RectF() }
    private val depths = FloatArray(items.size)
    private val ghostRect = RectF()

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (250 * d).toInt())
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); last = 0L; postInvalidateOnAnimation() }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1e9f).coerceAtMost(0.05f)
        last = now
        t += dt
        if (!dragging) { vel += (idle - vel) * (1f - Math.pow(0.35, dt.toDouble()).toFloat()); spin += vel * dt }
        wiggle = max(0f, wiggle - dt * 1.6f)
        if (pulse >= 0) { pulseT += dt * 4f; if (pulseT >= 1f) pulse = -1 }

        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2f; val cy = h * 0.52f
        val rx = w * 0.40f; val ry = h * 0.20f
        val n = items.size
        val order = (0 until n).sortedBy { cos(spin + it * 6.2831855f / n) }   // back first

        fun drawItem(i: Int) {
            val a = spin + i * 6.2831855f / n
            val depth = cos(a)
            depths[i] = depth
            val k = 0.62f + 0.38f * (depth + 1f) / 2f
            val x = cx + rx * sin(a)
            val y = cy + ry * depth * 0.9f - 6f * d
            var r = 27f * d * k
            if (i == pulse) r *= 1f + 0.25f * sin(pulseT * 3.1416f)
            fill.color = bubble; fill.alpha = (110 + 145 * (depth + 1f) / 2f).toInt()
            c.drawCircle(x, y, r, fill)
            line.color = if (depth > 0.5f) accent else stroke; line.alpha = fill.alpha
            c.drawCircle(x, y, r, line)
            emoji.textSize = 24f * d * k; emoji.alpha = fill.alpha
            c.drawText(items[i].first, x, y + emoji.textSize * 0.35f, emoji)
            if (depth > 0.15f) {
                label.color = textColor; label.alpha = (255 * depth).toInt().coerceIn(0, 255); label.textSize = 11f * d
                c.drawText(items[i].second, x, y + r + 13f * d, label)
            }
            rects[i].set(x - r, y - r, x + r, y + r + 14f * d)
        }
        val backs = order.filter { cos(spin + it * 6.2831855f / n) <= 0f }
        val fronts = order.filter { cos(spin + it * 6.2831855f / n) > 0f }
        backs.forEach { drawItem(it) }

        // the ghost, bobbing, with a little wiggle when tapped
        val gh = h * 0.46f
        val gw = gh * ghost.width / ghost.height
        val bob = sin(t * 2f) * 4f * d
        c.save()
        c.translate(cx, cy - 10f * d + bob)
        c.rotate(sin(t * 18f) * 9f * wiggle + sin(t * 1.3f) * 2f)
        ghostRect.set(-gw / 2, -gh / 2, gw / 2, gh / 2)
        c.drawBitmap(ghost, src, ghostRect, bmpPaint)
        c.restore()
        ghostRect.offset(cx, cy - 10f * d + bob)

        fronts.forEach { drawItem(it) }
        postInvalidateOnAnimation()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { downX = e.x; lastX = e.x; dragging = false; parent?.requestDisallowInterceptTouchEvent(false); return true }
            MotionEvent.ACTION_MOVE -> {
                if (abs(e.x - downX) > 12f * d) { dragging = true; parent?.requestDisallowInterceptTouchEvent(true) }
                if (dragging) { val dx = e.x - lastX; spin += dx / width * 3.1416f * 1.6f; vel = dx / width * 3.1416f * 1.6f / 0.016f * 0.3f }
                lastX = e.x
                return true
            }
            MotionEvent.ACTION_UP -> {
                val was = dragging; dragging = false
                if (!was) {
                    // front-most bubble under the finger wins
                    val hit = items.indices.filter { rects[it].contains(e.x, e.y) }.maxByOrNull { depths[it] }
                    if (hit != null) { pulse = hit; pulseT = 0f; onPick(hit) }
                    else if (ghostRect.contains(e.x, e.y)) wiggle = 1f
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> { dragging = false; return true }
        }
        return super.onTouchEvent(e)
    }
}
