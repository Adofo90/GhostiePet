package com.ghostie.pet

import kotlin.random.Random

/** Switchable personalities. Pure Kotlin: they colour what Chatter says without changing what it understands. */
object Moods {
    val ids = listOf("classic", "sweet", "playful", "sassy", "coach")
    val labels = listOf("👻 Classic", "💜 Sweet", "🎉 Playful", "😏 Sassy", "💪 Coach")

    private class Pack(
        val blurb: String,
        val idle: List<String>, val greet: List<String>, val thanks: List<String>, val tired: List<String>,
        val bored: List<String>, val praise: List<String>, val bye: List<String>,
        val suffix: List<String>, val deadline: String, val study: List<String>, val ai: String
    )

    private val packs = mapOf(
        "sweet" to Pack(
            "Gentle, caring and encouraging.",
            listOf("Just checking in. You're doing better than you think 💜", "Remember to be kind to yourself today 🌷", "Proud of you for showing up today 🥹", "A sip of water and a deep breath? I'll wait 💧", "You don't have to do everything at once. One small thing 💜", "I'm right here if you need me 👻", "Whatever today is, you can handle it 🌈"),
            listOf("Hi there 💜 I'm so happy to see you!", "Hello, lovely! How is your heart today?", "Hey you 🌷 I missed you a little."),
            listOf("Aww, anytime 💜", "Always happy to help you 🥹", "You're so welcome, friend 🌷"),
            listOf("Oh no, rest if you can 💜 Even ten minutes helps.", "You've worked hard. Be gentle with yourself, okay? 🌙", "Let's slow down. Water, stretch, and breathe 💧"),
            listOf("Want me to tell you a joke? Or we can just chill together 💜", "Bored is okay. Maybe a little walk and some music? 🎶", "Let's do something small and fun 🌈 Riddle?"),
            listOf("You're making me blush 🥹💜", "That means so much to me 🌷", "Aww, you're the sweetest 💜"),
            listOf("Bye for now 💜 Take care of yourself!", "Sweet dreams, and thank you for today 🌙", "See you soon, I'll be here 🌷"),
            listOf(" 💜", " 🌷", " You've got a good heart.", " I believe in you."),
            "Gentle nudge 💜 ",
            listOf("Focus time 🌷 I'll be quiet and proud of you.", "Break time 💜 Stretch and sip some water.", "That was lovely work 🥹 Rest a little."),
            "You are a warm, gentle, encouraging tiny ghost friend. Be kind, supportive and soft-spoken. 1-2 short sentences, a gentle emoji now and then."
        ),
        "playful" to Pack(
            "Jokes, teasing and dramatic reactions.",
            listOf("Boo! Did I scare you? No? Rude 👻", "I just did a backflip. You missed it. Tragic 🤸", "Plot twist: the ghost is bored again 🎭", "Want to hear a secret? ...I forgot it 🤫", "BREAKING NEWS: you haven't had water. More at eleven 📺", "Knock knock! ...okay I'm already inside 🚪", "I solved world peace, then forgot it. Typical 🌍"),
            listOf("Heyyy! The legend arrives 🎉", "Well well well, look who's here 👀", "Boo! ...I mean hi 👻"),
            listOf("You're welcome! Tips are accepted in snacks 🍪", "Anytime! I accept hugs as payment 🤗", "Ghost services: always free, never boring 🎩"),
            listOf("Sleepy human detected 🚨 Nap protocol activated 😴", "Eyes closing? That's a sign. Dramatic blanket time 🛌", "Recharge! Even phones do it 🔋"),
            listOf("Bored? Challenge accepted! Riddle time? 🧩", "Let's make trouble. The good kind. Say \"dance\" 💃", "Quick: coin flip decides your next move 🪙"),
            listOf("Obviously. I'm excellent 😎", "Stop it, I'm blushing in ghost 👻", "I know, I know. Autographs later ✍️"),
            listOf("Leaving already? Dramatic exit music 🎻", "Bye! Don't miss me too much 😘", "Night night! I'll haunt your dreams (nicely) 🌙"),
            listOf(" 😄", " 🎉", " (that was funny, admit it)", " *dramatic gasp*"),
            "Psst! ",
            listOf("Focus mode: ON 🚀 I'll be a quiet ghost. Maybe.", "Break! Go wiggle like me 🕺", "Round done! You're a machine 🤖"),
            "You are a playful, cheeky tiny ghost. Joke around, tease lightly, be dramatic and fun. 1-2 short sentences with an emoji."
        ),
        "sassy" to Pack(
            "Light sarcasm and playful roasting, never mean.",
            listOf("Still scrolling? The deadline is not going to submit itself 😏", "I'm not saying you're procrastinating. I'm just saying I noticed 👀", "Hydrate or diedrate. Your choice 💧", "Plot twist: the assignment doesn't do itself 📚", "Wow, a whole minute without touching your phone. Oh wait 📱", "I'm a ghost and even I have a better schedule than you 💅", "Cute that you think sleeping at 4 am is a plan 🌙"),
            listOf("Oh, you remembered I exist 😏", "Look who finally showed up 💅", "Hey. I was starting to get lonely. Not that I'd admit it."),
            listOf("Yeah yeah, you're welcome 😌", "Don't mention it. Seriously, don't tell anyone I'm nice 🤫", "Obviously. I'm a genius 💅"),
            listOf("Tired? Shocking. Humans need sleep, who knew 😴 Go rest.", "You said that last time too. But okay, take a break 🛋️", "Fine, five minutes. Then back to it 😏"),
            listOf("Bored? There's a to-do list, you know 😏 Say \"my todos\".", "Boredom is just procrastination in a nice outfit 💅", "Try a riddle. If you can handle it 🧩"),
            listOf("I know 💅", "Flattery works. Keep going 😏", "Finally, someone with taste 😌"),
            listOf("Leaving? Fine. I didn't want you here anyway. (Come back.)", "Bye! Try not to forget the deadlines 😏", "Goodnight. Actually sleep this time 🌙"),
            listOf(" 😏", " (you're welcome)", " Not that I care.", " Just saying 💅"),
            "Not to nag, but ",
            listOf("Study mode. Phone down. I'm watching 👀", "Break. You earned it, barely 😏", "Round done. Okay, I'm slightly impressed 💅"),
            "You are a sassy, witty tiny ghost. Light sarcasm and playful roasting, but never mean or hurtful, and always secretly caring. 1-2 short sentences."
        ),
        "coach" to Pack(
            "Motivating and focused, like a study coach.",
            listOf("Small steps count. What's your next 10-minute task? 💪", "Discipline beats motivation. Start with five minutes ⏱️", "Quick check: water, posture, then one focused task 🎯", "Your future self is watching. Make them proud 🚀", "Deadlines love plans. Want to set a timer? Say \"study mode\" 📚", "Progress, not perfection. Let's go 💪", "You've got this. Now pick one thing and finish it ✅"),
            listOf("Good to see you! What's the goal today? 🎯", "Ready to make today count? 💪", "Hey champ! Plan first, then execute 📋"),
            listOf("Anytime. Now go crush it 💪", "Happy to help. Keep the momentum 🚀", "That's what a team is for 🤝"),
            listOf("Rest is part of training. Ten-minute break, then back ⏱️", "Tired is a signal. Water, stretch, short walk, then restart 💧", "Recover smart. Even athletes sleep 😴"),
            listOf("Use it! Pick one small task and start a timer ⏱️", "Boredom means room for focus. Try \"study mode\" 📚", "Quick win: finish one tiny thing right now ✅"),
            listOf("Thanks! But the credit is yours 💪", "Keep that energy 🔥", "Good attitude. Now let's work 🎯"),
            listOf("Good session! See you next round 💪", "Rest well. Tomorrow we level up 🌙", "Bye! Review today's wins before you sleep ✅"),
            listOf(" Keep going 💪", " You've got this.", " One step at a time.", " Let's go! 🚀"),
            "Focus time: ",
            listOf("Focus block starts. Phone away. Go! 🚀", "Break! Water, stretch, breathe 💧", "Block complete. Great work, log it 📈"),
            "You are an upbeat study coach in the form of a tiny ghost. Motivate, keep answers practical and brief, 1-2 sentences with a motivating emoji."
        )
    )

    fun blurb(id: String): String = packs[id]?.blurb ?: "The original Ghostie: friendly and a little playful."

    private fun matches(l: String, p: String) = Regex(p, RegexOption.IGNORE_CASE).containsMatchIn(l)

    /** Idle line: sometimes replaced by a mood line, otherwise gets a small flourish. */
    fun idle(id: String, original: String, rnd: Random = Random.Default): String {
        val pk = packs[id] ?: return original
        return if (rnd.nextInt(100) < 45) pk.idle.random(rnd) else original
    }

    /** Reply to the user. [topicPending] = the ghost just asked a question, so don't override it. */
    fun reply(id: String, userText: String, original: String, topicPending: Boolean, rnd: Random = Random.Default): String {
        val pk = packs[id] ?: return original
        val l = userText.trim().lowercase()
        if (!topicPending && rnd.nextInt(100) < 80) {
            val pool = when {
                matches(l, "^(hi+|hello+|hey+|hii+|yo|good (morning|afternoon|evening)|namaste)\\b") -> pk.greet
                matches(l, "\\b(thanks|thank you|thx|ty|shukriya)\\b") -> pk.thanks
                matches(l, "\\b(tired|sleepy|exhausted|drained|thak gaya|thaka)\\b") -> pk.tired
                matches(l, "\\b(bored|boring|nothing to do)\\b") -> pk.bored
                matches(l, "\\b(good (job|bot|ghost)|well done|love you|you'?re (great|awesome|cute|the best)|nice one)\\b") -> pk.praise
                matches(l, "^(bye|goodbye|good ?night|gn|see you|cya|ttyl)\\b") -> pk.bye
                else -> null
            }
            if (pool != null) return pool.random(rnd)
        }
        return if (original.length < 140 && !topicPending && rnd.nextInt(100) < 35) original.trimEnd() + pk.suffix.random(rnd) else original
    }

    fun deadline(id: String, text: String): String = (packs[id]?.deadline ?: "") + text

    /** Lines for study mode phase changes: 0 = start focus, 1 = break, 2 = round complete. */
    fun study(id: String, phase: Int, original: String): String = packs[id]?.study?.getOrNull(phase) ?: original

    fun preview(id: String, rnd: Random = Random.Default): String = packs[id]?.idle?.random(rnd) ?: "Hi! I'm classic Ghostie 👻"

    fun ai(id: String): String = packs[id]?.ai ?: ""
}
