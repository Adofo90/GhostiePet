package com.ghostie.pet

/** Tiny calculator for "calculate 12*(3+4)" - no libraries. */
object Calc {
    fun eval(raw: String): Double? = try {
        val s = raw.lowercase().replace('x', '*').replace('×', '*').replace('÷', '/').replace(" ", "").replace(",", "")
        val p = Parser(s)
        val v = p.expr()
        if (p.pos != s.length || v.isNaN() || v.isInfinite()) null else v
    } catch (e: Exception) { null }

    fun format(v: Double): String =
        if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString()
        else String.format(java.util.Locale.US, "%.4f", v).trimEnd('0').trimEnd('.')

    private class Parser(val s: String) {
        var pos = 0
        fun peek() = if (pos < s.length) s[pos] else '\u0000'
        fun expr(): Double {
            var v = term()
            while (peek() == '+' || peek() == '-') { val op = s[pos++]; val r = term(); v = if (op == '+') v + r else v - r }
            return v
        }
        fun term(): Double {
            var v = power()
            while (peek() == '*' || peek() == '/' || peek() == '%') {
                val op = s[pos++]; val r = power()
                v = when (op) { '*' -> v * r; '/' -> v / r; else -> v % r }
            }
            return v
        }
        fun power(): Double {
            val b = unary()
            if (peek() == '^') { pos++; return Math.pow(b, power()) }
            return b
        }
        fun unary(): Double {
            if (peek() == '-') { pos++; return -unary() }
            if (peek() == '+') { pos++; return unary() }
            return primary()
        }
        fun primary(): Double {
            if (peek() == '(') {
                pos++
                val v = expr()
                if (peek() != ')') throw IllegalArgumentException("missing )")
                pos++
                return v
            }
            val st = pos
            while (peek().isDigit() || peek() == '.') pos++
            if (st == pos) throw IllegalArgumentException("number expected")
            return s.substring(st, pos).toDouble()
        }
    }
}
