package com.ghostie.pet

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.ByteArrayOutputStream
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.util.zip.ZipInputStream

/** Creates the calendar reminder + log entry for a detected submission (used by the live watcher and the importer). */
object ReminderMaker {
    private fun labelFor(s: SettingsStore, text: String, sub: Submission): String {
        val subject = SubjectMatcher.classify(text, SubjectMatcher.parse(s.subjects))
        return if (subject != SubjectMatcher.UNSORTED) subject else sub.summary.take(40)
    }

    fun isDuplicate(s: SettingsStore, text: String, sub: Submission): Boolean {
        val label = labelFor(s, text, sub)
        return s.logs().any { it.due == sub.deadline.toString() && ReminderLog.label(it) == label }
    }

    /** Returns the saved entry, or null if the calendar could not be written. */
    fun add(ctx: Context, s: SettingsStore, group: String, text: String, sub: Submission, now: LocalDateTime = LocalDateTime.now()): LogEntry? {
        val at = SubmissionParser.plan(sub, now)
        val due = SubmissionParser.dueText(sub, at)
        val label = labelFor(s, text, sub)
        val title = "📌 Submission due $due: $label"
        val description = "From WhatsApp group \"$group\":\n${sub.summary}" + (sub.time?.let { "\nDeadline time: $it" } ?: "")
        val start = at.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val id = CalendarHelper.insert(ctx, title, description, start, 30, 0) ?: return null
        val entry = LogEntry(System.currentTimeMillis(), group, title, sub.deadline.toString(), id)
        s.addLog(entry)
        return entry
    }
}

/** Catch-up path that does not depend on notifications: scan an exported chat or a shared message. */
object ChatImporter {
    data class Report(val messages: Int, val found: Int, val added: Int, val duplicates: Int, val needCalendar: Boolean)

    fun importText(ctx: Context, group: String, raw: String, today: LocalDate = LocalDate.now()): Report {
        val s = SettingsStore(ctx)
        if (!CalendarHelper.hasPermission(ctx)) return Report(0, 0, 0, 0, true)
        var msgs = ChatExport.parse(raw)
        if (msgs.isEmpty() && raw.isNotBlank()) {
            // A single shared message (or plain text), not an export file.
            msgs = raw.lines().filter { it.isNotBlank() }.map { ChatMsg(today, "", it) }
        }
        msgs = msgs.takeLast(600)
        var found = 0
        var added = 0
        var dup = 0
        for (m in msgs) {
            val sub = SubmissionParser.parse(m.text, today, m.date) ?: continue
            found++
            if (ReminderMaker.isDuplicate(s, m.text, sub) || !s.markSeen((group + "|" + m.text).hashCode())) {
                dup++
                continue
            }
            if (ReminderMaker.add(ctx, s, group, m.text, sub) != null) added++
        }
        return Report(msgs.size, found, added, dup, false)
    }

    /** Reads a .txt export or a .zip export (first .txt inside). Returns (group name, text). */
    fun read(ctx: Context, uri: Uri): Pair<String, String> {
        var name = "WhatsApp chat"
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0)?.let { name = it }
        }
        val group = name.removeSuffix(".zip").removeSuffix(".txt")
            .removePrefix("WhatsApp Chat with ").removePrefix("WhatsApp Chat - ").trim().ifEmpty { "WhatsApp chat" }
        val limit = 20 * 1024 * 1024
        val bytes: ByteArray = ctx.contentResolver.openInputStream(uri)?.use { input ->
            if (name.endsWith(".zip", true)) {
                val zin = ZipInputStream(input)
                var data = ByteArray(0)
                while (true) {
                    val entry = zin.nextEntry ?: break
                    if (entry.name.endsWith(".txt", true)) {
                        val bos = ByteArrayOutputStream()
                        val buf = ByteArray(8192)
                        while (bos.size() < limit) {
                            val n = zin.read(buf)
                            if (n < 0) break
                            bos.write(buf, 0, n)
                        }
                        data = bos.toByteArray()
                        break
                    }
                }
                data
            } else {
                input.readBytes().let { if (it.size > limit) it.copyOf(limit) else it }
            }
        } ?: ByteArray(0)
        return group to String(bytes, Charsets.UTF_8)
    }

    fun describe(group: String, r: Report): String = when {
        r.needCalendar -> "I need Calendar access first. Open the Ghostie app, tap Allow next to Calendar, then share again."
        r.found == 0 -> "I read ${r.messages} messages from \"$group\" but found no upcoming submission dates."
        else -> buildString {
            append("\"$group\": found ${r.found} submission message(s).\n")
            append("• Reminders added: ${r.added}\n")
            if (r.duplicates > 0) append("• Already had: ${r.duplicates}\n")
            append("\nSee them under Upcoming submissions in the app.")
        }
    }
}
