package com.ghostie.pet

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.ByteArrayOutputStream
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.zip.ZipInputStream

sealed class AddResult {
    data class Added(val entry: LogEntry, val times: List<LocalDateTime>, val dueNow: Boolean) : AddResult()
    object NoCalendar : AddResult()
    object Passed : AddResult()
}

/** Creates the calendar event (on the deadline) with alerts, plus a log entry. Shared by every detection path. */
object ReminderMaker {
    private fun labelFor(s: SettingsStore, text: String, sub: Submission): String {
        if (sub.kind == DeadlineKind.REGISTRATION) return sub.name ?: sub.summary.take(40)
        val subject = SubjectMatcher.classify(text, SubjectMatcher.parse(s.subjects))
        return if (subject != SubjectMatcher.UNSORTED) subject else sub.summary.take(40)
    }

    /** True if this deadline is already listed, or if the user threw a similar one in the bin before. */
    fun isDuplicate(s: SettingsStore, text: String, sub: Submission, ctx: Context? = null, group: String = ""): Boolean {
        val label = labelFor(s, text, sub)
        if (ctx != null && LearnStore.get(ctx).isBlocked(group, label)) return true
        return s.logs().any { it.due == sub.deadline.toString() && ReminderLog.label(it) == label }
    }

    fun add(ctx: Context, s: SettingsStore, group: String, text: String, sub: Submission, now: LocalDateTime = LocalDateTime.now()): AddResult {
        if (!CalendarHelper.hasPermission(ctx)) return AddResult.NoCalendar
        val start = SubmissionParser.eventStart(sub)
        if (!start.isAfter(now)) return AddResult.Passed
        val rs = SubmissionParser.reminderTimes(sub, now, s.remind2d, s.remindMorning)
        val label = labelFor(s, text, sub)
        val title = if (sub.kind == DeadlineKind.REGISTRATION) "📝 Registration closes: $label" else "📌 Submission due: $label"
        val description = "From WhatsApp group \"$group\":\n${sub.summary}" + (sub.time?.let { "\nDeadline time: $it" } ?: "")
        val startMs = start.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val minutes = rs.times.map { Duration.between(it, start).toMinutes().toInt() }
        val id = CalendarHelper.insert(ctx, title, description, startMs, 30, minutes) ?: return AddResult.NoCalendar
        val entry = LogEntry(System.currentTimeMillis(), group, title, sub.deadline.toString(), id, startMs, text.replace(Regex("\\s+"), " ").trim().take(220))
        s.addLog(entry)
        ReminderAlarms.scheduleTimes(ctx, entry, rs.times)
        ReminderAlarms.scheduleFinal(ctx, entry)
        GhostieWidget.refresh(ctx)
        return AddResult.Added(entry, rs.times, rs.dayBeforePassed)
    }

    /** Logs the outcome and notifies the user. Returns true if a reminder was created. */
    fun report(ctx: Context, source: String, group: String, sub: Submission, result: AddResult, now: LocalDateTime = LocalDateTime.now()): Boolean {
        when (result) {
            is AddResult.Added -> {
                val fmt = DateTimeFormatter.ofPattern("EEE d MMM, h:mm a", Locale.ENGLISH)
                val alerts = if (result.times.isEmpty()) "no future alerts left" else result.times.joinToString("; ") { it.format(fmt) }
                val urgent = if (result.dueNow) "⏰ Due ${SubmissionParser.dueText(sub, now)}! " else ""
                ActivityLog.add(ctx, source, "Reminder set: ${ReminderLog.label(result.entry)} due ${sub.deadline} (${result.times.size} alert(s))")
                Notifier.post(ctx, "Reminder added", urgent + result.entry.title + "\nAlerts: " + alerts)
                return true
            }
            is AddResult.NoCalendar -> {
                ActivityLog.add(ctx, source, "Found a deadline in \"$group\" but couldn't use the calendar")
                Notifier.post(ctx, "Deadline spotted in $group", "I need Calendar access to add a reminder. Open Ghostie and allow it.\n${sub.summary}")
            }
            is AddResult.Passed -> ActivityLog.add(ctx, source, "Skipped a deadline that has already passed (${sub.deadline})")
        }
        return false
    }

    /** Adds one more alert [hours] from now. Returns a message for the user. */
    fun snooze(ctx: Context, e: LogEntry, hours: Int = 3): String {
        if (e.start <= 0L) return "This older reminder can't be snoozed."
        val minutes = ((e.start - (System.currentTimeMillis() + hours * 3_600_000L)) / 60_000L).toInt()
        if (minutes <= 0) return "Too close to the deadline to snooze."
        return if (CalendarHelper.addReminder(ctx, e.eventId, minutes)) "I'll remind you again in $hours hours." else "Couldn't snooze."
    }
}

/** Catch-up path that does not depend on notifications: scan an exported chat or a shared message. */
object ChatImporter {
    data class Report(val messages: Int, val found: Int, val added: Int, val duplicates: Int, val needCalendar: Boolean)

    fun importText(ctx: Context, group: String, raw: String, today: LocalDate = LocalDate.now()): Report {
        val s = SettingsStore(ctx)
        if (!CalendarHelper.hasPermission(ctx)) {
            // No calendar yet, but the words are still worth learning.
            if (s.learnGroups) { SentenceStore.learn(ctx, raw.lines().take(800).joinToString("\n"), 1); SentenceStore.save(ctx) }
            return Report(0, 0, 0, 0, true)
        }
        var msgs = ChatExport.parse(raw)
        if (msgs.isEmpty() && raw.isNotBlank()) {
            // A single shared message (or plain text), not an export file.
            msgs = raw.lines().filter { it.isNotBlank() }.map { ChatMsg(today, "", it) }
        }
        msgs = msgs.takeLast(600)
        var found = 0
        var added = 0
        var dup = 0
        for (m in msgs) {
            if (s.learnGroups) SentenceStore.learn(ctx, m.text, 1)
            val sub = SubmissionParser.parse(m.text, today, m.date) ?: continue
            found++
            if (ReminderMaker.isDuplicate(s, m.text, sub, ctx, group) || !s.markSeen((group + "|" + m.text).hashCode())) {
                dup++
                continue
            }
            if (ReminderMaker.add(ctx, s, group, m.text, sub).let { it is AddResult.Added }) added++
        }
        ActivityLog.add(ctx, "Import", "Scanned \"$group\": ${msgs.size} messages, $found deadline(s), $added added")
        if (s.learnGroups) SentenceStore.save(ctx)
        return Report(msgs.size, found, added, dup, false)
    }

    /** Reads a .txt export or a .zip export (first .txt inside). Returns (group name, text). */
    fun read(ctx: Context, uri: Uri): Pair<String, String> {
        var name = "WhatsApp chat"
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0)?.let { name = it }
        }
        val group = name.removeSuffix(".zip").removeSuffix(".txt")
            .removePrefix("WhatsApp Chat with ").removePrefix("WhatsApp Chat - ").trim().ifEmpty { "WhatsApp chat" }
        val limit = 20 * 1024 * 1024
        val bytes: ByteArray = ctx.contentResolver.openInputStream(uri)?.use { input ->
            if (name.endsWith(".zip", true)) {
                val zin = ZipInputStream(input)
                var data = ByteArray(0)
                while (true) {
                    val entry = zin.nextEntry ?: break
                    if (entry.name.endsWith(".txt", true)) {
                        val bos = ByteArrayOutputStream()
                        val buf = ByteArray(8192)
                        while (bos.size() < limit) {
                            val n = zin.read(buf)
                            if (n < 0) break
                            bos.write(buf, 0, n)
                        }
                        data = bos.toByteArray()
                        break
                    }
                }
                data
            } else {
                input.readBytes().let { if (it.size > limit) it.copyOf(limit) else it }
            }
        } ?: ByteArray(0)
        return group to String(bytes, Charsets.UTF_8)
    }

    fun describe(group: String, r: Report): String = when {
        r.needCalendar -> "I need Calendar access first. Open the Ghostie app, tap Allow next to Calendar, then share again."
        r.found == 0 -> "I read ${r.messages} messages from \"$group\" but found no upcoming submission dates."
        else -> buildString {
            append("\"$group\": found ${r.found} submission message(s).\n")
            append("• Reminders added: ${r.added}\n")
            if (r.duplicates > 0) append("• Already had: ${r.duplicates}\n")
            append("\nSee them under Upcoming submissions in the app.")
        }
    }
}
