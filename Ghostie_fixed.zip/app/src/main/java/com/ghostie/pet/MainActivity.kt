package com.ghostie.pet

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.DragEvent
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ProgressBar
import android.os.PowerManager
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var s: SettingsStore
    private lateinit var content: LinearLayout
    private lateinit var subjectsField: EditText
    private lateinit var groupsField: EditText
    private lateinit var keyField: EditText
    private lateinit var vipField: EditText
    private lateinit var rulesField: EditText
    private var builtUnlocked = -1
    private lateinit var baseField: EditText
    private lateinit var modelField: EditText
    private lateinit var urgentField: EditText
    private lateinit var logBox: LinearLayout
    private lateinit var eventsBox: LinearLayout
    private lateinit var activityBox: LinearLayout
    private lateinit var docBox: LinearLayout
    private lateinit var learnBox: LinearLayout
    private lateinit var binZone: TextView
    private var section = "home"
    private var currentTab = "home"
    private val cardSections = LinkedHashMap<View, String>()
    private val hiddenCards = HashSet<View>()
    private val tabButtons = LinkedHashMap<String, TextView>()
    private val permChecks = mutableListOf<() -> Boolean>()
    private var pendingDrop: (() -> Unit)? = null
    private var dropped = false
    private val refreshers = mutableListOf<() -> Unit>()

    // Palette
    private val bg = Color.parseColor("#170E2B")
    private val card = Color.parseColor("#241640")
    private val cardStroke = Color.parseColor("#3A2763")
    private val field = Color.parseColor("#1B1033")
    private val textMain = Color.parseColor("#F3ECFF")
    private val textSub = Color.parseColor("#B9A8D9")
    private val accent = Color.parseColor("#A978E8")
    private val good = Color.parseColor("#7BE0A4")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        s = SettingsStore(this)
        build()
    }

    override fun onResume() {
        super.onResume()
        if (builtUnlocked >= 0 && builtUnlocked != Skins.all.count { Skins.unlocked(it, s.chatCount) }) { recreate(); return }
        refresh()
    }

    override fun onPause() {
        SentenceStore.save(this)
        saveFields()
        super.onPause()
    }

    private fun refresh() {
        refreshers.forEach { it() }
        GhostieWidget.refresh(this)
        renderLog()
        renderEvents()
        renderActivity()
        renderLearned()
    }

    private fun saveFields() {
        s.subjects = subjectsField.text.toString()
        s.watchedGroups = groupsField.text.toString()
        s.key = keyField.text.toString().trim()
        s.aiBase = baseField.text.toString()
        s.aiModel = modelField.text.toString()
        s.groupRules = rulesField.text.toString()
        s.callVips = vipField.text.toString()
        s.callUrgent = urgentField.text.toString()
    }

    // ---- small UI toolkit -----------------------------------------------------------------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    /** Long-press a row, drag it to the bin that appears, and let go. */
    private fun makeDraggable(view: View, onDrop: () -> Unit) {
        view.setOnLongClickListener { v ->
            pendingDrop = onDrop
            v.alpha = 0.4f
            @Suppress("DEPRECATION")
            v.startDragAndDrop(ClipData.newPlainText("ghostie", "bin"), View.DragShadowBuilder(v), v, 0)
            true
        }
    }

    /** Paper-in-the-bin: spin, shrink and fade, then do the delete. */
    private fun crumple(v: View, done: () -> Unit) {
        v.animate().scaleX(0.1f).scaleY(0.1f).rotation(300f).alpha(0f).setDuration(320).withEndAction { done() }.start()
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        if (bold) tv.setTypeface(tv.typeface, Typeface.BOLD)
        return tv
    }

    private fun match() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

    private fun card(title: String, subtitle: String? = null): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = rounded(card, 18, cardStroke)
        c.setPadding(dp(16), dp(14), dp(16), dp(16))
        c.addView(label(title, 17f, textMain, true))
        if (subtitle != null) {
            val sub = label(subtitle, 13f, textSub)
            sub.setPadding(0, dp(2), 0, dp(8))
            c.addView(sub)
        }
        val lp = match()
        lp.topMargin = dp(12)
        content.addView(c, lp)
        cardSections[c] = section
        return c
    }

    private fun button(text: String, filled: Boolean = true, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 14f
        b.stateListAnimator = null
        b.minHeight = dp(44)
        b.minimumHeight = dp(44)
        styleButton(b, filled)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun styleButton(b: Button, filled: Boolean) {
        b.setTextColor(if (filled) Color.WHITE else accent)
        b.background = if (filled) rounded(accent, 12) else rounded(Color.TRANSPARENT, 12, accent)
    }

    private fun buttonRow(parent: LinearLayout, vararg buttons: Button) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (b in buttons) {
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), dp(4), dp(3), dp(4))
            row.addView(b, lp)
        }
        parent.addView(row, match())
    }

    private fun switchRow(parent: LinearLayout, text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val sw = SwitchCompat(this)
        sw.text = text
        sw.setTextColor(textMain)
        sw.isChecked = checked
        sw.setPadding(0, dp(6), 0, dp(6))
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        parent.addView(sw, match())
    }

    private fun spinnerRow(parent: LinearLayout, title: String, options: List<String>, values: List<Int>, current: Int, onPick: (Int) -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(label(title, 15f, textMain), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        sp.setSelection(values.indexOf(current).coerceAtLeast(0))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                onPick(values[position])
            }
        }
        row.addView(sp, LinearLayout.LayoutParams(dp(140), LinearLayout.LayoutParams.WRAP_CONTENT))
        parent.addView(row, match())
    }

    private fun textField(hint: String, value: String, multiline: Boolean, lines: Int = 1, password: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(value)
        e.setTextColor(textMain)
        e.setHintTextColor(textSub)
        e.textSize = 13f
        e.background = rounded(field, 12, cardStroke)
        e.setPadding(dp(12), dp(10), dp(12), dp(10))
        var type = InputType.TYPE_CLASS_TEXT
        if (multiline) {
            type = type or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            e.minLines = lines
            e.gravity = Gravity.TOP or Gravity.START
        }
        if (password) type = type or InputType.TYPE_TEXT_VARIATION_PASSWORD
        e.inputType = type
        return e
    }

    private fun fieldLp(): LinearLayout.LayoutParams {
        val lp = match()
        lp.topMargin = dp(6)
        return lp
    }

    // ---- permissions ----------------------------------------------------------------------

    private fun hasNotificationPermission() =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun hasCalendar() = CalendarHelper.hasPermission(this)
    private fun ensureCalendar(): Boolean {
        if (hasCalendar()) return true
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR), 3)
        toast("Allow Calendar, then tap again")
        return false
    }

    private fun hasAccessibility(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.startsWith("$packageName/") }
    }

    private fun hasContactsAndPhone() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED

    private fun hasMic() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun hasListener() = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun askFileAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 2
            )
        }
    }

    private fun permRow(parent: LinearLayout, title: String, hint: String, isOn: () -> Boolean, request: () -> Unit) {
        permChecks.add(isOn)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(6), 0, dp(6))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(label(title, 15f, textMain))
        col.addView(label(hint, 12f, textSub))
        val b = button("Allow") { request() }
        row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(b, LinearLayout.LayoutParams(dp(92), dp(40)))
        parent.addView(row, match())
        refreshers.add {
            if (isOn()) {
                b.text = "✓ On"
                b.setTextColor(good)
                b.background = rounded(Color.TRANSPARENT, 12, good)
            } else {
                b.text = "Allow"
                styleButton(b, true)
            }
        }
    }

    // ---- screen ---------------------------------------------------------------------------

    private fun petIntent(action: String? = null): Intent {
        val i = Intent(this, PetOverlayService::class.java)
        if (action != null) i.action = action
        return i
    }

    private fun startPet() {
        saveFields()
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            toast("Allow \"Display over other apps\", then tap Start again")
        } else {
            s.enabled = true
            startForegroundService(petIntent())
            toast("Ghostie is ready 👻")
        }
    }

    private fun pauseFor(minutes: Long, label: String) {
        s.quietUntil = System.currentTimeMillis() + minutes * 60_000L
        toast("Quiet for $label")
    }

    private fun applyTab() {
        for ((c, sec) in cardSections) c.visibility = if (sec == currentTab && c !in hiddenCards) View.VISIBLE else View.GONE
        for ((key, b) in tabButtons) {
            val on = key == currentTab
            b.setTextColor(if (on) Color.WHITE else textSub)
            b.background = if (on) rounded(accent, 20) else rounded(Color.TRANSPARENT, 20, cardStroke)
        }
    }

    private fun showTab(key: String) {
        currentTab = key
        s.tab = key
        applyTab()
    }

    private fun build() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        scroll.isFillViewport = true
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(16), dp(16), dp(24))
        scroll.addView(content)
        val root = FrameLayout(this)
        root.addView(scroll, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        binZone = TextView(this)
        binZone.text = "🗑️"
        binZone.textSize = 34f
        binZone.gravity = Gravity.CENTER
        binZone.background = rounded(Color.parseColor("#33FFFFFF"), 40, accent)
        binZone.visibility = View.GONE
        root.addView(binZone, FrameLayout.LayoutParams(dp(84), dp(84), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(120) })
        binZone.setOnDragListener { v, ev ->
            when (ev.action) {
                DragEvent.ACTION_DRAG_STARTED -> { dropped = false; v.visibility = View.VISIBLE; v.alpha = 0f; v.animate().alpha(1f).setDuration(150).start(); true }
                DragEvent.ACTION_DRAG_ENTERED -> { v.animate().scaleX(1.35f).scaleY(1.35f).setDuration(120).start(); true }
                DragEvent.ACTION_DRAG_EXITED -> { v.animate().scaleX(1f).scaleY(1f).setDuration(120).start(); true }
                DragEvent.ACTION_DROP -> {
                    dropped = true
                    val cb = pendingDrop
                    pendingDrop = null
                    val dragged = ev.localState as? View
                    if (dragged != null) crumple(dragged) { cb?.invoke() } else cb?.invoke()
                    true
                }
                DragEvent.ACTION_DRAG_ENDED -> {
                    v.visibility = View.GONE
                    v.scaleX = 1f; v.scaleY = 1f
                    if (!dropped) (ev.localState as? View)?.alpha = 1f
                    pendingDrop = null
                    true
                }
                else -> true
            }
        }
        setContentView(root)
        // Android 15 draws apps edge-to-edge, so keep content clear of the status/navigation bars.
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }

        // Header
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val ghost = ImageView(this)
        ghost.setImageResource(R.drawable.ghost_pet)
        ghost.scaleType = ImageView.ScaleType.FIT_CENTER
        header.addView(ghost, LinearLayout.LayoutParams(dp(64), dp(64)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(14), 0, 0, 0)
        titles.addView(label("Ghostie", 28f, textMain, true))
        titles.addView(label("Your tiny floating study buddy", 14f, textSub))
        header.addView(titles)
        content.addView(header, match())

        // Tabs keep the long list of settings short.
        val tabs = listOf("home" to "🏠 Home", "setup" to "⚙️ Setup", "docs" to "📂 Docs", "brain" to "🧠 Brain", "more" to "✨ More")
        val tabScroll = HorizontalScrollView(this)
        tabScroll.isHorizontalScrollBarEnabled = false
        val tabRow = LinearLayout(this)
        tabRow.orientation = LinearLayout.HORIZONTAL
        tabRow.setPadding(0, dp(14), 0, dp(2))
        for ((key, title) in tabs) {
            val b = TextView(this)
            b.text = title
            b.textSize = 14f
            b.setPadding(dp(16), dp(8), dp(16), dp(8))
            b.setOnClickListener { showTab(key) }
            tabButtons[key] = b
            tabRow.addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) })
        }
        tabScroll.addView(tabRow)
        content.addView(tabScroll, match())

        // Setup progress banner (hidden once everything is on)
        section = "home"
        val banner = card("Finish setting up")
        val bannerText = label("", 13f, textSub)
        banner.addView(bannerText, match())
        val setupBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        setupBar.progressTintList = android.content.res.ColorStateList.valueOf(accent)
        setupBar.progressBackgroundTintList = android.content.res.ColorStateList.valueOf(cardStroke)
        banner.addView(setupBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(8)).apply { topMargin = dp(8); bottomMargin = dp(8) })
        buttonRow(banner, button("Open Setup") { showTab("setup") })
        refreshers.add {
            val done = permChecks.count { it() }
            val total = permChecks.size
            setupBar.max = maxOf(1, total)
            setupBar.progress = done
            bannerText.text = "$done of $total ready. Ghostie works best with everything switched on."
            val hide = total == 0 || done == total
            if (hide) hiddenCards.add(banner) else hiddenCards.remove(banner)
            applyTab()
        }

        // Pet controls
        section = "home"
        val pet = card("👻 Pet")
        buttonRow(pet, button("Start") { startPet() }, button("Stop", false) { stopService(petIntent()); toast("Ghostie stopped") })
        buttonRow(
            pet,
            button("Summon now", false) { startForegroundService(petIntent(PetOverlayService.ACTION_SUMMON)) },
            button("Bring on screen", false) {
                s.resetPosition()
                startForegroundService(petIntent(PetOverlayService.ACTION_RESET))
            }
        )

        // Upcoming submissions (filled by renderLog)
        val upcoming = card("📌 Upcoming deadlines", "Submissions and event registrations Ghostie spotted in your groups. Each one gets a calendar event with alerts (the day before, and optionally 2 days before and the morning of). Long-press one and drag it to the bin to delete it - Ghostie learns to ignore similar ones.")
        logBox = LinearLayout(this)
        logBox.orientation = LinearLayout.VERTICAL
        upcoming.addView(logBox, match())

        val evCard = card("🗓️ Recent events", "Events you added by chatting with Ghostie. Tap one to edit its name, date, time or category. Long-press and drag it to the bin to delete it.")
        eventsBox = LinearLayout(this)
        eventsBox.orientation = LinearLayout.VERTICAL
        evCard.addView(eventsBox, match())

        // Setup checklist
        section = "setup"
        val setup = card("✅ Setup", "Switch on what you want to use. Green means ready.")
        setup.addView(label("Installed from a shared file? Android may grey out Accessibility and Notification access. Open App info, tap the ⋮ menu (top right) and choose \"Allow restricted settings\", then switch them on. Also allow Calendar and Notifications here, or events and alerts can't work.", 12f, textSub).apply { setPadding(0, 0, 0, dp(6)) })
        buttonRow(setup, button("Open App info", false) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        permRow(setup, "Display over other apps", "Shows the floating ghost", { Settings.canDrawOverlays(this) }) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        permRow(setup, "Notifications", "Ghostie's own alerts", { hasNotificationPermission() }) {
            if (Build.VERSION.SDK_INT >= 33) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        permRow(setup, "File access", "To organize WhatsApp documents", { DocOrganizer.hasAccess(this) }) { askFileAccess() }
        permRow(setup, "Calendar", "To add events and reminders", { hasCalendar() }) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR), 3)
        }
        permRow(setup, "Contacts & calls", "So \"call Mom\" works (dials instantly)", { hasContactsAndPhone() }) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE), 4)
        }
        permRow(setup, "Microphone", "Hold the ghost (or tap 🎙 in chat) and talk to it", { hasMic() }) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 5)
        }
        permRow(setup, "Battery: no restrictions", "Stops Android from closing the ghost", {
            (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        }) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        }
        permRow(setup, "Notification access", "Reads new messages when WhatsApp is closed", { hasListener() }) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        permRow(setup, "Read open chats", "Catches messages while you have the group open", { hasAccessibility() }) {
            AlertDialog.Builder(this)
                .setTitle("Read open chats")
                .setMessage(
                    "Ghostie will only look at WhatsApp, and only act when one of your watched groups is on screen. Nothing leaves your phone.\n\n" +
                        "In the next screen open \"Installed apps\" (or \"Downloaded apps\"), choose \"Ghostie chat reader\" and switch it on.\n\n" +
                        "If Android says \"Restricted setting\": phone Settings > Apps > Ghostie > ⋮ (top right) > \"Allow restricted settings\", then try again."
                )
                .setPositiveButton("Continue") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                .setNegativeButton("Cancel", null)
                .show()
        }

        setup.addView(label("On Xiaomi/Poco phones also switch on Autostart for Ghostie (App settings > Autostart), or the system may stop it in the background.", 12f, textSub).apply { setPadding(0, dp(4), 0, dp(4)) })
        buttonRow(setup, button("Open Ghostie's app settings", false) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })

        // Group reminders
        val groups = card(
            "💬 Group reminders",
            "Ghostie watches the groups you list - through notifications when WhatsApp is closed, and by reading the screen when the group is open. A submission or registration deadline becomes a calendar event with reminders."
        )
        switchRow(groups, "Watch groups", s.watchEnabled) { s.watchEnabled = it }
        switchRow(groups, "Also warn 2 days before", s.remind2d) { s.remind2d = it }
        switchRow(groups, "Nudge on the morning it is due", s.remindMorning) { s.remindMorning = it }
        val status = label("", 12f, textSub)
        status.setPadding(0, dp(4), 0, dp(4))
        groups.addView(status, match())
        refreshers.add {
            fun ago(k: String): String {
                val tm = ActivityLog.lastTime(this, k) ?: return "never"
                val mins = (System.currentTimeMillis() - tm) / 60_000L
                return if (mins < 1) "just now" else if (mins < 60) "$mins min ago" else if (mins < 1440) "${mins / 60} h ago" else "${mins / 1440} d ago"
            }
            status.text = "Last WhatsApp notification heard: ${ago("Notification")}\nLast open chat read: ${ago("Open chat")}"
        }
        groupsField = textField("Group names, one per line (e.g. CSE 3A)", s.watchedGroups, true, 3)
        groups.addView(groupsField, fieldLp())
        groups.addView(label("Only messages that arrive while this is on can be seen. Keep Ghostie's battery setting on \"Unrestricted\".", 12f, textSub).apply { setPadding(0, dp(6), 0, dp(4)) })
        val testField = textField("Try a message, e.g. Last date to register for Hackathon is 12 Nov", "", false)
        groups.addView(testField, fieldLp())
        buttonRow(groups, button("Test message", false) {
            val text = testField.text.toString()
            val sub = SubmissionParser.parse(text, LocalDate.now())
            val msg = if (sub == null) {
                "No submission date found in that message."
            } else {
                val now = LocalDateTime.now()
                val rs = SubmissionParser.reminderTimes(sub, now, s.remind2d, s.remindMorning)
                val fmt = DateTimeFormatter.ofPattern("EEE d MMM, h:mm a", Locale.ENGLISH)
                val kind = if (sub.kind == DeadlineKind.REGISTRATION) "Registration closes" else "Submission due"
                val alerts = if (rs.times.isEmpty()) "(no future alerts - it is due very soon)" else rs.times.joinToString("\n") { "• " + it.format(fmt) }
                "$kind: ${SubmissionParser.eventStart(sub).format(fmt)}\nAlerts:\n$alerts"
            }
            AlertDialog.Builder(this).setTitle("Ghostie would...").setMessage(msg).setPositiveButton("OK", null).show()
        })

        // Catch-up (works even when notifications are missed)
        val catchUp = card(
            "📥 Manual catch-up (backup)",
            "Only needed for muted groups you never open, or if you skipped \"Read open chats\". To catch up: in the group tap ⋮ > More > Export chat > Without media, then choose \"Add Ghostie reminders\". You can also share a single message the same way."
        )
        buttonRow(catchUp, button("Scan a chat file…", false) {
            if (!ensureCalendar()) return@button
            val pick = Intent(Intent.ACTION_OPEN_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType("*/*")
                .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/plain", "application/zip"))
            startActivityForResult(pick, 77)
        })

        // Documents
        section = "docs"
        val docs = card(
            "📂 Documents",
            "Copies WhatsApp documents into Documents/Ghostie/<Subject>, sorted by file name. Originals stay put. You can also tell the ghost: \"organize documents\"."
        )
        subjectsField = textField("Subject: keyword, keyword", s.subjects, true, 6)
        subjectsField.textSize = 12f
        docs.addView(subjectsField, fieldLp())
        docs.addView(label("One subject per line. Start a line with * for a fallback category. Clear everything to restore the defaults.", 12f, textSub).apply { setPadding(0, dp(6), 0, dp(4)) })
        buttonRow(docs, button("Organize now") {
            saveFields()
            if (!DocOrganizer.hasAccess(this)) {
                askFileAccess()
            } else {
                toast("Sorting...")
                Thread {
                    val text = try {
                        DocOrganizer.summary(DocOrganizer.organize(this))
                    } catch (e: Exception) {
                        "Something went wrong while organizing."
                    }
                    runOnUiThread { AlertDialog.Builder(this).setTitle("Documents").setMessage(text).setPositiveButton("OK", null).show() }
                }.start()
            }
        })

        docs.addView(label("Smart sorting also uses which chat a file came from and what is written inside PDFs, Word and PowerPoint files.", 12f, textSub).apply { setPadding(0, dp(2), 0, dp(4)) })
        switchRow(docs, "Sort new documents automatically", s.autoOrganize) { s.autoOrganize = it }

        buttonRow(docs, button("Browse sorted files", false) { renderDocs() })
        docBox = LinearLayout(this)
        docBox.orientation = LinearLayout.VERTICAL
        docs.addView(docBox, match())

        // What Ghostie has learned
        section = "brain"
        val learn = card("🧠 What Ghostie learned", "Ghostie remembers your corrections on this phone only: which words mean which subject or calendar category, phrases you teach it, deadlines you throw away, and what you like to chat about. It is a small learner, not a big AI model, and works offline. Teach it in chat: \"when I say study mode, set timer 25 minutes\".")
        learnBox = LinearLayout(this)
        learnBox.orientation = LinearLayout.VERTICAL
        learn.addView(learnBox, match())

        // Words and sentences
        learn.addView(label("Words and sentences", 15f, textMain, true).apply { setPadding(0, dp(12), 0, dp(2)) })
        learn.addView(label("Ghostie reads what you say to it, text you paste here, and (if switched on) your watched groups and shared chats. It remembers which words follow which, then builds its own new sentences in your style and mixes them into its chat. Rate them 👍/👎 to teach it. It's a small word-chain model, so sentences can be quirky. Links, phone numbers and rude words are skipped.", 12f, textSub))
        switchRow(learn, "Learn words from watched groups and shared chats", s.learnGroups) { s.learnGroups = it }
        val teachField = textField("Teach by example: paste messages, jokes or lines you like", "", true, 3)
        learn.addView(teachField, fieldLp())
        buttonRow(
            learn,
            button("Learn from this") {
                val n = SentenceStore.learn(this, teachField.text.toString(), 3)
                SentenceStore.save(this)
                teachField.setText("")
                toast(if (n > 0) "Learned $n new sentence(s) 🧠" else "Nothing new to learn there")
                renderLearned()
            },
            button("Say something", false) {
                val m = SentenceStore.get(this)
                val msg = if (!m.ready) "I'm still learning words 📚 (${m.summary()})" else m.generate()?.let { it } ?: "I need a few more sentences first."
                AlertDialog.Builder(this).setTitle("Ghostie says").setMessage(msg).setPositiveButton("OK", null).show()
            }
        )
        buttonRow(learn, button("Forget learned words", false) {
            AlertDialog.Builder(this).setTitle("Forget all learned words?").setMessage("Ghostie will stop making its own sentences until it learns again.")
                .setPositiveButton("Forget") { _, _ -> SentenceStore.reset(this); renderLearned(); toast("Words forgotten") }
                .setNegativeButton("Cancel", null).show()
        })
        buttonRow(learn, button("Forget everything", false) {
            AlertDialog.Builder(this).setTitle("Forget everything?").setMessage("This erases what Ghostie learned. Your events and documents stay.")
                .setPositiveButton("Forget") { _, _ -> LearnStore.reset(this); renderLearned(); toast("Memory wiped") }
                .setNegativeButton("Cancel", null).show()
        })

        // Companion settings
        section = "more"
        val call = card(
            "📞 Ghostie calls me",
            "When someone you pick keeps messaging, or sends an urgent word, Ghostie rings like an incoming call and tells you who it is. Answer opens WhatsApp. Drag the ghost into the bin on the call screen (or tap 🗑 Never) and it stops ringing for that chat."
        )
        switchRow(call, "Ring me for the people below", s.callEnabled) { s.callEnabled = it }
        vipField = textField("One person or group per line, exactly as WhatsApp shows it", s.callVips, true, 3)
        call.addView(vipField, fieldLp())
        spinnerRow(call, "Ring after", listOf("2 messages", "3 messages", "4 messages", "5 messages"), listOf(2, 3, 4, 5), s.callCount) { s.callCount = it }
        spinnerRow(call, "Within", listOf("2 min", "5 min", "10 min", "30 min"), listOf(2, 5, 10, 30), s.callWindow) { s.callWindow = it }
        urgentField = textField("Urgent words, separated by commas", s.callUrgent, true, 2)
        call.addView(urgentField, fieldLp())
        buttonRow(
            call,
            button("Test call", false) {
                saveFields()
                CallAlerts.show(this, "Test", "Test chat has messaged you 3 times", "pls reply, it's urgent!")
            },
            button("Allow full screen", false) {
                try {
                    if (Build.VERSION.SDK_INT >= 34) startActivity(Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT", Uri.parse("package:$packageName")))
                    else toast("Already allowed on this Android version")
                } catch (e: Exception) { toast("Open Settings > Apps > Ghostie > Notifications") }
            },
            button("Unmute chats", false) {
                val n = LearnStore.get(this).clearBlocked("call")
                LearnStore.save(this)
                toast(if (n == 0) "No muted chats" else "Unmuted $n chat(s)")
            }
        )
        call.addView(label("Needs Notification access (Setup tab). Ghostie can't phone your own number, so this is an on-screen call with ringtone and vibration. It rings even in the background, but not if Do Not Disturb blocks it.", 12f, textSub).apply { setPadding(0, dp(6), 0, 0) })

        val pref = card("🎛️ Companion")
        switchRow(pref, "Enable pet", s.enabled) { s.enabled = it }
        switchRow(pref, "Check-ins", s.checkins) { s.checkins = it }
        switchRow(pref, "Always on top", s.alwaysTop) { s.alwaysTop = it }
        switchRow(pref, "Ghost speaks aloud", s.speak) { s.speak = it }
        switchRow(pref, "Sound effects (squeaks, giggles)", s.sound) { s.sound = it }
        spinnerRow(pref, "Voice", listOf("Squeaky", "Cute", "Normal"), listOf(18, 14, 10), s.voicePitch) { s.voicePitch = it }
        pref.addView(label("Uses your phone's text-to-speech voice, pitched up. Silent when the phone is on silent or vibrate. Tap and hold the ghost to pet it, double-tap to spin it, drag it and shake it to make it dizzy.", 12f, textSub).apply { setPadding(0, dp(2), 0, dp(4)) })
        switchRow(pref, "Sleep at night (11 pm - 6 am)", s.sleepEnabled) { s.sleepEnabled = it }
        val sizeLabel = label("Ghost size: ${s.petDp}", 15f, textMain)
        sizeLabel.setPadding(0, dp(8), 0, 0)
        pref.addView(sizeLabel, match())
        val bar = SeekBar(this)
        bar.max = 144
        bar.progress = s.petDp - 56
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                sizeLabel.text = "Ghost size: ${value + 56}"
                if (fromUser) s.petDp = value + 56
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        pref.addView(bar, match())
        pref.addView(label("The ghost also hides during calls, in landscape and in Do Not Disturb.", 12f, textSub).apply { setPadding(0, dp(2), 0, dp(4)) })
        spinnerRow(pref, "Visit every", listOf("5 min", "10 min", "15 min", "30 min", "1 hour"), listOf(5, 10, 15, 30, 60), s.visitMinutes) { s.visitMinutes = it }
        spinnerRow(pref, "Water reminder", listOf("15 min", "30 min", "1 hour", "2 hours"), listOf(15, 30, 60, 120), s.waterMinutes) { s.waterMinutes = it }

        spinnerRow(pref, "Language (voice)", listOf("English", "हिन्दी / Hinglish"), listOf(0, 1), if (s.language == "hi") 1 else 0) { s.language = if (it == 1) "hi" else "en" }
        pref.addView(label("Sets what Ghostie listens for and the voice it speaks with. Hindi and Hinglish commands like \"kal shaam 6 baje alarm lagao\" or \"5 minute ka timer\" work in either mode. Chat replies are still in English. Hindi voice needs Hindi installed in your phone's speech settings.", 12f, textSub).apply { setPadding(0, dp(2), 0, dp(4)) })
        switchRow(pref, "Show \"tap to open\" when Ghostie opens an app", s.openFallback) { s.openFallback = it }
        switchRow(pref, "Random tricks (dance, wave, yawn, flip)", s.tricks) { s.tricks = it }
        switchRow(pref, "React to charging / low battery", s.batteryReacts) { s.batteryReacts = it }
        val tintField = textField("Custom colour, e.g. #FFC9E3", s.customTint, false)
        pref.addView(tintField, fieldLp())
        buttonRow(pref, button("Use custom colour", false) {
            try {
                Color.parseColor(tintField.text.toString().trim())
                s.customTint = tintField.text.toString()
                s.skin = "custom"
                startService(petIntent(PetOverlayService.ACTION_SKIN))
                toast("Custom colour applied 🎨")
            } catch (e: Exception) { toast("Use a hex colour like #FFC9E3") }
        })
        val skinList = Skins.all
        builtUnlocked = skinList.count { Skins.unlocked(it, s.chatCount) }
        spinnerRow(
            pref, "Ghost look",
            skinList.map { (if (Skins.unlocked(it, s.chatCount)) "" else "🔒 ") + it.label + (if (Skins.unlocked(it, s.chatCount)) "" else " (${it.unlockChats} chats)") },
            skinList.indices.toList(), skinList.indexOfFirst { it.id == s.skin }.coerceAtLeast(0)
        ) { i ->
            val sk = skinList[i]
            if (!Skins.unlocked(sk, s.chatCount)) toast("Chat with Ghostie ${sk.unlockChats - s.chatCount} more times to unlock ${sk.label}")
            else if (sk.id != s.skin) { s.skin = sk.id; startService(petIntent(PetOverlayService.ACTION_SKIN)) }
        }

        val rules = card("🎯 Group rules", "Per group, words that mean \"not a deadline\". One rule per line, e.g.  CS Group: ignore lunch, party, trip   (use * for every group). Each deadline in the list also shows the original message so you can tell why it was added.")
        rulesField = textField("CS Group: ignore lunch, party", s.groupRules, true, 3)
        rules.addView(rulesField, fieldLp())

        // Quiet time
        val quiet = card("🔕 Quiet time", "Pause visits and reminders from the ghost.")
        buttonRow(quiet, button("30 min", false) { pauseFor(30, "30 minutes") }, button("1 hour", false) { pauseFor(60, "1 hour") })
        buttonRow(
            quiet,
            button("Until tomorrow", false) {
                s.quietUntil = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                toast("Quiet until tomorrow")
            },
            button("Resume") {
                s.quietUntil = 0L
                toast("Ghostie resumed")
            }
        )

        // Activity log
        val act = card("🧾 Activity log", "What Ghostie has seen and done lately. Useful if a reminder did not appear.")
        activityBox = LinearLayout(this)
        activityBox.orientation = LinearLayout.VERTICAL
        act.addView(activityBox, match())
        buttonRow(
            act,
            button("Refresh", false) { renderActivity() },
            button("Copy", false) {
                val text = ActivityLog.read(this).take(40).joinToString("\n") { it.text() }
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Ghostie log", text))
                toast("Copied")
            },
            button("Clear", false) { ActivityLog.clear(this); renderActivity() }
        )

        // AI
        val ai = card(
            "✨ AI chat (optional)",
            "Free and nothing to download: pick a provider, make a free key on their website (Groq: console.groq.com) and paste it here. Needs internet, and what you say to the AI is sent to that provider. Without it Ghostie still works offline."
        )
        switchRow(ai, "Use AI for free chat", s.ai) { s.ai = it }
        val provs = ChatEngine.providers
        baseField = textField("Address", s.aiBase, false)
        modelField = textField("Model", s.aiModel, false)
        spinnerRow(ai, "Provider", provs.map { it.label }, provs.indices.toList(), provs.indexOfFirst { it.id == s.aiProvider }.coerceAtLeast(0)) { i ->
            val pv = provs[i]
            if (pv.id != s.aiProvider) {
                s.aiProvider = pv.id
                s.aiBase = pv.base
                s.aiModel = pv.model
                baseField.setText(pv.base)
                modelField.setText(pv.model)
            }
        }
        keyField = textField("API key", s.key, false, 1, true)
        ai.addView(keyField, fieldLp())
        ai.addView(baseField, fieldLp())
        ai.addView(modelField, fieldLp())
        ai.addView(label("Address and model are filled in for you. Change them only if a provider renames its model.", 12f, textSub).apply { setPadding(0, dp(6), 0, 0) })

        currentTab = if (tabButtons.containsKey(s.tab)) s.tab else "home"
        applyTab()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != 77 || resultCode != RESULT_OK || uri == null) return
        toast("Scanning...")
        Thread {
            var group = "Chat"
            val msg = try {
                val (g, text) = ChatImporter.read(this, uri)
                group = g
                ChatImporter.describe(g, ChatImporter.importText(this, g, text))
            } catch (e: Exception) {
                "I couldn't read that file."
            }
            runOnUiThread {
                AlertDialog.Builder(this).setTitle(group).setMessage(msg).setPositiveButton("OK", null).show()
                renderLog()
            }
        }.start()
    }

    private fun renderLearned() {
        if (!::learnBox.isInitialized) return
        learnBox.removeAllViews()
        val l = LearnStore.get(this)
        learnBox.addView(label(l.summary() + "\n" + SentenceStore.get(this).summary(), 12f, textSub), match())
        for ((phrase, meaning) in l.aliases.entries.toList().take(10)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.addView(label("\"$phrase\" → " + meaning.removePrefix("word:").removePrefix("say:"), 13f, textMain), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val x = button("✕", false) { l.removeAlias(phrase); LearnStore.save(this); renderLearned() }
            x.minHeight = dp(34); x.minimumHeight = dp(34)
            row.addView(x, LinearLayout.LayoutParams(dp(52), dp(36)))
            learnBox.addView(row, match())
        }
    }

    private fun renderDocs() {
        if (!::docBox.isInitialized) return
        docBox.removeAllViews()
        if (!DocOrganizer.hasAccess(this)) {
            docBox.addView(label("Allow File access in Setup first.", 13f, textSub))
            return
        }
        val files = DocOrganizer.sortedFiles().take(40)
        if (files.isEmpty()) {
            docBox.addView(label("No sorted files yet. Tap Organize now.", 13f, textSub))
            return
        }
        docBox.addView(label("Tap a file to move it to another subject (Ghostie learns). Long-press and drag it to the bin to delete Ghostie's copy - the WhatsApp original stays.", 12f, textSub).apply { setPadding(0, dp(6), 0, dp(6)) })
        val names = SubjectMatcher.parse(s.subjects).map { it.name }
        for ((subject, file) in files) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.background = rounded(field, 12, cardStroke)
            row.setPadding(dp(12), dp(8), dp(12), dp(8))
            row.addView(label(file.name, 13f, textMain, true))
            row.addView(label(subject, 11f, accent))
            row.setOnClickListener {
                AlertDialog.Builder(this).setTitle("Move \"${file.name}\" to…")
                    .setItems(names.toTypedArray()) { _, i ->
                        toast(if (DocOrganizer.moveTo(this, file, names[i])) "Moved - I'll remember that 🧠" else "Couldn't move it")
                        renderDocs(); renderLearned(); renderActivity()
                    }.show()
            }
            makeDraggable(row) {
                toast(if (DocOrganizer.binFile(this, file)) "Thrown away 🗑️" else "Couldn't delete it")
                renderDocs(); renderActivity()
            }
            val lp = match()
            lp.bottomMargin = dp(6)
            docBox.addView(row, lp)
        }
    }

    private fun renderActivity() {
        if (!::activityBox.isInitialized) return
        activityBox.removeAllViews()
        val lines = ActivityLog.read(this).take(15)
        if (lines.isEmpty()) {
            activityBox.addView(label("Nothing yet.", 13f, textSub))
            return
        }
        for (l in lines) activityBox.addView(label(l.text(), 12f, textSub).apply { setPadding(0, dp(2), 0, dp(2)) }, match())
    }

    private fun renderEvents() {
        eventsBox.removeAllViews()
        val list = RecentEvents.list(this)
        if (list.isEmpty()) {
            eventsBox.addView(label("Nothing yet. Try telling Ghostie: \"add event dentist on 12 November at 5 pm\".", 13f, textSub))
            return
        }
        val zone = ZoneId.systemDefault()
        val fmt = DateTimeFormatter.ofPattern("EEE d MMM yyyy", Locale.ENGLISH)
        for (r in list) {
            val dt = java.time.Instant.ofEpochMilli(r.start).atZone(zone)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.background = rounded(field, 12, cardStroke)
            row.setPadding(dp(12), dp(8), dp(12), dp(8))
            row.addView(label(r.kind.icon + " " + r.title, 14f, textMain, true))
            val whenText = dt.format(fmt) + if (r.allDay) " (all day)" else dt.format(DateTimeFormatter.ofPattern(", h:mm a", Locale.ENGLISH))
            row.addView(label(whenText + (if (r.repeat.isNotEmpty()) " - repeats yearly" else ""), 12f, accent))
            row.setOnClickListener { editEvent(r) }
            makeDraggable(row) {
                CalendarHelper.delete(this, r.id)
                RecentEvents.remove(this, r.id)
                s.removeLog(r.id)
                toast("Event deleted 🗑️")
                refresh()
            }
            val lp = match()
            lp.bottomMargin = dp(6)
            eventsBox.addView(row, lp)
        }
    }

    private fun editEvent(r: RecentEvents.Rec) {
        val zone = ZoneId.systemDefault()
        var dt = java.time.Instant.ofEpochMilli(r.start).atZone(zone).toLocalDateTime()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val name = textField("Name", Commands.baseTitle(r.title), false)
        box.addView(name, fieldLp())
        val kinds = EventKind.values().toList()
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, kinds.map { it.icon + " " + it.label })
        sp.setSelection(kinds.indexOf(r.kind).coerceAtLeast(0))
        box.addView(sp, fieldLp())
        val dateBtn = Button(this)
        val timeBtn = Button(this)
        fun show() {
            dateBtn.text = "Date: " + dt.toLocalDate().format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH))
            timeBtn.text = "Time: " + dt.format(DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH))
        }
        show()
        dateBtn.setOnClickListener {
            android.app.DatePickerDialog(this, { _, y, m, d -> dt = dt.withYear(y).withMonth(m + 1).withDayOfMonth(d); show() }, dt.year, dt.monthValue - 1, dt.dayOfMonth).show()
        }
        timeBtn.setOnClickListener {
            android.app.TimePickerDialog(this, { _, h, mi -> dt = dt.withHour(h).withMinute(mi); show() }, dt.hour, dt.minute, false).show()
        }
        box.addView(dateBtn, fieldLp())
        box.addView(timeBtn, fieldLp())
        AlertDialog.Builder(this).setTitle("Edit event").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val kind = kinds[sp.selectedItemPosition]
                val title = name.text.toString().trim().ifEmpty { Commands.baseTitle(r.title) }
                val startMs = dt.atZone(zone).toInstant().toEpochMilli()
                val day = dt.toLocalDate().atStartOfDay(zone).toInstant().toEpochMilli()
                var ev = Command.Event(title, if (kind == EventKind.EVENT) startMs else day, EventKind.EVENT)
                if (kind != EventKind.EVENT) ev = Commands.withKind(ev, kind)
                CalendarHelper.delete(this, r.id)
                RecentEvents.remove(this, r.id)
                s.removeLog(r.id)
                val id = CalendarHelper.insertEvent(this, ev, "Added by Ghostie")
                if (id == null) toast("Couldn't save - is Calendar allowed?")
                else {
                    RecentEvents.add(this, ev, id)
                    val l = LearnStore.get(this)
                    l.teachKind(Commands.baseTitle(ev.title), kind.name)
                    LearnStore.save(this)
                    toast("Saved ✅")
                }
                refresh()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun renderLog() {
        if (!::logBox.isInitialized) return
        logBox.removeAllViews()
        val items = ReminderLog.upcoming(s.logs()).take(10)
        if (items.isEmpty()) {
            logBox.addView(label("Nothing due. When someone posts a submission or registration deadline in a watched group, it appears here.", 13f, textSub))
            return
        }
        val warn = Color.parseColor("#FF8A7A")
        for (e in items) {
            val days = ReminderLog.daysLeft(e)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = rounded(field, 12, if (days <= 1) warn else cardStroke)
            row.setPadding(dp(12), dp(8), dp(8), dp(8))
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            val icon = when {
                ReminderLog.isRegistration(e) -> "📝 Registration: "
                e.title.startsWith("⏳") -> "⏳ "
                else -> "📌 "
            }
            col.addView(label(icon + ReminderLog.label(e), 14f, textMain, true))
            col.addView(label(ReminderLog.dueLabel(e), 12f, if (days <= 1) warn else accent))
            col.addView(label("from " + e.group, 11f, textSub))
            if (e.msg.isNotBlank()) col.addView(label("\u201C" + e.msg + "\u201D", 11f, textSub).apply { setPadding(0, dp(2), 0, 0) })
            row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val remove = button("Done", false) {
                CalendarHelper.delete(this, e.eventId)
                s.removeLog(e.eventId)
                renderLog()
            }
            remove.textSize = 12f
            remove.minHeight = dp(34)
            remove.minimumHeight = dp(34)
            val snooze = button("Snooze", false) {
                toast(ReminderMaker.snooze(this, e, 3))
            }
            snooze.textSize = 12f
            snooze.minHeight = dp(34)
            snooze.minimumHeight = dp(34)
            val btns = LinearLayout(this)
            btns.orientation = LinearLayout.VERTICAL
            btns.addView(snooze, LinearLayout.LayoutParams(dp(78), dp(36)))
            btns.addView(remove, LinearLayout.LayoutParams(dp(78), dp(36)).apply { topMargin = dp(4) })
            row.addView(btns)
            makeDraggable(row) {
                LearnStore.get(this).block(e.group, ReminderLog.label(e))
                LearnStore.save(this)
                CalendarHelper.delete(this, e.eventId)
                s.removeLog(e.eventId)
                ActivityLog.add(this, "Bin", "Threw away \"${ReminderLog.label(e)}\" - I'll ignore similar ones from ${e.group}")
                toast("Thrown away 🗑️ I'll ignore similar ones from ${e.group}")
                renderLog()
                renderActivity()
                renderLearned()
            }
            val lp = match()
            lp.bottomMargin = dp(6)
            logBox.addView(row, lp)
        }
    }
}
