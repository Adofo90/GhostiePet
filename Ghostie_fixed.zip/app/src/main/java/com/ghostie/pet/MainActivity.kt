package com.ghostie.pet

import android.Manifest
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.DragEvent
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ProgressBar
import android.os.PowerManager
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var s: SettingsStore
    private lateinit var content: LinearLayout
    private lateinit var groupsField: EditText
    private lateinit var keyField: EditText
    private lateinit var vipField: EditText
    private lateinit var rulesField: EditText
    private lateinit var linkField: EditText
    private var builtUnlocked = -1
    private lateinit var baseField: EditText
    private lateinit var modelField: EditText
    private lateinit var urgentField: EditText
    private lateinit var logBox: LinearLayout
    private lateinit var eventsBox: LinearLayout
    private lateinit var activityBox: LinearLayout
    private lateinit var docBox: LinearLayout
    private lateinit var learnBox: LinearLayout
    private lateinit var binZone: TextView
    private var section = "home"
    private var currentTab = "home"
    private var navBar: GlassNavBar? = null
    private val navKeys = listOf("home", "study", "setup", "docs", "brain", "more")
    private val cardSections = LinkedHashMap<View, String>()
    private val cardTitles = HashMap<View, String>()
    private val cardOpeners = HashMap<View, () -> Unit>()
    private var searchQuery = ""
    private lateinit var scrollRef: ScrollView
    private var homeFab: TextView? = null
    private val hiddenCards = HashSet<View>()
    private val advancedCards = HashSet<View>()
    /** Cards that only show in Advanced mode (matched by the start of their title). */
    private val advancedTitles = listOf("🗓️ Recent", "📥", "🧠 What", "🎛️", "📤", "🎯", "🧾", "✨ AI")
    private val tabButtons = LinkedHashMap<String, TextView>()
    private val permChecks = mutableListOf<() -> Boolean>()
    private var pendingDrop: (() -> Unit)? = null
    private var dropped = false
    private val refreshers = mutableListOf<() -> Unit>()

    // Palette (set from the chosen theme in onCreate)
    private lateinit var pal: Palette
    private var bg = 0
    private var card = 0
    private var cardStroke = 0
    private var field = 0
    private var textMain = 0
    private var textSub = 0
    private var accent = 0
    private var onAccent = 0
    private var good = 0
    private val hintViews = mutableListOf<View>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        s = SettingsStore(this)
        Sym.on = s.symbolIcons
        pal = Themes.palette(s)
        bg = pal.bg; card = pal.card; cardStroke = pal.stroke; field = pal.field; textMain = pal.text
        textSub = pal.sub; accent = pal.accent; onAccent = pal.onAccent; good = pal.good
        build()
        window.decorView.post { maybeTutorial() }
    }

    override fun onResume() {
        super.onResume()
        if (builtUnlocked >= 0 && builtUnlocked != Skins.all.count { Skins.unlocked(it, s.chatCount) }) { recreate(); return }
        refresh()
        try { pendingRefresh?.invoke(); attRefresh?.invoke() } catch (e: Exception) { }   // answers given in a notification show up here
    }
    private var pendingRefresh: (() -> Unit)? = null
    private var attRefresh: (() -> Unit)? = null

    override fun onPause() {
        SentenceStore.save(this)
        saveFields()
        super.onPause()
    }

    private fun refresh() {
        refreshers.forEach { it() }
        GhostieWidget.refresh(this)
        renderLog()
        renderEvents()
        renderActivity()
        renderLearned()
    }

    private fun saveFields() {
        s.watchedGroups = groupsField.text.toString()
        s.key = keyField.text.toString().trim()
        s.aiBase = baseField.text.toString()
        s.aiModel = modelField.text.toString()
        s.groupRules = rulesField.text.toString()
        s.shareLink = linkField.text.toString()
        s.callVips = vipField.text.toString()
        s.callUrgent = urgentField.text.toString()
    }

    // ---- small UI toolkit -----------------------------------------------------------------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun toast(msg: String) = Toast.makeText(this, Sym.t(msg), Toast.LENGTH_SHORT).show()

    /** Long-press a row, drag it to the bin that appears, and let go. */
    private fun makeDraggable(view: View, onDrop: () -> Unit) {
        view.setOnLongClickListener { v ->
            pendingDrop = onDrop
            v.alpha = 0.4f
            @Suppress("DEPRECATION")
            v.startDragAndDrop(ClipData.newPlainText("ghostie", "bin"), View.DragShadowBuilder(v), v, 0)
            true
        }
    }

    /** Paper-in-the-bin: spin, shrink and fade, then do the delete. */
    private fun crumple(v: View, done: () -> Unit) {
        v.animate().scaleX(0.1f).scaleY(0.1f).rotation(300f).alpha(0f).setDuration(320).withEndAction { done() }.start()
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val tv = SymText(this)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        if (bold) tv.setTypeface(tv.typeface, Typeface.BOLD)
        return tv
    }

    /** Long explanation text: hidden unless "Show explanations" is on (the tutorial covers it). */
    private fun hint(t: String): TextView = label(t, 12f, textSub).also {
        it.visibility = if (s.showHints) View.VISIBLE else View.GONE
        hintViews.add(it)
    }

    private fun match() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)


    // ---------- student tools (More tab) ----------
    private fun buildStudentCards() {
        val st = Student.load(this)
        val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

        // Classes waiting for an answer: a closed notification can't lose a class any more
        val pc = card("📝 Attendance to fill", "Classes of the last 2 weeks that are over and still waiting for your answer. If you close the notification by mistake, answer here.")
        val pendList = LinearLayout(this); pendList.orientation = LinearLayout.VERTICAL
        fun renderPending() {
            pendList.removeAllViews()
            val items = Student.pending(st, java.time.LocalDateTime.now())
            if (items.isEmpty()) { pendList.addView(label("✅ Nothing waiting - you're all caught up.", 14f, textMain)); return }
            val nm = getSystemService(android.app.NotificationManager::class.java)
            fun answer(p: Student.Pending, result: Int, subject: String = p.subject) {
                Student.answer(st, p.key, subject, result); Student.save(this)
                try { nm.cancel(6000 + (p.key.hashCode() and 0xFFF)) } catch (e: Exception) { }
            }
            // a slot that holds two subjects ("MAT/ESC"): ask which one it was, then count it
            fun answerPick(p: Student.Pending, result: Int) {
                val opts = p.subject.split('/').map { it.trim() }.filter { it.isNotEmpty() }
                if (opts.size <= 1) { answer(p, result); renderPending(); attRefresh?.invoke(); return }
                SymBuilder(this).setTitle("Which subject was it?").setItems(opts.toTypedArray()) { _, i -> answer(p, result, opts[i]); renderPending(); attRefresh?.invoke() }
                    .setNegativeButton("Cancel", null).show()
            }
            for (p in items) {
                pendList.addView(label("${days[p.date.dayOfWeek.value - 1]} ${p.date.dayOfMonth}/${p.date.monthValue}  ·  ${p.period.start}-${p.period.end}  ·  ${p.subject}", 14f, textMain, true).apply { setPadding(0, dp(8), 0, 0) })
                buttonRow(pendList,
                    button("Present", true) { answerPick(p, 1) },
                    button("Absent", false) { answerPick(p, 0) },
                    button("No class", false) { answer(p, -1); renderPending() }
                )
            }
            buttonRow(pendList, button("Clear all (don't count them)", false) {
                SymBuilder(this).setTitle("Clear ${items.size} waiting classes?").setMessage("They won't be counted as present or absent.")
                    .setPositiveButton("Clear") { _, _ -> items.forEach { answer(it, -1) }; renderPending() }.setNegativeButton("Cancel", null).show()
            })
        }
        renderPending(); pc.addView(pendList)
        pendingRefresh = { renderPending() }

        // Timetable grid
        val tt = card("🗓️ Timetable", "Like a paper timetable: edit the period times on the left and type the subject in each box. Ghostie uses it to ask about attendance after each class and (if you allow) to silence the phone during class.")
        val gridHolder = LinearLayout(this)
        gridHolder.orientation = LinearLayout.VERTICAL
        val timeFields = mutableListOf<Pair<EditText, EditText>>()
        val cellFields = mutableMapOf<String, EditText>()
        fun cellBox(w: Int, hint: String): EditText {
            val e = EditText(this)
            e.hint = hint; e.textSize = 12f; e.setSingleLine(true); e.setTextColor(textMain); e.setHintTextColor(textSub)
            e.setPadding(dp(4), dp(4), dp(4), dp(4)); e.background = rounded(card, 6, cardStroke)
            e.layoutParams = LinearLayout.LayoutParams(dp(w), dp(40)).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
            return e
        }
        fun buildGrid() {
            gridHolder.removeAllViews(); timeFields.clear(); cellFields.clear()
            val head = LinearLayout(this); head.orientation = LinearLayout.HORIZONTAL
            head.addView(label("", 12f, textSub), LinearLayout.LayoutParams(dp(96), dp(24)))
            days.forEach { d -> head.addView(label(d, 12f, textSub, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(84), dp(24))) }
            gridHolder.addView(head)
            st.periods.forEachIndexed { i, per ->
                val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
                val a = cellBox(46, "09:00"); a.setText(per.start); a.inputType = InputType.TYPE_CLASS_DATETIME or InputType.TYPE_DATETIME_VARIATION_TIME
                val b = cellBox(46, "10:00"); b.setText(per.end); b.inputType = InputType.TYPE_CLASS_DATETIME or InputType.TYPE_DATETIME_VARIATION_TIME
                row.addView(a); row.addView(b)
                timeFields.add(a to b)
                for (d in 0..6) {
                    val c = cellBox(84, "-"); c.setText(st.cells["$d,$i"].orEmpty()); cellFields["$d,$i"] = c; row.addView(c)
                }
                gridHolder.addView(row)
            }
        }
        fun readGrid() {
            val np = mutableListOf<Student.Period>()
            timeFields.forEach { (a, b) -> np.add(Student.Period(a.text.toString().trim(), b.text.toString().trim())) }
            st.periods = np
            st.cells.clear()
            cellFields.forEach { (k, v) -> val t = v.text.toString().trim(); if (t.isNotEmpty()) st.cells[k] = t }
        }
        buildGrid()
        val hs = HorizontalScrollView(this); hs.addView(gridHolder); tt.addView(hs)
        lateinit var renderSubj: () -> Unit
        val satReaders = mutableListOf<() -> Unit>()
        lateinit var renderSat: () -> Unit
        fun saveTimetable() {
                readGrid(); satReaders.forEach { it() }
                val bad = st.periods.indexOfFirst { Student.parseTime(it.start) == null || Student.parseTime(it.end) == null }
                if (bad >= 0) { toast("Period ${bad + 1}: write times like 09:00"); return }
                val badSat = st.satTables.firstOrNull { t -> t.periods.any { Student.parseTime(it.start) == null || Student.parseTime(it.end) == null } }
                if (badSat != null) { toast("${badSat.label}: write times like 09:00"); return }
                // subjects that were in the saved timetable but are not any more (renamed or taken out)
                val before = SubjectTidy.timetableSubjects(Student.savedCopy(this))
                val now = SubjectTidy.timetableSubjects(st)
                val gone = before.filter { b -> now.none { it.equals(b, true) } }
                val fresh = now.filter { n -> before.none { it.equals(n, true) } }
                // a gone subject with no attendance recorded just disappears from attendance
                gone.forEach { g ->
                    val k = st.att.keys.firstOrNull { it.equals(g, true) }
                    if (k != null && st.att[k]!![1] == 0) { st.att.remove(k); st.subjectReq.keys.filter { it.equals(g, true) }.forEach { st.subjectReq.remove(it) } }
                }
                val withData = gone.filter { g -> st.att.keys.any { it.equals(g, true) } }
                fun finish() {
                    SubjectTidy.syncAttendance(st)
                    Student.save(this)
                    val dups = SubjectTidy.duplicateGroups(st)
                    toast(if (dups.isEmpty()) "Timetable saved ✅" else "Saved. Some subjects look the same, check the subject list below")
                    renderSubj(); attRefresh?.invoke()
                }
                fun resolve(queue: List<String>) {
                    if (queue.isEmpty()) { finish(); return }
                    val old = queue.first(); val rest = queue.drop(1)
                    val rec = st.att[st.att.keys.first { it.equals(old, true) }]!!
                    val swap = if (queue.size == withData.size && withData.size == 1 && fresh.size == 1) fresh[0] else null
                    val b = SymBuilder(this).setTitle("\"$old\" is no longer in your timetable")
                        .setMessage((if (swap != null) "You changed it to \"$swap\". " else "") + "Its attendance record is ${rec[0]}/${rec[1]}. What should happen to it?")
                        .setCancelable(false)
                        .setNegativeButton("Delete it") { _, _ -> SubjectTidy.remove(st, old); resolve(rest) }
                    if (swap != null) b.setPositiveButton("Move to $swap") { _, _ -> SubjectTidy.merge(st, old, swap); resolve(rest) }
                    else b.setPositiveButton("Keep it") { _, _ -> resolve(rest) }
                    b.setNeutralButton(if (swap != null) "Keep it" else "Move into...") { _, _ ->
                        if (swap != null) { resolve(rest) } else {
                            val targets = now.filter { n -> !n.equals(old, true) }
                            if (targets.isEmpty()) { resolve(rest); return@setNeutralButton }
                            SymBuilder(this).setTitle("Move \"$old\" attendance into:").setCancelable(false)
                                .setItems(targets.toTypedArray()) { _, i -> SubjectTidy.merge(st, old, targets[i]); resolve(rest) }
                                .setNegativeButton("Keep it") { _, _ -> resolve(rest) }.show()
                        }
                    }
                    b.show()
                }
                resolve(withData)
        }
        buttonRow(tt,
            button("Save timetable", true) { saveTimetable()             },
            button("📷 From a photo", false) {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*")
                @Suppress("DEPRECATION") startActivityForResult(i, 81)
            },
            button("+ Period", false) { readGrid(); st.periods.add(Student.Period("16:00", "17:00")); buildGrid() },
            button("− Period", false) { if (st.periods.size > 1) { readGrid(); val last = st.periods.size - 1; st.periods.removeAt(last); st.cells.keys.removeAll { it.endsWith(",$last") }; buildGrid() } }
        )
        // Subject list: one tidy list used for attendance, with duplicate spotting and Remove
        val subjBox = LinearLayout(this); subjBox.orientation = LinearLayout.VERTICAL
        tt.addView(label("Subjects in your timetable", 14f, textMain, true).apply { setPadding(0, dp(12), 0, dp(2)) })
        tt.addView(hint("This list is used for attendance. If two names look like the same subject, merge them so attendance isn't split."))
        tt.addView(subjBox, match())
        renderSubj = {
            readGrid()
            subjBox.removeAllViews()
            val subs = SubjectTidy.timetableSubjects(st)
            if (subs.isEmpty()) subjBox.addView(hint("No subjects yet. Type them in the boxes above and tap Save timetable."))
            for (g in SubjectTidy.duplicateGroups(st)) {
                val warn = LinearLayout(this); warn.orientation = LinearLayout.VERTICAL
                warn.background = rounded(field, 12, Color.parseColor("#FF8A7A")); warn.setPadding(dp(12), dp(8), dp(12), dp(8))
                warn.addView(label("Look like the same subject: " + g.names.joinToString(", "), 13f, textMain, true))
                for (other in g.names.filter { !it.equals(g.suggested, true) }) {
                    warn.addView(button("Merge \"$other\" into \"${g.suggested}\"", false) {
                        SubjectTidy.merge(st, other, g.suggested); SubjectTidy.syncAttendance(st); Student.save(this)
                        toast("Merged"); buildGrid(); renderSubj(); attRefresh?.invoke()
                    })
                }
                subjBox.addView(warn, match().apply { bottomMargin = dp(6) })
            }
            for (sub in subs) {
                val r = st.att[Student.key(st.att.keys, sub)] ?: intArrayOf(0, 0)
                val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
                row.addView(label(sub + "\n" + SubjectTidy.boxes(st, sub) + " box(es) in the week, attended ${r[0]}/${r[1]}", 13f, textMain), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                row.addView(button("Merge into...", false) {
                    val others = subs.filter { !it.equals(sub, true) }
                    if (others.isEmpty()) { toast("No other subject to merge with"); return@button }
                    SymBuilder(this).setTitle("Merge \"$sub\" into:").setItems(others.toTypedArray()) { _, i ->
                        SubjectTidy.merge(st, sub, others[i]); SubjectTidy.syncAttendance(st); Student.save(this)
                        toast("Merged into ${others[i]}"); buildGrid(); renderSubj(); attRefresh?.invoke()
                    }.setNegativeButton("Cancel", null).show()
                })
                row.addView(button("Remove", false) {
                    val b = SubjectTidy.boxes(st, sub)
                    SymBuilder(this).setTitle("Remove \"$sub\"?")
                        .setMessage("Clears it from $b timetable box(es) and deletes its attendance record (${r[0]}/${r[1]}). Exams and flashcards for it are kept.")
                        .setPositiveButton("Remove") { _, _ -> SubjectTidy.remove(st, sub); Student.save(this); toast("Removed"); buildGrid(); renderSubj(); attRefresh?.invoke() }
                        .setNegativeButton("Cancel", null).show()
                })
                subjBox.addView(row, match())
            }
        }
        renderSubj()
        // Working Saturdays: some colleges meet only on certain Saturdays, each with its own timetable
        tt.addView(label("Working Saturdays", 14f, textMain, true).apply { setPadding(0, dp(14), 0, dp(2)) })
        tt.addView(hint("If your college runs only on some Saturdays (for example the 2nd and 4th), add a Saturday timetable for them. Once you add one, other Saturdays have no classes."))
        val satBox = LinearLayout(this); satBox.orientation = LinearLayout.VERTICAL
        tt.addView(satBox, match())
        fun satRules(existing: Student.SatTable?) {
            val nameBox = EditText(this); nameBox.hint = "Name, e.g. 2nd Saturday"; nameBox.setSingleLine(true); nameBox.setText(existing?.label.orEmpty())
            val ord = listOf(1 to "1st Saturday", 2 to "2nd Saturday", 3 to "3rd Saturday", 4 to "4th Saturday", 5 to "5th Saturday")
            val checks = ord.map { (n, name) -> SymCheck(this).also { it.text = name; it.isChecked = existing?.ordinals?.contains(n) == true } }
            val altCheck = SymCheck(this); altCheck.text = "Every other Saturday, counting from this Saturday:"
            altCheck.isChecked = existing?.altFrom?.isNotEmpty() == true
            val altDate = EditText(this); altDate.hint = "YYYY-MM-DD, e.g. 2026-11-07"; altDate.setSingleLine(true); altDate.setText(existing?.altFrom.orEmpty())
            val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL; col.setPadding(dp(20), dp(8), dp(20), 0)
            col.addView(nameBox); checks.forEach { col.addView(it) }; col.addView(altCheck); col.addView(altDate)
            val quick = LinearLayout(this); quick.orientation = LinearLayout.HORIZONTAL
            quick.addView(button("1st & 3rd", false) { checks.forEachIndexed { i, c -> c.isChecked = i == 0 || i == 2 } })
            quick.addView(button("2nd & 4th", false) { checks.forEachIndexed { i, c -> c.isChecked = i == 1 || i == 3 } })
            col.addView(quick)
            val sv = android.widget.ScrollView(this); sv.addView(col)
            SymBuilder(this).setTitle(if (existing == null) "Which Saturdays?" else "Change which Saturdays").setView(sv)
                .setPositiveButton("Save") { _, _ ->
                    val picked = ord.filterIndexed { i, _ -> checks[i].isChecked }.map { it.first }.toMutableSet()
                    val alt = if (altCheck.isChecked) altDate.text.toString().trim() else ""
                    val altOk = alt.isEmpty() || try { java.time.LocalDate.parse(alt).dayOfWeek == java.time.DayOfWeek.SATURDAY } catch (e: Exception) { false }
                    if (picked.isEmpty() && alt.isEmpty()) { toast("Tick at least one Saturday"); return@setPositiveButton }
                    if (!altOk) { toast("Write the date like 2026-11-07, and it must be a Saturday"); return@setPositiveButton }
                    val t = existing ?: Student.SatTable().also { st.satTables.add(it); it.periods = st.periods.map { p -> Student.Period(p.start, p.end) }.toMutableList() }
                    t.ordinals = picked; t.altFrom = alt
                    t.label = nameBox.text.toString().trim().ifEmpty { t.ruleText().replaceFirstChar { c -> c.uppercase() } }
                    Student.save(this); renderSat()
                }.setNegativeButton("Cancel", null).show()
        }
        renderSat = {
            satReaders.clear(); satBox.removeAllViews()
            for (t in st.satTables.toList()) {
                satBox.addView(label(t.label + "\n" + t.ruleText(), 13f, accent, true).apply { setPadding(0, dp(10), 0, dp(4)) })
                val grid = LinearLayout(this); grid.orientation = LinearLayout.VERTICAL
                val tf = mutableListOf<Pair<EditText, EditText>>(); val cf = mutableMapOf<String, EditText>()
                fun build() {
                    grid.removeAllViews(); tf.clear(); cf.clear()
                    t.periods.forEachIndexed { i, per ->
                        val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
                        val a = cellBox(46, "09:00"); a.setText(per.start); a.inputType = InputType.TYPE_CLASS_DATETIME or InputType.TYPE_DATETIME_VARIATION_TIME
                        val b = cellBox(46, "10:00"); b.setText(per.end); b.inputType = InputType.TYPE_CLASS_DATETIME or InputType.TYPE_DATETIME_VARIATION_TIME
                        val c = cellBox(170, "subject (or MAT/ESC if it varies)"); c.setText(t.cells["$i"].orEmpty()); cf["$i"] = c
                        tf.add(a to b)
                        row.addView(a); row.addView(b); row.addView(c); grid.addView(row)
                    }
                }
                fun read() {
                    t.periods = tf.map { (a, b) -> Student.Period(a.text.toString().trim(), b.text.toString().trim()) }.toMutableList()
                    t.cells.clear(); cf.forEach { (k, v) -> val x = v.text.toString().trim(); if (x.isNotEmpty()) t.cells[k] = x }
                }
                build()
                satReaders.add { if (tf.isNotEmpty()) read() }
                val hs2 = HorizontalScrollView(this); hs2.addView(grid); satBox.addView(hs2)
                buttonRow(satBox,
                    button("Save", true) { saveTimetable() },
                    button("+ Period", false) { read(); t.periods.add(Student.Period("16:00", "17:00")); build() },
                    button("− Period", false) { if (t.periods.size > 1) { read(); val last = t.periods.size - 1; t.periods.removeAt(last); t.cells.remove("$last"); build() } },
                    button("Which Saturdays", false) { satRules(t) },
                    button("Delete", false) {
                        SymBuilder(this).setTitle("Delete \"${t.label}\"?").setMessage("This Saturday timetable is removed. Attendance already recorded stays.")
                            .setPositiveButton("Delete") { _, _ -> st.satTables.remove(t); Student.save(this); renderSat(); renderSubj(); attRefresh?.invoke() }
                            .setNegativeButton("Cancel", null).show()
                    })
            }
            if (st.satTables.isEmpty()) satBox.addView(hint("No Saturday timetables yet."))
        }
        renderSat()
        buttonRow(tt, button("+ Add Saturday timetable", false) { satRules(null) })
        switchRow(tt, "Ask me after each class: Present / Absent / No class", st.autoAsk) { st.autoAsk = it; Student.save(this) }
        switchRow(tt, "Silence my phone during class (Do Not Disturb)", st.dnd) {
            st.dnd = it; Student.save(this)
            if (it && !getSystemService(android.app.NotificationManager::class.java).isNotificationPolicyAccessGranted) {
                toast("Allow Ghostie under \"Do Not Disturb access\", then switch this on again")
                try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) } catch (e: Exception) { }
            }
        }
        tt.addView(hint("Do Not Disturb needs the \"Do Not Disturb access\" permission (the switch opens that screen). Ghostie only changes it during your class slots and puts it back after; if you were already on DND it leaves it alone."))

        // Attendance
        val ac = card("📋 Attendance", "Required % can differ per subject (tap a subject's % to change it). Say \"can I bunk maths\" in chat for the answer.")
        val reqField = textField("Required %", st.required.toString(), false)
        reqField.inputType = InputType.TYPE_CLASS_NUMBER
        ac.addView(label("Required attendance % (default for every subject)", 13f, textSub))
        ac.addView(reqField, fieldLp())
        reqField.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(e: android.text.Editable?) { e?.toString()?.toIntOrNull()?.takeIf { it in 1..100 }?.let { st.required = it; Student.save(this@MainActivity) } }
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
        })
        val attList = LinearLayout(this); attList.orientation = LinearLayout.VERTICAL
        fun renderAtt() {
            attList.removeAllViews()
            val subs = SubjectTidy.attendanceSubjects(st)
            if (subs.isEmpty()) attList.addView(hint("Fill in the timetable above, or type a subject below."))
            for (sub in subs) {
                val r = st.att[sub] ?: intArrayOf(0, 0)
                val req = Student.reqFor(st, sub)
                val ok = Student.pct(r[0], r[1]) >= req
                val info = label("$sub" + (if (SubjectTidy.timetableSubjects(st).none { it.equals(sub, true) }) " (not in timetable)" else "") + "\n${r[0]}/${r[1]} = ${"%.0f".format(Student.pct(r[0], r[1]))}%  (need $req%)  " + (if (r[1] == 0) "" else if (ok) "skip ${Student.canSkip(r[0], r[1], req)}" else "attend ${Student.mustAttend(r[0], r[1], req)}"), 13f, if (ok) textMain else Color.parseColor("#E57373"))
                info.setOnClickListener {
                    val f = EditText(this); f.inputType = InputType.TYPE_CLASS_NUMBER; f.setText(req.toString())
                    SymBuilder(this).setTitle("Required % for $sub").setView(f)
                        .setPositiveButton("Save") { _, _ -> f.text.toString().toIntOrNull()?.takeIf { it in 1..100 }?.let { st.subjectReq[sub] = it; Student.save(this); renderAtt() } }
                        .setNeutralButton("Use default") { _, _ -> st.subjectReq.remove(sub); Student.save(this); renderAtt() }.show()
                }
                attList.addView(info, match())
                val removeBtn = button("Remove", false) {
                    val inTt = SubjectTidy.timetableSubjects(st).any { it.equals(sub, true) }
                    SymBuilder(this).setTitle("Remove \"$sub\" from attendance?")
                        .setMessage("Deletes its record (${r[0]}/${r[1]})." + (if (inTt) " It stays in your timetable, but Ghostie stops asking about it. You can track it again from the list below." else ""))
                        .setPositiveButton("Remove") { _, _ ->
                            if (inTt) SubjectTidy.stopTracking(st, sub) else SubjectTidy.remove(st, sub)
                            Student.save(this); renderAtt()
                        }
                        .setNegativeButton("Cancel", null).show()
                }
                buttonRow(attList, removeBtn,
                    button("✓", false) { Student.mark(st, sub, true); Student.save(this); renderAtt() },
                    button("✗", false) { Student.mark(st, sub, false); Student.save(this); renderAtt() },
                    button("↶", false) {
                        val x = st.att[sub]; if (x != null && x[1] > 0) { x[1]--; if (x[0] > x[1]) x[0] = x[1]; Student.save(this); renderAtt() }
                    })
            }
            if (st.noTrack.isNotEmpty()) {
                attList.addView(label("Not tracked (removed from attendance)", 13f, textSub, true).apply { setPadding(0, dp(10), 0, dp(2)) })
                if (st.noTrack.size > 1) buttonRow(attList, button("Track all again", false) { for (n in st.noTrack.toList()) SubjectTidy.trackAgain(st, n); Student.save(this); renderAtt() })
                for (n in st.noTrack.toList()) {
                    val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
                    row.addView(label(n, 14f, textSub), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                    row.addView(button("Track again", false) { SubjectTidy.trackAgain(st, n); Student.save(this); renderAtt() })
                    attList.addView(row)
                }
            }
        }
        renderAtt(); ac.addView(attList)
        attRefresh = { renderAtt() }
        val newSub = textField("Add a subject (e.g. Maths)", "", false)
        ac.addView(newSub, fieldLp())
        buttonRow(ac, button("Add subject", false) {
            val n = newSub.text.toString().trim()
            if (n.isNotEmpty()) { st.att.getOrPut(Student.key(st.att.keys, n)) { intArrayOf(0, 0) }; Student.save(this); newSub.setText(""); renderAtt() }
        }, button("Refresh", false) { renderAtt() })
        ac.addView(hint("✓ present, ✗ absent, ↶ undo the last mark. For a class that didn't happen, just don't mark it."))

        // Exams
        val ec = card("📚 Exams & syllabus", "Add an exam with its topics (one per line). Tick topics off as you finish them; Ghostie nudges you at 8 am with what to study today.")
        val exList = LinearLayout(this); exList.orientation = LinearLayout.VERTICAL
        fun renderEx() {
            exList.removeAllViews()
            val today = java.time.LocalDate.now()
            val all = st.exams.sortedBy { it.date }
            if (all.isEmpty()) exList.addView(hint("No exams yet."))
            for (e in all) {
                exList.addView(label(Student.examLine(e, today), 14f, textMain, true).apply { setPadding(0, dp(8), 0, dp(2)) })
                e.topics.forEachIndexed { i, tp ->
                    val cb = SymCheck(this)
                    cb.text = tp.text; cb.setTextColor(textMain); cb.isChecked = tp.done
                    cb.setOnCheckedChangeListener { _, on ->
                        st.exams = st.exams.map { x -> if (x.id == e.id) x.copy(topics = x.topics.mapIndexed { j, t2 -> if (j == i) t2.copy(done = on) else t2 }) else x }.toMutableList()
                        Student.save(this)
                    }
                    exList.addView(cb)
                }
                exList.addView(button("Delete this exam", false) { st.exams.removeAll { it.id == e.id }; Student.save(this); renderEx() })
            }
        }
        renderEx(); ec.addView(exList)
        val exSub = textField("Subject", "", false); ec.addView(exSub, fieldLp())
        var exDate: java.time.LocalDate? = null
        val dateBtn = button("Pick exam date", false) { }
        dateBtn.setOnClickListener {
            val n = java.time.LocalDate.now()
            android.app.DatePickerDialog(this, { _, y, m, d -> exDate = java.time.LocalDate.of(y, m + 1, d); dateBtn.text = "Exam: $exDate" }, n.year, n.monthValue - 1, n.dayOfMonth).show()
        }
        ec.addView(dateBtn)
        val exTopics = textField("Topics, one per line", "", true, 4); ec.addView(exTopics, fieldLp())
        buttonRow(ec, button("Add exam", true) {
            val sub = exSub.text.toString().trim(); val d = exDate
            if (sub.isEmpty() || d == null) { toast("Add a subject and pick a date"); return@button }
            val topics = exTopics.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }.map { Student.Topic(it, false) }
            st.exams.add(Student.Exam(System.currentTimeMillis(), Student.matchSubject(st, sub) ?: sub, d, topics))
            Student.save(this); exSub.setText(""); exTopics.setText(""); exDate = null; dateBtn.text = "Pick exam date"; renderEx(); renderAtt()
        }, button("Study today?", false) { toast(Student.studyToday(st, java.time.LocalDate.now()) ?: "Nothing pending") })

        // Flashcards
        val fc = card("🃏 Flashcards", "Type one per line as  Question = Answer  (optionally  Subject: Question = Answer). Cards you know come back less often; ones you miss come back tomorrow. In chat: \"card Q = A\" and \"quiz me\".")
        val due = Student.dueCards(st, java.time.LocalDate.now()).size
        val cardInfo = label("${st.cards.size} cards, $due due today", 13f, textSub)
        fc.addView(cardInfo)
        val cardText = textField("Deadlock = circular wait for resources\nOS: Semaphore = counter used to control access", "", true, 4)
        fc.addView(cardText, fieldLp())
        buttonRow(fc,
            button("Save cards", true) {
                val n = Student.addCards(st, cardText.text.toString(), java.time.LocalDate.now())
                Student.save(this); cardText.setText("")
                toast(if (n > 0) "$n card(s) saved" else "Nothing new - use  Question = Answer")
                cardInfo.text = "${st.cards.size} cards, ${Student.dueCards(st, java.time.LocalDate.now()).size} due today"
            },
            button("Review now", false) { reviewCards(st) }
        )
        buttonRow(fc, button("My cards (browse, edit, delete)", false) { cardsUi().browse(st, { Student.save(this) }) { recreate() } })
        buttonRow(fc, button("Make cards from a notes or question-paper file", false) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation", "text/plain"))
            @Suppress("DEPRECATION") startActivityForResult(i, 80)
        })
        fc.addView(hint("Finds multiple-choice questions (with an answer line or answer key) and numerical problems with answers or solutions. Questions without an answer in the file are skipped.").apply { setPadding(0, dp(4), 0, dp(2)) })

        // Digest
        val dc = card("👀 What did I miss?", "A short summary of what your watched class groups posted (exams, deadlines, cancellations...) since you last asked.")
        buttonRow(dc, button("Show digest", true) {
            val since = if (st.lastDigestAt > 0) st.lastDigestAt else System.currentTimeMillis() - 24 * 3_600_000L
            SymBuilder(this).setTitle("What you missed").setMessage(Student.digestText(st, since, System.currentTimeMillis())).setPositiveButton("OK", null).show()
            st.lastDigestAt = System.currentTimeMillis(); Student.save(this)
        })
    }

    private fun cardsUi() = CardsUi(this, CardsTheme(bg, card, cardStroke, textMain, textSub, accent, onAccent, field, good))

    private fun reviewCards(st: Student.State) {
        cardsUi().review(st, { Student.save(this) }) { recreate() }
    }

    private fun reviewCardsOld(st: Student.State) {
        val queue = Student.dueCards(st, java.time.LocalDate.now()).toMutableList()
        if (queue.isEmpty()) { toast("No cards due 🎉"); return }
        fun show() {
            if (queue.isEmpty()) { toast("All done 🎉"); return }
            val c = queue.removeAt(0)
            SymBuilder(this).setTitle(c.subject).setMessage(c.q).setCancelable(true)
                .setPositiveButton("Show answer") { _, _ ->
                    SymBuilder(this).setTitle(c.q).setMessage(c.a).setCancelable(false)
                        .setPositiveButton("Got it") { _, _ -> upd(st, c, true); show() }
                        .setNegativeButton("Again") { _, _ -> upd(st, c, false); show() }.show()
                }.setNegativeButton("Stop", null).show()
        }
        show()
    }

    private fun upd(st: Student.State, c: Student.Card, good: Boolean) {
        val n = Student.graded(c, good, java.time.LocalDate.now())
        st.cards = st.cards.map { if (it.id == c.id) n else it }.toMutableList()
        Student.save(this)
    }

    /** Ghostie's own alarms: one row per alarm with an on/off switch; adding a time that already exists just switches it on. */
    /** Reminders made by chat ("remind me to drink water in 20 minutes") that haven't rung yet, with a way to remove them. */
    private fun buildQuickRemindersCard() {
        val c = card("🔔 Waiting reminders", "Reminders you asked Ghostie for in chat that haven't rung yet. Remove the ones you don't need. Or say: \"cancel reminders\".")
        val list = LinearLayout(this); list.orientation = LinearLayout.VERTICAL
        val fmt = java.text.SimpleDateFormat("EEE d MMM, h:mm a", java.util.Locale.getDefault())
        fun render() {
            list.removeAllViews()
            val all = ReminderAlarms.quickList(this)
            if (all.isEmpty()) list.addView(hint("No reminders waiting."))
            for ((whenMs, text) in all) {
                val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL; row.setPadding(0, dp(4), 0, dp(4))
                row.addView(label(text + "\n" + fmt.format(java.util.Date(whenMs)), 14f, textMain), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                row.addView(button("Remove", false) { ReminderAlarms.cancelQuick(this, whenMs, text); render() })
                list.addView(row, match())
            }
        }
        val rangBox = LinearLayout(this); rangBox.orientation = LinearLayout.VERTICAL
        fun renderRang() {
            rangBox.removeAllViews()
            val done = ReminderAlarms.rangList(this)
            if (done.isEmpty()) return
            rangBox.addView(label("Already rang (${done.size})", 13f, accent, true).apply { setPadding(0, dp(10), 0, dp(4)) }, match())
            for ((whenMs, text) in done) {
                val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
                row.addView(label(text + "\n" + fmt.format(java.util.Date(whenMs)), 13f, textSub), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                row.addView(button("Remove", false) { ReminderAlarms.removeRang(this, whenMs, text); renderRang() })
                rangBox.addView(row, match())
            }
            rangBox.addView(button("Clear all old", false) { ReminderAlarms.clearRang(this); renderRang() }, match())
        }
        render()
        renderRang()
        c.addView(list, match())
        c.addView(rangBox, match())
        buttonRow(c, button("Refresh", false) { render(); renderRang() }, button("Remove all", false) {
            SymBuilder(this).setTitle("Remove all waiting reminders?").setMessage("They won't ring.")
                .setPositiveButton("Remove") { _, _ -> val n = ReminderAlarms.cancelAllQuick(this); render(); toast("Removed $n") }
                .setNegativeButton("Cancel", null).show()
        })
    }

    private var alarmsRefresh: (() -> Unit)? = null
    private fun addAlarmNow(h: Int, m: Int, label: String) {
        val r = AlarmStore.add(this, h, m, 0, label.trim())
        toast(if (r.existed) "Already had ${AlarmStore.timeText(r.alarm)} - switched on" else "Alarm set for ${AlarmStore.timeText(r.alarm)}")
        alarmsRefresh?.invoke()
    }

    private fun buildAlarmsCard() {
        val c = card("⏰ Alarms", "Ghostie rings these itself. Adding a time that already has an alarm just switches that one on. Or tell Ghostie: \"alarm 6:30 am\", \"alarm 7 weekdays\", \"my alarms\", \"turn off alarm 6:30\".")
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        fun render() {
            list.removeAllViews()
            val all = AlarmStore.all(this)
            if (all.isEmpty()) list.addView(hint("No alarms yet. Tap an alarm's text to give it a label."))
            for (a in all) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(0, dp(4), 0, dp(4))
                val t = label(AlarmStore.timeText(a) + "  " + AlarmStore.daysText(a.days) + (if (a.label.isNotBlank()) "\n" + a.label else ""), 15f, textMain)
                t.setOnClickListener {
                    val f = textField("Label, e.g. Gym", a.label, false)
                    SymBuilder(this).setTitle("Label for " + AlarmStore.timeText(a)).setView(f)
                        .setPositiveButton("Save") { _, _ -> AlarmStore.setLabel(this, a.id, f.text.toString()); render() }
                        .setNegativeButton("Cancel", null).show()
                }
                row.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                val sw = GhostSwitch(this, 3)
                sw.setCheckedInstant(a.enabled)
                sw.contentDescription = "Alarm " + AlarmStore.timeText(a)
                sw.onChange = { on -> AlarmStore.setEnabled(this, a.id, on) }
                row.addView(sw, LinearLayout.LayoutParams(dp(72), dp(38)))
                val del = button("✕", false) { AlarmStore.delete(this, a.id); render() }
                row.addView(del)
                list.addView(row)
            }
        }
        render()
        c.addView(list)
        val nextLine = label(AlarmStore.nextText(this) ?: "No alarm is on.", 13f, textSub)
        c.addView(nextLine)
        alarmsRefresh = { render(); nextLine.text = AlarmStore.nextText(this) ?: "No alarm is on." }
        refreshers.add { nextLine.text = AlarmStore.nextText(this) ?: "No alarm is on." }
        buttonRow(c, button("Test ring (10 s)", false) {
            AlarmStore.testIn(this, 10); toast("Lock the screen or leave the app - it should ring in 10 seconds")
        }, button("Ring reliably", false) {
            SymBuilder(this).setTitle("Make alarms ring on time")
                .setMessage("Poco/Xiaomi phones often stop apps from waking up. Turn Ghostie ON in Autostart, and set Battery saver to \"No restrictions\" for Ghostie (App info > Battery). Then use Test ring.")
                .setPositiveButton("Allow no limits") { _, _ -> PermHelp.requestBatteryFree(this) }
                .setNegativeButton("Open Autostart") { _, _ -> PermHelp.openBackgroundRun(this) }
                .setNeutralButton("App info") { _, _ -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
                .show()
        })
        buttonRow(c, button("Add alarm", true) {
            val now = java.time.LocalTime.now()
            TimePickerDialog(this, { _, h, m ->
                val f = textField("Label (optional), e.g. Gym", "", false)
                SymBuilder(this).setTitle("Label for this alarm").setView(f)
                    .setPositiveButton("Set alarm") { _, _ -> addAlarmNow(h, m, f.text.toString()) }
                    .setNegativeButton("No label") { _, _ -> addAlarmNow(h, m, "") }
                    .setCancelable(false).show()
            }, now.hour, now.minute, false).show()
        })
    }

    private fun card(title: String, subtitle: String? = null): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = rounded(card, 18, cardStroke)
        c.setPadding(dp(16), dp(14), dp(16), dp(16))
        val titleView = label(title, 17f, textMain, true)
        c.addView(titleView)
        if (subtitle != null) {
            val sub = label(subtitle, 13f, textSub)
            sub.setPadding(0, dp(2), 0, dp(8))
            sub.visibility = if (s.showHints) View.VISIBLE else View.GONE
            hintViews.add(sub)
            c.addView(sub)
            if (!s.showHints) { // tap the title to read what the card does
                titleView.setOnClickListener { sub.visibility = if (sub.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
            }
        }
        val lp = match()
        lp.topMargin = dp(12)
        content.addView(c, lp)
        cardSections[c] = section
        cardTitles[c] = title
        return c
    }

    private fun button(text: String, filled: Boolean = true, onClick: () -> Unit): Button {
        val b = SymButton(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 14f
        b.stateListAnimator = null
        b.minHeight = dp(44)
        b.minimumHeight = dp(44)
        styleButton(b, filled)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun styleButton(b: Button, filled: Boolean) {
        b.setTextColor(if (filled) onAccent else accent)
        b.background = if (filled) rounded(accent, 12) else rounded(Color.TRANSPARENT, 12, accent)
    }

    private fun buttonRow(parent: LinearLayout, vararg buttons: Button) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (b in buttons) {
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), dp(4), dp(3), dp(4))
            row.addView(b, lp)
        }
        parent.addView(row, match())
    }

    private fun switchRow(parent: LinearLayout, text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val sw = SymSwitch(this)
        sw.text = text
        sw.setTextColor(textMain)
        sw.isChecked = checked
        // Follow the chosen theme colour instead of the default purple.
        val on = intArrayOf(android.R.attr.state_checked)
        val off = intArrayOf(-android.R.attr.state_checked)
        val trackOn = Color.argb(0x88, Color.red(accent), Color.green(accent), Color.blue(accent))
        sw.thumbTintList = android.content.res.ColorStateList(arrayOf(on, off), intArrayOf(accent, textSub))
        sw.trackTintList = android.content.res.ColorStateList(arrayOf(on, off), intArrayOf(trackOn, cardStroke))
        sw.setPadding(0, dp(6), 0, dp(6))
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        parent.addView(sw, match())
    }

    /** A row with one of Ghostie's animated switches (style 0 Boo, 1 Haunted Hill, 2 Ectoplasm, 3 Wisp, 4 Poltergeist). */
    private fun ghostSwitchRow(parent: LinearLayout, text: String, checked: Boolean, style: Int, onChange: (Boolean) -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(6), 0, dp(6))
        row.addView(label(text, 15f, textMain), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val g = GhostSwitch(this, style)
        g.setCheckedInstant(checked)
        g.onChange = onChange
        g.contentDescription = text
        row.addView(g, LinearLayout.LayoutParams(dp(72), dp(38)).apply { leftMargin = dp(10) })
        row.setOnClickListener { g.performClick() }
        parent.addView(row, match())
    }

    private fun spinnerRow(parent: LinearLayout, title: String, options: List<String>, values: List<Int>, current: Int, onPick: (Int) -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(label(title, 15f, textMain), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val sp = Spinner(this)
        sp.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, options) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View =
                (super.getView(position, convertView, parent) as TextView).apply { setTextColor(textMain) }
        }
        sp.backgroundTintList = android.content.res.ColorStateList.valueOf(textMain)
        sp.setSelection(values.indexOf(current).coerceAtLeast(0))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                onPick(values[position])
            }
        }
        row.addView(sp, LinearLayout.LayoutParams(dp(140), LinearLayout.LayoutParams.WRAP_CONTENT))
        parent.addView(row, match())
    }

    private fun textField(hint: String, value: String, multiline: Boolean, lines: Int = 1, password: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(value)
        e.setTextColor(textMain)
        e.setHintTextColor(textSub)
        e.textSize = 13f
        e.background = rounded(field, 12, cardStroke)
        e.setPadding(dp(12), dp(10), dp(12), dp(10))
        var type = InputType.TYPE_CLASS_TEXT
        if (multiline) {
            type = type or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            e.minLines = lines
            e.gravity = Gravity.TOP or Gravity.START
        }
        if (password) type = type or InputType.TYPE_TEXT_VARIATION_PASSWORD
        e.inputType = type
        return e
    }

    private fun fieldLp(): LinearLayout.LayoutParams {
        val lp = match()
        lp.topMargin = dp(6)
        return lp
    }

    // ---- permissions ----------------------------------------------------------------------

    private fun hasNotificationPermission() =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun hasCalendar() = CalendarHelper.hasPermission(this)
    private fun ensureCalendar(): Boolean {
        if (hasCalendar()) return true
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR), 3)
        toast("Allow Calendar, then tap again")
        return false
    }

    // ---- tutorial -------------------------------------------------------------------------

    private val tutorialSteps = listOf(
        "👋 Welcome to Ghostie" to "Ghostie is a little ghost that lives on top of your screen. Tap the small ghost on the screen edge and it comes out to chat. Hold it to talk, drag it to move it, and throw it in the bin to send it away.",
        "✅ Setup first" to "Open the Setup tab and switch on what you want: Display over apps (needed), Notifications, Calendar, and Notification access for WhatsApp. If Android greys something out: App info > ⋮ > Allow restricted settings.",
        "💬 Chat commands" to "Type or say things like: add event maths exam tomorrow 10am, timer 10 minutes, alarm 6:30 am, note buy milk, todo finish record, remind me to drink water in 20 minutes, open WhatsApp. Say help for the full list.",
        "📌 Deadlines" to "Add your class groups under Group reminders. When a submission or registration date appears, Ghostie adds it to your calendar and reminds you. Tick Done on the reminder when finished - if it is still not done in its last hour, Ghostie rings like a call.",
        "📞 Calls" to "Pick people or groups under Ghostie calls me. If they message again and again, or say an urgent word, Ghostie rings. Answer opens WhatsApp, Dismiss stops it, and dragging the ghost into the bin mutes that chat.",
        "📚 Study & food" to "Say study 45 for a focus timer with breaks. Say cheapest chicken biryani and Ghostie compares Zomato, Swiggy and brand apps for you. It only reads prices and never orders.",
        "🎨 Make it yours" to "Look & feel lets you change theme, colour, glass look, chat box size and whether the ghost opens chat directly. Unlock new ghost looks by chatting. You can reopen this tutorial any time from Look & feel."
    )

    private fun showTutorial(step: Int = 0) {
        val (title, body) = tutorialSteps[step]
        val last = step == tutorialSteps.lastIndex
        val b = SymBuilder(this)
            .setTitle("${step + 1}/${tutorialSteps.size}  $title")
            .setMessage(body)
            .setCancelable(true)
            .setPositiveButton(if (last) "Done" else "Next") { _, _ -> if (!last) showTutorial(step + 1) }
        if (step > 0) b.setNeutralButton("Back") { _, _ -> showTutorial(step - 1) }
        if (!last) b.setNegativeButton("Skip", null)
        b.show()
    }

    /** Shows the tutorial once after a fresh install or an update (not on every start). */
    private fun maybeTutorial() {
        try {
            val stamp = packageManager.getPackageInfo(packageName, 0).lastUpdateTime
            if (s.tutorialStamp != stamp) {
                s.tutorialStamp = stamp
                if (s.tutorialAuto && !isFinishing) showTutorial()
            }
        } catch (e: Exception) { }
    }

    private fun hasAccessibility(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.startsWith("$packageName/") && it.contains("ChatScreenService") }
    }

    private fun hasContactsAndPhone() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED

    private fun hasMic() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun hasListener() = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun askFileAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 2
            )
        }
    }

    private fun permRow(parent: LinearLayout, title: String, desc: String, isOn: () -> Boolean, request: () -> Unit) {
        permChecks.add(isOn)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(6), 0, dp(6))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(label(title, 15f, textMain))
        col.addView(hint(desc))
        val b = button("Allow") { request() }
        row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(b, LinearLayout.LayoutParams(dp(92), dp(40)))
        parent.addView(row, match())
        refreshers.add {
            if (isOn()) {
                b.text = "✓ On"
                b.setTextColor(good)
                b.background = rounded(Color.TRANSPARENT, 12, good)
            } else {
                b.text = "Allow"
                styleButton(b, true)
            }
        }
    }

    // ---- screen ---------------------------------------------------------------------------

    private fun petIntent(action: String? = null): Intent {
        val i = Intent(this, PetOverlayService::class.java)
        if (action != null) i.action = action
        return i
    }

    private fun startPet() {
        saveFields()
        if (!Settings.canDrawOverlays(this)) {
            PermHelp.openOverlay(this)
            toast("Allow \"Display over other apps\", then tap Start again")
        } else {
            s.enabled = true
            startForegroundService(petIntent())
            toast("Ghostie is ready 👻")
        }
    }

    private fun pauseFor(minutes: Long, label: String) {
        s.quietUntil = System.currentTimeMillis() + minutes * 60_000L
        toast("Quiet for $label")
    }

    private fun applyTab() {
        navBar?.select(navKeys.indexOf(currentTab).coerceAtLeast(0), animate = navBar?.width ?: 0 > 0)
        val q = searchQuery.trim().lowercase()
        for ((c, sec) in cardSections) {
            c.visibility = if (q.length >= 2) {
                if (matches(c, q)) { cardOpeners[c]?.invoke(); View.VISIBLE } else View.GONE
            } else if (sec == currentTab && c !in hiddenCards && !(s.simpleMode && c in advancedCards)) View.VISIBLE else View.GONE
        }
        orbitView?.visibility = if (currentTab == "home" && q.length < 2) View.VISIBLE else View.GONE
        homeFab?.visibility = if (currentTab != "home" && q.length < 2) View.VISIBLE else View.GONE
        for ((key, b) in tabButtons) {
            val on = key == currentTab
            b.setTextColor(if (on) onAccent else textSub)
            b.background = if (on) rounded(accent, 20) else rounded(Color.TRANSPARENT, 20, cardStroke)
        }
    }

    private var orbitView: OrbitView? = null

    private fun textsOf(v: View, out: StringBuilder) {
        if (v is TextView) out.append(v.text).append(' ').append(v.hint ?: "").append(' ')
        if (v is ViewGroup) for (i in 0 until v.childCount) textsOf(v.getChildAt(i), out)
    }

    private fun matches(c: View, q: String): Boolean {
        if ((cardTitles[c] ?: "").lowercase().contains(q)) return true
        val sb = StringBuilder(); textsOf(c, sb)
        return sb.toString().lowercase().contains(q)
    }

    /** Jumps to the card whose title starts with [prefix]: switches tab, opens it and scrolls it into view. */
    private fun jumpTo(prefix: String) {
        val hit = cardTitles.entries.firstOrNull { it.value.startsWith(prefix) }?.key ?: return
        searchQuery = ""
        searchField?.setText("")
        currentTab = cardSections[hit] ?: "home"; s.tab = currentTab
        hiddenCards.remove(hit)
        applyTab()
        cardOpeners[hit]?.invoke()
        scrollRef.post { scrollRef.smoothScrollTo(0, (hit.top - dp(70)).coerceAtLeast(0)) }
    }

    private var searchField: EditText? = null

    private fun showTab(key: String) {
        currentTab = key
        s.tab = key
        applyTab()
    }

    private fun build() {
        val scroll = ScrollView(this)
        scrollRef = scroll
        scroll.background = pal.background()
        scroll.isFillViewport = true
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(16), dp(16), dp(24))
        scroll.addView(content)
        val root = FrameLayout(this)
        root.addView(scroll, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        binZone = SymText(this)
        binZone.text = "🗑️"
        binZone.textSize = 34f
        binZone.gravity = Gravity.CENTER
        binZone.background = rounded(Color.parseColor("#33FFFFFF"), 40, accent)
        binZone.visibility = View.GONE
        root.addView(binZone, FrameLayout.LayoutParams(dp(84), dp(84), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(120) })
        binZone.setOnDragListener { v, ev ->
            when (ev.action) {
                DragEvent.ACTION_DRAG_STARTED -> { dropped = false; v.visibility = View.VISIBLE; v.alpha = 0f; v.animate().alpha(1f).setDuration(150).start(); true }
                DragEvent.ACTION_DRAG_ENTERED -> { v.animate().scaleX(1.35f).scaleY(1.35f).setDuration(120).start(); true }
                DragEvent.ACTION_DRAG_EXITED -> { v.animate().scaleX(1f).scaleY(1f).setDuration(120).start(); true }
                DragEvent.ACTION_DROP -> {
                    dropped = true
                    val cb = pendingDrop
                    pendingDrop = null
                    val dragged = ev.localState as? View
                    if (dragged != null) crumple(dragged) { cb?.invoke() } else cb?.invoke()
                    true
                }
                DragEvent.ACTION_DRAG_ENDED -> {
                    v.visibility = View.GONE
                    v.scaleX = 1f; v.scaleY = 1f
                    if (!dropped) (ev.localState as? View)?.alpha = 1f
                    pendingDrop = null
                    true
                }
                else -> true
            }
        }
        setContentView(root)
        // Android 15 draws apps edge-to-edge, so keep content clear of the status/navigation bars.
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }

        // Header
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val ghost = ImageView(this)
        ghost.setImageResource(R.drawable.ghost_pet)
        ghost.scaleType = ImageView.ScaleType.FIT_CENTER
        header.addView(ghost, LinearLayout.LayoutParams(dp(64), dp(64)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(14), 0, 0, 0)
        titles.addView(label("Ghostie", 28f, textMain, true))
        titles.addView(label("Your tiny floating study buddy", 14f, textSub))
        header.addView(titles)
        content.addView(header, match())
        val modeRow = LinearLayout(this)
        modeRow.orientation = LinearLayout.VERTICAL
        switchRow(modeRow, "Advanced mode (show every setting)", !s.simpleMode) { on ->
            s.simpleMode = !on
            applyTab()
            toast(if (on) "Advanced: everything is shown" else "Simple: just the essentials")
        }
        content.addView(modeRow, match())

        // Search: finds any card or setting across every tab
        val search = EditText(this)
        search.hint = "🔍  Find anything (alarm, attendance, quiet, skin...)"
        search.textSize = 14f; search.setSingleLine(true)
        search.setTextColor(textMain); search.setHintTextColor(textSub)
        search.setPadding(dp(14), dp(8), dp(14), dp(8)); search.background = rounded(field, 22, cardStroke)
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(e: android.text.Editable?) {
                val typed = e?.toString() ?: ""
                val pmem = PrefsMemory(this@MainActivity)
                if (PrivateCode.matches(pmem, typed)) { search.setText(""); openPrivate(pmem); return }
                if (PrivateCode.wantsSetup(pmem, typed)) { search.setText(""); setPrivateCode(pmem, true); return }
                searchQuery = typed; applyTab()
            }
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
        })
        searchField = search
        content.addView(search, match().apply { topMargin = dp(10) })

        // The orbit: the ghost in the middle, the features circling it
        val spots = listOf(
            Triple("🗓️", "Timetable", "🗓️ Timetable"), Triple("📋", "Bunk?", "📋 Attendance"), Triple("📚", "Exams", "📚 Exams"),
            Triple("🃏", "Cards", "🃏 Flashcards"), Triple("⏰", "Alarms", "⏰ Alarms"), Triple("🎓", "Study mode", "📚 Study mode"),
            Triple("🎨", "Looks", "🎨 Look"), Triple("📂", "Docs", "#docs"), Triple("🧠", "Brain", "#brain"), Triple("⚙️", "Setup", "✅ Setup")
        )
        val orbit = OrbitView(this, spots.map { it.first to it.second }, card, cardStroke, textMain, accent) { i ->
            val t = spots[i].third
            if (t.startsWith("#")) showTab(t.substring(1)) else jumpTo(t)
        }
        orbitView = orbit
        content.addView(orbit, match().apply { topMargin = dp(4) })

        // Tabs keep the long list of settings short.
        val tabs = listOf("home" to "🏠 Home", "study" to "🎓 Study", "setup" to "⚙️ Setup", "docs" to "📂 Docs", "brain" to "🧠 Brain", "more" to "✨ More")
        val tabScroll = HorizontalScrollView(this)
        tabScroll.isHorizontalScrollBarEnabled = false
        val tabRow = LinearLayout(this)
        tabRow.orientation = LinearLayout.HORIZONTAL
        tabRow.setPadding(0, dp(14), 0, dp(2))
        for ((key, title) in tabs) {
            val b = SymText(this)
            b.text = title
            b.textSize = 14f
            b.setPadding(dp(16), dp(8), dp(16), dp(8))
            b.setOnClickListener { showTab(key) }
            tabButtons[key] = b
            tabRow.addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) })
        }
        tabScroll.addView(tabRow)
        content.addView(tabScroll, match())
        if (s.navStyle in 1..3) {
            tabScroll.visibility = View.GONE
            content.setPadding(dp(16), dp(16), dp(16), dp(110))
            val nav = GlassNavBar(this, listOf("🏠" to "Home", "🎓" to "Study", "⚙️" to "Setup", "📂" to "Docs", "🧠" to "Brain", "✨" to "More"), s.navStyle, pal) { i ->
                showTab(tabs[i].first)
            }
            navBar = nav
            root.addView(nav, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        }

        val fab = SymText(this)
        fab.text = "👻"; fab.textSize = 26f; fab.gravity = Gravity.CENTER
        fab.background = rounded(card, 30, accent)
        fab.elevation = dp(6).toFloat()
        fab.visibility = View.GONE
        fab.setOnClickListener { showTab("home"); scrollRef.post { scrollRef.smoothScrollTo(0, 0) } }
        homeFab = fab
        root.addView(fab, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM or Gravity.END).apply { rightMargin = dp(16); bottomMargin = dp(if (s.navStyle in 1..3) 112 else 24) })

        // Setup progress banner (hidden once everything is on)
        section = "home"
        val banner = card("Finish setting up")
        val bannerText = label("", 13f, textSub)
        banner.addView(bannerText, match())
        val setupBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        setupBar.progressTintList = android.content.res.ColorStateList.valueOf(accent)
        setupBar.progressBackgroundTintList = android.content.res.ColorStateList.valueOf(cardStroke)
        banner.addView(setupBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(8)).apply { topMargin = dp(8); bottomMargin = dp(8) })
        buttonRow(banner, button("Open Setup") { showTab("setup") })
        refreshers.add {
            val done = permChecks.count { it() }
            val total = permChecks.size
            setupBar.max = maxOf(1, total)
            setupBar.progress = done
            bannerText.text = "$done of $total ready. Ghostie works best with everything switched on."
            val hide = total == 0 || done == total
            if (hide) hiddenCards.add(banner) else hiddenCards.remove(banner)
            applyTab()
        }

        // Pet controls
        section = "home"
        val pet = card("👻 Pet")
        buttonRow(pet, button("Start") { startPet() }, button("Stop", false) { stopService(petIntent()); toast("Ghostie stopped") })
        buttonRow(
            pet,
            button("Summon now", false) { startForegroundService(petIntent(PetOverlayService.ACTION_SUMMON)) },
            button("Bring on screen", false) {
                s.resetPosition()
                startForegroundService(petIntent(PetOverlayService.ACTION_RESET))
            }
        )

        // Upcoming submissions (filled by renderLog)
        val upcoming = card("📌 Upcoming deadlines", "Submissions and event registrations Ghostie spotted in your groups. Each one gets a calendar event with alerts (the day before, and optionally 2 days before and the morning of). Long-press one and drag it to the bin to delete it - Ghostie learns to ignore similar ones.")
        logBox = LinearLayout(this)
        logBox.orientation = LinearLayout.VERTICAL
        upcoming.addView(logBox, match())

        val evCard = card("🗓️ Recent events", "Events you added by chatting with Ghostie. Tap one to edit its name, date, time or category. Long-press and drag it to the bin to delete it.")
        eventsBox = LinearLayout(this)
        eventsBox.orientation = LinearLayout.VERTICAL
        evCard.addView(eventsBox, match())

        // Study mode (lives in the Study tab)
        section = "study"
        val study = card("📚 Study mode", "Focus timer with breaks. Optionally silences notifications (Do Not Disturb) and covers distracting apps while you focus. Or just tell Ghostie: \"study 45\".")
        val studyStatus = label("", 14f, accent)
        study.addView(studyStatus, match())
        refreshers.add {
            val sec = ((s.studyPhaseEnd - System.currentTimeMillis()) / 1000).coerceAtLeast(0)
            studyStatus.text = (if (s.studyActive) (if (s.studyPhase == "focus") "🎯 Focusing: " else "☕ Break: ") + "%d:%02d left\n".format(sec / 60, sec % 60) else "") +
                "Today ${StudyLog.format(StudyLog.today(s.studyLog))} · week ${StudyLog.format(StudyLog.week(s.studyLog))}" +
                StudyLog.streak(s.studyLog).let { if (it >= 2) " · $it-day streak 🔥" else "" }
        }
        spinnerRow(study, "Focus", listOf("15 min", "25 min", "45 min", "60 min", "90 min"), listOf(15, 25, 45, 60, 90), s.studyFocus) { s.studyFocus = it }
        spinnerRow(study, "Break", listOf("5 min", "10 min", "15 min"), listOf(5, 10, 15), s.studyBreak) { s.studyBreak = it }
        ghostSwitchRow(study, "Do Not Disturb while focusing", s.studyDnd, 4) { on ->
            s.studyDnd = on
            if (on && !getSystemService(android.app.NotificationManager::class.java).isNotificationPolicyAccessGranted) {
                toast("Allow Ghostie in the next screen, then come back")
                try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) } catch (e: Exception) { }
            }
        }
        ghostSwitchRow(study, "Cover distracting apps while focusing", s.studyBlock, 4) { s.studyBlock = it }
        val appsLabel = hint("")
        fun showApps() { appsLabel.text = if (s.studyAppSet().isEmpty()) "No apps chosen yet." else "Blocked: " + s.studyAppSet().joinToString(", ") { p -> try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(p, 0)).toString() } catch (e: Exception) { p } } }
        showApps()
        study.addView(appsLabel, match())
        buttonRow(
            study,
            button("Choose apps to block", false) { chooseBlockedApps { showApps() } },
            button("Allow usage access", false) {
                try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (e: Exception) { toast("Open Settings > Apps > Special access > Usage access") }
            }
        )
        buttonRow(
            study,
            button("Start") {
                saveFields()
                startService(petIntent(PetOverlayService.ACTION_STUDY_START).putExtra("focus", s.studyFocus).putExtra("brk", s.studyBreak))
                toast("Study mode started 📚")
                handlerRefreshSoon()
            },
            button("Stop", false) {
                if (s.studyActive && s.studyPhase == "focus") confirmEndStudy()
                else {
                    startService(petIntent(PetOverlayService.ACTION_STUDY_STOP).putExtra("confirmed", true))
                    toast("Study mode stopped")
                    handlerRefreshSoon()
                }
            }
        )

        buildMoneyCard()
        buildSplitCard()
        buildProjectsCard()
        buildPlacementCard()
        buildCallNotesCard()
        buildWeeklyCard()
        buildStudyTimeCard()

        // Setup checklist
        section = "setup"
        val setup = card("✅ Setup", "Switch on what you want to use. Green means ready.")
        setup.addView(hint("Installed from a shared file? Android may grey out Accessibility and Notification access. Open App info, tap the ⋮ menu (top right) and choose \"Allow restricted settings\", then switch them on. Also allow Calendar and Notifications here, or events and alerts can't work.").apply { setPadding(0, 0, 0, dp(6)) })
        buttonRow(setup, button("Switch greyed out? Help", false) {
            SymBuilder(this).setTitle("Can't switch it on?").setMessage(PermHelp.HELP).setPositiveButton("Open App info") { _, _ ->
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }.setNegativeButton("Close", null).show()
        })
        buttonRow(setup, button("Open App info", false) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        permRow(setup, "Display over other apps", "Shows the floating ghost", { Settings.canDrawOverlays(this) }) {
            PermHelp.openOverlay(this)
        }
        permRow(setup, "Notifications", "Ghostie's own alerts", { hasNotificationPermission() }) {
            if (Build.VERSION.SDK_INT >= 33) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        permRow(setup, "File access", "To organize WhatsApp documents", { DocOrganizer.hasAccess(this) }) { askFileAccess() }
        permRow(setup, "Calendar", "To add events and reminders", { hasCalendar() }) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR), 3)
        }
        permRow(setup, "Contacts & calls", "So \"call Mom\" works (dials instantly)", { hasContactsAndPhone() }) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE), 4)
        }
        permRow(setup, "Microphone", "Hold the ghost (or tap 🎙 in chat) and talk to it", { hasMic() }) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 5)
        }
        permRow(setup, "Battery: no restrictions", "Stops Android from closing the ghost", {
            (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        }) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        }
        permRow(setup, "Notification access", "Reads new messages when WhatsApp is closed", { hasListener() }) {
            PermHelp.openListener(this, "GroupWatcherService")
        }
        permRow(setup, "Read open chats", "Catches messages while you have the group open", { hasAccessibility() }) {
            SymBuilder(this)
                .setTitle("Read open chats")
                .setMessage(
                    "Ghostie will only look at WhatsApp, and only act when one of your watched groups is on screen. Nothing leaves your phone.\n\n" +
                        "In the next screen open \"Installed apps\" (or \"Downloaded apps\"), choose \"Ghostie chat reader\" and switch it on.\n\n" +
                        "If Android says \"Restricted setting\": phone Settings > Apps > Ghostie > ⋮ (top right) > \"Allow restricted settings\", then try again."
                )
                .setPositiveButton("Continue") { _, _ -> PermHelp.openAccessibility(this, "ChatScreenService") }
                .setNegativeButton("Cancel", null)
                .show()
        }

        buttonRow(setup,
            button("💳 Pause screen reading (for Paytm / BharatPe)", false) {
                val n = PaymentPause.pause()
                toast(if (n > 0) "Paused. Payment apps can run now." else if (PaymentPause.isOn(this)) "Couldn't pause. Switch off Ghostie in Accessibility settings." else "Already off.")
                refresh()
            },
            button("Turn reading back on", false) { try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (e: Exception) { } })
        setup.addView(hint("Paytm and BharatPe block payments while any app has Accessibility on. This switches Ghostie's readers off (Read open chats, Food price reader). Android only lets you switch them back on yourself: Settings > Accessibility > Installed apps. Notification reading is unaffected.").apply { setPadding(0, dp(2), 0, dp(6)) })
        permRow(setup, "Food price reader", "Lets me compare food prices when you ask", { FoodScanService.isEnabled(this) }) {
            SymBuilder(this)
                .setTitle("Food price reader")
                .setMessage(
                    "Ghostie will open Zomato, Swiggy, Domino's, Popeyes and EatSure ONLY when you ask it to compare prices (e.g. \"cheapest chicken biryani\"), search your item and read the prices on screen.\n\n" +
                        "It never adds to a cart, pays, logs in or places an order, and it does nothing the rest of the time. Nothing leaves your phone.\n\n" +
                        "In the next screen open \"Installed apps\", choose \"Ghostie food price reader\" and switch it on. If Android says \"Restricted setting\": phone Settings > Apps > Ghostie > ⋮ > \"Allow restricted settings\"."
                )
                .setPositiveButton("Continue") { _, _ -> PermHelp.openAccessibility(this, "FoodScanService") }
                .setNegativeButton("Cancel", null)
                .show()
        }
        buttonRow(setup, button("📋 Share last food-check log (for troubleshooting)", false) {
            val log = s.foodDebug.ifBlank { "No food check has run yet." }
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, log.take(90_000)), "Share log"))
        })
        buttonRow(setup, button("👆 Teach Ghostie where an app's search bar is", false) {
            val apps = FoodApps.ALL
            SymBuilder(this).setTitle("Which app?")
                .setItems(apps.map { it.label + (s.foodTapFor(it.id)?.let { " (taught ✓)" } ?: "") }.toTypedArray()) { _, i ->
                    toast("Opening ${apps[i].label}… tap its search bar when the dim layer appears")
                    startService(petIntent(PetOverlayService.ACTION_TEACH_TAP).putExtra("app", apps[i].id))
                }.setNegativeButton("Cancel", null).show()
        })
        setup.addView(hint("Use this only for an app where the food check can't open the search (Swiggy). Ghostie opens the app, then waits for your one touch on its search bar.").apply { setPadding(0, 0, 0, dp(4)) })
        buttonRow(setup, button("🍽️ Assumed delivery fee: ₹${s.foodFee} (when an app doesn't show it)", false) {
            val et = android.widget.EditText(this).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText(s.foodFee.toString()) }
            SymBuilder(this).setTitle("Assumed delivery fee (₹)").setView(et)
                .setPositiveButton("Save") { _, _ -> et.text.toString().toIntOrNull()?.let { s.foodFee = it.coerceIn(0, 300) }; recreate() }
                .setNegativeButton("Cancel", null).show()
        })

        setup.addView(hint("On Xiaomi/Poco phones also switch on Autostart for Ghostie (App settings > Autostart), or the system may stop it in the background.").apply { setPadding(0, dp(4), 0, dp(4)) })
        buttonRow(setup, button("Open Ghostie's app settings", false) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })

        // Privacy Shield
        val shield = card("🛡️ Privacy Shield", "Hides Ghostie completely while a payment or banking app is open, and brings it back when you leave. Ghostie only learns the app's name, never what is on screen.")
        ghostSwitchRow(shield, "Hide Ghostie in protected apps", s.shieldOn, 2) { s.shieldOn = it; refresh() }
        permRow(shield, "Usage access", "Lets Ghostie know which app is open (needed for the shield)", { usageOk() }) {
            try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (e: Exception) { toast("Open Settings > Apps > Special access > Usage access") }
        }
        switchRow(shield, "Also protect apps with \"bank\" in their name", s.shieldGuessBanks) { s.shieldGuessBanks = it }
        val shieldList = hint("")
        fun showShield() {
            val pm = packageManager
            val names = installedLaunchers().filter { s.shieldProtects(it.first) || (!s.shieldOn && ShieldPolicy.isProtected(it.first, ShieldPolicy.parse(s.shieldCustom), ShieldPolicy.parse(s.shieldRemoved), s.shieldGuessBanks)) }.map { it.second }
            shieldList.text = if (names.isEmpty()) "No protected apps found on this phone yet." else "Protected: " + names.joinToString(", ")
        }
        showShield()
        shield.addView(shieldList, match())
        buttonRow(shield, button("Manage protected apps", false) { chooseShieldApps { showShield() } })
        shield.addView(hint("Not available in the Lite build (it has no Usage access).").apply { setPadding(0, dp(4), 0, dp(2)) })

        // Group reminders
        val groups = card(
            "💬 Group reminders",
            "Ghostie watches the groups you list - through notifications when WhatsApp is closed, and by reading the screen when the group is open. A submission or registration deadline becomes a calendar event with reminders."
        )
        switchRow(groups, "Watch groups", s.watchEnabled) { s.watchEnabled = it }
        switchRow(groups, "Also warn 2 days before", s.remind2d) { s.remind2d = it }
        switchRow(groups, "Nudge on the morning it is due", s.remindMorning) { s.remindMorning = it }
        groups.addView(hint("Other chat apps: scans every chat in the app for deadlines (needs Notification access and Read open chats).").apply { setPadding(0, dp(6), 0, dp(2)) })
        for (appName in ChatApps.apps.keys) {
            switchRow(groups, "Find deadlines in $appName", s.otherChatOn(appName)) { on ->
                val cur = ChatApps.parse(s.otherChatApps).toMutableSet()
                if (on) cur.add(appName) else cur.remove(appName)
                s.otherChatApps = cur.joinToString(",")
            }
        }
        val status = hint("")
        status.setPadding(0, dp(4), 0, dp(4))
        groups.addView(status, match())
        refreshers.add {
            fun ago(k: String): String {
                val tm = ActivityLog.lastTime(this, k) ?: return "never"
                val mins = (System.currentTimeMillis() - tm) / 60_000L
                return if (mins < 1) "just now" else if (mins < 60) "$mins min ago" else if (mins < 1440) "${mins / 60} h ago" else "${mins / 1440} d ago"
            }
            status.text = "Last WhatsApp notification heard: ${ago("Notification")}\nLast open chat read: ${ago("Open chat")}"
        }
        groupsField = textField("Group names, one per line (e.g. CSE 3A)", s.watchedGroups, true, 3)
        groups.addView(groupsField, fieldLp())
        groups.addView(hint("Only messages that arrive while this is on can be seen. Keep Ghostie's battery setting on \"Unrestricted\".").apply { setPadding(0, dp(6), 0, dp(4)) })
        val testField = textField("Try a message, e.g. Last date to register for Hackathon is 12 Nov", "", false)
        groups.addView(testField, fieldLp())
        buttonRow(groups, button("Test message", false) {
            val text = testField.text.toString()
            val sub = SubmissionParser.parse(text, LocalDate.now())
            val msg = if (sub == null) {
                "No submission date found in that message."
            } else {
                val now = LocalDateTime.now()
                val rs = SubmissionParser.reminderTimes(sub, now, s.remind2d, s.remindMorning)
                val fmt = DateTimeFormatter.ofPattern("EEE d MMM, h:mm a", Locale.ENGLISH)
                val kind = if (sub.kind == DeadlineKind.REGISTRATION) "Registration closes" else "Submission due"
                val alerts = if (rs.times.isEmpty()) "(no future alerts - it is due very soon)" else rs.times.joinToString("\n") { "• " + it.format(fmt) }
                "$kind: ${SubmissionParser.eventStart(sub).format(fmt)}\nAlerts:\n$alerts"
            }
            SymBuilder(this).setTitle("Ghostie would...").setMessage(msg).setPositiveButton("OK", null).show()
        })

        // Catch-up (works even when notifications are missed)
        val catchUp = card(
            "📥 Manual catch-up (backup)",
            "Only needed for muted groups you never open, or if you skipped \"Read open chats\". To catch up: in the group tap ⋮ > More > Export chat > Without media, then choose \"Add Ghostie reminders\". You can also share a single message the same way."
        )
        buttonRow(catchUp, button("Scan a chat file…", false) {
            if (!ensureCalendar()) return@button
            val pick = Intent(Intent.ACTION_OPEN_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType("*/*")
                .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/plain", "application/zip"))
            startActivityForResult(pick, 77)
        })

        // Documents
        section = "docs"
        val docs = card(
            "📂 Documents",
            "Copies WhatsApp documents into Documents/Ghostie/<Subject>. Tick the subjects you study and only those are organized. Originals stay put. You can also tell the ghost: \"organize documents\"."
        )
        buildSubjectPicker(docs)
        buttonRow(docs, button("Organize now") {
            saveFields()
            if (!DocOrganizer.hasAccess(this)) {
                askFileAccess()
            } else {
                toast("Sorting...")
                Thread {
                    val text = try {
                        DocOrganizer.summary(DocOrganizer.organize(this))
                    } catch (e: Exception) {
                        "Something went wrong while organizing."
                    }
                    runOnUiThread { SymBuilder(this).setTitle("Documents").setMessage(text).setPositiveButton("OK", null).show() }
                }.start()
            }
        })

        docs.addView(hint("Smart sorting also uses which chat a file came from and what is written inside PDFs, Word and PowerPoint files.").apply { setPadding(0, dp(2), 0, dp(4)) })
        switchRow(docs, "Sort new WhatsApp documents automatically (off by default)", s.autoOrganize) { s.autoOrganize = it }
        switchRow(docs, "Read inside PDF, Word, PowerPoint, text and CSV files to pick the subject", s.readInside) { s.readInside = it }

        buttonRow(docs, button("Browse sorted files", false) { renderDocs() })
        docBox = LinearLayout(this)
        docBox.orientation = LinearLayout.VERTICAL
        docs.addView(docBox, match())

        // What Ghostie has learned
        section = "brain"
        val agent = card(
            "🤖 Ghostie's agent",
            "Ghostie watches how you use it (when you study, which focus length you finish, which deadlines you act on or bin, when you ignore it) and suggests things. Every suggestion has Yes / Not now chips, and it goes quiet about things you keep declining. All of this stays on your phone."
        )
        switchRow(agent, "Let Ghostie make suggestions", s.suggestions) { s.suggestions = it }
        val insightBox = label("", 13f, textMain)
        agent.addView(insightBox, match())
        refreshers.add {
            val ins = HabitStore.get(this).insights()
            val quiet = s.quietHourSet().sorted()
            insightBox.text = (if (ins.isEmpty()) "Still learning. Use me for a few days (study, chat, answer reminders) and I'll start spotting patterns." else ins.joinToString("\n") { "• $it" }) +
                (if (quiet.isNotEmpty()) "\n• Quiet hours (no visits): " + HabitStore.get(this).rangeText(quiet) else "")
        }
        buttonRow(
            agent,
            button("Plan my week", false) { startService(petIntent(PetOverlayService.ACTION_PLAN)) },
            button("Clear quiet hours", false) { s.quietHoursList = ""; refresh() }
        )
        buttonRow(
            agent,
            button("Unmute suggestions", false) { HabitStore.get(this).unmuteAll(); HabitStore.save(this); toast("Suggestions unmuted"); refresh() },
            button("Forget my habits", false) {
                SymBuilder(this).setTitle("Forget my habits?").setMessage("Ghostie will unlearn your routines, study history by subject and quiet hours.")
                    .setPositiveButton("Forget") { _, _ -> HabitStore.reset(this); s.quietHoursList = ""; s.subjectLog = ""; toast("Forgotten 🧹"); refresh() }
                    .setNegativeButton("Cancel", null).show()
            }
        )

        val learn = card("🧠 What Ghostie learned", "Ghostie remembers your corrections on this phone only: which words mean which subject or calendar category, phrases you teach it, deadlines you throw away, and what you like to chat about. It is a small learner, not a big AI model, and works offline. Teach it in chat: \"when I say study mode, set timer 25 minutes\".")
        learnBox = LinearLayout(this)
        learnBox.orientation = LinearLayout.VERTICAL
        learn.addView(learnBox, match())

        // Words and sentences
        learn.addView(label("Words and sentences", 15f, textMain, true).apply { setPadding(0, dp(12), 0, dp(2)) })
        learn.addView(hint("Ghostie reads what you say to it, text you paste here, and (if switched on) your watched groups and shared chats. It remembers which words follow which, then builds its own new sentences in your style and mixes them into its chat. Rate them 👍/👎 to teach it. It's a small word-chain model, so sentences can be quirky. Links, phone numbers and rude words are skipped."))
        switchRow(learn, "Learn words from watched groups and shared chats", s.learnGroups) { s.learnGroups = it }
        val teachField = textField("Teach by example: paste messages, jokes or lines you like", "", true, 3)
        learn.addView(teachField, fieldLp())
        buttonRow(
            learn,
            button("Learn from this") {
                val n = SentenceStore.learn(this, teachField.text.toString(), 3)
                SentenceStore.save(this)
                teachField.setText("")
                toast(if (n > 0) "Learned $n new sentence(s) 🧠" else "Nothing new to learn there")
                renderLearned()
            },
            button("Say something", false) {
                val m = SentenceStore.get(this)
                val msg = if (!m.ready) "I'm still learning words 📚 (${m.summary()})" else m.generate()?.let { it } ?: "I need a few more sentences first."
                SymBuilder(this).setTitle("Ghostie says").setMessage(msg).setPositiveButton("OK", null).show()
            }
        )
        buttonRow(learn, button("Forget learned words", false) {
            SymBuilder(this).setTitle("Forget all learned words?").setMessage("Ghostie will stop making its own sentences until it learns again.")
                .setPositiveButton("Forget") { _, _ -> SentenceStore.reset(this); renderLearned(); toast("Words forgotten") }
                .setNegativeButton("Cancel", null).show()
        })
        buttonRow(learn, button("Forget everything", false) {
            SymBuilder(this).setTitle("Forget everything?").setMessage("This erases what Ghostie learned. Your events and documents stay.")
                .setPositiveButton("Forget") { _, _ -> LearnStore.reset(this); renderLearned(); toast("Memory wiped") }
                .setNegativeButton("Cancel", null).show()
        })

        // Companion settings
        section = "study"
        buildStudentCards()
        section = "more"
        buildAlarmsCard()
        buildQuickRemindersCard()
        buildTripCard()
        val bk = card("💾 Backup & move", "Saves your timetable, attendance, exams, flashcards, alarms and settings to one file. Updating the app keeps them already; use this before uninstalling, when switching between the full and lite apps, or moving to a new phone.")
        buttonRow(bk, button("Export backup", true) {
            val i = Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json")
                .putExtra(Intent.EXTRA_TITLE, "ghostie-backup-" + java.time.LocalDate.now() + ".json")
            @Suppress("DEPRECATION") startActivityForResult(i, 79)
        }, button("Import backup", false) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
            @Suppress("DEPRECATION") startActivityForResult(i, 78)
        })
        val call = card(
            "📞 Ghostie calls me",
            "When someone you pick keeps messaging, or sends an urgent word, Ghostie rings like an incoming call and tells you who it is. Answer opens WhatsApp. Drag the ghost into the bin on the call screen (or tap 🗑 Never) and it stops ringing for that chat."
        )
        switchRow(call, "Ring me for the people below", s.callEnabled) { s.callEnabled = it }
        switchRow(call, "Also ring if a deadline isn't marked done in its last hour", s.finalCall) {
            s.finalCall = it
            if (it) ReminderAlarms.rescheduleAll(this)
        }
        spinnerRow(call, "Last-hour call at", listOf("2 hours before", "1 hour before", "30 min before", "15 min before"), listOf(120, 60, 30, 15), s.finalCallMin) {
            if (it != s.finalCallMin) { s.finalCallMin = it; ReminderAlarms.rescheduleAll(this) }
        }
        vipField = textField("One person or group per line, exactly as WhatsApp shows it", s.callVips, true, 3)
        call.addView(vipField, fieldLp())
        spinnerRow(call, "Ring after", listOf("2 messages", "3 messages", "4 messages", "5 messages"), listOf(2, 3, 4, 5), s.callCount) { s.callCount = it }
        spinnerRow(call, "Within", listOf("2 min", "5 min", "10 min", "30 min"), listOf(2, 5, 10, 30), s.callWindow) { s.callWindow = it }
        urgentField = textField("Urgent words, separated by commas", s.callUrgent, true, 2)
        call.addView(urgentField, fieldLp())
        buttonRow(
            call,
            button("Test call", false) {
                saveFields()
                CallAlerts.show(this, "Test", "Test chat has messaged you 3 times", "pls reply, it's urgent!")
            },
            button("Test deadline call", false) {
                CallAlerts.show(this, "Test", "⏰ Lab record is due in about 60 min and isn't marked done", "", 1L)
            },
            button("Allow full screen", false) {
                try {
                    if (Build.VERSION.SDK_INT >= 34) startActivity(Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT", Uri.parse("package:$packageName")))
                    else toast("Already allowed on this Android version")
                } catch (e: Exception) { toast("Open Settings > Apps > Ghostie > Notifications") }
            },
            button("Unmute chats", false) {
                val n = LearnStore.get(this).clearBlocked("call")
                LearnStore.save(this)
                toast(if (n == 0) "No muted chats" else "Unmuted $n chat(s)")
            }
        )
        call.addView(hint("Needs Notification access (Setup tab). Ghostie can't phone your own number, so this is an on-screen call with ringtone and vibration. It rings even in the background, but not if Do Not Disturb blocks it.").apply { setPadding(0, dp(6), 0, 0) })

        val pref = card("🎛️ Companion")
        val themeCard = card("🎨 Look & feel")
        switchRow(themeCard, "Use simple symbols instead of emoji", s.symbolIcons) { s.symbolIcons = it; Sym.on = it; recreate() }
        spinnerRow(themeCard, "Theme", Themes.labels, Themes.ids.indices.toList(), Themes.ids.indexOf(s.theme).coerceAtLeast(0)) { i ->
            if (Themes.ids[i] != s.theme) { s.theme = Themes.ids[i]; recreate() }
        }
        spinnerRow(themeCard, "Theme colour", Themes.accentLabels, Themes.accentLabels.indices.toList(), s.accentChoice) { i ->
            if (i != s.accentChoice) { s.accentChoice = i; recreate() }
        }
        spinnerRow(themeCard, "Navigation bar", listOf("Classic tabs (top)", "Neon glass", "Dip bubble", "Pop bubble"), listOf(0, 1, 2, 3), s.navStyle) {
            if (it != s.navStyle) { s.navStyle = it; recreate() }
        }
        ghostSwitchRow(themeCard, "Glass look", s.glass, 1) { s.glass = it; recreate() }
        if (s.glass) {
            themeCard.addView(label("Glass intensity", 14f, textMain).apply { setPadding(0, dp(4), 0, 0) })
            val bar = android.widget.SeekBar(this)
            bar.max = 100
            bar.progress = s.glassLevel
            bar.progressTintList = android.content.res.ColorStateList.valueOf(accent)
            bar.thumbTintList = android.content.res.ColorStateList.valueOf(accent)
            bar.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: android.widget.SeekBar?, v: Int, fromUser: Boolean) {}
                override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
                override fun onStopTrackingTouch(sb: android.widget.SeekBar?) { s.glassLevel = sb?.progress ?: 50; recreate() }
            })
            themeCard.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        }
        switchRow(themeCard, "Tap the small ghost: open the chat box directly (off = big ghost comes first)", s.directChat) { s.directChat = it }
        themeCard.addView(label("Chat box: drag its title bar to move it and the ◢ corner to resize it.", 12f, textSub).apply { setPadding(0, dp(2), 0, dp(4)) })
        buttonRow(
            themeCard,
            button("Small", false) { s.chatW = 260; s.chatH = 140; toast("Chat box: small") },
            button("Medium", false) { s.chatW = 320; s.chatH = 200; toast("Chat box: medium") },
            button("Large", false) { s.chatW = 380; s.chatH = 320; toast("Chat box: large") }
        )
        buttonRow(themeCard, button("Reset chat position", false) { s.chatX = -1; s.chatY = -1; toast("Chat box position reset") })
        switchRow(themeCard, "Show explanations under settings", s.showHints) {
            s.showHints = it
            for (v in hintViews) v.visibility = if (it) View.VISIBLE else View.GONE
        }
        switchRow(themeCard, "Show the tutorial after Ghostie is installed or updated", s.tutorialAuto) { s.tutorialAuto = it }
        buttonRow(themeCard, button("📖 Show tutorial") { showTutorial() })
        switchRow(pref, "Enable pet", s.enabled) { s.enabled = it }
        ghostSwitchRow(pref, "Check-ins", s.checkins, 3) { s.checkins = it }
        switchRow(pref, "Always on top", s.alwaysTop) { s.alwaysTop = it }
        switchRow(pref, "Ghost speaks aloud", s.speak) { s.speak = it }
        switchRow(pref, "Sound effects (squeaks, giggles)", s.sound) { s.sound = it }
        val modes = listOf("both", "mic", "hold", "always")
        spinnerRow(pref, "Listening", listOf("Mic button + hold ghost", "Mic button only", "Hold ghost only", "Always on"), listOf(0, 1, 2, 3), modes.indexOf(s.listenMode).coerceAtLeast(0)) { s.listenMode = modes[it] }
        pref.addView(hint("Always on keeps the microphone ready in the background (uses more battery, and Android may stop it). Outside the chat box it only reacts when you start with its name (Ghostie, or the name you set below), for example \"Ghostie, what's the time\". Needs the Microphone permission.").apply { setPadding(0, dp(2), 0, dp(4)) })
        val wakeField = textField("Name for Always on (default Ghostie)", s.petName, false)
        pref.addView(wakeField, fieldLp())
        buttonRow(pref, button("Save name", false) {
            s.petName = wakeField.text.toString().trim().take(20)
            Toast.makeText(this, "Always on now waits for \"${s.petName}\"", Toast.LENGTH_SHORT).show()
        })
        pref.addView(hint("Pick a name that is easy to say and unlike everyday words, for example Casper or Boo. Phones often mishear names, so Ghostie also accepts close sounds like \"ghosty\".").apply { setPadding(0, dp(2), 0, dp(4)) })
        spinnerRow(pref, "Voice", listOf("Squeaky", "Cute", "Normal"), listOf(18, 14, 10), s.voicePitch) { s.voicePitch = it }
        pref.addView(hint("Uses your phone's text-to-speech voice, pitched up. Silent when the phone is on silent or vibrate. Tap and hold the ghost to pet it, double-tap to spin it, drag it and shake it to make it dizzy.").apply { setPadding(0, dp(2), 0, dp(4)) })
        ghostSwitchRow(pref, "Sleep at night (11 pm - 6 am)", s.sleepEnabled, 0) { s.sleepEnabled = it }
        val sizeLabel = label("Ghost size: ${s.petDp}", 15f, textMain)
        sizeLabel.setPadding(0, dp(8), 0, 0)
        pref.addView(sizeLabel, match())
        val bar = SeekBar(this)
        bar.max = 144
        bar.progress = s.petDp - 56
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                sizeLabel.text = "Ghost size: ${value + 56}"
                if (fromUser) s.petDp = value + 56
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        pref.addView(bar, match())
        pref.addView(hint("The ghost also hides during calls, in landscape and in Do Not Disturb.").apply { setPadding(0, dp(2), 0, dp(4)) })
        spinnerRow(pref, "Visit every", listOf("5 min", "10 min", "15 min", "30 min", "1 hour"), listOf(5, 10, 15, 30, 60), s.visitMinutes) { s.visitMinutes = it }
        spinnerRow(pref, "Water reminder", listOf("15 min", "30 min", "1 hour", "2 hours"), listOf(15, 30, 60, 120), s.waterMinutes) { s.waterMinutes = it }

        spinnerRow(pref, "Language (voice)", listOf("English", "हिन्दी / Hinglish"), listOf(0, 1), if (s.language == "hi") 1 else 0) { s.language = if (it == 1) "hi" else "en" }
        pref.addView(hint("Sets what Ghostie listens for and the voice it speaks with. Hindi and Hinglish commands like \"kal shaam 6 baje alarm lagao\" or \"5 minute ka timer\" work in either mode. Chat replies are still in English. Hindi voice needs Hindi installed in your phone's speech settings.").apply { setPadding(0, dp(2), 0, dp(4)) })
        val moodBlurb = label(Moods.blurb(s.mood), 12f, textSub)
        spinnerRow(pref, "Personality", Moods.labels, Moods.ids.indices.toList(), Moods.ids.indexOf(s.mood).coerceAtLeast(0)) { i ->
            s.mood = Moods.ids[i]
            moodBlurb.text = Moods.blurb(s.mood)
        }
        pref.addView(moodBlurb, match())
        buttonRow(pref, button("Hear it", false) {
            startService(petIntent(PetOverlayService.ACTION_SAY).putExtra("text", Moods.preview(s.mood)))
        })
        switchRow(pref, "Show \"tap to open\" when Ghostie opens an app", s.openFallback) { s.openFallback = it }
        switchRow(pref, "Random tricks (dance, wave, yawn, flip)", s.tricks) { s.tricks = it }
        switchRow(pref, "Big ghost's cloth keeps waving", s.ghostWave) { s.ghostWave = it; startService(petIntent(PetOverlayService.ACTION_SKIN)) }
        switchRow(pref, "Spooky wail when the big ghost arrives", s.spooky) { s.spooky = it }
        buttonRow(pref, button("Hear the wail 👻", false) { SpookySound.play() })
        switchRow(pref, "React to charging / low battery", s.batteryReacts) { s.batteryReacts = it }
        val tintField = textField("Custom colour, e.g. #FFC9E3", s.customTint, false)
        pref.addView(tintField, fieldLp())
        buttonRow(pref, button("Use custom colour", false) {
            try {
                Color.parseColor(tintField.text.toString().trim())
                s.customTint = tintField.text.toString()
                s.skin = "custom"
                startService(petIntent(PetOverlayService.ACTION_SKIN))
                toast("Custom colour applied 🎨")
            } catch (e: Exception) { toast("Use a hex colour like #FFC9E3") }
        })
        val skinList = Skins.all
        builtUnlocked = skinList.count { Skins.unlocked(it, s.chatCount) }
        spinnerRow(
            pref, "Ghost look",
            skinList.map { (if (Skins.unlocked(it, s.chatCount)) "" else "🔒 ") + it.label + (if (Skins.unlocked(it, s.chatCount)) "" else " (${it.unlockChats} chats)") },
            skinList.indices.toList(), skinList.indexOfFirst { it.id == s.skin }.coerceAtLeast(0)
        ) { i ->
            val sk = skinList[i]
            if (!Skins.unlocked(sk, s.chatCount)) toast("Chat with Ghostie ${sk.unlockChats - s.chatCount} more times to unlock ${sk.label}")
            else if (sk.id != s.skin) { s.skin = sk.id; startService(petIntent(PetOverlayService.ACTION_SKIN)) }
        }

        val shareCard = card("📤 Share Ghostie", "Paste your download link once (GitHub release link), then send it to friends in one tap.")
        linkField = textField("https://github.com/you/repo/releases/latest/download/Ghostie.apk", s.shareLink, false)
        shareCard.addView(linkField, fieldLp())
        buttonRow(shareCard, button("Share with a friend", false) {
            saveFields()
            if (s.shareLink.isBlank()) toast("Paste the download link first")
            else {
                val msg = "Try Ghostie 👻, a floating ghost that reads your class groups and reminds you of deadlines.\n\nDownload: ${s.shareLink}\n\nAfter installing: open Ghostie → Setup tab, allow Display over apps, Notifications and Calendar. If Accessibility or Notification access is greyed out: App info → ⋮ → Allow restricted settings."
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg), "Share Ghostie"))
            }
        })

        val rules = card("🎯 Group rules", "Per group, words that mean \"not a deadline\". One rule per line, e.g.  CS Group: ignore lunch, party, trip   (use * for every group). Each deadline in the list also shows the original message so you can tell why it was added.")
        switchRow(rules, "Alert me about class changes (cancelled, moved, room, online)", s.classAlerts) { s.classAlerts = it }
        rulesField = textField("CS Group: ignore lunch, party", s.groupRules, true, 3)
        rules.addView(rulesField, fieldLp())

        // Quiet time
        val quiet = card("🔕 Quiet time", "Pause visits and reminders from the ghost.")
        buttonRow(quiet, button("30 min", false) { pauseFor(30, "30 minutes") }, button("1 hour", false) { pauseFor(60, "1 hour") })
        buttonRow(
            quiet,
            button("Until tomorrow", false) {
                s.quietUntil = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                toast("Quiet until tomorrow")
            },
            button("Resume") {
                s.quietUntil = 0L
                toast("Ghostie resumed")
            }
        )

        // Activity log
        val act = card("🧾 Activity log", "What Ghostie has seen and done lately. Useful if a reminder did not appear.")
        activityBox = LinearLayout(this)
        activityBox.orientation = LinearLayout.VERTICAL
        act.addView(activityBox, match())
        buttonRow(
            act,
            button("Refresh", false) { renderActivity() },
            button("Copy", false) {
                val text = ActivityLog.read(this).take(40).joinToString("\n") { it.text() }
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Ghostie log", text))
                toast("Copied")
            },
            button("Clear", false) { ActivityLog.clear(this); renderActivity() }
        )

        // AI
        val ai = card(
            "✨ AI chat (optional)",
            "Free and nothing to download: pick a provider, make a free key on their website (Groq: console.groq.com) and paste it here. Needs internet, and what you say to the AI is sent to that provider. Without it Ghostie still works offline."
        )
        switchRow(ai, "Use AI for free chat", s.ai) { s.ai = it }
        switchRow(ai, "Also send a short summary of my deadlines, study time and habits (never message text), so AI answers and plans fit me", s.aiContext) { s.aiContext = it }
        val provs = ChatEngine.providers
        baseField = textField("Address", s.aiBase, false)
        modelField = textField("Model", s.aiModel, false)
        spinnerRow(ai, "Provider", provs.map { it.label }, provs.indices.toList(), provs.indexOfFirst { it.id == s.aiProvider }.coerceAtLeast(0)) { i ->
            val pv = provs[i]
            if (pv.id != s.aiProvider) {
                s.aiProvider = pv.id
                s.aiBase = pv.base
                s.aiModel = pv.model
                baseField.setText(pv.base)
                modelField.setText(pv.model)
            }
        }
        keyField = textField("API key", s.key, false, 1, true)
        ai.addView(keyField, fieldLp())
        ai.addView(baseField, fieldLp())
        ai.addView(modelField, fieldLp())
        ai.addView(hint("Address and model are filled in for you. Change them only if a provider renames its model.").apply { setPadding(0, dp(6), 0, 0) })

        finalizeCards()
        currentTab = if (tabButtons.containsKey(s.tab)) s.tab else "home"
        applyTab()
    }

    /** Cards become tap-to-open: one short title line each; the first card of every tab starts open. */
    private fun finalizeCards() {
        val state = s.cardState.toMutableSet()
        val firstOfTab = HashSet<String>()
        for ((c, sec) in cardSections) {
            val ll = c as? LinearLayout ?: continue
            val titleView = ll.getChildAt(0) as? TextView ?: continue
            val key = titleView.text.toString()
            if (advancedTitles.any { key.startsWith(it) }) advancedCards.add(c)
            if (ll.childCount < 3) continue
            val default = firstOfTab.add(sec) || key.startsWith("Finish setting up") || key.startsWith("👻")
            val body = LinearLayout(this)
            body.orientation = LinearLayout.VERTICAL
            val kids = (1 until ll.childCount).map { ll.getChildAt(it) }
            kids.forEach { ll.removeView(it); body.addView(it) }
            ll.addView(body)
            var open = when {
                "$key=1" in state -> true
                "$key=0" in state -> false
                else -> default
            }
            fun render() {
                body.visibility = if (open) View.VISIBLE else View.GONE
                titleView.text = (if (open) "▾  " else "▸  ") + key
            }
            render()
            cardOpeners[c] = { if (!open) { open = true; render() } }
            titleView.setOnClickListener {
                open = !open
                render()
                state.remove("$key=1"); state.remove("$key=0"); state.add("$key=" + if (open) "1" else "0")
                s.cardState = state.toSet()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode == RESULT_OK && uri != null && requestCode == 79) {
            try { contentResolver.openOutputStream(uri, "wt")?.use { it.write(Backup.export(this).toByteArray()) }; toast("Backup saved ✅") }
            catch (e: Exception) { toast("Couldn't save the backup") }
            return
        }
        if (resultCode == RESULT_OK && uri != null && requestCode == 80) { mineFile(uri); return }
        if (resultCode == RESULT_OK && uri != null && requestCode == 81) { timetableFromPhoto(uri); return }
        if (resultCode == RESULT_OK && uri != null && requestCode == 78) {
            val n = try { Backup.import(this, contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: "") } catch (e: Exception) { -1 }
            if (n < 0) toast("That isn't a Ghostie backup file") else { toast("Restored $n items ✅"); recreate() }
            return
        }
        if (requestCode != 77 || resultCode != RESULT_OK || uri == null) return
        toast("Scanning...")
        Thread {
            var group = "Chat"
            val msg = try {
                val (g, text) = ChatImporter.read(this, uri)
                group = g
                ChatImporter.describe(g, ChatImporter.importText(this, g, text))
            } catch (e: Exception) {
                "I couldn't read that file."
            }
            runOnUiThread {
                SymBuilder(this).setTitle(group).setMessage(msg).setPositiveButton("OK", null).show()
                renderLog()
            }
        }.start()
    }

    private fun renderLearned() {
        if (!::learnBox.isInitialized) return
        learnBox.removeAllViews()
        val l = LearnStore.get(this)
        learnBox.addView(label(l.summary() + "\n" + SentenceStore.get(this).summary(), 12f, textSub), match())
        for ((phrase, meaning) in l.aliases.entries.toList().take(10)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.addView(label("\"$phrase\" → " + meaning.removePrefix("word:").removePrefix("say:"), 13f, textMain), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val x = button("✕", false) { l.removeAlias(phrase); LearnStore.save(this); renderLearned() }
            x.minHeight = dp(34); x.minimumHeight = dp(34)
            row.addView(x, LinearLayout.LayoutParams(dp(52), dp(36)))
            learnBox.addView(row, match())
        }
    }

    private fun renderDocs() {
        if (!::docBox.isInitialized) return
        docBox.removeAllViews()
        if (!DocOrganizer.hasAccess(this)) {
            docBox.addView(label("Allow File access in Setup first.", 13f, textSub))
            return
        }
        val files = DocOrganizer.sortedFiles()
        if (files.isEmpty()) {
            docBox.addView(label("No sorted files yet. Tap Organize now.", 13f, textSub))
            return
        }
        docBox.addView(hint("Folders by subject. Tap a folder to open it. Tap a file to move it to another subject (Ghostie learns). Long-press and drag a file to the bin to delete Ghostie's copy - the WhatsApp original stays.").apply { setPadding(0, 0, 0, dp(6)) })
        val names = SubjectMatcher.parse(s.subjects).map { it.name }
        val groups = files.groupBy { it.first }.toSortedMap(compareBy<String> { it.lowercase() })
        for ((subject, list) in groups) {
            val open = docFolderOpen.contains(subject)
            val head = LinearLayout(this)
            head.orientation = LinearLayout.HORIZONTAL
            head.gravity = Gravity.CENTER_VERTICAL
            head.background = rounded(field, 12, cardStroke)
            head.setPadding(dp(12), dp(10), dp(12), dp(10))
            head.addView(label((if (open) "📂 " else "📁 ") + subject, 14f, textMain, true), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            head.addView(label("${list.size} " + (if (list.size == 1) "file" else "files") + if (open) "  ▾" else "  ▸", 12f, accent))
            head.setOnClickListener { if (open) docFolderOpen.remove(subject) else docFolderOpen.add(subject); renderDocs() }
            val hlp = match(); hlp.bottomMargin = dp(6)
            docBox.addView(head, hlp)
            if (!open) continue
            for ((_, file) in list.take(60)) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.VERTICAL
                row.background = rounded(field, 12, cardStroke)
                row.setPadding(dp(12), dp(8), dp(12), dp(8))
                row.addView(label(file.name, 13f, textMain, true))
                row.setOnClickListener {
                    SymBuilder(this).setTitle("Move \"${file.name}\" to…")
                        .setItems(names.toTypedArray()) { _, i ->
                            toast(if (DocOrganizer.moveTo(this, file, names[i])) "Moved - I'll remember that 🧠" else "Couldn't move it")
                            renderDocs(); renderLearned(); renderActivity()
                        }.show()
                }
                makeDraggable(row) {
                    toast(if (DocOrganizer.binFile(this, file)) "Thrown away 🗑️" else "Couldn't delete it")
                    renderDocs(); renderActivity()
                }
                val lp = match()
                lp.bottomMargin = dp(6); lp.leftMargin = dp(14)
                docBox.addView(row, lp)
            }
            if (list.size > 60) docBox.addView(hint("Showing the newest 60 of ${list.size}."))
        }
    }

    private val docFolderOpen = HashSet<String>()

    private fun renderActivity() {
        if (!::activityBox.isInitialized) return
        activityBox.removeAllViews()
        val lines = ActivityLog.read(this).take(15)
        if (lines.isEmpty()) {
            activityBox.addView(label("Nothing yet.", 13f, textSub))
            return
        }
        for (l in lines) activityBox.addView(label(l.text(), 12f, textSub).apply { setPadding(0, dp(2), 0, dp(2)) }, match())
    }

    /** Ending study mode during a focus block is deliberately slow: 30 seconds of waiting, then a sentence to type. */
    private fun confirmEndStudy() {
        val phrase = "I want to stop"
        val box = LinearLayout(this); box.orientation = LinearLayout.VERTICAL; box.setPadding(dp(20), dp(8), dp(20), 0)
        val info = SymText(this); info.text = "You're in a focus block. Wait 30 seconds, then type exactly:\n\"$phrase\""
        val input = EditText(this); input.hint = phrase; input.isEnabled = false
        box.addView(info); box.addView(input)
        val dlg = SymBuilder(this).setTitle("End study mode?").setView(box)
            .setPositiveButton("End study mode", null).setNegativeButton("Keep studying", null).create()
        dlg.show()
        val ok = dlg.getButton(android.app.AlertDialog.BUTTON_POSITIVE)
        ok.isEnabled = false
        val h = android.os.Handler(mainLooper)
        var left = 30
        val tick = object : Runnable { override fun run() {
            if (!dlg.isShowing) return
            if (left > 0) { info.text = "Wait $left s, then type exactly:\n\"$phrase\""; left--; h.postDelayed(this, 1000) }
            else { info.text = "Now type exactly:\n\"$phrase\""; input.isEnabled = true }
        } }
        h.post(tick)
        input.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(e: android.text.Editable?) { ok.isEnabled = left <= 0 && e.toString().trim().equals(phrase, true) }
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
        })
        ok.setOnClickListener {
            if (ok.isEnabled) {
                startService(petIntent(PetOverlayService.ACTION_STUDY_STOP).putExtra("confirmed", true))
                toast("Study mode stopped"); dlg.dismiss(); handlerRefreshSoon()
            }
        }
    }

    private fun hasSms(): Boolean = checkSelfPermission(Manifest.permission.RECEIVE_SMS) == android.content.pm.PackageManager.PERMISSION_GRANTED &&
        checkSelfPermission(Manifest.permission.READ_SMS) == android.content.pm.PackageManager.PERMISSION_GRANTED

    /** Student spending: budget, this month's total, top categories, latest payments. Data comes from bank/UPI SMS, payment notifications or typing "spent 120 on lunch". */
    private fun buildMoneyCard() {
        val c = card("💸 Spending", "Keeps your money in check. Reads bank/UPI texts and payment notifications on this phone (amount and shop only, never the message) or tell Ghostie: \"spent 120 on lunch\".")
        val summary = label("", 14f, textMain)
        c.addView(summary, match())
        val where = hint("")
        c.addView(where, match())
        val recent = hint("")
        c.addView(recent, match())
        fun render() {
            summary.text = ExpenseStore.summaryText(this)
            val bd = MoneyMath.breakdown(ExpenseStore.all(this), java.time.YearMonth.now())
            where.text = if (bd.isEmpty()) "" else "Where it went this month:\n" + bd.joinToString("\n")
            val last = ExpenseStore.all(this).takeLast(5).reversed()
            val fmt = DateTimeFormatter.ofPattern("d MMM", Locale.ENGLISH)
            recent.text = if (last.isEmpty()) "No payments yet." else last.joinToString("\n") {
                val d = java.time.Instant.ofEpochMilli(it.time).atZone(ZoneId.systemDefault()).format(fmt)
                (if (it.debit) "−" else "+") + MoneyParser.format(it.amount) + "  " + it.merchant + " · " + it.category + " · " + d + MoneyParser.senderOf(it.source).let { f -> if (f.isEmpty()) "" else " · $f" }
            }
        }
        render()
        refreshers.add { render() }
        switchRow(c, "Read bank texts and payment notifications", s.moneyAuto) { s.moneyAuto = it }
        permRow(c, "SMS access", "Lets Ghostie see bank/UPI texts as they arrive", { hasSms() }) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS), 6)
        }
        buttonRow(c,
            button("Set monthly budget", false) {
                val et = android.widget.EditText(this)
                et.inputType = android.text.InputType.TYPE_CLASS_NUMBER
                et.setText(if (s.monthlyBudget > 0) s.monthlyBudget.toString() else "")
                et.hint = "e.g. 5000"
                SymBuilder(this).setTitle("Monthly budget (₹)").setView(et)
                    .setPositiveButton("Save") { _, _ -> s.monthlyBudget = et.text.toString().trim().toIntOrNull() ?: 0; render() }
                    .setNegativeButton("Cancel", null).show()
            },
            button("Scan last 30 days of texts", false) {
                if (!hasSms()) { toast("Allow SMS access first"); return@button }
                val n = MoneySmsReceiver.scanInbox(this, 30)
                toast("Found $n new payment(s)"); render()
            }
        )
        buttonRow(c, button("See what I spent on", true) { showSpendBreakdown(java.time.YearMonth.now()) })
        buttonRow(c,
            button("Add expense", false) {
                val box = LinearLayout(this); box.orientation = LinearLayout.VERTICAL; box.setPadding(dp(20), dp(8), dp(20), 0)
                val amt = android.widget.EditText(this); amt.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; amt.hint = "Amount (₹)"
                val note = android.widget.EditText(this); note.hint = "What for? (lunch, auto, xerox)"
                box.addView(amt); box.addView(note)
                SymBuilder(this).setTitle("Add expense").setView(box)
                    .setPositiveButton("Add") { _, _ ->
                        val a = amt.text.toString().toDoubleOrNull()
                        if (a != null && a > 0) { val n = note.text.toString().trim(); ExpenseStore.add(this, Txn(System.currentTimeMillis(), a, true, n.ifBlank { "Manual" }, MoneyParser.categorize(n), "manual")); render() }
                    }.setNegativeButton("Cancel", null).show()
            },
            button("Clear all", false) {
                SymBuilder(this).setTitle("Clear spending history?").setMessage("This only removes Ghostie's list. Your bank and texts are untouched.")
                    .setPositiveButton("Clear") { _, _ -> ExpenseStore.clear(this); render() }.setNegativeButton("Cancel", null).show()
            }
        )
    }

    /** Where the money went in a month: categories with totals, tap one to see each payment. Previous/next month buttons. */
    private fun showSpendBreakdown(month: java.time.YearMonth) {
        val list = ExpenseStore.all(this)
        val cats = MoneyMath.byCategory(list, month)
        val total = cats.sumOf { it.second }
        val title = month.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)) + ": " + MoneyParser.format(total)
        val b = SymBuilder(this).setTitle(title)
            .setNeutralButton("◀ Earlier") { _, _ -> showSpendBreakdown(month.minusMonths(1)) }
            .setPositiveButton("Close", null)
        if (month.isBefore(java.time.YearMonth.now())) b.setNegativeButton("Later ▶") { _, _ -> showSpendBreakdown(month.plusMonths(1)) }
        if (cats.isEmpty()) b.setMessage("No spending recorded in this month.")
        else {
            val lines = MoneyMath.breakdown(list, month)
            b.setItems((lines + "All payments").toTypedArray()) { _, i ->
                val cat = if (i < cats.size) cats[i].first else null
                val fmt = DateTimeFormatter.ofPattern("d MMM", Locale.ENGLISH)
                val pays = MoneyMath.payments(list, month, cat)
                val rows = pays.map {
                    java.time.Instant.ofEpochMilli(it.time).atZone(ZoneId.systemDefault()).format(fmt) + "  " + MoneyParser.format(it.amount) + "  " + it.merchant + (if (cat == null) " · " + it.category else "") + MoneyParser.senderOf(it.source).let { f -> if (f.isEmpty()) "" else " · from $f" }
                }
                SymBuilder(this).setTitle((cat ?: "All payments") + " (" + pays.size + ")  tap one to remove it")
                    .setItems(rows.toTypedArray()) { _, k ->
                        val t = pays[k]
                        SymBuilder(this).setTitle("This payment").setMessage(rows[k] + "\n\nCame from: " + MoneyParser.sourceText(t.source) + "\n\nRemove it if it isn't really a payment (a bill reminder, an offer). Only Ghostie's list changes.")
                            .setPositiveButton("Remove") { _, _ -> ExpenseStore.remove(this, t); refreshers.forEach { r -> r() }; showSpendBreakdown(month) }
                            .setNeutralButton("Find the text") { _, _ ->
                                val found = if (hasSms()) MoneySmsReceiver.findTexts(this, t) else null
                                val msg = when {
                                    found == null -> "Allow SMS access (Spending card) so I can look in your inbox."
                                    found.isEmpty() -> "No text in your inbox mentions ${MoneyParser.format(t.amount)} around that time. It probably came from a payment-app notification, or the text was deleted."
                                    else -> found.joinToString("\n\n") { "From ${it.first}:\n${it.second}" }
                                }
                                SymBuilder(this).setTitle("Matching text(s)").setMessage(msg).setPositiveButton("OK") { _, _ -> showSpendBreakdown(month) }.show()
                            }
                            .setNegativeButton("Keep") { _, _ -> showSpendBreakdown(month) }.show()
                    }
                    .setPositiveButton("Back") { _, _ -> showSpendBreakdown(month) }.show()
            }
        }
        b.show()
    }

    /** Call notes: scans the recordings your phone's own call recorder makes, saves deadlines, then deletes the recording. */
    private fun buildCallNotesCard() {
        val c = card("📞 Call notes", "After a call, Ghostie reads the recording your phone's call recorder saved, turns up deadlines into reminders and other points into notes, then deletes the recording. Turn on call recording in your phone's Phone app first.")
        c.addView(hint("Recording a call may need the other person's consent where you live. Ghostie never records calls itself, and it keeps no transcript. Needs Android 13+, and a recording is kept (not deleted) if it couldn't be read.").apply { setPadding(0, 0, 0, dp(6)) })
        switchRow(c, "Scan new call recordings", s.callNotes) {
            s.callNotes = it
            if (it && !DocOrganizer.hasAccess(this)) toast("Allow File access below so Ghostie can see the recordings")
            try { startService(Intent(this, PetOverlayService::class.java)) } catch (e: Exception) { }
            refresh()
        }
        permRow(c, "File access", "To find and delete call recordings", { DocOrganizer.hasAccess(this) }) { askFileAccess() }
        permRow(c, "Microphone", "Needed by Android's speech reader", { hasMic() }) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 5)
        }
        val folders = hint("")
        fun show() {
            val f = CallNotes.folders(this)
            folders.text = if (f.isEmpty()) "No call recording folder found yet. Make a recorded call, or add your folder below." else "Watching: " + f.joinToString(", ") { it.absolutePath.removePrefix(android.os.Environment.getExternalStorageDirectory().absolutePath + "/") }
        }
        show()
        c.addView(folders, match())
        buttonRow(c, button("Set recordings folder", false) {
            val et = android.widget.EditText(this); et.setText(s.callFolder); et.hint = "e.g. MIUI/sound_recorder/call_rec"
            SymBuilder(this).setTitle("Call recordings folder").setMessage("Folder inside your phone storage.").setView(et)
                .setPositiveButton("Save") { _, _ -> s.callFolder = et.text.toString(); try { startService(Intent(this, PetOverlayService::class.java)) } catch (e: Exception) { }; show() }
                .setNegativeButton("Cancel", null).show()
        })
    }

    /** Tick-box list of subjects (grouped, tap a group to open it). Only ticked subjects are organized. */
    private fun buildSubjectPicker(parent: LinearLayout) {
        val picks = s.subjectPicks.toMutableSet()
        val boxes = ArrayList<Pair<String, android.widget.CheckBox>>()
        val heads = ArrayList<() -> Unit>()
        val summary = label("", 13f, textMain, true)
        fun upd() {
            summary.text = when {
                picks.isNotEmpty() || SubjectCatalog.parseCombos(s.subjectCombos).isNotEmpty() ->
                    "Organizing ${picks.size + SubjectCatalog.parseCombos(s.subjectCombos).size} subject(s)" + if (s.subjectCustom.isNotBlank()) " + your own" else ""
                s.subjectCustom.isNotBlank() -> "Organizing your own subjects only"
                else -> "Nothing ticked yet, so Ghostie's general list is used. Tick the subjects you study."
            }
            heads.forEach { it() }
        }
        parent.addView(summary, match())
        // Combined subjects (e.g. AI + ML = AIML): one row each, tap to split them apart again
        val comboBox = LinearLayout(this); comboBox.orientation = LinearLayout.VERTICAL
        parent.addView(comboBox, match())
        fun renderCombos(popName: String? = null) {
            comboBox.removeAllViews()
            for (cb in SubjectCatalog.parseCombos(s.subjectCombos)) {
                val row = label("🔗 ${cb.name}  =  " + cb.members.joinToString(" + ") + "   (tap to split)", 13f, accent, true)
                row.setPadding(dp(10), dp(8), dp(10), dp(8))
                row.background = rounded(card, 8, cardStroke)
                row.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(2)) }
                row.setOnClickListener {
                    SymBuilder(this).setTitle("Split ${cb.name}?")
                        .setMessage("${cb.name} goes back to ${cb.members.joinToString(" and ")}. Files already sorted stay where they are.")
                        .setPositiveButton("Split") { _, _ ->
                            s.subjectCombos = SubjectCatalog.writeCombos(SubjectCatalog.parseCombos(s.subjectCombos).filter { it.name != cb.name })
                            renderCombos(); upd(); toast("Split ${cb.name}")
                        }.setNegativeButton("Cancel", null).show()
                }
                comboBox.addView(row)
                if (cb.name == popName) {
                    // small "snap together" animation: starts wide and faint, settles in with a light overshoot
                    row.alpha = 0f; row.scaleX = 1.12f; row.scaleY = 0.8f
                    row.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(android.view.animation.OvershootInterpolator(2f)).start()
                }
            }
        }
        renderCombos()
        for (g in SubjectCatalog.groups) {
            val body = LinearLayout(this)
            body.orientation = LinearLayout.VERTICAL
            body.visibility = View.GONE
            val head = label("", 14f, accent, true)
            head.setPadding(0, dp(10), 0, dp(6))
            fun setHead() {
                val n = g.entries.count { it.name in picks }
                head.text = (if (body.visibility == View.VISIBLE) "▾ " else "▸ ") + g.title + (if (n > 0) "  ($n)" else "")
            }
            heads.add { setHead() }
            head.setOnClickListener { body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE; setHead() }
            for (en in g.entries) {
                val cb = SymCheck(this)
                cb.text = en.name
                cb.setTextColor(textMain)
                cb.buttonTintList = android.content.res.ColorStateList.valueOf(accent)
                cb.isChecked = en.name in picks
                cb.setOnCheckedChangeListener { _, on ->
                    if (on) picks.add(en.name) else picks.remove(en.name)
                    s.subjectPicksText = picks.joinToString("|")
                    upd()
                }
                boxes.add(en.name to cb)
                body.addView(cb, match())
            }
            parent.addView(head, match())
            parent.addView(body, match())
        }
        upd()
        switchRow(parent, "Also sort exam papers, timetables, assignments and labs", s.sortExtras) { s.sortExtras = it }
        buttonRow(parent, button("🔗 Combine subjects", false) {
            val names = SubjectCatalog.allNames()
            val chosen = BooleanArray(names.size)
            SymBuilder(this).setTitle("Pick 2 or more subjects to combine")
                .setMultiChoiceItems(names.toTypedArray(), chosen) { _, i, on -> chosen[i] = on }
                .setPositiveButton("Next") { _, _ ->
                    val members = names.filterIndexed { i, _ -> chosen[i] }
                    if (members.size < 2) { toast("Pick at least two subjects"); return@setPositiveButton }
                    val et = EditText(this)
                    et.setText(SubjectCatalog.suggestName(members)); et.setSelection(et.text.length)
                    val box = LinearLayout(this); box.setPadding(dp(20), dp(8), dp(20), 0); box.addView(et, match())
                    SymBuilder(this).setTitle("Name the combined subject")
                        .setMessage(members.joinToString(" + ") + "\n\nFiles about any of these go into one folder with this name.")
                        .setView(box)
                        .setPositiveButton("Combine") { _, _ ->
                            val nm = et.text.toString().trim().replace(Regex("[:|\\n]"), " ").trim()
                            if (nm.isEmpty()) { toast("Give it a name"); return@setPositiveButton }
                            val list = SubjectCatalog.parseCombos(s.subjectCombos).filter { it.name != nm } + SubjectCatalog.Combo(nm, members)
                            s.subjectCombos = SubjectCatalog.writeCombos(list)
                            // the members now live inside the combined subject, so untick them
                            picks.removeAll(members.toSet()); s.subjectPicksText = picks.joinToString("|")
                            for ((name, cbx) in boxes) if (name in members && cbx.isChecked) {
                                cbx.setOnCheckedChangeListener(null); cbx.isChecked = false
                                cbx.setOnCheckedChangeListener { _, on -> if (on) picks.add(name) else picks.remove(name); s.subjectPicksText = picks.joinToString("|"); upd() }
                            }
                            renderCombos(nm); upd(); toast("Combined into $nm ✅")
                        }.setNegativeButton("Cancel", null).show()
                }.setNegativeButton("Cancel", null).show()
        })
        buttonRow(parent,
            button("My own subjects", false) {
                val et = EditText(this)
                et.setText(s.subjectCustom)
                et.hint = "Robotics: robot, ros, manipulator"
                et.minLines = 4
                et.gravity = Gravity.TOP
                SymBuilder(this).setTitle("My own subjects").setMessage("One per line: Subject: keyword, keyword")
                    .setView(et)
                    .setPositiveButton("Save") { _, _ -> s.subjectCustom = et.text.toString(); upd() }
                    .setNegativeButton("Cancel", null).show()
            },
            button("Reset subjects", false) {
                SymBuilder(this).setTitle("Reset subjects?").setMessage("Unticks everything, removes your own subjects and restores Ghostie's general list. Files already sorted stay where they are.")
                    .setPositiveButton("Reset") { _, _ ->
                        s.resetSubjects(); picks.clear()
                        boxes.forEach { it.second.setOnCheckedChangeListener(null); it.second.isChecked = false }
                        // re-attach listeners
                        for ((name, cb) in boxes) cb.setOnCheckedChangeListener { _, on ->
                            if (on) picks.add(name) else picks.remove(name)
                            s.subjectPicksText = picks.joinToString("|"); upd()
                        }
                        upd(); toast("Subjects reset")
                    }.setNegativeButton("Cancel", null).show()
            }
        )
    }

    /** Opens the hidden private memories (reached only by typing the secret code in the search bar). */
    private fun openPrivate(pmem: PrefsMemory) {
        val pt = PersonalTalk(pmem)
        SymBuilder(this).setTitle("Private memories").setMessage(pt.summary() + "\n\nOnly on this phone, never in backups.")
            .setPositiveButton("Close", null)
            .setNeutralButton("Delete") { _, _ ->
                SymBuilder(this).setTitle("Delete what?").setItems(arrayOf("Forget my crush", "Erase all private memories", "Change secret code")) { _, i ->
                    when (i) {
                        0 -> { pt.forgetCrush(); toast("Forgotten") }
                        1 -> { pt.forgetAll(); toast("Erased") }
                        else -> setPrivateCode(pmem, false)
                    }
                }.show()
            }.show()
    }

    private fun setPrivateCode(pmem: PrefsMemory, first: Boolean) {
        val box = EditText(this); box.hint = "At least 4 characters"; box.setSingleLine(true)
        box.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        val col = LinearLayout(this); col.setPadding(dp(20), dp(8), dp(20), 0); col.addView(box, match())
        SymBuilder(this).setTitle(if (first) "Create your secret code" else "New secret code")
            .setMessage("Type this code in the search bar any time to open your private memories. Don't forget it: it can't be recovered.")
            .setView(col)
            .setPositiveButton("Save") { _, _ -> if (PrivateCode.set(pmem, box.text.toString())) toast("Code saved") else toast("Too short: use 4 or more characters") }
            .setNegativeButton("Cancel", null).show()
    }

    /** Trip pack list: usual items ticked off, own items added, long-press to remove, new trip and reset buttons. */
    private fun buildTripCard() {
        val c = card("🧳 Trip pack list", "The usual things to pack. Tick them off, add your own, long-press an item to remove it. Or tell Ghostie: \"add charger to pack list\".")
        val progress = label("", 13f, textMain, true)
        c.addView(progress, match())
        val daysLine = label("", 13f, accent, true)
        c.addView(daysLine, match())
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        c.addView(box, match())
        val open = HashSet<String>()
        fun render() {
            box.removeAllViews()
            val items = TripStore.items(this)
            val packed = TripStore.packed(this)
            val (done, total) = TripPack.progress(items, packed)
            progress.text = if (done == total && total > 0) "Everything is packed ✅ ($total)" else "$done of $total packed"
            val dn = TripStore.days(this)
            daysLine.text = if (dn > 0) "Trip length: $dn day${if (dn == 1) "" else "s"}. Clothes numbers follow it; tap a number to change it." else "Trip length not set: tap \"Trip length\" so the numbers fit your trip."
            for ((cat, list) in items.groupBy { it.category }) {
                val n = list.count { TripPack.isPacked(packed, it.name) }
                val head = label((if (cat in open) "▾ " else "▸ ") + cat + "  ($n/${list.size})", 14f, accent, true)
                head.setPadding(0, dp(10), 0, dp(6))
                head.setOnClickListener { if (!open.add(cat)) open.remove(cat); render() }
                box.addView(head, match())
                if (cat !in open) continue
                for (item in list) {
                    val cb = SymCheck(this)
                    cb.text = item.name
                    cb.setTextColor(textMain)
                    cb.buttonTintList = android.content.res.ColorStateList.valueOf(accent)
                    cb.isChecked = TripPack.isPacked(packed, item.name)
                    cb.setOnCheckedChangeListener { _, on -> TripStore.setPacked(this, item.name, on); render() }
                    cb.setOnLongClickListener {
                        SymBuilder(this).setTitle("Remove \"${item.name}\"?").setMessage("You can bring it back with Reset list.")
                            .setPositiveButton("Remove") { _, _ -> TripStore.remove(this, item); render() }
                            .setNegativeButton("Cancel", null).show()
                        true
                    }
                    if (TripStore.showsQty(this, item.name)) {
                        val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL; row.gravity = android.view.Gravity.CENTER_VERTICAL
                        row.addView(cb, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                        val q = button("x" + TripStore.qty(this, item.name), false) {
                            val num = EditText(this); num.inputType = android.text.InputType.TYPE_CLASS_NUMBER; num.setText(TripStore.qty(this, item.name).toString()); num.setSelection(num.text.length)
                            val col = LinearLayout(this); col.setPadding(dp(20), dp(8), dp(20), 0); col.addView(num, match())
                            SymBuilder(this).setTitle("How many ${item.name.lowercase()}?").setView(col)
                                .setPositiveButton("Save") { _, _ -> num.text.toString().toIntOrNull()?.let { TripStore.setQty(this, item.name, it); render() } }
                                .setNegativeButton("Cancel", null).show()
                        }
                        row.addView(q, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
                        box.addView(row, match())
                    } else box.addView(cb, match())
                }
            }
        }
        render()
        buttonRow(c,
            button("Trip length", true) {
                val num = EditText(this); num.hint = "Number of days, e.g. 5"; num.inputType = android.text.InputType.TYPE_CLASS_NUMBER
                val cur = TripStore.days(this); if (cur > 0) { num.setText(cur.toString()); num.setSelection(num.text.length) }
                val col = LinearLayout(this); col.setPadding(dp(20), dp(8), dp(20), 0); col.addView(num, match())
                SymBuilder(this).setTitle("How many days is the trip?").setMessage("Clothes numbers are worked out from this. Numbers you typed in yourself are reset.").setView(col)
                    .setPositiveButton("Set") { _, _ -> val d = num.text.toString().toIntOrNull(); if (d != null && d in 1..120) { TripStore.setDays(this, d); render() } else toast("Enter 1 to 120 days") }
                    .setNegativeButton("Cancel", null).show()
            },
            button("Add item", false) {
                val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL; col.setPadding(dp(20), dp(8), dp(20), 0)
                val name = EditText(this); name.hint = "e.g. Trekking shoes"; name.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                val sp = android.widget.Spinner(this)
                val cats = TripPack.categories
                sp.adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, cats)
                col.addView(name); col.addView(sp)
                SymBuilder(this).setTitle("Add to pack list").setView(col)
                    .setPositiveButton("Add") { _, _ ->
                        val cat = cats[sp.selectedItemPosition]
                        if (TripStore.add(this, cat, name.text.toString())) { open.add(cat); render() } else toast("Already on the list, or empty")
                    }.setNegativeButton("Cancel", null).show()
            },
            button("New trip (untick all)", false) { TripStore.newTrip(this); render(); toast("All unticked") }
        )
        buttonRow(c, button("Reset list to defaults", false) {
            SymBuilder(this).setTitle("Reset pack list?").setMessage("Removes the items you added, brings back items you removed, and unticks everything.")
                .setPositiveButton("Reset") { _, _ -> TripStore.reset(this); render(); toast("Pack list reset") }
                .setNegativeButton("Cancel", null).show()
        })
    }

    /** Reads a photo of a printed timetable, shows what it found, and replaces the timetable only after the student confirms. */
    private fun timetableFromPhoto(uri: android.net.Uri) {
        toast("Reading the photo...")
        OcrReader.read(this, uri) { boxes ->
            val p = boxes?.let { TimetableOcr.parse(it) }
            if (p == null) {
                SymBuilder(this).setTitle("Couldn't read it")
                    .setMessage("I couldn't read that photo. The first scan needs internet (to download the reader once) and Google Play Services. Otherwise try a straight, well-lit photo of the whole table with the day names and time slots visible, or fill it in by hand.")
                    .setPositiveButton("OK", null).show()
            } else {
                SymBuilder(this).setTitle("Is this right?")
                    .setMessage(TimetableOcr.preview(p) + "\n\nThis will replace your current timetable" + (if (p.sats.isNotEmpty()) " and Saturday timetables" else "") + ". You can still edit any box afterwards.")
                    .setPositiveButton("Use it") { _, _ ->
                        val st2 = Student.load(this)
                        TimetableOcr.apply(st2, p)
                        SubjectTidy.syncAttendance(st2)
                        Student.save(this); toast("Timetable updated ✅"); recreate()
                    }
                    .setNegativeButton("Cancel", null).show()
            }
        }
    }

    /** Reads the chosen notes/question paper, finds MCQs and numericals, and offers to add them as flashcards. */
    private fun mineFile(uri: android.net.Uri) {
        toast("Reading the file...")
        Thread(null, {
            val result: Triple<String, QuestionMiner.Result, List<NotesMiner.Card>>? = try {
                var name = "file"
                contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) ?: name }
                val ext = name.substringAfterLast('.', "").lowercase().ifEmpty { "txt" }
                val tmp = java.io.File(cacheDir, "mine." + ext)
                contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                val text = DocText.full(tmp)
                tmp.delete()
                if (text.isBlank()) null else { val q = QuestionMiner.mine(text); Triple(name, q, if (q.cards.isEmpty()) NotesMiner.mine(text) else emptyList()) }
            } catch (e: Exception) { null } catch (e: StackOverflowError) { null }
            runOnUiThread {
                if (result == null) { toast("I couldn't read text from that file (scanned PDFs can't be read)"); return@runOnUiThread }
                val (name, r, notes) = result
                val sub0 = s.subjectPicks.firstOrNull() ?: "General"
                fun addPicked(picked: List<CardsUi.Draft>, subject: String, kinds: java.util.IdentityHashMap<CardsUi.Draft, QuestionMiner.Kind>) {
                    val st = Student.load(this)
                    val n = QuestionMiner.addTo(st, picked.map { QuestionMiner.Mined(kinds[it] ?: QuestionMiner.Kind.NOTE, it.q, it.a) }, subject, java.time.LocalDate.now())
                    Student.save(this); toast("$n card(s) added"); recreate()
                }
                if (r.cards.isEmpty() && notes.size >= 3) {
                    val kinds = java.util.IdentityHashMap<CardsUi.Draft, QuestionMiner.Kind>()
                    val drafts = notes.map { CardsUi.Draft(it.q, it.a).also { d -> kinds[d] = QuestionMiner.Kind.NOTE } }
                    cardsUi().pickDrafts("Cards from your notes",
                        "There are no questions in $name, so I made ${notes.size} study cards from definitions and \"term: explanation\" lines. Untick the ones you don't want, tap ✎ to fix wording (PDF text sometimes splits words), then add.",
                        drafts, sub0) { picked, subject -> addPicked(picked, subject, kinds) }
                    return@runOnUiThread
                }
                if (r.cards.isEmpty()) {
                    SymBuilder(this).setTitle("No questions found")
                        .setMessage("I look for numbered questions with options A to D plus an \"Ans:\" line or answer key, and numerical problems followed by \"Ans:\" or \"Solution:\"." + if (r.skippedNoAnswer > 0) "\n${r.skippedNoAnswer} question(s) had no answer in the file." else "")
                        .setPositiveButton("OK", null).show()
                    return@runOnUiThread
                }
                val mcq = r.cards.count { it.kind == QuestionMiner.Kind.MCQ }
                val kinds = java.util.IdentityHashMap<CardsUi.Draft, QuestionMiner.Kind>()
                val drafts = r.cards.map { CardsUi.Draft(it.q, it.a).also { d -> kinds[d] = it.kind } }
                cardsUi().pickDrafts("Found ${r.cards.size} questions",
                    "$mcq multiple-choice, ${r.cards.size - mcq} numerical from $name." + (if (r.skippedNoAnswer > 0) " ${r.skippedNoAnswer} skipped (no answer in the file)." else "") + " Untick any you don't want, then add.",
                    drafts, sub0) { picked, subject -> addPicked(picked, subject, kinds) }
            }
        }, "mine", 32L * 1024 * 1024).start()
    }

    private fun buildStudyTimeCard() {
        val c = card("📚 My study time", "Tell Ghostie when you usually study. When that time starts, it lists everything due tomorrow (submissions, project tasks, exams). Chat: \"I study at 7pm\".")
        val info = hint("")
        c.addView(info, match())
        fun render() {
            val l = s.studyTimes.split(",").filter { it.isNotBlank() }
            info.text = if (l.isEmpty()) "No study time set." else "Study times: " + StudyBrief.listText(l)
        }
        render()
        buttonRow(c, button("Add study time", true) {
            val now = java.time.LocalTime.now()
            TimePickerDialog(this, { _, h, m ->
                val l = (s.studyTimes.split(",").filter { it.isNotBlank() } + "%02d:%02d".format(h, m)).toSortedSet()
                s.studyTimes = l.joinToString(","); render()
            }, now.hour, now.minute, false).show()
        }, button("Clear", false) { s.studyTimes = ""; render() })
        buttonRow(c, button("Show what's due tomorrow", false) {
            val st = Student.load(this)
            val lines = StudyBrief.tomorrowLines(s.logs(), st.exams, ProjectStore.load(this).tasks, java.time.LocalDate.now())
            SymBuilder(this).setTitle("Due tomorrow").setMessage(if (lines.isEmpty()) "Nothing due tomorrow ✅" else lines.joinToString("\n")).setPositiveButton("OK", null).show()
        })
    }

    private fun buildWeeklyCard() {
        val c = card("📊 Weekly summary & warnings", "A Sunday-evening notification with your week (study time, attendance, spending, what's due), and a heads-up 15 minutes before a class when that subject's attendance is at risk. Chat: \"weekly summary\".")
        ghostSwitchRow(c, "Sunday summary notification", s.weeklySummary, 3) { s.weeklySummary = it }
        switchRow(c, "Warn before a class when attendance is at risk", s.attWarn) { s.attWarn = it }
        buttonRow(c, button("Show this week now", false) {
            SymBuilder(this).setTitle("Your week").setMessage(WeeklySummary.text(this)).setPositiveButton("OK", null).show()
        })
    }

    /** Shared expenses: who owes you, who you owe, one-tap reminder to a friend. */
    private fun buildSplitCard() {
        val c = card("🤝 Split expenses", "For shared lunches, trips and subscriptions. Chat: \"split 600 lunch with Ravi and Meena\", \"Ravi paid me back 200\", \"who owes me\", \"settle Ravi\".")
        val box = LinearLayout(this); box.orientation = LinearLayout.VERTICAL
        c.addView(box, match())
        fun render() {
            box.removeAllViews()
            val b = SplitStore.load(this).filter { Math.abs(it.value) >= 0.01 }
            if (b.isEmpty()) { box.addView(hint("Nobody owes anything."), match()); return }
            for ((name, v) in b) {
                val row = label((if (v > 0) "$name owes you " else "You owe $name ") + MoneyParser.format(Math.abs(v)) + "   (tap)", 14f, textMain)
                row.setPadding(0, dp(6), 0, dp(6))
                row.setOnClickListener {
                    val opts = if (v > 0) arrayOf("Send a reminder on WhatsApp", "Got paid back in full", "Got part of it back", "Clear this") else arrayOf("I paid in full", "Clear this")
                    SymBuilder(this).setTitle(name).setItems(opts) { _, i ->
                        val bal = SplitStore.load(this)
                        val k = Ledger.key(bal, name)
                        when (opts[i]) {
                            "Send a reminder on WhatsApp" -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, Ledger.reminderText(name, v, SplitStore.noteFor(this, name))), "Remind $name"))
                            "Got paid back in full", "I paid in full", "Clear this" -> { Ledger.settle(bal, k); SplitStore.save(this, bal); render() }
                            "Got part of it back" -> {
                                val et = EditText(this); et.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; et.hint = "Amount (₹)"
                                SymBuilder(this).setTitle("How much did $name pay back?").setView(et)
                                    .setPositiveButton("Save") { _, _ -> et.text.toString().toDoubleOrNull()?.let { a -> Ledger.paidBack(bal, k, a); SplitStore.save(this, bal); render() } }
                                    .setNegativeButton("Cancel", null).show()
                            }
                        }
                    }.show()
                }
                box.addView(row, match())
            }
        }
        render()
        buttonRow(c, button("Add a split", false) {
            val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL; col.setPadding(dp(20), dp(8), dp(20), 0)
            val total = EditText(this); total.hint = "Total you paid (₹)"; total.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            val who = EditText(this); who.hint = "Friends (Ravi, Meena)"
            val what = EditText(this); what.hint = "For what? (optional)"
            col.addView(total); col.addView(who); col.addView(what)
            SymBuilder(this).setTitle("Split equally (you included)").setView(col)
                .setPositiveButton("Split") { _, _ ->
                    val amt = total.text.toString().toDoubleOrNull(); val names = Ledger.names(who.text.toString())
                    if (amt == null || amt <= 0 || names.isEmpty()) { toast("Need an amount and at least one friend"); return@setPositiveButton }
                    val b = SplitStore.load(this); Ledger.split(b, amt, names); SplitStore.save(this, b); SplitStore.setNote(this, names, what.text.toString().trim()); render()
                }.setNegativeButton("Cancel", null).show()
        })
    }

    /** Group projects: tasks with owners and dates, status, and reminders you can send to teammates. */
    private fun buildProjectsCard() {
        val c = card("👥 Group projects", "Track who is doing what. Add a project, add tasks with an owner and date, and Ghostie drafts a WhatsApp reminder for anyone who is overdue or due soon. Chat: \"projects\".")
        val box = LinearLayout(this); box.orientation = LinearLayout.VERTICAL
        c.addView(box, match())
        val open = HashSet<String>()
        fun render() {
            box.removeAllViews()
            val d = ProjectStore.load(this)
            val today = java.time.LocalDate.now()
            val names = (d.projects + d.tasks.map { it.project }).distinct()
            if (names.isEmpty()) box.addView(hint("No projects yet."), match())
            for (pr in names) {
                val mine = d.tasks.filter { it.project == pr }
                val head = label((if (pr in open) "▾ " else "▸ ") + pr + "  (${mine.count { it.done }}/${mine.size})" + (if (Projects.overdue(mine, today).isNotEmpty()) "  ⚠️" else ""), 14f, accent, true)
                head.setPadding(0, dp(10), 0, dp(6))
                head.setOnClickListener { if (!open.add(pr)) open.remove(pr); render() }
                box.addView(head, match())
                if (pr !in open) continue
                for (t in mine.sortedWith(compareBy({ it.done }, { it.due ?: java.time.LocalDate.MAX }))) {
                    val cb = SymCheck(this)
                    cb.text = t.title + (if (t.owner.isNotBlank()) " · ${t.owner}" else "") + (t.due?.let { " · " + it.format(DateTimeFormatter.ofPattern("d MMM", Locale.ENGLISH)) } ?: "")
                    cb.setTextColor(if (t.due != null && t.due.isBefore(today) && !t.done) 0xFFD32F2F.toInt() else textMain)
                    cb.buttonTintList = android.content.res.ColorStateList.valueOf(accent)
                    cb.isChecked = t.done
                    cb.setOnCheckedChangeListener { _, on ->
                        val dd = ProjectStore.load(this); val i = dd.tasks.indexOfFirst { it.id == t.id }
                        if (i >= 0) { dd.tasks[i] = dd.tasks[i].copy(done = on); ProjectStore.save(this, dd) }
                        render()
                    }
                    cb.setOnLongClickListener {
                        SymBuilder(this).setTitle("Delete \"${t.title}\"?").setPositiveButton("Delete") { _, _ ->
                            val dd = ProjectStore.load(this); dd.tasks.removeAll { it.id == t.id }; ProjectStore.save(this, dd); render()
                        }.setNegativeButton("Cancel", null).show(); true
                    }
                    box.addView(cb, match())
                }
                val acts = LinearLayout(this); acts.orientation = LinearLayout.HORIZONTAL
                acts.addView(button("Add task", false) { addTaskDialog(pr) { render() } }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                acts.addView(button("Remind team", false) { remindTeam(pr) }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                acts.addView(button("Share status", false) {
                    startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, Projects.status(pr, ProjectStore.load(this).tasks, today)), "Share status"))
                }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                box.addView(acts, match())
                box.addView(button("Delete project", false) {
                    SymBuilder(this).setTitle("Delete \"$pr\" and its tasks?").setPositiveButton("Delete") { _, _ ->
                        val dd = ProjectStore.load(this); dd.projects.remove(pr); dd.tasks.removeAll { it.project == pr }; ProjectStore.save(this, dd); render()
                    }.setNegativeButton("Cancel", null).show()
                }, match())
            }
        }
        render()
        buttonRow(c, button("New project", false) {
            val et = EditText(this); et.hint = "e.g. DBMS mini project"; et.setSingleLine()
            SymBuilder(this).setTitle("New project").setView(et).setPositiveButton("Create") { _, _ ->
                val n = Projects.clean(et.text.toString())
                if (n.isNotEmpty()) { val dd = ProjectStore.load(this); if (n !in dd.projects) dd.projects.add(n); ProjectStore.save(this, dd); open.add(n); render() }
            }.setNegativeButton("Cancel", null).show()
        })
    }

    private fun addTaskDialog(project: String, done: () -> Unit) {
        val d0 = ProjectStore.load(this)
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL; col.setPadding(dp(20), dp(8), dp(20), 0)
        val title = EditText(this); title.hint = "Task (e.g. Make the slides)"
        val owner = EditText(this); owner.hint = "Who? (name)"
        val phone = EditText(this); phone.hint = "Their WhatsApp number (optional)"; phone.inputType = android.text.InputType.TYPE_CLASS_PHONE
        val due = EditText(this); due.hint = "Due date (tap to pick)"; due.isFocusable = false
        var picked: java.time.LocalDate? = null
        due.setOnClickListener {
            val n = java.time.LocalDate.now()
            android.app.DatePickerDialog(this, { _, y, m, dd -> picked = java.time.LocalDate.of(y, m + 1, dd); due.setText(picked.toString()) }, n.year, n.monthValue - 1, n.dayOfMonth).show()
        }
        owner.setOnFocusChangeListener { _, _ -> d0.phones[Ledger.clean(owner.text.toString())]?.let { if (phone.text.isBlank()) phone.setText(it) } }
        col.addView(title); col.addView(owner); col.addView(phone); col.addView(due)
        SymBuilder(this).setTitle("Add task to $project").setView(col).setPositiveButton("Add") { _, _ ->
            val t = Projects.clean(title.text.toString()); if (t.isEmpty()) return@setPositiveButton
            val dd = ProjectStore.load(this)
            val o = Ledger.clean(Projects.clean(owner.text.toString()))
            if (o.isNotEmpty() && phone.text.isNotBlank()) dd.phones[o] = phone.text.toString().trim()
            if (project !in dd.projects) dd.projects.add(project)
            dd.tasks.add(Projects.Task(System.currentTimeMillis(), project, t, o, picked, false))
            ProjectStore.save(this, dd); done()
        }.setNegativeButton("Cancel", null).show()
    }

    /** One WhatsApp draft per teammate who is overdue or due within 2 days. Opens the chat if their number is saved, else the share sheet. */
    private fun remindTeam(project: String) {
        val d = ProjectStore.load(this)
        val msgs = Projects.reminderMessages(d.tasks.filter { it.project == project }, java.time.LocalDate.now())
        if (msgs.isEmpty()) { toast("Nobody is overdue or due in the next 2 days 🎉"); return }
        val owners = msgs.keys.toList()
        SymBuilder(this).setTitle("Send a reminder to...").setItems(owners.map { it + (if (d.phones[it] == null) "  (no number saved)" else "") }.toTypedArray()) { _, i ->
            val o = owners[i]; val text = msgs[o]!!
            val num = d.phones[o]?.let { Projects.waNumber(it) }
            try {
                if (num != null) startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://wa.me/$num?text=" + android.net.Uri.encode(text))))
                else startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Remind $o"))
            } catch (e: Exception) { toast("Couldn't open WhatsApp") }
        }.setNegativeButton("Cancel", null).show()
    }

    /** Placement prep: aptitude, reasoning, verbal, C, DSA, OS, DBMS, networks and HR questions with a results tracker. */
    private fun buildPlacementCard() {
        val c = card("🎯 Placement prep", "${PlacementBank.builtIn.size} built-in questions (aptitude, reasoning, verbal, C, DSA, OS, DBMS, networks, HR) plus your own. Your results show which areas are weakest.")
        val statsView = hint("")
        c.addView(statsView, match())
        fun showStats() { statsView.text = PlacementBank.statsText(PlacementStore.stats(this)) }
        showStats()
        val cats = listOf("All topics") + PlacementBank.categories.filter { it != "HR & interview" } + "My questions"
        val sp = android.widget.Spinner(this)
        sp.adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, cats)
        c.addView(sp, match())
        fun ask(list: List<PlacementBank.Q>, i: Int, right: Int) {
            if (i >= list.size) {
                SymBuilder(this).setTitle("Done 🎉").setMessage("You got $right of ${list.size} right.").setPositiveButton("OK", null).show(); showStats(); return
            }
            val q = list[i]
            val opts = PlacementBank.shuffledOptions(q)
            SymBuilder(this).setTitle("Question ${i + 1} of ${list.size}  ·  ${q.cat}").setMessage(q.text)
                .setItems(opts.toTypedArray()) { _, which ->
                    val ok = opts[which] == q.answer
                    PlacementStore.record(this, q.cat, ok)
                    SymBuilder(this).setTitle(if (ok) "✅ Correct" else "❌ Not quite")
                        .setMessage((if (ok) "" else "Answer: ${q.answer}\n") + q.why)
                        .setPositiveButton(if (i + 1 < list.size) "Next" else "Finish") { _, _ -> ask(list, i + 1, right + if (ok) 1 else 0) }
                        .setCancelable(false).show()
                }
                .setNegativeButton("Stop") { _, _ -> showStats() }.setCancelable(false).show()
        }
        buttonRow(c,
            button("Practice 5", true) {
                val sel = sp.selectedItem as String
                val qs = PlacementBank.pick(PlacementStore.own(this), 5, if (sel == "All topics") null else sel)
                if (qs.isEmpty()) toast("No questions in that topic yet") else ask(qs, 0, 0)
            },
            button("Interview question", false) {
                val q = PlacementBank.pick(emptyList(), 1, "HR & interview").firstOrNull() ?: return@button
                SymBuilder(this).setTitle("Interview question").setMessage(q.text)
                    .setPositiveButton("Show how to answer") { _, _ -> SymBuilder(this).setTitle("How to answer").setMessage(q.answer).setPositiveButton("OK", null).show() }
                    .setNegativeButton("Close", null).show()
            }
        )
        buttonRow(c,
            button("Add my question", false) {
                val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL; col.setPadding(dp(20), dp(8), dp(20), 0)
                val qe = EditText(this); qe.hint = "Question"
                val ans = EditText(this); ans.hint = "Correct answer"
                val wrong = EditText(this); wrong.hint = "Wrong options, separated by commas (at least 1)"
                col.addView(qe); col.addView(ans); col.addView(wrong)
                SymBuilder(this).setTitle("Add a question").setView(col).setPositiveButton("Add") { _, _ ->
                    val w = wrong.text.toString().split(',').map { it.trim() }.filter { it.isNotEmpty() }.take(3)
                    if (qe.text.isBlank() || ans.text.isBlank() || w.isEmpty()) { toast("Need a question, the answer and at least one wrong option"); return@setPositiveButton }
                    PlacementStore.addOwn(this, PlacementBank.Q("My questions", qe.text.toString().trim(), listOf(ans.text.toString().trim()) + w, ans.text.toString().trim(), "", true))
                    toast("Added")
                }.setNegativeButton("Cancel", null).show()
            },
            button("Reset results", false) {
                SymBuilder(this).setTitle("Reset practice results?").setMessage("Your own questions stay.").setPositiveButton("Reset") { _, _ -> PlacementStore.resetStats(this); showStats() }.setNegativeButton("Cancel", null).show()
            }
        )
        switchRow(c, "Question of the day at 7 pm", s.placementDaily) { s.placementDaily = it }
    }

    private fun usageOk(): Boolean = try {
        val ops = getSystemService(APP_OPS_SERVICE) as android.app.AppOpsManager
        ops.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == android.app.AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) { false }

    private fun installedLaunchers(): List<Pair<String, String>> {
        val pm = packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
    }

    /** Tick which installed apps the Privacy Shield protects (built-in banking apps start ticked). */
    private fun chooseShieldApps(done: () -> Unit) {
        val apps = installedLaunchers()
        if (apps.isEmpty()) { toast("I can't see your apps"); return }
        val custom = ShieldPolicy.parse(s.shieldCustom).toMutableSet()
        val removed = ShieldPolicy.parse(s.shieldRemoved).toMutableSet()
        val guess = s.shieldGuessBanks
        val builtIn = { pkg: String -> ShieldPolicy.isProtected(pkg, emptySet(), emptySet(), guess) }
        val chosen = apps.map { ShieldPolicy.isProtected(it.first, custom, removed, guess) }.toBooleanArray()
        SymBuilder(this).setTitle("Protected apps")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), chosen) { _, i, on -> chosen[i] = on }
            .setPositiveButton("Save") { _, _ ->
                for ((i, a) in apps.withIndex()) {
                    val pkg = a.first
                    if (chosen[i]) { removed.remove(pkg); if (!builtIn(pkg)) custom.add(pkg) }
                    else { custom.remove(pkg); if (builtIn(pkg)) removed.add(pkg) }
                }
                s.shieldCustom = custom.joinToString("\n")
                s.shieldRemoved = removed.joinToString("\n")
                done()
                toast("Saved")
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun handlerRefreshSoon() {
        content.postDelayed({ refresh() }, 600)
    }

    /** Lets the user tick which installed apps get covered during focus time. */
    private fun chooseBlockedApps(done: () -> Unit) {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
        if (apps.isEmpty()) { toast("I can't see your apps"); return }
        val chosen = s.studyAppSet().toMutableSet()
        if (chosen.isEmpty()) {
            val common = setOf("com.instagram.android", "com.google.android.youtube", "com.snapchat.android", "com.twitter.android", "com.facebook.katana", "com.reddit.frontpage", "com.zhiliaoapp.musically", "in.mohalla.sharechat", "com.netflix.mediaclient")
            chosen.addAll(apps.map { it.first }.filter { it in common })
        }
        val names = apps.map { it.second }.toTypedArray()
        val checked = apps.map { it.first in chosen }.toBooleanArray()
        SymBuilder(this).setTitle("Apps to cover while you focus")
            .setMultiChoiceItems(names, checked) { _, i, on -> if (on) chosen.add(apps[i].first) else chosen.remove(apps[i].first) }
            .setPositiveButton("Save") { _, _ ->
                s.studyApps = chosen.joinToString("\n")
                s.studyBlock = true
                done()
                toast("Saved. Allow Usage access too, so Ghostie can see which app is open.")
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun renderEvents() {
        eventsBox.removeAllViews()
        val list = RecentEvents.list(this)
        if (list.isEmpty()) {
            eventsBox.addView(label("Nothing yet. Try telling Ghostie: \"add event dentist on 12 November at 5 pm\".", 13f, textSub))
            return
        }
        val zone = ZoneId.systemDefault()
        val fmt = DateTimeFormatter.ofPattern("EEE d MMM yyyy", Locale.ENGLISH)
        val nowMs = System.currentTimeMillis()
        val bar = LinearLayout(this); bar.orientation = LinearLayout.HORIZONTAL
        bar.addView(button("Clear past events", false) {
            val past = list.filter { it.start < nowMs && it.repeat.isEmpty() }
            if (past.isEmpty()) { toast("No past events here"); return@button }
            SymBuilder(this).setTitle("Clear ${past.size} past event${if (past.size == 1) "" else "s"}?").setMessage("Removes them from this list only. Your phone calendar keeps them.")
                .setPositiveButton("Clear") { _, _ -> past.forEach { RecentEvents.remove(this, it.id); s.removeLog(it.id) }; toast("Cleared"); refresh() }
                .setNegativeButton("Cancel", null).show()
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(button("Remove all", false) {
            SymBuilder(this).setTitle("Remove all ${list.size} events?").setMessage("This also deletes the calendar entries Ghostie added for them.")
                .setPositiveButton("Remove all") { _, _ -> list.forEach { CalendarHelper.delete(this, it.id); RecentEvents.remove(this, it.id); s.removeLog(it.id) }; toast("Removed"); refresh() }
                .setNegativeButton("Cancel", null).show()
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        eventsBox.addView(bar, match().apply { bottomMargin = dp(6) })
        for (r in list) {
            val dt = java.time.Instant.ofEpochMilli(r.start).atZone(zone)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.background = rounded(field, 12, cardStroke)
            row.setPadding(dp(12), dp(8), dp(12), dp(8))
            row.addView(label(r.kind.icon + " " + r.title, 14f, textMain, true))
            val whenText = dt.format(fmt) + if (r.allDay) " (all day)" else dt.format(DateTimeFormatter.ofPattern(", h:mm a", Locale.ENGLISH))
            row.addView(label(whenText + (if (r.repeat.isNotEmpty()) " - repeats yearly" else ""), 12f, accent))
            row.setOnClickListener { editEvent(r) }
            val rm = button("Remove", false) {
                CalendarHelper.delete(this, r.id); RecentEvents.remove(this, r.id); s.removeLog(r.id)
                toast("Event removed"); refresh()
            }
            rm.textSize = 12f; rm.minHeight = dp(34); rm.minimumHeight = dp(34)
            row.addView(rm, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(36)).apply { topMargin = dp(4); gravity = Gravity.END })
            makeDraggable(row) {
                CalendarHelper.delete(this, r.id)
                RecentEvents.remove(this, r.id)
                s.removeLog(r.id)
                toast("Event deleted 🗑️")
                refresh()
            }
            val lp = match()
            lp.bottomMargin = dp(6)
            eventsBox.addView(row, lp)
        }
    }

    private fun editEvent(r: RecentEvents.Rec) {
        val zone = ZoneId.systemDefault()
        var dt = java.time.Instant.ofEpochMilli(r.start).atZone(zone).toLocalDateTime()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val name = textField("Name", Commands.baseTitle(r.title), false)
        box.addView(name, fieldLp())
        val kinds = EventKind.values().toList()
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, kinds.map { it.icon + " " + it.label })
        sp.setSelection(kinds.indexOf(r.kind).coerceAtLeast(0))
        box.addView(sp, fieldLp())
        val dateBtn = SymButton(this)
        val timeBtn = SymButton(this)
        fun show() {
            dateBtn.text = "Date: " + dt.toLocalDate().format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH))
            timeBtn.text = "Time: " + dt.format(DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH))
        }
        show()
        dateBtn.setOnClickListener {
            android.app.DatePickerDialog(this, { _, y, m, d -> dt = dt.withYear(y).withMonth(m + 1).withDayOfMonth(d); show() }, dt.year, dt.monthValue - 1, dt.dayOfMonth).show()
        }
        timeBtn.setOnClickListener {
            android.app.TimePickerDialog(this, { _, h, mi -> dt = dt.withHour(h).withMinute(mi); show() }, dt.hour, dt.minute, false).show()
        }
        box.addView(dateBtn, fieldLp())
        box.addView(timeBtn, fieldLp())
        SymBuilder(this).setTitle("Edit event").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val kind = kinds[sp.selectedItemPosition]
                val title = name.text.toString().trim().ifEmpty { Commands.baseTitle(r.title) }
                val startMs = dt.atZone(zone).toInstant().toEpochMilli()
                val day = dt.toLocalDate().atStartOfDay(zone).toInstant().toEpochMilli()
                var ev = Command.Event(title, if (kind == EventKind.EVENT) startMs else day, EventKind.EVENT)
                if (kind != EventKind.EVENT) ev = Commands.withKind(ev, kind)
                CalendarHelper.delete(this, r.id)
                RecentEvents.remove(this, r.id)
                s.removeLog(r.id)
                val id = CalendarHelper.insertEvent(this, ev, "Added by Ghostie")
                if (id == null) toast("Couldn't save - is Calendar allowed?")
                else {
                    RecentEvents.add(this, ev, id)
                    val l = LearnStore.get(this)
                    l.teachKind(Commands.baseTitle(ev.title), kind.name)
                    LearnStore.save(this)
                    toast("Saved ✅")
                }
                refresh()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun renderLog() {
        if (!::logBox.isInitialized) return
        logBox.removeAllViews()
        val items = ReminderLog.upcoming(s.logs()).take(10)
        val today = java.time.LocalDate.now()
        val pastLogs = s.logs().filter { val d = ReminderLog.dueDate(it); d != null && d.isBefore(today) }
        if (pastLogs.isNotEmpty()) {
            val pastRow = LinearLayout(this); pastRow.orientation = LinearLayout.HORIZONTAL; pastRow.gravity = Gravity.CENTER_VERTICAL
            pastRow.addView(label("${pastLogs.size} past deadline${if (pastLogs.size == 1) "" else "s"} stored", 12f, textSub), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            pastRow.addView(button("Show", false) {
                val names = pastLogs.map { ReminderLog.label(it) + "  (" + it.due + ", " + it.group + ")" }.toTypedArray()
                SymBuilder(this).setTitle("Past deadlines: tap one to remove it").setItems(names) { _, i ->
                    val e = pastLogs[i]; s.removeLog(e.eventId); toast("Removed"); renderLog()
                }.setNegativeButton("Close", null).show()
            })
            pastRow.addView(button("Clear all past", false) {
                SymBuilder(this).setTitle("Clear ${pastLogs.size} past deadlines?").setMessage("Only the saved records go. Your phone calendar is untouched.")
                    .setPositiveButton("Clear") { _, _ -> pastLogs.forEach { s.removeLog(it.eventId) }; renderLog() }
                    .setNegativeButton("Cancel", null).show()
            })
            logBox.addView(pastRow, match().apply { bottomMargin = dp(6) })
        }
        if (items.isEmpty()) {
            logBox.addView(label("Nothing due. When someone posts a submission or registration deadline in a watched group, it appears here.", 13f, textSub))
            return
        }
        val warn = Color.parseColor("#FF8A7A")
        for (e in items) {
            val days = ReminderLog.daysLeft(e)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = rounded(field, 12, if (days <= 1) warn else cardStroke)
            row.setPadding(dp(12), dp(8), dp(8), dp(8))
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            val icon = when {
                ReminderLog.isRegistration(e) -> "📝 Registration: "
                e.title.startsWith("⏳") -> "⏳ "
                else -> "📌 "
            }
            col.addView(label(icon + ReminderLog.label(e), 14f, textMain, true))
            col.addView(label(ReminderLog.dueLabel(e), 12f, if (days <= 1) warn else accent))
            col.addView(label("from " + e.group, 11f, textSub))
            if (e.msg.isNotBlank()) col.addView(label("\u201C" + e.msg + "\u201D", 11f, textSub).apply { setPadding(0, dp(2), 0, 0) })
            row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val remove = button("Done", false) {
                HabitStore.get(this).groupAct(e.group, 0); HabitStore.save(this)
                CalendarHelper.delete(this, e.eventId)
                s.removeLog(e.eventId)
                renderLog()
            }
            remove.textSize = 12f
            remove.minHeight = dp(34)
            remove.minimumHeight = dp(34)
            val snooze = button("Snooze", false) {
                HabitStore.get(this).groupAct(e.group, 1); HabitStore.save(this)
                toast(ReminderMaker.snooze(this, e, 3))
            }
            snooze.textSize = 12f
            snooze.minHeight = dp(34)
            snooze.minimumHeight = dp(34)
            val btns = LinearLayout(this)
            btns.orientation = LinearLayout.VERTICAL
            btns.addView(snooze, LinearLayout.LayoutParams(dp(78), dp(36)))
            btns.addView(remove, LinearLayout.LayoutParams(dp(78), dp(36)).apply { topMargin = dp(4) })
            row.addView(btns)
            makeDraggable(row) {
                HabitStore.get(this).groupAct(e.group, 2); HabitStore.save(this)
                LearnStore.get(this).block(e.group, ReminderLog.label(e))
                LearnStore.save(this)
                CalendarHelper.delete(this, e.eventId)
                s.removeLog(e.eventId)
                ActivityLog.add(this, "Bin", "Threw away \"${ReminderLog.label(e)}\" - I'll ignore similar ones from ${e.group}")
                toast("Thrown away 🗑️ I'll ignore similar ones from ${e.group}")
                renderLog()
                renderActivity()
                renderLearned()
            }
            val lp = match()
            lp.bottomMargin = dp(6)
            logBox.addView(row, lp)
        }
    }
}
