package com.ghostie.pet

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.DragEvent
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ProgressBar
import android.os.PowerManager
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var s: SettingsStore
    private lateinit var content: LinearLayout
    private lateinit var subjectsField: EditText
    private lateinit var groupsField: EditText
    private lateinit var keyField: EditText
    private lateinit var vipField: EditText
    private lateinit var rulesField: EditText
    private lateinit var linkField: EditText
    private var builtUnlocked = -1
    private lateinit var baseField: EditText
    private lateinit var modelField: EditText
    private lateinit var urgentField: EditText
    private lateinit var logBox: LinearLayout
    private lateinit var eventsBox: LinearLayout
    private lateinit var activityBox: LinearLayout
    private lateinit var docBox: LinearLayout
    private lateinit var learnBox: LinearLayout
    private lateinit var binZone: TextView
    private var section = "home"
    private var currentTab = "home"
    private var navBar: GlassNavBar? = null
    private val navKeys = listOf("home", "setup", "docs", "brain", "more")
    private val cardSections = LinkedHashMap<View, String>()
    private val hiddenCards = HashSet<View>()
    private val tabButtons = LinkedHashMap<String, TextView>()
    private val permChecks = mutableListOf<() -> Boolean>()
    private var pendingDrop: (() -> Unit)? = null
    private var dropped = false
    private val refreshers = mutableListOf<() -> Unit>()

    // Palette (set from the chosen theme in onCreate)
    private lateinit var pal: Palette
    private var bg = 0
    private var card = 0
    private var cardStroke = 0
    private var field = 0
    private var textMain = 0
    private var textSub = 0
    private var accent = 0
    private var onAccent = 0
    private var good = 0
    private val hintViews = mutableListOf<View>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        s = SettingsStore(this)
        pal = Themes.palette(s)
        bg = pal.bg; card = pal.card; cardStroke = pal.stroke; field = pal.field; textMain = pal.text
        textSub = pal.sub; accent = pal.accent; onAccent = pal.onAccent; good = pal.good
        build()
        window.decorView.post { maybeTutorial() }
    }

    override fun onResume() {
        super.onResume()
        if (builtUnlocked >= 0 && builtUnlocked != Skins.all.count { Skins.unlocked(it, s.chatCount) }) { recreate(); return }
        refresh()
    }

    override fun onPause() {
        SentenceStore.save(this)
        saveFields()
        super.onPause()
    }

    private fun refresh() {
        refreshers.forEach { it() }
        GhostieWidget.refresh(this)
        renderLog()
        renderEvents()
        renderActivity()
        renderLearned()
    }

    private fun saveFields() {
        s.subjects = subjectsField.text.toString()
        s.watchedGroups = groupsField.text.toString()
        s.key = keyField.text.toString().trim()
        s.aiBase = baseField.text.toString()
        s.aiModel = modelField.text.toString()
        s.groupRules = rulesField.text.toString()
        s.shareLink = linkField.text.toString()
        s.callVips = vipField.text.toString()
        s.callUrgent = urgentField.text.toString()
    }

    // ---- small UI toolkit -----------------------------------------------------------------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    /** Long-press a row, drag it to the bin that appears, and let go. */
    private fun makeDraggable(view: View, onDrop: () -> Unit) {
        view.setOnLongClickListener { v ->
            pendingDrop = onDrop
            v.alpha = 0.4f
            @Suppress("DEPRECATION")
            v.startDragAndDrop(ClipData.newPlainText("ghostie", "bin"), View.DragShadowBuilder(v), v, 0)
            true
        }
    }

    /** Paper-in-the-bin: spin, shrink and fade, then do the delete. */
    private fun crumple(v: View, done: () -> Unit) {
        v.animate().scaleX(0.1f).scaleY(0.1f).rotation(300f).alpha(0f).setDuration(320).withEndAction { done() }.start()
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        if (bold) tv.setTypeface(tv.typeface, Typeface.BOLD)
        return tv
    }

    /** Long explanation text: hidden unless "Show explanations" is on (the tutorial covers it). */
    private fun hint(t: String): TextView = label(t, 12f, textSub).also {
        it.visibility = if (s.showHints) View.VISIBLE else View.GONE
        hintViews.add(it)
    }

    private fun match() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

    private fun card(title: String, subtitle: String? = null): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = rounded(card, 18, cardStroke)
        c.setPadding(dp(16), dp(14), dp(16), dp(16))
        val titleView = label(title, 17f, textMain, true)
        c.addView(titleView)
        if (subtitle != null) {
            val sub = label(subtitle, 13f, textSub)
            sub.setPadding(0, dp(2), 0, dp(8))
            sub.visibility = if (s.showHints) View.VISIBLE else View.GONE
            hintViews.add(sub)
            c.addView(sub)
            if (!s.showHints) { // tap the title to read what the card does
                titleView.setOnClickListener { sub.visibility = if (sub.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
            }
        }
        val lp = match()
        lp.topMargin = dp(12)
        content.addView(c, lp)
        cardSections[c] = section
        return c
    }

    private fun button(text: String, filled: Boolean = true, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 14f
        b.stateListAnimator = null
        b.minHeight = dp(44)
        b.minimumHeight = dp(44)
        styleButton(b, filled)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun styleButton(b: Button, filled: Boolean) {
        b.setTextColor(if (filled) onAccent else accent)
        b.background = if (filled) rounded(accent, 12) else rounded(Color.TRANSPARENT, 12, accent)
    }

    private fun buttonRow(parent: LinearLayout, vararg buttons: Button) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (b in buttons) {
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), dp(4), dp(3), dp(4))
            row.addView(b, lp)
        }
        parent.addView(row, match())
    }

    private fun switchRow(parent: LinearLayout, text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val sw = SwitchCompat(this)
        sw.text = text
        sw.setTextColor(textMain)
        sw.isChecked = checked
        // Follow the chosen theme colour instead of the default purple.
        val on = intArrayOf(android.R.attr.state_checked)
        val off = intArrayOf(-android.R.attr.state_checked)
        val trackOn = Color.argb(0x88, Color.red(accent), Color.green(accent), Color.blue(accent))
        sw.thumbTintList = android.content.res.ColorStateList(arrayOf(on, off), intArrayOf(accent, textSub))
        sw.trackTintList = android.content.res.ColorStateList(arrayOf(on, off), intArrayOf(trackOn, cardStroke))
        sw.setPadding(0, dp(6), 0, dp(6))
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        parent.addView(sw, match())
    }

    private fun spinnerRow(parent: LinearLayout, title: String, options: List<String>, values: List<Int>, current: Int, onPick: (Int) -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(label(title, 15f, textMain), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val sp = Spinner(this)
        sp.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, options) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View =
                (super.getView(position, convertView, parent) as TextView).apply { setTextColor(textMain) }
        }
        sp.backgroundTintList = android.content.res.ColorStateList.valueOf(textMain)
        sp.setSelection(values.indexOf(current).coerceAtLeast(0))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                onPick(values[position])
            }
        }
        row.addView(sp, LinearLayout.LayoutParams(dp(140), LinearLayout.LayoutParams.WRAP_CONTENT))
        parent.addView(row, match())
    }

    private fun textField(hint: String, value: String, multiline: Boolean, lines: Int = 1, password: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(value)
        e.setTextColor(textMain)
        e.setHintTextColor(textSub)
        e.textSize = 13f
        e.background = rounded(field, 12, cardStroke)
        e.setPadding(dp(12), dp(10), dp(12), dp(10))
        var type = InputType.TYPE_CLASS_TEXT
        if (multiline) {
            type = type or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            e.minLines = lines
            e.gravity = Gravity.TOP or Gravity.START
        }
        if (password) type = type or InputType.TYPE_TEXT_VARIATION_PASSWORD
        e.inputType = type
        return e
    }

    private fun fieldLp(): LinearLayout.LayoutParams {
        val lp = match()
        lp.topMargin = dp(6)
        return lp
    }

    // ---- permissions ----------------------------------------------------------------------

    private fun hasNotificationPermission() =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun hasCalendar() = CalendarHelper.hasPermission(this)
    private fun ensureCalendar(): Boolean {
        if (hasCalendar()) return true
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR), 3)
        toast("Allow Calendar, then tap again")
        return false
    }

    // ---- tutorial -------------------------------------------------------------------------

    private val tutorialSteps = listOf(
        "👋 Welcome to Ghostie" to "Ghostie is a little ghost that lives on top of your screen. Tap the small ghost on the screen edge and it comes out to chat. Hold it to talk, drag it to move it, and throw it in the bin to send it away.",
        "✅ Setup first" to "Open the Setup tab and switch on what you want: Display over apps (needed), Notifications, Calendar, and Notification access for WhatsApp. If Android greys something out: App info > ⋮ > Allow restricted settings.",
        "💬 Chat commands" to "Type or say things like: add event maths exam tomorrow 10am, timer 10 minutes, alarm 6:30 am, note buy milk, todo finish record, remind me to drink water in 20 minutes, open WhatsApp. Say help for the full list.",
        "📌 Deadlines" to "Add your class groups under Group reminders. When a submission or registration date appears, Ghostie adds it to your calendar and reminds you. Tick Done on the reminder when finished - if it is still not done in its last hour, Ghostie rings like a call.",
        "📞 Calls" to "Pick people or groups under Ghostie calls me. If they message again and again, or say an urgent word, Ghostie rings. Answer opens WhatsApp, Dismiss stops it, and dragging the ghost into the bin mutes that chat.",
        "📚 Study & food" to "Say study 45 for a focus timer with breaks. Say cheapest chicken biryani and Ghostie compares Zomato, Swiggy and brand apps for you. It only reads prices and never orders.",
        "🎨 Make it yours" to "Look & feel lets you change theme, colour, glass look, chat box size and whether the ghost opens chat directly. Unlock new ghost looks by chatting. You can reopen this tutorial any time from Look & feel."
    )

    private fun showTutorial(step: Int = 0) {
        val (title, body) = tutorialSteps[step]
        val last = step == tutorialSteps.lastIndex
        val b = AlertDialog.Builder(this)
            .setTitle("${step + 1}/${tutorialSteps.size}  $title")
            .setMessage(body)
            .setCancelable(true)
            .setPositiveButton(if (last) "Done" else "Next") { _, _ -> if (!last) showTutorial(step + 1) }
        if (step > 0) b.setNeutralButton("Back") { _, _ -> showTutorial(step - 1) }
        if (!last) b.setNegativeButton("Skip", null)
        b.show()
    }

    /** Shows the tutorial once after a fresh install or an update (not on every start). */
    private fun maybeTutorial() {
        try {
            val stamp = packageManager.getPackageInfo(packageName, 0).lastUpdateTime
            if (s.tutorialStamp != stamp) {
                s.tutorialStamp = stamp
                if (s.tutorialAuto && !isFinishing) showTutorial()
            }
        } catch (e: Exception) { }
    }

    private fun hasAccessibility(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.startsWith("$packageName/") && it.contains("ChatScreenService") }
    }

    private fun hasContactsAndPhone() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED

    private fun hasMic() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun hasListener() = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun askFileAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 2
            )
        }
    }

    private fun permRow(parent: LinearLayout, title: String, desc: String, isOn: () -> Boolean, request: () -> Unit) {
        permChecks.add(isOn)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(6), 0, dp(6))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(label(title, 15f, textMain))
        col.addView(hint(desc))
        val b = button("Allow") { request() }
        row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(b, LinearLayout.LayoutParams(dp(92), dp(40)))
        parent.addView(row, match())
        refreshers.add {
            if (isOn()) {
                b.text = "✓ On"
                b.setTextColor(good)
                b.background = rounded(Color.TRANSPARENT, 12, good)
            } else {
                b.text = "Allow"
                styleButton(b, true)
            }
        }
    }

    // ---- screen ---------------------------------------------------------------------------

    private fun petIntent(action: String? = null): Intent {
        val i = Intent(this, PetOverlayService::class.java)
        if (action != null) i.action = action
        return i
    }

    private fun startPet() {
        saveFields()
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            toast("Allow \"Display over other apps\", then tap Start again")
        } else {
            s.enabled = true
            startForegroundService(petIntent())
            toast("Ghostie is ready 👻")
        }
    }

    private fun pauseFor(minutes: Long, label: String) {
        s.quietUntil = System.currentTimeMillis() + minutes * 60_000L
        toast("Quiet for $label")
    }

    private fun applyTab() {
        navBar?.select(navKeys.indexOf(currentTab).coerceAtLeast(0), animate = navBar?.width ?: 0 > 0)
        for ((c, sec) in cardSections) c.visibility = if (sec == currentTab && c !in hiddenCards) View.VISIBLE else View.GONE
        for ((key, b) in tabButtons) {
            val on = key == currentTab
            b.setTextColor(if (on) onAccent else textSub)
            b.background = if (on) rounded(accent, 20) else rounded(Color.TRANSPARENT, 20, cardStroke)
        }
    }

    private fun showTab(key: String) {
        currentTab = key
        s.tab = key
        applyTab()
    }

    private fun build() {
        val scroll = ScrollView(this)
        scroll.background = pal.background()
        scroll.isFillViewport = true
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(16), dp(16), dp(24))
        scroll.addView(content)
        val root = FrameLayout(this)
        root.addView(scroll, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        binZone = TextView(this)
        binZone.text = "🗑️"
        binZone.textSize = 34f
        binZone.gravity = Gravity.CENTER
        binZone.background = rounded(Color.parseColor("#33FFFFFF"), 40, accent)
        binZone.visibility = View.GONE
        root.addView(binZone, FrameLayout.LayoutParams(dp(84), dp(84), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(120) })
        binZone.setOnDragListener { v, ev ->
            when (ev.action) {
                DragEvent.ACTION_DRAG_STARTED -> { dropped = false; v.visibility = View.VISIBLE; v.alpha = 0f; v.animate().alpha(1f).setDuration(150).start(); true }
                DragEvent.ACTION_DRAG_ENTERED -> { v.animate().scaleX(1.35f).scaleY(1.35f).setDuration(120).start(); true }
                DragEvent.ACTION_DRAG_EXITED -> { v.animate().scaleX(1f).scaleY(1f).setDuration(120).start(); true }
                DragEvent.ACTION_DROP -> {
                    dropped = true
                    val cb = pendingDrop
                    pendingDrop = null
                    val dragged = ev.localState as? View
                    if (dragged != null) crumple(dragged) { cb?.invoke() } else cb?.invoke()
                    true
                }
                DragEvent.ACTION_DRAG_ENDED -> {
                    v.visibility = View.GONE
                    v.scaleX = 1f; v.scaleY = 1f
                    if (!dropped) (ev.localState as? View)?.alpha = 1f
                    pendingDrop = null
                    true
                }
                else -> true
            }
        }
        setContentView(root)
        // Android 15 draws apps edge-to-edge, so keep content clear of the status/navigation bars.
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }

        // Header
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val ghost = ImageView(this)
        ghost.setImageResource(R.drawable.ghost_pet)
        ghost.scaleType = ImageView.ScaleType.FIT_CENTER
        header.addView(ghost, LinearLayout.LayoutParams(dp(64), dp(64)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(14), 0, 0, 0)
        titles.addView(label("Ghostie", 28f, textMain, true))
        titles.addView(label("Your tiny floating study buddy", 14f, textSub))
        header.addView(titles)
        content.addView(header, match())

        // Tabs keep the long list of settings short.
        val tabs = listOf("home" to "🏠 Home", "setup" to "⚙️ Setup", "docs" to "📂 Docs", "brain" to "🧠 Brain", "more" to "✨ More")
        val tabScroll = HorizontalScrollView(this)
        tabScroll.isHorizontalScrollBarEnabled = false
        val tabRow = LinearLayout(this)
        tabRow.orientation = LinearLayout.HORIZONTAL
        tabRow.setPadding(0, dp(14), 0, dp(2))
        for ((key, title) in tabs) {
            val b = TextView(this)
            b.text = title
            b.textSize = 14f
            b.setPadding(dp(16), dp(8), dp(16), dp(8))
            b.setOnClickListener { showTab(key) }
            tabButtons[key] = b
            tabRow.addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) })
        }
        tabScroll.addView(tabRow)
        content.addView(tabScroll, match())
        if (s.navStyle in 1..3) {
            tabScroll.visibility = View.GONE
            content.setPadding(dp(16), dp(16), dp(16), dp(110))
            val nav = GlassNavBar(this, listOf("🏠" to "Home", "⚙️" to "Setup", "📂" to "Docs", "🧠" to "Brain", "✨" to "More"), s.navStyle, pal) { i ->
                showTab(tabs[i].first)
            }
            navBar = nav
            root.addView(nav, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        }

        // Setup progress banner (hidden once everything is on)
        section = "home"
        val banner = card("Finish setting up")
        val bannerText = label("", 13f, textSub)
        banner.addView(bannerText, match())
        val setupBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        setupBar.progressTintList = android.content.res.ColorStateList.valueOf(accent)
        setupBar.progressBackgroundTintList = android.content.res.ColorStateList.valueOf(cardStroke)
        banner.addView(setupBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(8)).apply { topMargin = dp(8); bottomMargin = dp(8) })
        buttonRow(banner, button("Open Setup") { showTab("setup") })
        refreshers.add {
            val done = permChecks.count { it() }
            val total = permChecks.size
            setupBar.max = maxOf(1, total)
            setupBar.progress = done
            bannerText.text = "$done of $total ready. Ghostie works best with everything switched on."
            val hide = total == 0 || done == total
            if (hide) hiddenCards.add(banner) else hiddenCards.remove(banner)
            applyTab()
        }

        // Pet controls
        section = "home"
        val pet = card("👻 Pet")
        buttonRow(pet, button("Start") { startPet() }, button("Stop", false) { stopService(petIntent()); toast("Ghostie stopped") })
        buttonRow(
            pet,
            button("Summon now", false) { startForegroundService(petIntent(PetOverlayService.ACTION_SUMMON)) },
            button("Bring on screen", false) {
                s.resetPosition()
                startForegroundService(petIntent(PetOverlayService.ACTION_RESET))
            }
        )

        // Upcoming submissions (filled by renderLog)
        val upcoming = card("📌 Upcoming deadlines", "Submissions and event registrations Ghostie spotted in your groups. Each one gets a calendar event with alerts (the day before, and optionally 2 days before and the morning of). Long-press one and drag it to the bin to delete it - Ghostie learns to ignore similar ones.")
        logBox = LinearLayout(this)
        logBox.orientation = LinearLayout.VERTICAL
        upcoming.addView(logBox, match())

        val evCard = card("🗓️ Recent events", "Events you added by chatting with Ghostie. Tap one to edit its name, date, time or category. Long-press and drag it to the bin to delete it.")
        eventsBox = LinearLayout(this)
        eventsBox.orientation = LinearLayout.VERTICAL
        evCard.addView(eventsBox, match())

        // Study mode
        val study = card("📚 Study mode", "Focus timer with breaks. Optionally silences notifications (Do Not Disturb) and covers distracting apps while you focus. Or just tell Ghostie: \"study 45\".")
        val studyStatus = label("", 14f, accent)
        study.addView(studyStatus, match())
        refreshers.add {
            val sec = ((s.studyPhaseEnd - System.currentTimeMillis()) / 1000).coerceAtLeast(0)
            studyStatus.text = (if (s.studyActive) (if (s.studyPhase == "focus") "🎯 Focusing: " else "☕ Break: ") + "%d:%02d left\n".format(sec / 60, sec % 60) else "") +
                "Today ${StudyLog.format(StudyLog.today(s.studyLog))} · week ${StudyLog.format(StudyLog.week(s.studyLog))}" +
                StudyLog.streak(s.studyLog).let { if (it >= 2) " · $it-day streak 🔥" else "" }
        }
        spinnerRow(study, "Focus", listOf("15 min", "25 min", "45 min", "60 min", "90 min"), listOf(15, 25, 45, 60, 90), s.studyFocus) { s.studyFocus = it }
        spinnerRow(study, "Break", listOf("5 min", "10 min", "15 min"), listOf(5, 10, 15), s.studyBreak) { s.studyBreak = it }
        switchRow(study, "Do Not Disturb while focusing", s.studyDnd) { on ->
            s.studyDnd = on
            if (on && !getSystemService(android.app.NotificationManager::class.java).isNotificationPolicyAccessGranted) {
                toast("Allow Ghostie in the next screen, then come back")
                try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) } catch (e: Exception) { }
            }
        }
        switchRow(study, "Cover distracting apps while focusing", s.studyBlock) { s.studyBlock = it }
        val appsLabel = hint("")
        fun showApps() { appsLabel.text = if (s.studyAppSet().isEmpty()) "No apps chosen yet." else "Blocked: " + s.studyAppSet().joinToString(", ") { p -> try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(p, 0)).toString() } catch (e: Exception) { p } } }
        showApps()
        study.addView(appsLabel, match())
        buttonRow(
            study,
            button("Choose apps to block", false) { chooseBlockedApps { showApps() } },
            button("Allow usage access", false) {
                try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (e: Exception) { toast("Open Settings > Apps > Special access > Usage access") }
            }
        )
        buttonRow(
            study,
            button("Start") {
                saveFields()
                startService(petIntent(PetOverlayService.ACTION_STUDY_START).putExtra("focus", s.studyFocus).putExtra("brk", s.studyBreak))
                toast("Study mode started 📚")
                handlerRefreshSoon()
            },
            button("Stop", false) {
                startService(petIntent(PetOverlayService.ACTION_STUDY_STOP))
                toast("Study mode stopped")
                handlerRefreshSoon()
            }
        )

        // Setup checklist
        section = "setup"
        val setup = card("✅ Setup", "Switch on what you want to use. Green means ready.")
        setup.addView(hint("Installed from a shared file? Android may grey out Accessibility and Notification access. Open App info, tap the ⋮ menu (top right) and choose \"Allow restricted settings\", then switch them on. Also allow Calendar and Notifications here, or events and alerts can't work.").apply { setPadding(0, 0, 0, dp(6)) })
        buttonRow(setup, button("Open App info", false) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        permRow(setup, "Display over other apps", "Shows the floating ghost", { Settings.canDrawOverlays(this) }) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        permRow(setup, "Notifications", "Ghostie's own alerts", { hasNotificationPermission() }) {
            if (Build.VERSION.SDK_INT >= 33) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        permRow(setup, "File access", "To organize WhatsApp documents", { DocOrganizer.hasAccess(this) }) { askFileAccess() }
        permRow(setup, "Calendar", "To add events and reminders", { hasCalendar() }) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR), 3)
        }
        permRow(setup, "Contacts & calls", "So \"call Mom\" works (dials instantly)", { hasContactsAndPhone() }) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE), 4)
        }
        permRow(setup, "Microphone", "Hold the ghost (or tap 🎙 in chat) and talk to it", { hasMic() }) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 5)
        }
        permRow(setup, "Battery: no restrictions", "Stops Android from closing the ghost", {
            (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        }) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        }
        permRow(setup, "Notification access", "Reads new messages when WhatsApp is closed", { hasListener() }) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        permRow(setup, "Read open chats", "Catches messages while you have the group open", { hasAccessibility() }) {
            AlertDialog.Builder(this)
                .setTitle("Read open chats")
                .setMessage(
                    "Ghostie will only look at WhatsApp, and only act when one of your watched groups is on screen. Nothing leaves your phone.\n\n" +
                        "In the next screen open \"Installed apps\" (or \"Downloaded apps\"), choose \"Ghostie chat reader\" and switch it on.\n\n" +
                        "If Android says \"Restricted setting\": phone Settings > Apps > Ghostie > ⋮ (top right) > \"Allow restricted settings\", then try again."
                )
                .setPositiveButton("Continue") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                .setNegativeButton("Cancel", null)
                .show()
        }

        permRow(setup, "Food price reader", "Lets me compare food prices when you ask", { FoodScanService.isEnabled(this) }) {
            AlertDialog.Builder(this)
                .setTitle("Food price reader")
                .setMessage(
                    "Ghostie will open Zomato, Swiggy, Domino's, Popeyes and EatSure ONLY when you ask it to compare prices (e.g. \"cheapest chicken biryani\"), search your item and read the prices on screen.\n\n" +
                        "It never adds to a cart, pays, logs in or places an order, and it does nothing the rest of the time. Nothing leaves your phone.\n\n" +
                        "In the next screen open \"Installed apps\", choose \"Ghostie food price reader\" and switch it on. If Android says \"Restricted setting\": phone Settings > Apps > Ghostie > ⋮ > \"Allow restricted settings\"."
                )
                .setPositiveButton("Continue") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                .setNegativeButton("Cancel", null)
                .show()
        }
        buttonRow(setup, button("🍽️ Assumed delivery fee: ₹${s.foodFee} (when an app doesn't show it)", false) {
            val et = android.widget.EditText(this).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText(s.foodFee.toString()) }
            AlertDialog.Builder(this).setTitle("Assumed delivery fee (₹)").setView(et)
                .setPositiveButton("Save") { _, _ -> et.text.toString().toIntOrNull()?.let { s.foodFee = it.coerceIn(0, 300) }; recreate() }
                .setNegativeButton("Cancel", null).show()
        })

        setup.addView(hint("On Xiaomi/Poco phones also switch on Autostart for Ghostie (App settings > Autostart), or the system may stop it in the background.").apply { setPadding(0, dp(4), 0, dp(4)) })
        buttonRow(setup, button("Open Ghostie's app settings", false) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })

        // Group reminders
        val groups = card(
            "💬 Group reminders",
            "Ghostie watches the groups you list - through notifications when WhatsApp is closed, and by reading the screen when the group is open. A submission or registration deadline becomes a calendar event with reminders."
        )
        switchRow(groups, "Watch groups", s.watchEnabled) { s.watchEnabled = it }
        switchRow(groups, "Also warn 2 days before", s.remind2d) { s.remind2d = it }
        switchRow(groups, "Nudge on the morning it is due", s.remindMorning) { s.remindMorning = it }
        val status = hint("")
        status.setPadding(0, dp(4), 0, dp(4))
        groups.addView(status, match())
        refreshers.add {
            fun ago(k: String): String {
                val tm = ActivityLog.lastTime(this, k) ?: return "never"
                val mins = (System.currentTimeMillis() - tm) / 60_000L
                return if (mins < 1) "just now" else if (mins < 60) "$mins min ago" else if (mins < 1440) "${mins / 60} h ago" else "${mins / 1440} d ago"
            }
            status.text = "Last WhatsApp notification heard: ${ago("Notification")}\nLast open chat read: ${ago("Open chat")}"
        }
        groupsField = textField("Group names, one per line (e.g. CSE 3A)", s.watchedGroups, true, 3)
        groups.addView(groupsField, fieldLp())
        groups.addView(hint("Only messages that arrive while this is on can be seen. Keep Ghostie's battery setting on \"Unrestricted\".").apply { setPadding(0, dp(6), 0, dp(4)) })
        val testField = textField("Try a message, e.g. Last date to register for Hackathon is 12 Nov", "", false)
        groups.addView(testField, fieldLp())
        buttonRow(groups, button("Test message", false) {
            val text = testField.text.toString()
            val sub = SubmissionParser.parse(text, LocalDate.now())
            val msg = if (sub == null) {
                "No submission date found in that message."
            } else {
                val now = LocalDateTime.now()
                val rs = SubmissionParser.reminderTimes(sub, now, s.remind2d, s.remindMorning)
                val fmt = DateTimeFormatter.ofPattern("EEE d MMM, h:mm a", Locale.ENGLISH)
                val kind = if (sub.kind == DeadlineKind.REGISTRATION) "Registration closes" else "Submission due"
                val alerts = if (rs.times.isEmpty()) "(no future alerts - it is due very soon)" else rs.times.joinToString("\n") { "• " + it.format(fmt) }
                "$kind: ${SubmissionParser.eventStart(sub).format(fmt)}\nAlerts:\n$alerts"
            }
            AlertDialog.Builder(this).setTitle("Ghostie would...").setMessage(msg).setPositiveButton("OK", null).show()
        })

        // Catch-up (works even when notifications are missed)
        val catchUp = card(
            "📥 Manual catch-up (backup)",
            "Only needed for muted groups you never open, or if you skipped \"Read open chats\". To catch up: in the group tap ⋮ > More > Export chat > Without media, then choose \"Add Ghostie reminders\". You can also share a single message the same way."
        )
        buttonRow(catchUp, button("Scan a chat file…", false) {
            if (!ensureCalendar()) return@button
            val pick = Intent(Intent.ACTION_OPEN_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType("*/*")
                .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/plain", "application/zip"))
            startActivityForResult(pick, 77)
        })

        // Documents
        section = "docs"
        val docs = card(
            "📂 Documents",
            "Copies WhatsApp documents into Documents/Ghostie/<Subject>, sorted by file name. Originals stay put. You can also tell the ghost: \"organize documents\"."
        )
        subjectsField = textField("Subject: keyword, keyword", s.subjects, true, 6)
        subjectsField.textSize = 12f
        docs.addView(subjectsField, fieldLp())
        docs.addView(hint("One subject per line. Start a line with * for a fallback category. Clear everything to restore the defaults.").apply { setPadding(0, dp(6), 0, dp(4)) })
        buttonRow(docs, button("Organize now") {
            saveFields()
            if (!DocOrganizer.hasAccess(this)) {
                askFileAccess()
            } else {
                toast("Sorting...")
                Thread {
                    val text = try {
                        DocOrganizer.summary(DocOrganizer.organize(this))
                    } catch (e: Exception) {
                        "Something went wrong while organizing."
                    }
                    runOnUiThread { AlertDialog.Builder(this).setTitle("Documents").setMessage(text).setPositiveButton("OK", null).show() }
                }.start()
            }
        })

        docs.addView(hint("Smart sorting also uses which chat a file came from and what is written inside PDFs, Word and PowerPoint files.").apply { setPadding(0, dp(2), 0, dp(4)) })
        switchRow(docs, "Sort new WhatsApp documents automatically (off by default)", s.autoOrganize) { s.autoOrganize = it }

        buttonRow(docs, button("Browse sorted files", false) { renderDocs() })
        docBox = LinearLayout(this)
        docBox.orientation = LinearLayout.VERTICAL
        docs.addView(docBox, match())

        // What Ghostie has learned
        section = "brain"
        val agent = card(
            "🤖 Ghostie's agent",
            "Ghostie watches how you use it (when you study, which focus length you finish, which deadlines you act on or bin, when you ignore it) and suggests things. Every suggestion has Yes / Not now chips, and it goes quiet about things you keep declining. All of this stays on your phone."
        )
        switchRow(agent, "Let Ghostie make suggestions", s.suggestions) { s.suggestions = it }
        val insightBox = label("", 13f, textMain)
        agent.addView(insightBox, match())
        refreshers.add {
            val ins = HabitStore.get(this).insights()
            val quiet = s.quietHourSet().sorted()
            insightBox.text = (if (ins.isEmpty()) "Still learning. Use me for a few days (study, chat, answer reminders) and I'll start spotting patterns." else ins.joinToString("\n") { "• $it" }) +
                (if (quiet.isNotEmpty()) "\n• Quiet hours (no visits): " + HabitStore.get(this).rangeText(quiet) else "")
        }
        buttonRow(
            agent,
            button("Plan my week", false) { startService(petIntent(PetOverlayService.ACTION_PLAN)) },
            button("Clear quiet hours", false) { s.quietHoursList = ""; refresh() }
        )
        buttonRow(
            agent,
            button("Unmute suggestions", false) { HabitStore.get(this).unmuteAll(); HabitStore.save(this); toast("Suggestions unmuted"); refresh() },
            button("Forget my habits", false) {
                AlertDialog.Builder(this).setTitle("Forget my habits?").setMessage("Ghostie will unlearn your routines, study history by subject and quiet hours.")
                    .setPositiveButton("Forget") { _, _ -> HabitStore.reset(this); s.quietHoursList = ""; s.subjectLog = ""; toast("Forgotten 🧹"); refresh() }
                    .setNegativeButton("Cancel", null).show()
            }
        )

        val learn = card("🧠 What Ghostie learned", "Ghostie remembers your corrections on this phone only: which words mean which subject or calendar category, phrases you teach it, deadlines you throw away, and what you like to chat about. It is a small learner, not a big AI model, and works offline. Teach it in chat: \"when I say study mode, set timer 25 minutes\".")
        learnBox = LinearLayout(this)
        learnBox.orientation = LinearLayout.VERTICAL
        learn.addView(learnBox, match())

        // Words and sentences
        learn.addView(label("Words and sentences", 15f, textMain, true).apply { setPadding(0, dp(12), 0, dp(2)) })
        learn.addView(hint("Ghostie reads what you say to it, text you paste here, and (if switched on) your watched groups and shared chats. It remembers which words follow which, then builds its own new sentences in your style and mixes them into its chat. Rate them 👍/👎 to teach it. It's a small word-chain model, so sentences can be quirky. Links, phone numbers and rude words are skipped."))
        switchRow(learn, "Learn words from watched groups and shared chats", s.learnGroups) { s.learnGroups = it }
        val teachField = textField("Teach by example: paste messages, jokes or lines you like", "", true, 3)
        learn.addView(teachField, fieldLp())
        buttonRow(
            learn,
            button("Learn from this") {
                val n = SentenceStore.learn(this, teachField.text.toString(), 3)
                SentenceStore.save(this)
                teachField.setText("")
                toast(if (n > 0) "Learned $n new sentence(s) 🧠" else "Nothing new to learn there")
                renderLearned()
            },
            button("Say something", false) {
                val m = SentenceStore.get(this)
                val msg = if (!m.ready) "I'm still learning words 📚 (${m.summary()})" else m.generate()?.let { it } ?: "I need a few more sentences first."
                AlertDialog.Builder(this).setTitle("Ghostie says").setMessage(msg).setPositiveButton("OK", null).show()
            }
        )
        buttonRow(learn, button("Forget learned words", false) {
            AlertDialog.Builder(this).setTitle("Forget all learned words?").setMessage("Ghostie will stop making its own sentences until it learns again.")
                .setPositiveButton("Forget") { _, _ -> SentenceStore.reset(this); renderLearned(); toast("Words forgotten") }
                .setNegativeButton("Cancel", null).show()
        })
        buttonRow(learn, button("Forget everything", false) {
            AlertDialog.Builder(this).setTitle("Forget everything?").setMessage("This erases what Ghostie learned. Your events and documents stay.")
                .setPositiveButton("Forget") { _, _ -> LearnStore.reset(this); renderLearned(); toast("Memory wiped") }
                .setNegativeButton("Cancel", null).show()
        })

        // Companion settings
        section = "more"
        val call = card(
            "📞 Ghostie calls me",
            "When someone you pick keeps messaging, or sends an urgent word, Ghostie rings like an incoming call and tells you who it is. Answer opens WhatsApp. Drag the ghost into the bin on the call screen (or tap 🗑 Never) and it stops ringing for that chat."
        )
        switchRow(call, "Ring me for the people below", s.callEnabled) { s.callEnabled = it }
        switchRow(call, "Also ring if a deadline isn't marked done in its last hour", s.finalCall) {
            s.finalCall = it
            if (it) ReminderAlarms.rescheduleAll(this)
        }
        spinnerRow(call, "Last-hour call at", listOf("2 hours before", "1 hour before", "30 min before", "15 min before"), listOf(120, 60, 30, 15), s.finalCallMin) {
            if (it != s.finalCallMin) { s.finalCallMin = it; ReminderAlarms.rescheduleAll(this) }
        }
        vipField = textField("One person or group per line, exactly as WhatsApp shows it", s.callVips, true, 3)
        call.addView(vipField, fieldLp())
        spinnerRow(call, "Ring after", listOf("2 messages", "3 messages", "4 messages", "5 messages"), listOf(2, 3, 4, 5), s.callCount) { s.callCount = it }
        spinnerRow(call, "Within", listOf("2 min", "5 min", "10 min", "30 min"), listOf(2, 5, 10, 30), s.callWindow) { s.callWindow = it }
        urgentField = textField("Urgent words, separated by commas", s.callUrgent, true, 2)
        call.addView(urgentField, fieldLp())
        buttonRow(
            call,
            button("Test call", false) {
                saveFields()
                CallAlerts.show(this, "Test", "Test chat has messaged you 3 times", "pls reply, it's urgent!")
            },
            button("Test deadline call", false) {
                CallAlerts.show(this, "Test", "⏰ Lab record is due in about 60 min and isn't marked done", "", 1L)
            },
            button("Allow full screen", false) {
                try {
                    if (Build.VERSION.SDK_INT >= 34) startActivity(Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT", Uri.parse("package:$packageName")))
                    else toast("Already allowed on this Android version")
                } catch (e: Exception) { toast("Open Settings > Apps > Ghostie > Notifications") }
            },
            button("Unmute chats", false) {
                val n = LearnStore.get(this).clearBlocked("call")
                LearnStore.save(this)
                toast(if (n == 0) "No muted chats" else "Unmuted $n chat(s)")
            }
        )
        call.addView(hint("Needs Notification access (Setup tab). Ghostie can't phone your own number, so this is an on-screen call with ringtone and vibration. It rings even in the background, but not if Do Not Disturb blocks it.").apply { setPadding(0, dp(6), 0, 0) })

        val pref = card("🎛️ Companion")
        val themeCard = card("🎨 Look & feel")
        spinnerRow(themeCard, "Theme", Themes.labels, Themes.ids.indices.toList(), Themes.ids.indexOf(s.theme).coerceAtLeast(0)) { i ->
            if (Themes.ids[i] != s.theme) { s.theme = Themes.ids[i]; recreate() }
        }
        spinnerRow(themeCard, "Theme colour", Themes.accentLabels, Themes.accentLabels.indices.toList(), s.accentChoice) { i ->
            if (i != s.accentChoice) { s.accentChoice = i; recreate() }
        }
        spinnerRow(themeCard, "Navigation bar", listOf("Classic tabs (top)", "Neon glass", "Dip bubble", "Pop bubble"), listOf(0, 1, 2, 3), s.navStyle) {
            if (it != s.navStyle) { s.navStyle = it; recreate() }
        }
        switchRow(themeCard, "Glass look", s.glass) { s.glass = it; recreate() }
        if (s.glass) {
            themeCard.addView(label("Glass intensity", 14f, textMain).apply { setPadding(0, dp(4), 0, 0) })
            val bar = android.widget.SeekBar(this)
            bar.max = 100
            bar.progress = s.glassLevel
            bar.progressTintList = android.content.res.ColorStateList.valueOf(accent)
            bar.thumbTintList = android.content.res.ColorStateList.valueOf(accent)
            bar.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: android.widget.SeekBar?, v: Int, fromUser: Boolean) {}
                override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
                override fun onStopTrackingTouch(sb: android.widget.SeekBar?) { s.glassLevel = sb?.progress ?: 50; recreate() }
            })
            themeCard.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        }
        switchRow(themeCard, "Tap the ghost to open chat straight away", s.directChat) { s.directChat = it }
        themeCard.addView(label("Chat box: drag its title bar to move it and the ◢ corner to resize it.", 12f, textSub).apply { setPadding(0, dp(2), 0, dp(4)) })
        buttonRow(
            themeCard,
            button("Small", false) { s.chatW = 260; s.chatH = 140; toast("Chat box: small") },
            button("Medium", false) { s.chatW = 320; s.chatH = 200; toast("Chat box: medium") },
            button("Large", false) { s.chatW = 380; s.chatH = 320; toast("Chat box: large") }
        )
        buttonRow(themeCard, button("Reset chat position", false) { s.chatX = -1; s.chatY = -1; toast("Chat box position reset") })
        switchRow(themeCard, "Show explanations under settings", s.showHints) {
            s.showHints = it
            for (v in hintViews) v.visibility = if (it) View.VISIBLE else View.GONE
        }
        switchRow(themeCard, "Show the tutorial after Ghostie is installed or updated", s.tutorialAuto) { s.tutorialAuto = it }
        buttonRow(themeCard, button("📖 Show tutorial") { showTutorial() })
        switchRow(pref, "Enable pet", s.enabled) { s.enabled = it }
        switchRow(pref, "Check-ins", s.checkins) { s.checkins = it }
        switchRow(pref, "Always on top", s.alwaysTop) { s.alwaysTop = it }
        switchRow(pref, "Ghost speaks aloud", s.speak) { s.speak = it }
        switchRow(pref, "Sound effects (squeaks, giggles)", s.sound) { s.sound = it }
        spinnerRow(pref, "Voice", listOf("Squeaky", "Cute", "Normal"), listOf(18, 14, 10), s.voicePitch) { s.voicePitch = it }
        pref.addView(hint("Uses your phone's text-to-speech voice, pitched up. Silent when the phone is on silent or vibrate. Tap and hold the ghost to pet it, double-tap to spin it, drag it and shake it to make it dizzy.").apply { setPadding(0, dp(2), 0, dp(4)) })
        switchRow(pref, "Sleep at night (11 pm - 6 am)", s.sleepEnabled) { s.sleepEnabled = it }
        val sizeLabel = label("Ghost size: ${s.petDp}", 15f, textMain)
        sizeLabel.setPadding(0, dp(8), 0, 0)
        pref.addView(sizeLabel, match())
        val bar = SeekBar(this)
        bar.max = 144
        bar.progress = s.petDp - 56
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                sizeLabel.text = "Ghost size: ${value + 56}"
                if (fromUser) s.petDp = value + 56
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        pref.addView(bar, match())
        pref.addView(hint("The ghost also hides during calls, in landscape and in Do Not Disturb.").apply { setPadding(0, dp(2), 0, dp(4)) })
        spinnerRow(pref, "Visit every", listOf("5 min", "10 min", "15 min", "30 min", "1 hour"), listOf(5, 10, 15, 30, 60), s.visitMinutes) { s.visitMinutes = it }
        spinnerRow(pref, "Water reminder", listOf("15 min", "30 min", "1 hour", "2 hours"), listOf(15, 30, 60, 120), s.waterMinutes) { s.waterMinutes = it }

        spinnerRow(pref, "Language (voice)", listOf("English", "हिन्दी / Hinglish"), listOf(0, 1), if (s.language == "hi") 1 else 0) { s.language = if (it == 1) "hi" else "en" }
        pref.addView(hint("Sets what Ghostie listens for and the voice it speaks with. Hindi and Hinglish commands like \"kal shaam 6 baje alarm lagao\" or \"5 minute ka timer\" work in either mode. Chat replies are still in English. Hindi voice needs Hindi installed in your phone's speech settings.").apply { setPadding(0, dp(2), 0, dp(4)) })
        val moodBlurb = label(Moods.blurb(s.mood), 12f, textSub)
        spinnerRow(pref, "Personality", Moods.labels, Moods.ids.indices.toList(), Moods.ids.indexOf(s.mood).coerceAtLeast(0)) { i ->
            s.mood = Moods.ids[i]
            moodBlurb.text = Moods.blurb(s.mood)
        }
        pref.addView(moodBlurb, match())
        buttonRow(pref, button("Hear it", false) {
            startService(petIntent(PetOverlayService.ACTION_SAY).putExtra("text", Moods.preview(s.mood)))
        })
        switchRow(pref, "Show \"tap to open\" when Ghostie opens an app", s.openFallback) { s.openFallback = it }
        switchRow(pref, "Random tricks (dance, wave, yawn, flip)", s.tricks) { s.tricks = it }
        switchRow(pref, "React to charging / low battery", s.batteryReacts) { s.batteryReacts = it }
        val tintField = textField("Custom colour, e.g. #FFC9E3", s.customTint, false)
        pref.addView(tintField, fieldLp())
        buttonRow(pref, button("Use custom colour", false) {
            try {
                Color.parseColor(tintField.text.toString().trim())
                s.customTint = tintField.text.toString()
                s.skin = "custom"
                startService(petIntent(PetOverlayService.ACTION_SKIN))
                toast("Custom colour applied 🎨")
            } catch (e: Exception) { toast("Use a hex colour like #FFC9E3") }
        })
        val skinList = Skins.all
        builtUnlocked = skinList.count { Skins.unlocked(it, s.chatCount) }
        spinnerRow(
            pref, "Ghost look",
            skinList.map { (if (Skins.unlocked(it, s.chatCount)) "" else "🔒 ") + it.label + (if (Skins.unlocked(it, s.chatCount)) "" else " (${it.unlockChats} chats)") },
            skinList.indices.toList(), skinList.indexOfFirst { it.id == s.skin }.coerceAtLeast(0)
        ) { i ->
            val sk = skinList[i]
            if (!Skins.unlocked(sk, s.chatCount)) toast("Chat with Ghostie ${sk.unlockChats - s.chatCount} more times to unlock ${sk.label}")
            else if (sk.id != s.skin) { s.skin = sk.id; startService(petIntent(PetOverlayService.ACTION_SKIN)) }
        }

        val shareCard = card("📤 Share Ghostie", "Paste your download link once (GitHub release link), then send it to friends in one tap.")
        linkField = textField("https://github.com/you/repo/releases/latest/download/Ghostie.apk", s.shareLink, false)
        shareCard.addView(linkField, fieldLp())
        buttonRow(shareCard, button("Share with a friend", false) {
            saveFields()
            if (s.shareLink.isBlank()) toast("Paste the download link first")
            else {
                val msg = "Try Ghostie 👻, a floating ghost that reads your class groups and reminds you of deadlines.\n\nDownload: ${s.shareLink}\n\nAfter installing: open Ghostie → Setup tab, allow Display over apps, Notifications and Calendar. If Accessibility or Notification access is greyed out: App info → ⋮ → Allow restricted settings."
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg), "Share Ghostie"))
            }
        })

        val rules = card("🎯 Group rules", "Per group, words that mean \"not a deadline\". One rule per line, e.g.  CS Group: ignore lunch, party, trip   (use * for every group). Each deadline in the list also shows the original message so you can tell why it was added.")
        switchRow(rules, "Alert me about class changes (cancelled, moved, room, online)", s.classAlerts) { s.classAlerts = it }
        rulesField = textField("CS Group: ignore lunch, party", s.groupRules, true, 3)
        rules.addView(rulesField, fieldLp())

        // Quiet time
        val quiet = card("🔕 Quiet time", "Pause visits and reminders from the ghost.")
        buttonRow(quiet, button("30 min", false) { pauseFor(30, "30 minutes") }, button("1 hour", false) { pauseFor(60, "1 hour") })
        buttonRow(
            quiet,
            button("Until tomorrow", false) {
                s.quietUntil = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                toast("Quiet until tomorrow")
            },
            button("Resume") {
                s.quietUntil = 0L
                toast("Ghostie resumed")
            }
        )

        // Activity log
        val act = card("🧾 Activity log", "What Ghostie has seen and done lately. Useful if a reminder did not appear.")
        activityBox = LinearLayout(this)
        activityBox.orientation = LinearLayout.VERTICAL
        act.addView(activityBox, match())
        buttonRow(
            act,
            button("Refresh", false) { renderActivity() },
            button("Copy", false) {
                val text = ActivityLog.read(this).take(40).joinToString("\n") { it.text() }
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Ghostie log", text))
                toast("Copied")
            },
            button("Clear", false) { ActivityLog.clear(this); renderActivity() }
        )

        // AI
        val ai = card(
            "✨ AI chat (optional)",
            "Free and nothing to download: pick a provider, make a free key on their website (Groq: console.groq.com) and paste it here. Needs internet, and what you say to the AI is sent to that provider. Without it Ghostie still works offline."
        )
        switchRow(ai, "Use AI for free chat", s.ai) { s.ai = it }
        switchRow(ai, "Also send a short summary of my deadlines, study time and habits (never message text), so AI answers and plans fit me", s.aiContext) { s.aiContext = it }
        val provs = ChatEngine.providers
        baseField = textField("Address", s.aiBase, false)
        modelField = textField("Model", s.aiModel, false)
        spinnerRow(ai, "Provider", provs.map { it.label }, provs.indices.toList(), provs.indexOfFirst { it.id == s.aiProvider }.coerceAtLeast(0)) { i ->
            val pv = provs[i]
            if (pv.id != s.aiProvider) {
                s.aiProvider = pv.id
                s.aiBase = pv.base
                s.aiModel = pv.model
                baseField.setText(pv.base)
                modelField.setText(pv.model)
            }
        }
        keyField = textField("API key", s.key, false, 1, true)
        ai.addView(keyField, fieldLp())
        ai.addView(baseField, fieldLp())
        ai.addView(modelField, fieldLp())
        ai.addView(hint("Address and model are filled in for you. Change them only if a provider renames its model.").apply { setPadding(0, dp(6), 0, 0) })

        finalizeCards()
        currentTab = if (tabButtons.containsKey(s.tab)) s.tab else "home"
        applyTab()
    }

    /** Cards become tap-to-open: one short title line each; the first card of every tab starts open. */
    private fun finalizeCards() {
        val state = s.cardState.toMutableSet()
        val firstOfTab = HashSet<String>()
        for ((c, sec) in cardSections) {
            val ll = c as? LinearLayout ?: continue
            val titleView = ll.getChildAt(0) as? TextView ?: continue
            if (ll.childCount < 3) continue
            val key = titleView.text.toString()
            val default = firstOfTab.add(sec) || key.startsWith("Finish setting up") || key.startsWith("👻")
            val body = LinearLayout(this)
            body.orientation = LinearLayout.VERTICAL
            val kids = (1 until ll.childCount).map { ll.getChildAt(it) }
            kids.forEach { ll.removeView(it); body.addView(it) }
            ll.addView(body)
            var open = when {
                "$key=1" in state -> true
                "$key=0" in state -> false
                else -> default
            }
            fun render() {
                body.visibility = if (open) View.VISIBLE else View.GONE
                titleView.text = (if (open) "▾  " else "▸  ") + key
            }
            render()
            titleView.setOnClickListener {
                open = !open
                render()
                state.remove("$key=1"); state.remove("$key=0"); state.add("$key=" + if (open) "1" else "0")
                s.cardState = state.toSet()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != 77 || resultCode != RESULT_OK || uri == null) return
        toast("Scanning...")
        Thread {
            var group = "Chat"
            val msg = try {
                val (g, text) = ChatImporter.read(this, uri)
                group = g
                ChatImporter.describe(g, ChatImporter.importText(this, g, text))
            } catch (e: Exception) {
                "I couldn't read that file."
            }
            runOnUiThread {
                AlertDialog.Builder(this).setTitle(group).setMessage(msg).setPositiveButton("OK", null).show()
                renderLog()
            }
        }.start()
    }

    private fun renderLearned() {
        if (!::learnBox.isInitialized) return
        learnBox.removeAllViews()
        val l = LearnStore.get(this)
        learnBox.addView(label(l.summary() + "\n" + SentenceStore.get(this).summary(), 12f, textSub), match())
        for ((phrase, meaning) in l.aliases.entries.toList().take(10)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.addView(label("\"$phrase\" → " + meaning.removePrefix("word:").removePrefix("say:"), 13f, textMain), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val x = button("✕", false) { l.removeAlias(phrase); LearnStore.save(this); renderLearned() }
            x.minHeight = dp(34); x.minimumHeight = dp(34)
            row.addView(x, LinearLayout.LayoutParams(dp(52), dp(36)))
            learnBox.addView(row, match())
        }
    }

    private fun renderDocs() {
        if (!::docBox.isInitialized) return
        docBox.removeAllViews()
        if (!DocOrganizer.hasAccess(this)) {
            docBox.addView(label("Allow File access in Setup first.", 13f, textSub))
            return
        }
        val files = DocOrganizer.sortedFiles().take(40)
        if (files.isEmpty()) {
            docBox.addView(label("No sorted files yet. Tap Organize now.", 13f, textSub))
            return
        }
        docBox.addView(hint("Tap a file to move it to another subject (Ghostie learns). Long-press and drag it to the bin to delete Ghostie's copy - the WhatsApp original stays.").apply { setPadding(0, dp(6), 0, dp(6)) })
        val names = SubjectMatcher.parse(s.subjects).map { it.name }
        for ((subject, file) in files) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.background = rounded(field, 12, cardStroke)
            row.setPadding(dp(12), dp(8), dp(12), dp(8))
            row.addView(label(file.name, 13f, textMain, true))
            row.addView(label(subject, 11f, accent))
            row.setOnClickListener {
                AlertDialog.Builder(this).setTitle("Move \"${file.name}\" to…")
                    .setItems(names.toTypedArray()) { _, i ->
                        toast(if (DocOrganizer.moveTo(this, file, names[i])) "Moved - I'll remember that 🧠" else "Couldn't move it")
                        renderDocs(); renderLearned(); renderActivity()
                    }.show()
            }
            makeDraggable(row) {
                toast(if (DocOrganizer.binFile(this, file)) "Thrown away 🗑️" else "Couldn't delete it")
                renderDocs(); renderActivity()
            }
            val lp = match()
            lp.bottomMargin = dp(6)
            docBox.addView(row, lp)
        }
    }

    private fun renderActivity() {
        if (!::activityBox.isInitialized) return
        activityBox.removeAllViews()
        val lines = ActivityLog.read(this).take(15)
        if (lines.isEmpty()) {
            activityBox.addView(label("Nothing yet.", 13f, textSub))
            return
        }
        for (l in lines) activityBox.addView(label(l.text(), 12f, textSub).apply { setPadding(0, dp(2), 0, dp(2)) }, match())
    }

    private fun handlerRefreshSoon() {
        content.postDelayed({ refresh() }, 600)
    }

    /** Lets the user tick which installed apps get covered during focus time. */
    private fun chooseBlockedApps(done: () -> Unit) {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
        if (apps.isEmpty()) { toast("I can't see your apps"); return }
        val chosen = s.studyAppSet().toMutableSet()
        if (chosen.isEmpty()) {
            val common = setOf("com.instagram.android", "com.google.android.youtube", "com.snapchat.android", "com.twitter.android", "com.facebook.katana", "com.reddit.frontpage", "com.zhiliaoapp.musically", "in.mohalla.sharechat", "com.netflix.mediaclient")
            chosen.addAll(apps.map { it.first }.filter { it in common })
        }
        val names = apps.map { it.second }.toTypedArray()
        val checked = apps.map { it.first in chosen }.toBooleanArray()
        AlertDialog.Builder(this).setTitle("Apps to cover while you focus")
            .setMultiChoiceItems(names, checked) { _, i, on -> if (on) chosen.add(apps[i].first) else chosen.remove(apps[i].first) }
            .setPositiveButton("Save") { _, _ ->
                s.studyApps = chosen.joinToString("\n")
                s.studyBlock = true
                done()
                toast("Saved. Allow Usage access too, so Ghostie can see which app is open.")
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun renderEvents() {
        eventsBox.removeAllViews()
        val list = RecentEvents.list(this)
        if (list.isEmpty()) {
            eventsBox.addView(label("Nothing yet. Try telling Ghostie: \"add event dentist on 12 November at 5 pm\".", 13f, textSub))
            return
        }
        val zone = ZoneId.systemDefault()
        val fmt = DateTimeFormatter.ofPattern("EEE d MMM yyyy", Locale.ENGLISH)
        for (r in list) {
            val dt = java.time.Instant.ofEpochMilli(r.start).atZone(zone)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.background = rounded(field, 12, cardStroke)
            row.setPadding(dp(12), dp(8), dp(12), dp(8))
            row.addView(label(r.kind.icon + " " + r.title, 14f, textMain, true))
            val whenText = dt.format(fmt) + if (r.allDay) " (all day)" else dt.format(DateTimeFormatter.ofPattern(", h:mm a", Locale.ENGLISH))
            row.addView(label(whenText + (if (r.repeat.isNotEmpty()) " - repeats yearly" else ""), 12f, accent))
            row.setOnClickListener { editEvent(r) }
            makeDraggable(row) {
                CalendarHelper.delete(this, r.id)
                RecentEvents.remove(this, r.id)
                s.removeLog(r.id)
                toast("Event deleted 🗑️")
                refresh()
            }
            val lp = match()
            lp.bottomMargin = dp(6)
            eventsBox.addView(row, lp)
        }
    }

    private fun editEvent(r: RecentEvents.Rec) {
        val zone = ZoneId.systemDefault()
        var dt = java.time.Instant.ofEpochMilli(r.start).atZone(zone).toLocalDateTime()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val name = textField("Name", Commands.baseTitle(r.title), false)
        box.addView(name, fieldLp())
        val kinds = EventKind.values().toList()
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, kinds.map { it.icon + " " + it.label })
        sp.setSelection(kinds.indexOf(r.kind).coerceAtLeast(0))
        box.addView(sp, fieldLp())
        val dateBtn = Button(this)
        val timeBtn = Button(this)
        fun show() {
            dateBtn.text = "Date: " + dt.toLocalDate().format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH))
            timeBtn.text = "Time: " + dt.format(DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH))
        }
        show()
        dateBtn.setOnClickListener {
            android.app.DatePickerDialog(this, { _, y, m, d -> dt = dt.withYear(y).withMonth(m + 1).withDayOfMonth(d); show() }, dt.year, dt.monthValue - 1, dt.dayOfMonth).show()
        }
        timeBtn.setOnClickListener {
            android.app.TimePickerDialog(this, { _, h, mi -> dt = dt.withHour(h).withMinute(mi); show() }, dt.hour, dt.minute, false).show()
        }
        box.addView(dateBtn, fieldLp())
        box.addView(timeBtn, fieldLp())
        AlertDialog.Builder(this).setTitle("Edit event").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val kind = kinds[sp.selectedItemPosition]
                val title = name.text.toString().trim().ifEmpty { Commands.baseTitle(r.title) }
                val startMs = dt.atZone(zone).toInstant().toEpochMilli()
                val day = dt.toLocalDate().atStartOfDay(zone).toInstant().toEpochMilli()
                var ev = Command.Event(title, if (kind == EventKind.EVENT) startMs else day, EventKind.EVENT)
                if (kind != EventKind.EVENT) ev = Commands.withKind(ev, kind)
                CalendarHelper.delete(this, r.id)
                RecentEvents.remove(this, r.id)
                s.removeLog(r.id)
                val id = CalendarHelper.insertEvent(this, ev, "Added by Ghostie")
                if (id == null) toast("Couldn't save - is Calendar allowed?")
                else {
                    RecentEvents.add(this, ev, id)
                    val l = LearnStore.get(this)
                    l.teachKind(Commands.baseTitle(ev.title), kind.name)
                    LearnStore.save(this)
                    toast("Saved ✅")
                }
                refresh()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun renderLog() {
        if (!::logBox.isInitialized) return
        logBox.removeAllViews()
        val items = ReminderLog.upcoming(s.logs()).take(10)
        if (items.isEmpty()) {
            logBox.addView(label("Nothing due. When someone posts a submission or registration deadline in a watched group, it appears here.", 13f, textSub))
            return
        }
        val warn = Color.parseColor("#FF8A7A")
        for (e in items) {
            val days = ReminderLog.daysLeft(e)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = rounded(field, 12, if (days <= 1) warn else cardStroke)
            row.setPadding(dp(12), dp(8), dp(8), dp(8))
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            val icon = when {
                ReminderLog.isRegistration(e) -> "📝 Registration: "
                e.title.startsWith("⏳") -> "⏳ "
                else -> "📌 "
            }
            col.addView(label(icon + ReminderLog.label(e), 14f, textMain, true))
            col.addView(label(ReminderLog.dueLabel(e), 12f, if (days <= 1) warn else accent))
            col.addView(label("from " + e.group, 11f, textSub))
            if (e.msg.isNotBlank()) col.addView(label("\u201C" + e.msg + "\u201D", 11f, textSub).apply { setPadding(0, dp(2), 0, 0) })
            row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val remove = button("Done", false) {
                HabitStore.get(this).groupAct(e.group, 0); HabitStore.save(this)
                CalendarHelper.delete(this, e.eventId)
                s.removeLog(e.eventId)
                renderLog()
            }
            remove.textSize = 12f
            remove.minHeight = dp(34)
            remove.minimumHeight = dp(34)
            val snooze = button("Snooze", false) {
                HabitStore.get(this).groupAct(e.group, 1); HabitStore.save(this)
                toast(ReminderMaker.snooze(this, e, 3))
            }
            snooze.textSize = 12f
            snooze.minHeight = dp(34)
            snooze.minimumHeight = dp(34)
            val btns = LinearLayout(this)
            btns.orientation = LinearLayout.VERTICAL
            btns.addView(snooze, LinearLayout.LayoutParams(dp(78), dp(36)))
            btns.addView(remove, LinearLayout.LayoutParams(dp(78), dp(36)).apply { topMargin = dp(4) })
            row.addView(btns)
            makeDraggable(row) {
                HabitStore.get(this).groupAct(e.group, 2); HabitStore.save(this)
                LearnStore.get(this).block(e.group, ReminderLog.label(e))
                LearnStore.save(this)
                CalendarHelper.delete(this, e.eventId)
                s.removeLog(e.eventId)
                ActivityLog.add(this, "Bin", "Threw away \"${ReminderLog.label(e)}\" - I'll ignore similar ones from ${e.group}")
                toast("Thrown away 🗑️ I'll ignore similar ones from ${e.group}")
                renderLog()
                renderActivity()
                renderLearned()
            }
            val lp = match()
            lp.bottomMargin = dp(6)
            logBox.addView(row, lp)
        }
    }
}
