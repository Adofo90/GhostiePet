package com.ghostie.pet

/**
 * What Ghostie has learned about the user's routines. Pure Kotlin, stored as text on the phone only.
 * It counts things (when you chat, when you study, which focus length you finish, what you do with reminders,
 * when you ignore the ghost, which suggestions you accept) and turns the counts into insights.
 */
class Habits {
    val hourUse = IntArray(24)
    val studyHour = IntArray(24)
    /** focus length -> [finished, stopped early] */
    val focus = LinkedHashMap<Int, IntArray>()
    /** group -> [done, snoozed, never] */
    val groups = LinkedHashMap<String, IntArray>()
    /** hour -> [engaged, ignored] ghost visits */
    val visits = Array(24) { IntArray(2) }
    /** suggestion type -> [accepted, declined] */
    val sugg = LinkedHashMap<String, IntArray>()
    val muted = LinkedHashMap<String, Long>()

    fun touch(hour: Int) { hourUse[hour.coerceIn(0, 23)]++ }
    fun studyStart(hour: Int) { studyHour[hour.coerceIn(0, 23)]++ }
    fun focusResult(length: Int, finished: Boolean) {
        val a = focus.getOrPut(length) { IntArray(2) }
        if (finished) a[0]++ else a[1]++
    }
    fun groupAct(group: String, kind: Int) { groups.getOrPut(group.trim()) { IntArray(3) }[kind.coerceIn(0, 2)]++ }
    fun visit(hour: Int, engaged: Boolean) { visits[hour.coerceIn(0, 23)][if (engaged) 0 else 1]++ }

    /** Remembers a yes/no on a suggestion. Three declines in a row of one type mutes it for a week. */
    fun suggestion(type: String, accepted: Boolean, nowMs: Long) {
        val a = sugg.getOrPut(type) { IntArray(2) }
        if (accepted) { a[0]++; a[1] = 0; muted.remove(type) }
        else {
            a[1]++
            if (a[1] >= 3 && a[1] > a[0]) { muted[type] = nowMs + 7 * 86_400_000L; a[1] = 0 }
        }
    }

    fun isMuted(type: String, nowMs: Long): Boolean = (muted[type] ?: 0L) > nowMs

    fun unmuteAll() { muted.clear(); sugg.values.forEach { it[1] = 0 } }

    /** The hour you most often start studying (needs a clear pattern), or null. */
    fun usualStudyHour(): Int? {
        val total = studyHour.sum()
        if (total < 4) return null
        var best = -1; var bestN = 0
        for (h in 0..23) {
            val n = studyHour[h] + studyHour[(h + 23) % 24] + studyHour[(h + 1) % 24]
            if (n > bestN) { bestN = n; best = h }
        }
        // the peak hour itself must matter, and the window must hold a clear share of all sessions
        return if (best >= 0 && studyHour[best] >= 2 && bestN * 100 / total >= 50) best else null
    }

    /** The focus length you finish most reliably (at least two tries), or null. */
    fun bestFocus(): Int? {
        val ok = focus.filter { it.value[0] + it.value[1] >= 2 }
        if (ok.isEmpty()) return null
        return ok.maxWithOrNull(compareBy<Map.Entry<Int, IntArray>>({ it.value[0].toDouble() / (it.value[0] + it.value[1]) }, { it.value[0] }, { it.key }))?.key
    }

    /** Hours when the ghost visited at least five times and you never engaged. */
    fun quietCandidates(): List<Int> = (0..23).filter { visits[it][1] >= 5 && visits[it][0] == 0 }

    fun activeHours(): List<Int> = (0..23).filter { hourUse[it] > 0 }.sortedByDescending { hourUse[it] }.take(3).sorted()

    fun hourText(h: Int): String {
        val x = ((h % 12) + 11) % 12 + 1
        return "$x ${if (h < 12) "am" else "pm"}"
    }

    fun rangeText(hours: List<Int>): String {
        if (hours.isEmpty()) return ""
        val s = hours.sorted()
        val parts = mutableListOf<String>()
        var start = s[0]; var prev = s[0]
        for (h in s.drop(1)) {
            if (h == prev + 1) { prev = h; continue }
            parts.add(if (start == prev) hourText(start) else "${hourText(start)}-${hourText(prev + 1)}")
            start = h; prev = h
        }
        parts.add(if (start == prev) hourText(start) else "${hourText(start)}-${hourText(prev + 1)}")
        return parts.joinToString(", ")
    }

    /** Plain-language things Ghostie has noticed. */
    fun insights(): List<String> {
        val out = mutableListOf<String>()
        usualStudyHour()?.let { out.add("You usually start studying around ${hourText(it)}.") }
        bestFocus()?.let { out.add("You finish ${it}-minute focus blocks most reliably.") }
        val act = activeHours()
        if (hourUse.sum() >= 15 && act.isNotEmpty()) out.add("You chat with me mostly around ${act.joinToString(", ") { hourText(it) }}.")
        val keen = groups.filter { it.value[0] >= 2 }.entries.sortedByDescending { it.value[0] }.take(2)
        if (keen.isNotEmpty()) out.add("You act on deadlines from " + keen.joinToString(" and ") { "\"${it.key}\"" } + ".")
        val dull = groups.filter { it.value[2] >= 2 }.keys.take(2)
        if (dull.isNotEmpty()) out.add("You mostly bin reminders from " + dull.joinToString(" and ") { "\"$it\"" } + ".")
        val q = quietCandidates()
        if (q.isNotEmpty()) out.add("You rarely answer my visits around ${rangeText(q)}.")
        val liked = sugg.filter { it.value[0] >= 2 }.keys
        if (liked.isNotEmpty()) out.add("You like my suggestions about: ${liked.joinToString(", ")}.")
        if (muted.isNotEmpty()) out.add("I'm staying quiet about: ${muted.keys.joinToString(", ")} (you declined them).")
        return out
    }

    // ---- storage ------------------------------------------------------------------------------

    private fun c(s: String) = s.replace('\t', ' ').replace('\n', ' ')

    fun toText(): String {
        val sb = StringBuilder()
        for (h in 0..23) if (hourUse[h] > 0) sb.append("H\t$h\t${hourUse[h]}\n")
        for (h in 0..23) if (studyHour[h] > 0) sb.append("S\t$h\t${studyHour[h]}\n")
        for ((l, a) in focus) sb.append("F\t$l\t${a[0]}\t${a[1]}\n")
        for ((g, a) in groups) sb.append("G\t${c(g)}\t${a[0]}\t${a[1]}\t${a[2]}\n")
        for (h in 0..23) if (visits[h][0] + visits[h][1] > 0) sb.append("V\t$h\t${visits[h][0]}\t${visits[h][1]}\n")
        for ((k, a) in sugg) sb.append("A\t${c(k)}\t${a[0]}\t${a[1]}\n")
        for ((k, u) in muted) sb.append("M\t${c(k)}\t$u\n")
        return sb.toString()
    }

    companion object {
        fun fromText(raw: String): Habits {
            val h = Habits()
            for (line in raw.lines()) {
                val p = line.split('\t')
                try {
                    when (p[0]) {
                        "H" -> h.hourUse[p[1].toInt()] = p[2].toInt()
                        "S" -> h.studyHour[p[1].toInt()] = p[2].toInt()
                        "F" -> h.focus[p[1].toInt()] = intArrayOf(p[2].toInt(), p[3].toInt())
                        "G" -> h.groups[p[1]] = intArrayOf(p[2].toInt(), p[3].toInt(), p[4].toInt())
                        "V" -> { h.visits[p[1].toInt()][0] = p[2].toInt(); h.visits[p[1].toInt()][1] = p[3].toInt() }
                        "A" -> h.sugg[p[1]] = intArrayOf(p[2].toInt(), p[3].toInt())
                        "M" -> h.muted[p[1]] = p[2].toLong()
                    }
                } catch (e: Exception) { }
            }
            return h
        }
    }
}

/** Keeps one Habits object in memory and saved in settings. */
object HabitStore {
    private var cached: Habits? = null

    @Synchronized
    fun get(ctx: android.content.Context): Habits {
        cached?.let { return it }
        val h = Habits.fromText(SettingsStore(ctx).habitData)
        cached = h
        return h
    }

    @Synchronized
    fun save(ctx: android.content.Context) { cached?.let { SettingsStore(ctx).habitData = it.toText() } }

    @Synchronized
    fun reset(ctx: android.content.Context) { cached = Habits(); SettingsStore(ctx).habitData = "" }
}
