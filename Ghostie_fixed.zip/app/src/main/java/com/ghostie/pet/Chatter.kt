package com.ghostie.pet

import java.time.DayOfWeek
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.random.Random

/**
 * Offline small talk for the ghost. Pure Kotlin: no Android classes, no internet.
 * Whatever the ghost says on its own (a question, a deadline nudge) becomes the current topic, so the
 * user's next message is understood as an answer to it, and quick-reply chips are offered.
 */
class Chatter(var userName: String = "", private val rnd: Random = Random.Default, private val learner: Learner? = null) {
    data class Line(val text: String, val chips: List<String> = emptyList())

    /** What the ghost last asked about ("" = nothing pending). */
    var topic = ""
        private set
    private var topicData = ""

    /** Suggested quick replies for the current topic. */
    var chips: List<String> = emptyList()
        private set

    private val recent = ArrayDeque<String>()
    private var turns = 0

    private val I = RegexOption.IGNORE_CASE
    private fun has(l: String, pattern: String) = Regex(pattern, I).containsMatchIn(l)

    private fun pick(vararg options: String): String = pickFrom(options.toList())

    private fun pickFrom(options: List<String>): String {
        val fresh = options.filter { it !in recent }
        val choice = (if (fresh.isNotEmpty()) fresh else options).random(rnd)
        recent.addLast(choice)
        while (recent.size > 10) recent.removeFirst()
        return choice
    }

    private fun nm(): String = if (userName.isNotBlank()) " $userName" else ""

    private fun part(now: LocalDateTime): String = when (now.hour) {
        in 5..11 -> "morning"
        in 12..16 -> "afternoon"
        in 17..21 -> "evening"
        else -> "night"
    }

    private fun ask(topic: String, text: String, chips: List<String>, data: String = ""): Line {
        this.topic = topic
        this.topicData = data
        this.chips = chips
        return Line(text, chips)
    }

    /** Lets the app attach a topic to its own messages (deadline nudges, water reminders). */
    fun prompt(topic: String, text: String, chips: List<String>): Line = ask(topic, text, chips)

    // ---- content pools --------------------------------------------------------------------

    private val jokes = listOf(
        "Why don't ghosts lie? Because you can see right through them 👻",
        "What's a ghost's favourite pasta? Boo-ghetti 🍝",
        "Why did the ghost go to the party? For the boos 🎉",
        "What do you call a ghost with no sense of direction? Lost soul... of the party 😄",
        "Why was the computer cold? It left its Windows open 🥶",
        "I told my WiFi it's special. Now it thinks it's the one 📶",
        "Why did the student eat his homework? The teacher said it was a piece of cake 🍰",
        "What do ghosts put on their salad? Boo-berry dressing 🥗",
        "Why are ghosts bad liars? Too transparent 👻",
        "What's a ghost's favourite ride? The roller-ghoster 🎢",
        "Why did the math book look sad? Too many problems 📘",
        "How do ghosts stay fit? They do boo-t camp 💪",
        "What did the ghost say to the nervous kid? Don't worry, I'm just here for the boos-t 💜",
        "Why did the scarecrow win an award? Outstanding in his field 🌾"
    )
    private val facts = listOf(
        "Fun fact: honey never spoils. Edible honey was found in ancient tombs 🍯",
        "Fun fact: octopuses have three hearts 🐙",
        "Fun fact: a day on Venus is longer than its year 🪐",
        "Fun fact: bananas are berries, but strawberries aren't 🍌",
        "Fun fact: your brain uses about 20% of your body's energy 🧠",
        "Fun fact: sharks are older than trees 🦈",
        "Fun fact: a group of flamingos is called a flamboyance 🦩",
        "Fun fact: wombat poop is cube shaped 🟫",
        "Fun fact: lightning is about five times hotter than the surface of the sun ⚡",
        "Fun fact: there are more stars in the universe than grains of sand on Earth ✨",
        "Fun fact: your bones are about five times stronger than steel of the same weight 🦴",
        "Fun fact: the Eiffel Tower grows a few centimetres taller in summer 🗼",
        "Fun fact: cows have best friends and get stressed when separated 🐄",
        "Fun fact: the first computer bug was a real moth stuck in a machine 🦋"
    )
    private val wyr = listOf(
        "Would you rather: always be 10 minutes early, or always 10 minutes late? ⏰" to listOf("Early", "Late"),
        "Would you rather: never have to study again, or never have to sleep again? 😴" to listOf("No studying", "No sleeping"),
        "Would you rather: have a pet dragon, or a pet unicorn? 🐉" to listOf("Dragon", "Unicorn"),
        "Would you rather: be able to fly, or be invisible? 🦸" to listOf("Fly", "Invisible"),
        "Would you rather: only eat pizza forever, or only eat biryani forever? 🍕" to listOf("Pizza", "Biryani"),
        "Would you rather: have extra holidays, or extra pocket money? 🏖️" to listOf("Holidays", "Pocket money")
    )
    private val riddles = listOf(
        Triple("I have keys but no locks, space but no room. What am I?", "keyboard", "A keyboard ⌨️"),
        Triple("What gets wetter the more it dries?", "towel", "A towel 🧺"),
        Triple("I speak without a mouth and hear without ears. What am I?", "echo", "An echo 🏔️"),
        Triple("The more you take, the more you leave behind. What am I?", "footsteps|steps|footstep", "Footsteps 👣"),
        Triple("What has hands but can't clap?", "clock|watch", "A clock ⏰"),
        Triple("What can travel the world while staying in a corner?", "stamp", "A stamp 📮"),
        Triple("What has a head and a tail but no body?", "coin", "A coin 🪙")
    )
    private val motivation = listOf(
        "Small steps still move you forward 👣",
        "You don't have to be perfect, just a little better than yesterday 💜",
        "Start before you feel ready. Ten minutes is enough to begin 🚀",
        "Hard things feel hard because they're worth it 💪",
        "Tired is not the same as done. Rest, then continue 🌙",
        "Progress, not perfection 📈",
        "One page, one problem, one task. That's all you need right now 📚",
        "Future you will be so glad you started today ✨",
        "You've survived every bad day so far. Good record 👻"
    )
    private val studyTips = listOf(
        "Study tip: 25 minutes focus, 5 minutes break. Say \"timer 25 minutes\" 📚",
        "Study tip: explain the topic out loud like you're teaching a friend. Gaps show up fast 🗣️",
        "Study tip: do the hardest subject first, while your brain is fresh 🧠",
        "Study tip: put your phone face down, or in another room 📵",
        "Study tip: past papers beat re-reading. Try questions, not just notes ✍️",
        "Study tip: sleep is part of studying. Memory gets saved overnight 😴",
        "Study tip: write the deadline on your list the moment you hear it 📌"
    )
    private val compliments = listOf(
        "You show up even on tired days. That counts for a lot 💜",
        "You're doing better than you think\$n 👻",
        "Your future self is lucky to have you ✨",
        "You're kinder to your little ghost than you need to be 🥹",
        "Honestly? You've got good taste in ghosts 😄"
    )
    private val morningLines = listOf(
        "Morning\$n! Did you eat something? 🍳", "Good morning\$n ☀️ Water first?", "Morning! Ready for today?",
        "Rise and shine\$n ✨ What's the plan today?", "Morning\$n! Stretch your arms up, it helps 🙆",
        "New day, fresh start 🌅 Anything due today?"
    )
    private val afternoonLines = listOf(
        "Afternoon slump? Stretch for a sec 🙆", "Hey\$n, how's the day going?", "Psst... sit up straight 😄",
        "Halfway through the day\$n. Proud of you 💜", "Quick break? Even two minutes helps ☕",
        "Still going? Don't forget to blink 👀"
    )
    private val eveningLines = listOf(
        "Evening\$n! Anything fun planned?", "You've been working hard. Short break? 🌆", "Day's almost done\$n. What went well today?",
        "Golden hour outside. Peek at the sky for a minute? 🌇", "Evening check-in 👻 Everything okay?"
    )
    private val nightLines = listOf(
        "It's getting late\$n... sleep soon? 🌙", "Night owl mode? Don't forget to rest 😴", "Screens off soon? Your eyes will thank you",
        "Stars are out ✨ Wrap up the last task and rest?", "Late-night study? Set an alarm for the morning so you can sleep easy ⏰"
    )
    private val weekdayLines = mapOf(
        DayOfWeek.MONDAY to listOf("Monday! Pick one tiny goal for the week 🎯", "New week\$n. You've got this 💪"),
        DayOfWeek.WEDNESDAY to listOf("Midweek already. Anything pending to submit? 📌", "Wednesday: over the hump 🐫"),
        DayOfWeek.FRIDAY to listOf("Friday! Finish strong, then rest 🎉", "Almost the weekend\$n! Any submissions left? 📚"),
        DayOfWeek.SATURDAY to listOf("Saturday! Do something just for fun today 🎈", "Weekend mode. Rest counts as productive 😴"),
        DayOfWeek.SUNDAY to listOf("Sunday reset: tidy the desk, check next week's deadlines 🗂️", "Slow Sunday\$n. Plan the week or just relax? 💜")
    )

    private fun yesNo() = listOf("Yes", "Not yet")

    /** An unprompted line for the pet to say when it visits. It also becomes the current topic. */
    fun idle(now: LocalDateTime = LocalDateTime.now()): Line {
        val n = nm()
        val p = part(now)
        if (rnd.nextInt(4) == 0) {
            topic = ""; chips = emptyList()
            val pool = when (p) { "morning" -> morningLines; "afternoon" -> afternoonLines; "evening" -> eveningLines; else -> nightLines }
            return Line(pickFrom(pool).replace("\$n", n))
        }
        val cat = pickCategory()
        return when (cat) {
            "time" -> when (p) {
                "morning" -> ask("meal", pick("Did you have breakfast$n? 🍳", "Breakfast done? Brain needs fuel 🥣"), yesNo(), "breakfast")
                "afternoon" -> ask("meal", pick("Have you had lunch$n? 🍛", "Lunch time check: eaten yet?"), yesNo(), "lunch")
                "evening" -> ask("plans", pick("Any plans for the evening$n? 🌆", "What are you up to tonight?"), listOf("Yes", "Nothing much"))
                else -> ask("sleep", pick("Sleeping soon$n? 🌙", "It's late. Going to bed soon?"), listOf("Yes", "Not yet"))
            }
            "water" -> ask("water", pick("Water check 💧 Had some recently?", "Sip time$n 💧 Done?"), listOf("Just did", "Not yet"))
            "posture" -> ask("posture", pick("Posture check! Sitting up straight? 🦴", "Shoulders down, back straight. Done?"), listOf("Yes", "Fixing it"))
            "eyes" -> ask("eyes", "Eye break! Look at something far away for 20 seconds 👀 Did it?", yesNo())
            "break" -> ask("break", pick("Been at it a while$n. Take a 5 minute break? ☕", "Short break time? 🧘"), listOf("Yes", "Later"))
            "mood" -> ask("mood", pick("How's your day going$n?", "Mood check: how are you feeling right now?"), listOf("Great", "Okay", "Tired"))
            "wyr" -> { val w = wyr.random(rnd); ask("wyr", w.first, w.second) }
            "riddle" -> { val q = riddles.random(rnd); ask("riddle", "Riddle time: ${q.first}", listOf("Give up"), q.second + "§" + q.third) }
            "fact" -> Line(pickFrom(facts))
            "joke" -> Line(pickFrom(jokes))
            "motivation" -> Line(pickFrom(motivation))
            "tip" -> Line(pickFrom(studyTips))
            "compliment" -> Line(pickFrom(compliments).replace("\$n", n))
            else -> weekdayLines[now.dayOfWeek]?.let { Line(pickFrom(it).replace("\$n", n)) } ?: Line(pickFrom(morningLines))
        }.let { line ->
            if (line.chips.isEmpty()) { topic = ""; chips = emptyList() }
            lastCategory = cat
            line.copy(text = line.text.replace("\$n", n))
        }
    }

    // ---- learning which kinds of messages the user likes ---------------------------------------

    private var lastCategory = ""
    private val baseWeights = listOf(
        "time" to 30.0, "water" to 12.0, "posture" to 8.0, "eyes" to 6.0, "break" to 6.0, "mood" to 4.0, "wyr" to 6.0,
        "riddle" to 5.0, "fact" to 5.0, "joke" to 4.0, "motivation" to 4.0, "tip" to 3.0, "compliment" to 3.0, "weekday" to 4.0
    )

    /** Picks what to talk about: base odds, nudged by what the user has engaged with or ignored before. */
    fun pickCategory(): String {
        val ws = baseWeights.map { (c, w) -> c to w * (learner?.topicWeight(c) ?: 1.0) }
        var x = rnd.nextDouble() * ws.sumOf { it.second }
        for ((c, w) in ws) { x -= w; if (x <= 0) return c }
        return ws.last().first
    }

    private fun like(category: String, delta: Double) {
        learner?.bumpTopic(category, delta)
    }

    /** Call when the ghost left without the user replying to its question. */
    fun unanswered() {
        if (topic.isNotEmpty() && lastCategory.isNotEmpty()) like(lastCategory, -0.25)
        topic = ""
        chips = emptyList()
    }

    fun idleLine(now: LocalDateTime = LocalDateTime.now()): String = idle(now).text

    // ---- follow-ups to something the ghost said ------------------------------------------

    private val yesRe = Regex("^(y|yes|yeah|yea|yep|yup|ya|yaa|sure|ok|okay|haan|han|ha|done|did|had|just did|i did|i have|already|of course|definitely|great|fixing it)\\b", I)
    private val noRe = Regex("^(n|no|nope|nah|na|not yet|not really|nahi|nai|later|didn'?t|haven'?t|not now|skip|nothing|nothing much)\\b", I)

    private fun followUp(pending: String, data: String, l: String, t: String): String? {
        val n = nm()
        val yes = yesRe.containsMatchIn(l)
        val no = noRe.containsMatchIn(l)
        return when (pending) {
            "meal" -> when {
                yes -> pick("Nice! Fuel in, brain on 🍛", "Good. Proud of you 💜", "Yay, a fed human is a happy human 😄")
                no -> pick("Go grab something first, I'll wait 🍛", "Skipping meals makes everything harder. Eat, then come back 👻")
                else -> pick("Ooh, that sounds tasty 😋", "Good choice$n! Hope it was yummy", "Mmm, now I'm curious how it tasted")
            }
            "water" -> if (no) pick("Sip now? I'll wait 💧", "Go grab a glass, quick! 💧") else pick("Great, a hydrated human 💧", "Yay! Keep it up")
            "mood" -> when {
                has(l, "\\b(good|great|fine|well|awesome|happy|amazing|nice|best|better|mast|badhiya|accha)\\b") ->
                    ask("good", pick("Love to hear it! What's been the best bit? 🎉", "Yay$n! What made it good?"), emptyList()).text
                has(l, "\\b(bad|tired|sad|meh|stressed|rough|awful|worse|terrible|not good|exhausted|low|down|thak)\\b") ->
                    ask("vent", pick("Aw, sorry$n. Want to tell me what's wrong? 💜", "That sounds rough. I'm listening 👻"), emptyList()).text
                else -> pick("Okay okay. Anything exciting later?", "Fair enough. Want a joke to lift things up? Say \"joke\" 😄")
            }
            "good" -> pick("That's lovely$n 💜", "Great! Keep that energy 🎉", "Nice! You deserve it")
            "vent" -> pick("That sounds like a lot. Thanks for telling me 💜 A short walk or some water might help.", "I hear you$n. One small thing at a time, okay?", "Thank you for sharing that. I'm here whenever you want to talk 👻")
            "plans" -> if (no) pick("A cosy night then 🛋️", "Nothing is also a fine plan 💜") else pick("Sounds nice! Have fun$n 🎉", "Ooh, enjoy! Tell me how it went 👻")
            "break" -> if (yes) pick("Do it! Say \"timer 5 minutes\" and I'll watch the clock ⏱️", "Good call. Stretch, sip water, come back fresh 💧") else pick("Okay, but at least roll your shoulders 😄", "Alright. I'll nudge you again later")
            "sleep" -> if (yes) pick("Good call. Sleep well$n 🌙", "Sweet dreams! Say \"alarm 7 am\" if you want one set ⏰") else pick("Just 10 more minutes? Say \"alarm 7 am\" and I'll set tomorrow's alarm ⏰", "Okay, but don't stay up too long 😴")
            "posture" -> if (no) pick("Sit up for me 😄 Feet flat, shoulders back", "Fixing it counts 💪") else pick("Spine approves 🦴", "Nice! Keep it up")
            "eyes" -> if (no) pick("Look at something far away for 20 seconds. Do it now 👀", "Your eyes will thank you. Quick one!") else pick("Great, your eyes are happy 👀", "Nice! Do it every 20 minutes")
            "deadline" -> when {
                yes || has(l, "\\bdone|submitted|finished|completed\\b") -> pick("Amazing$n! One less thing 🎉", "Proud of you! 💜", "Done and dusted. Go celebrate 👻")
                no || has(l, "\\blater|remind\\b") -> pick("Okay. I'll keep it on your list. Don't leave it too late 📌", "Alright, but please don't forget 😅")
                else -> pick("Noted 👻 Want a focus timer? Say \"timer 25 minutes\"", "Okay! Need me to set an alarm? Say \"alarm 6 pm\" ⏰")
            }
            "wyr" -> pick("Interesting pick$n! Why that one?", "Hmm, I'd have chosen the same 😄", "Bold choice 👻", "Ooh, a thoughtful answer")
            "riddle" -> {
                val answers = data.substringBefore("§")
                val reveal = data.substringAfter("§")
                when {
                    Regex("\\b($answers)\\b", I).containsMatchIn(l) -> pick("Correct!! You're good at this 🎉", "Yes! Clever$n 💜")
                    has(l, "give up|idk|don'?t know|tell me|no idea|dunno|answer") -> "It's $reveal 😄"
                    else -> ask("riddle", pick("Not quite... try again, or say \"give up\" 🤔", "Close, maybe? Another guess or give up?"), listOf("Give up"), data).text
                }
            }
            else -> null
        }?.replace("\$n", n)
    }

    // ---- replies --------------------------------------------------------------------------

    fun reply(raw: String, now: LocalDateTime = LocalDateTime.now()): String {
        turns++
        val pending = topic
        val data = topicData
        topic = ""
        topicData = ""
        chips = emptyList()
        val t = raw.trim()
        val l = t.lowercase()
        val n = nm()

        // Remember the user's name.
        Regex("\\b(?:my name is|call me|i am called|name's)\\s+([a-z][a-z'-]{1,20})\\b", I).find(t)?.let { m ->
            userName = m.groupValues[1].replaceFirstChar { it.uppercase() }
            return pick("Nice to meet you, $userName! I'll remember that 💜", "$userName... I like it! Hi $userName 👻")
        }

        // Safety first.
        if (has(l, "\\b(kill myself|suicide|end my life|want to die|self.?harm|hurt myself)\\b")) {
            return "I'm really glad you told me. I'm only a small ghost, but you matter. Please talk to someone you trust right now. " +
                "In India you can call Tele-MANAS at 14416 any time. If you're in danger, call your local emergency number. 💜"
        }

        if (pending.isNotEmpty() && lastCategory.isNotEmpty()) like(lastCategory, 0.3)
        if (pending.isNotEmpty()) followUp(pending, data, l, t)?.let { return it }

        if (has(l, "^(hi+|hello+|hey+|heyy+|yo|sup|hola|hii+|hiya|howdy|namaste|namaskar|hellooo+)\\b")) {
            return when (part(now)) {
                "morning" -> pick("Good morning$n! ☀️", "Hey$n! Up early? 👻", "Morning! How did you sleep?")
                "afternoon" -> pick("Hey$n! How's your day?", "Hi$n 💜 Surviving the afternoon?", "Hello! What are you up to?")
                "evening" -> pick("Hey$n! Evening already 🌆", "Hi$n! How was your day?", "Hello! Winding down?")
                else -> pick("Hey$n... still up? 🌙", "Hi$n! Late night, huh?", "Hello, night owl 🦉")
            }
        }
        if (has(l, "\\bgood ?night\\b|\\bgn\\b|\\bnight night\\b|\\bshubh ratri\\b")) return pick("Good night$n 🌙 Sleep well!", "Sweet dreams$n 💤", "Night! I'll keep watch 👻")
        if (has(l, "\\bgood ?morning\\b|\\bgm\\b|\\bsuprabhat\\b")) return pick("Good morning$n! ☀️ Go get 'em", "Morning$n! Water first? 💧")
        if (has(l, "\\bgood ?afternoon\\b|\\bgood ?evening\\b")) return pick("Hey$n! 💜", "Hello$n! Hope it's going well")
        if (has(l, "\\b(i'?m back|im back|i am back|back again)\\b")) return pick("Welcome back$n! 👻", "Yay, you're back! Missed you 💜")
        if (has(l, "\\b(miss you|missed you)\\b")) return pick("Aww, I missed you too$n 🥹", "I was floating around waiting 👻")

        if (has(l, "how are you|how r u|\\bhru\\b|how('?s| is) it going|what'?s up|\\bwassup\\b|kya haal|kaise ho|kaisa hai|sab theek")) {
            return pick("Floating along nicely 👻 You?", "Pretty good! Just vibing on your screen. How about you?", "Can't complain. Ghosts have it easy 😄 You okay?", "Mast, as always! Tum batao 💜")
        }
        if (has(l, "what are you doing|what r u doing|kya kar rahe|wyd")) return pick("Floating. Haunting your screen. Classic 👻", "Watching your deadlines like a tiny guard 🕵️", "Practising my boo. Want to hear? ...Boo! 😄")
        if (has(l, "who are you|what are you|your name|who made you|what'?s ur name|tum kaun")) {
            return pick("I'm Ghostie, a tiny ghost who lives on your screen 👻", "Ghostie! Your little floating study buddy 💜")
        }
        if (has(l, "are you (an? )?(ai|bot|robot|real|human|alive)")) {
            return "I'm a small app on your phone, a ghost-shaped one 👻 No big AI brain unless you add an OpenAI key, but I try my best!"
        }
        if (has(l, "what can you do|what do you do|your features|kya kar sakte")) return "Lots! I remind you of deadlines, sort documents, call people, set alarms and timers, add events, and chat. Say \"help\" for the full list 💜"
        if (has(l, "\\b(thanks|thank you|thx|ty|tysm|shukriya|dhanyavaad|dhanyawad)\\b")) return pick("Anytime$n 💜", "You're welcome!", "Happy to help 👻", "No problem!")
        if (has(l, "\\b(sorry|my bad|oops)\\b")) return pick("No worries$n 💜", "All good!", "Don't even think about it 👻")
        if (has(l, "\\b(congrat|well done|good job|nice work|great job)\\b")) return pick("Thank you! 🥳", "Aww, teamwork! 💜", "Yay! Let's celebrate 🎉")
        if (has(l, "\\b(bye|goodbye|see you|see ya|cya|gtg|ttyl|later|alvida)\\b")) return pick("Bye$n! I'll be around 👻", "See you soon!", "Take care! 💜")

        if (has(l, "\\b(joke|funny|make me laugh|chutkula)\\b")) { like("joke", 0.4); return pickFrom(jokes) }
        if (has(l, "fun fact|tell me something|random fact|did you know|trivia")) { like("fact", 0.4); return pickFrom(facts) }
        if (has(l, "would you rather|play a game|play something|let'?s play|wyr")) { val w = wyr.random(rnd); return ask("wyr", w.first, w.second).text }
        if (has(l, "\\b(riddle|puzzle|brain ?teaser)\\b")) { like("riddle", 0.4); val q = riddles.random(rnd); return ask("riddle", "Riddle: ${q.first}", listOf("Give up"), q.second + "§" + q.third).text }
        if (has(l, "\\b(motivat|inspire|inspiration|cheer me|encourage|quote)")) return pickFrom(motivation)
        if (has(l, "\\b(study tips?|tips? (for|on) stud|how to study|how do i study|advice|tips?)\\b")) return pickFrom(studyTips)
        if (has(l, "compliment|say something nice|make me smile")) return pickFrom(compliments).replace("\$n", n)
        if (has(l, "breath|calm (me )?down|relax|meditat")) return "Let's breathe together: in through the nose for 4... hold for 4... out slowly for 6. Repeat 3 times 🌬️ Want a timer? Say \"timer 2 minutes\"."
        if (has(l, "^(lol|lmao|haha+|hehe+|rofl|😂|🤣)")) return pick("😄", "Hehe 😄", "Glad that landed!", "Ha! 👻")

        if (has(l, "what('?s| is) the time|what time|current time|kitne baje")) {
            return "It's " + now.format(DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH)) + " ⏰"
        }
        if (has(l, "what('?s| is) (the )?(date|day)|which day|today'?s date")) {
            return "It's " + now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.ENGLISH)) +
                (if (now.dayOfWeek == DayOfWeek.FRIDAY) " - almost the weekend! 🎉" else "")
        }
        if (has(l, "weather|rain|temperature|\\bhot\\b outside|baarish|garmi")) return pick("I can't see outside from in here 🌤️ Check your weather app. If it's rainy, stay dry!", "Rain makes the best study weather ☔ and chai weather")
        if (has(l, "favou?rite colou?r")) return "Lavender, obviously 💜"
        if (has(l, "favou?rite (food|dish)")) return pick("Boo-berries! 🫐", "Anything I can't actually eat, so: everything 🍕")
        if (has(l, "music|song|playlist|\\bsing\\b|gaana")) return pick("I'm a soft lo-fi ghost 🎧", "Something chill. You?", "I'd sing but I only know 'Boo' 🎤")
        if (has(l, "\\b(coffee|tea|chai)\\b")) return pick("Chai is basically a study aid ☕", "Coffee for deadlines, chai for everything else 😄", "Careful with too much caffeine, sip water too 💧")
        if (has(l, "\\b(gym|workout|exercise|running|yoga|walk(ing)?)\\b")) return pick("Moving your body helps your brain too 💪", "Nice! Even a 10 minute walk counts 🚶", "Love that. Stretch after, and drink water 💧")
        if (has(l, "\\b(movie|series|netflix|anime|show|web ?series)\\b")) return pick("Ooh, what are you watching? 🍿", "Movie night? Don't forget the snacks 😄", "Tell me the plot, no spoilers for the ending 👀")
        if (has(l, "\\b(game|gaming|bgmi|valorant|minecraft|pubg|cod|fifa)\\b")) return pick("Gaming break? Just set a timer so it doesn't eat the evening 🎮", "Nice! What are you playing?", "GG! Don't forget to drink water between rounds 💧")
        if (has(l, "\\b(cricket|football|match|ipl|sports?)\\b")) return pick("Who's winning? 🏏", "Sports talk! Which team are you cheering for?", "I'd play but I keep passing through the ball 👻")
        if (has(l, "\\b(friend|friends|bestie|buddy)\\b")) return pick("Good friends make everything easier 💜", "Tell me about them! 👻", "Friends are the best study breaks (and distractions) 😄")
        if (has(l, "\\b(college|class|lecture|teacher|professor|prof|lab|campus)\\b")) return pick("How's college treating you$n? 🎓", "Any lectures worth remembering today?", "Say \"watch group <name>\" and I'll keep an eye on your class group 👀")
        if (has(l, "\\b(wifi|internet|network|slow|lag)\\b")) return pick("Ugh, slow internet is the worst 📶 Try toggling airplane mode for 5 seconds.", "Have you tried turning it off and on again? 😄")
        if (has(l, "\\b(battery|charge|charging)\\b")) return pick("Low battery? Charge it before the deadline night 🔋", "Keep Ghostie on Unrestricted battery so I can watch your groups 💜")
        if (has(l, "\\b(birthday|bday)\\b")) return pick("Ooh, birthday! 🎂 Say \"add event birthday on 19 October\" and I'll put it in your calendar.", "Happy birthday in advance! 🎉")
        if (has(l, "\\b(holiday|vacation|trip|travel|weekend)\\b")) return pick("Ooh, where to? 🏖️", "A break sounds lovely. Plan it, then I'll remind you 💜", "Pack snacks and a charger 😄")
        if (has(l, "\\b(result|results|marks|grade|cgpa|sgpa|percentage)\\b")) return pick("Whatever the number is, it's not the whole you 💜", "Fingers crossed! How are you feeling about it?")
        if (has(l, "\\b(dog|cat|puppy|kitten|pet)\\b")) return pick("Aww! Pets are the best 🐶 I'm a ghost pet myself", "Cat or dog person? Both are good 💜")
        if (has(l, "\\b(scary|boo|haunt|spooky|horror)\\b")) return pick("Boo! Did I scare you? 👻", "I'm the friendly kind of scary 😄", "Spooky season is any season for me 🎃")
        if (has(l, "\\b(dance|dancing)\\b")) return "💃 I'd dance but I mostly just float in rhythm 👻"
        if (has(l, "\\b(do you|can you) (sleep|eat|dream)\\b")) return pick("I mostly nap between visits 😴", "I eat deadlines for breakfast 📌")
        if (has(l, "where do you live|where are you")) return "Right here on your screen, near the edge 👻"
        if (has(l, "how old are you|your age")) return "Old enough to haunt, young enough to bounce 😄"
        if (has(l, "\\b(bhook|bhookh|khana khaya)\\b")) return pick("Khana khao pehle! 🍛", "Kuch khaya? Brain ko fuel chahiye 😄")
        if (has(l, "\\b(neend|so ja|sone)\\b")) return pick("Thoda so jao 😴 Kal fresh feel karoge", "Alarm laga du? Bolo \"alarm 7 am\" ⏰")
        if (has(l, "\\b(padhai|padh raha|padh rahi)\\b")) return pick("Shabash! Focus mode on 📚", "Break bhi lena beech mein 💜")

        if (has(l, "love you|luv u|you'?re (cute|sweet|nice|the best|awesome|great)|good (ghost|boy|girl|bot)|best ghost")) {
            return pick("Aww 🥹 you're sweet$n", "That made my day 💜", "You're pretty great too$n!")
        }
        if (has(l, "\\b(stupid|useless|dumb|hate you|shut up|idiot)\\b")) {
            return pick("Ouch 😅 I'll try to do better. Say \"help\" to see what I can do.", "Fair, I'm a small ghost. Tell me what went wrong?")
        }

        if (has(l, "\\b(suicidal|depress(ed|ing)|hopeless|worthless|lonely|alone|so sad|feel sad|bad day|cried|crying)\\b")) {
            return pick(
                "I'm sorry$n, that sounds heavy. I'm here. Want to tell me what happened? 💜",
                "That sounds really hard. You don't have to handle it alone. Is there someone you could talk to today?",
                "Thanks for telling me. I'm listening. What's been the hardest part?"
            )
        }
        if (has(l, "\\b(stress(ed)?|anxious|anxiety|overwhelm(ed)?|panic|worried|nervous|pressure|tension)\\b")) {
            return pick(
                "Take one slow breath with me: in for 4, out for 6. You don't have to do it all at once 💜",
                "That's a lot. Pick the one smallest task and start there. Want a 10 minute timer? Say \"timer 10 minutes\".",
                "It's okay to feel that. Water, a stretch, then one thing at a time 👻"
            )
        }
        if (has(l, "\\b(tired|sleepy|exhausted|drained|no energy|thak)\\b")) {
            return pick("A tiny break might help. Stretch, sip some water 💧", "Rest counts as productive too. Nap for 20 minutes? Say \"timer 20 minutes\".", "You've earned a break 😴")
        }
        if (has(l, "\\b(bored|boring|nothing to do|bore)\\b")) return pick("Bored? Say \"joke\", \"riddle\" or \"fun fact\", or I'll give you a would-you-rather 😄", "Stretch break? Or tell me what you've been wanting to do lately")
        if (has(l, "\\b(hungry|starving|food|eat|lunch|dinner|breakfast|snack)\\b")) {
            return pick("Go eat something! Brain needs fuel 🍛", "What are you craving?", "Hydrate too, not just snacks 💧")
        }
        if (has(l, "\\b(water|thirsty|hydrat)")) return "Water check! A few sips would be lovely 💧"
        if (has(l, "\\b(happy|excited|great|awesome|amazing|good news|yay|celebrate)\\b")) {
            return pick("Yay! Tell me more 🎉", "That's great$n! What happened?", "Love that for you 💜")
        }
        if (has(l, "\\b(exam|test|quiz|study|studying|assignment|homework|submission|deadline|viva)\\b")) {
            return pick(
                "Study mode! Try 25 minutes focus, 5 minutes break. Say \"timer 25 minutes\" and I'll start it 📚",
                "You've got this$n! Want me to watch your class group for deadlines? Say \"watch group <name>\".",
                "One topic at a time. What's the subject? 👻"
            )
        }
        if (has(l, "\\b(break|stretch)\\b")) return "Good idea. Stand up, stretch, then come back when you're ready."

        if (has(l, "^(ok|okay|k|kk|cool|nice|fine|alright|hmm+|oh|ah|yeah|yep|yes|yup|sure|no|nope|nah)[.! ]*$")) {
            return pick("👻", "Mhm!", "Got it 💜", "Okay! Anything else?", "What's on your mind?", "Want a joke, a riddle or a fun fact?")
        }
        if (t.endsWith("?")) {
            return pick("Good question... I'm just a small ghost though. Try asking a friend, or add an OpenAI key in the app and I'll think harder 👻", "Hmm, not sure I know that one 🤔", "Ooh. I'd need a bigger brain for that. What do you think?")
        }

        // Mirror what the user said, so the chat feels like it is listening.
        mirror(t)?.let { return it }

        return if (turns % 4 == 0) pick("Tell me more?", "Interesting$n. Go on 👻")
        else pick("I'm listening 💜", "Hmm, tell me more?", "Go on, I'm all ears (well, I'm a ghost) 👻", "Really? What happened next?", "Oh? 👀")
    }

    private fun flip(s: String): String = s.trim().trimEnd('.', '!', '?', ',', ' ')
        .replace(Regex("\\bmy\\b", I), "your").replace(Regex("\\bme\\b", I), "you").replace(Regex("\\bI'm\\b|\\bI am\\b", I), "you're")
        .replace(Regex("\\bI\\b"), "you")

    private fun mirror(t: String): String? {
        if (t.length > 80) return null
        Regex("^i(?:'m| am)\\s+(.{2,50})$", I).find(t)?.let { return pick("You're ${flip(it.groupValues[1])}, huh? What's that like?", "Oh, ${flip(it.groupValues[1])}? Tell me more 👻") }
        Regex("^i (?:like|love|enjoy)\\s+(.{2,50})$", I).find(t)?.let { return pick("Ooh, ${flip(it.groupValues[1])}! What do you like about it?", "Nice taste! Since when? 💜") }
        Regex("^i (?:want|need)\\s+(.{2,50})$", I).find(t)?.let { return pick("You want ${flip(it.groupValues[1])}? Let's make a tiny plan for it 📝", "Okay! What's the first small step toward ${flip(it.groupValues[1])}?") }
        Regex("^i (?:have|had|got)\\s+(.{2,50})$", I).find(t)?.let { return pick("You have ${flip(it.groupValues[1])}? Tell me more 👻", "Oh? ${flip(it.groupValues[1]).replaceFirstChar { c -> c.uppercase() }}. How's that going?") }
        Regex("^i (?:think|feel|believe)\\s+(.{2,50})$", I).find(t)?.let { return pick("Why do you think ${flip(it.groupValues[1])}?", "Hmm, that's interesting. Go on 💜") }
        return null
    }
}
