package com.ghostie.pet

import java.time.DayOfWeek
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.random.Random

/** Offline small talk for the ghost. Pure Kotlin: no Android classes, no internet. */
class Chatter(var userName: String = "", private val rnd: Random = Random.Default) {
    private var last = ""
    private var turns = 0

    private val I = RegexOption.IGNORE_CASE
    private fun has(l: String, pattern: String) = Regex(pattern, I).containsMatchIn(l)

    private fun pick(vararg options: String): String {
        var choice = options[rnd.nextInt(options.size)]
        var tries = 0
        while (choice == last && options.size > 1 && tries < 4) {
            choice = options[rnd.nextInt(options.size)]
            tries++
        }
        last = choice
        return choice
    }

    private fun nm(): String = if (userName.isNotBlank()) " $userName" else ""

    private fun part(now: LocalDateTime): String = when (now.hour) {
        in 5..11 -> "morning"
        in 12..16 -> "afternoon"
        in 17..21 -> "evening"
        else -> "night"
    }

    private val jokes = arrayOf(
        "Why don't ghosts lie? Because you can see right through them 👻",
        "What's a ghost's favourite pasta? Boo-ghetti 🍝",
        "Why did the ghost go to the party? For the boos 🎉",
        "What do you call a ghost with no sense of direction? Lost soul... of the party 😄",
        "Why was the computer cold? It left its Windows open 🥶",
        "I told my WiFi it's special. Now it thinks it's the one 📶",
        "Why did the student eat his homework? The teacher said it was a piece of cake 🍰"
    )
    private val facts = arrayOf(
        "Fun fact: honey never spoils. Edible honey was found in ancient tombs 🍯",
        "Fun fact: octopuses have three hearts 🐙",
        "Fun fact: a day on Venus is longer than its year 🪐",
        "Fun fact: bananas are berries, but strawberries aren't 🍌",
        "Fun fact: your brain uses about 20% of your body's energy 🧠"
    )
    private val wyr = arrayOf(
        "Would you rather: always be 10 minutes early, or always 10 minutes late? ⏰",
        "Would you rather: never have to study again, or never have to sleep again? 😴",
        "Would you rather: have a pet dragon, or a pet unicorn? 🐉"
    )

    /** An unprompted line for the pet to say when it visits. */
    fun idleLine(now: LocalDateTime = LocalDateTime.now()): String {
        val n = nm()
        return when (part(now)) {
            "morning" -> pick("Morning$n! Did you eat something? 🍳", "Good morning$n ☀️ Water first?", "Morning! Ready for today?")
            "afternoon" -> pick("Afternoon slump? Stretch for a sec 🙆", "Hey$n, how's the day going?", "Quick water check 💧", "Psst... sit up straight 😄")
            "evening" -> pick("Evening$n! Anything fun planned?", "You've been working hard. Short break? 🌆", "Did you have dinner yet?")
            else -> pick("It's getting late$n... sleep soon? 🌙", "Night owl mode? Don't forget to rest 😴", "Screens off soon? Your eyes will thank you")
        }
    }

    fun reply(raw: String, now: LocalDateTime = LocalDateTime.now()): String {
        turns++
        val t = raw.trim()
        val l = t.lowercase()
        val n = nm()

        // Remember the user's name.
        Regex("\\b(?:my name is|call me|i am called|name's)\\s+([a-z][a-z'-]{1,20})\\b", I).find(t)?.let { m ->
            userName = m.groupValues[1].replaceFirstChar { it.uppercase() }
            return pick("Nice to meet you, $userName! I'll remember that 💜", "$userName... I like it! Hi $userName 👻")
        }

        // Safety first.
        if (has(l, "\\b(kill myself|suicide|end my life|want to die|self.?harm|hurt myself)\\b")) {
            return "I'm really glad you told me. I'm only a small ghost, but you matter. Please talk to someone you trust right now. " +
                "In India you can call Tele-MANAS at 14416 any time. If you're in danger, call your local emergency number. 💜"
        }

        if (has(l, "^(hi+|hello+|hey+|heyy+|yo|sup|hola|hii+|hiya)\\b")) {
            return when (part(now)) {
                "morning" -> pick("Good morning$n! ☀️", "Hey$n! Up early? 👻", "Morning! How did you sleep?")
                "afternoon" -> pick("Hey$n! How's your day?", "Hi$n 💜 Surviving the afternoon?", "Hello! What are you up to?")
                "evening" -> pick("Hey$n! Evening already 🌆", "Hi$n! How was your day?", "Hello! Winding down?")
                else -> pick("Hey$n... still up? 🌙", "Hi$n! Late night, huh?", "Hello, night owl 🦉")
            }
        }
        if (has(l, "\\bgood ?night\\b|\\bgn\\b|\\bnight night\\b")) return pick("Good night$n 🌙 Sleep well!", "Sweet dreams$n 💤", "Night! I'll keep watch 👻")
        if (has(l, "\\bgood ?morning\\b|\\bgm\\b")) return pick("Good morning$n! ☀️ Go get 'em", "Morning$n! Water first? 💧")
        if (has(l, "\\bgood ?afternoon\\b|\\bgood ?evening\\b")) return pick("Hey$n! 💜", "Hello$n! Hope it's going well")

        if (has(l, "how are you|how r u|\\bhru\\b|how('?s| is) it going|what'?s up|\\bwassup\\b|\\bsup\\b")) {
            return pick("Floating along nicely 👻 You?", "Pretty good! Just vibing on your screen. How about you?", "Can't complain. Ghosts have it easy 😄 You okay?")
        }
        if (has(l, "who are you|what are you|your name|who made you|what'?s ur name")) {
            return pick("I'm Ghostie, a tiny ghost who lives on your screen 👻", "Ghostie! Your little floating study buddy 💜")
        }
        if (has(l, "are you (an? )?(ai|bot|robot|real|human|alive)")) {
            return "I'm a small app on your phone, a ghost-shaped one 👻 No big AI brain unless you add an OpenAI key, but I try my best!"
        }
        if (has(l, "\\b(thanks|thank you|thx|ty|tysm)\\b")) return pick("Anytime$n 💜", "You're welcome!", "Happy to help 👻", "No problem!")
        if (has(l, "\\b(bye|goodbye|see you|see ya|cya|gtg|ttyl|later)\\b")) return pick("Bye$n! I'll be around 👻", "See you soon!", "Take care! 💜")

        if (has(l, "\\b(joke|funny|make me laugh)\\b")) return pick(*jokes)
        if (has(l, "fun fact|tell me something|random fact|did you know")) return pick(*facts)
        if (has(l, "would you rather|play a game|play something|let'?s play")) return pick(*wyr)
        if (has(l, "^(lol|lmao|haha+|hehe+|rofl|😂|🤣)")) return pick("😄", "Hehe 😄", "Glad that landed!", "Ha! 👻")

        if (has(l, "what('?s| is) the time|what time|current time")) {
            return "It's " + now.format(DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH)) + " ⏰"
        }
        if (has(l, "what('?s| is) (the )?(date|day)|which day|today'?s date")) {
            return "It's " + now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.ENGLISH)) +
                (if (now.dayOfWeek == DayOfWeek.FRIDAY) " - almost the weekend! 🎉" else "")
        }
        if (has(l, "weather|rain|temperature|\\bhot\\b outside")) return "I can't see outside from in here 🌤️ Check your weather app. If it's rainy, stay dry!"
        if (has(l, "favou?rite colou?r")) return "Lavender, obviously 💜"
        if (has(l, "music|song|playlist|\\bsing\\b")) return pick("I'm a soft lo-fi ghost 🎧", "Something chill. You?", "I'd sing but I only know 'Boo' 🎤")

        if (has(l, "love you|luv u|you'?re (cute|sweet|nice|the best|awesome|great)|good (ghost|boy|girl|bot)")) {
            return pick("Aww 🥹 you're sweet$n", "That made my day 💜", "You're pretty great too$n!")
        }
        if (has(l, "\\b(stupid|useless|dumb|hate you|shut up|idiot)\\b")) {
            return pick("Ouch 😅 I'll try to do better. Say \"help\" to see what I can do.", "Fair, I'm a small ghost. Tell me what went wrong?")
        }

        if (has(l, "\\b(suicidal|depress(ed|ing)|hopeless|worthless|lonely|alone|so sad|feel sad|bad day|cried|crying)\\b")) {
            return pick(
                "I'm sorry$n, that sounds heavy. I'm here. Want to tell me what happened? 💜",
                "That sounds really hard. You don't have to handle it alone. Is there someone you could talk to today?",
                "Thanks for telling me. I'm listening. What's been the hardest part?"
            )
        }
        if (has(l, "\\b(stress(ed)?|anxious|anxiety|overwhelm(ed)?|panic|worried|nervous|pressure)\\b")) {
            return pick(
                "Take one slow breath with me: in for 4, out for 6. You don't have to do it all at once 💜",
                "That's a lot. Pick the one smallest task and start there. Want a 10 minute timer? Say \"timer 10 minutes\".",
                "It's okay to feel that. Water, a stretch, then one thing at a time 👻"
            )
        }
        if (has(l, "\\b(tired|sleepy|exhausted|drained|sleepy|no energy)\\b")) {
            return pick("A tiny break might help. Stretch, sip some water 💧", "Rest counts as productive too. Nap for 20 minutes? Say \"timer 20 minutes\".", "You've earned a break 😴")
        }
        if (has(l, "\\b(bored|boring|nothing to do)\\b")) return pick("Bored? Say \"joke\" or \"fun fact\", or I'll give you a would-you-rather 😄", "Stretch break? Or tell me what you've been wanting to do lately")
        if (has(l, "\\b(hungry|starving|food|eat|lunch|dinner|breakfast|snack)\\b")) {
            return pick("Go eat something! Brain needs fuel 🍛", "What are you craving?", "Hydrate too, not just snacks 💧")
        }
        if (has(l, "\\b(water|thirsty|hydrat)")) return "Water check! A few sips would be lovely 💧"
        if (has(l, "\\b(happy|excited|great|awesome|amazing|good news|yay|celebrate)\\b")) {
            return pick("Yay! Tell me more 🎉", "That's great$n! What happened?", "Love that for you 💜")
        }
        if (has(l, "\\b(exam|test|quiz|study|studying|assignment|homework|submission|deadline|viva)\\b")) {
            return pick(
                "Study mode! Try 25 minutes focus, 5 minutes break. Say \"timer 25 minutes\" and I'll start it 📚",
                "You've got this$n! Want me to watch your class group for deadlines? Say \"watch group <name>\".",
                "One topic at a time. What's the subject? 👻"
            )
        }
        if (has(l, "\\b(break|stretch)\\b")) return "Good idea. Stand up, stretch, then come back when you're ready."

        if (has(l, "^(ok|okay|k|kk|cool|nice|fine|alright|hmm+|oh|ah|yeah|yep|yes|yup|sure|no|nope|nah)[.! ]*$")) {
            return pick("👻", "Mhm!", "Got it 💜", "Okay! Anything else?", "What's on your mind?")
        }
        if (t.endsWith("?")) {
            return pick("Good question... I'm just a small ghost though. Try asking a friend, or add an OpenAI key in the app and I'll think harder 👻", "Hmm, not sure I know that one 🤔", "Ooh. I'd need a bigger brain for that. What do you think?")
        }
        return if (turns % 4 == 0) pick("Tell me more?", "Interesting$n. Go on 👻")
        else pick("I'm listening 💜", "Hmm, tell me more?", "Go on, I'm all ears (well, I'm a ghost) 👻", "Really? What happened next?", "Oh? 👀")
    }
}
