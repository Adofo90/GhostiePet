package com.ghostie.pet

import android.app.Notification
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.time.LocalDate
import java.time.LocalDateTime

/**
 * Reads WhatsApp notifications (needs "Notification access"). When a message in a watched group
 * mentions a submission date, adds a calendar reminder for the day before.
 * Only messages that arrive while this is running can be seen - history is not readable.
 */
class GroupWatcherService : NotificationListenerService() {
    private val whatsapp = setOf("com.whatsapp", "com.whatsapp.w4b")

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            handle(sbn)
        } catch (e: Exception) {
            // never crash the listener
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        if (sbn.packageName !in whatsapp) return
        val s = SettingsStore(this)
        if (!s.watchEnabled) return
        val groups = s.watchedGroupList()
        if (groups.isEmpty()) return

        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val extras = n.extras
        val title = (extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)
            ?: extras.getCharSequence(Notification.EXTRA_TITLE))?.toString() ?: return
        val groupName = title.replace(Regex("\\s*\\(\\d+ messages?\\)\\s*$"), "").trim()
        if (groups.none { title.contains(it, ignoreCase = true) }) return

        val texts = mutableListOf<String>()
        @Suppress("DEPRECATION")
        val msgs = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
        if (msgs != null) {
            for (m in msgs) (m as? Bundle)?.getCharSequence("text")?.toString()?.let { texts.add(it) }
        }
        if (texts.isEmpty()) {
            val t = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()
            if (t != null) texts.addAll(t.lines())
        }

        val today = LocalDate.now()
        val now = LocalDateTime.now()
        for (text in texts) {
            if (!s.markSeen((groupName + "|" + text).hashCode())) continue
            val sub = SubmissionParser.parse(text, today) ?: continue
            if (ReminderMaker.isDuplicate(s, text, sub)) continue
            val entry = ReminderMaker.add(this, s, groupName, text, sub, now)
            if (entry != null) {
                Notifier.post(this, "Reminder added", "${entry.title}\nDeadline: ${entry.due}")
            } else {
                Notifier.post(this, "Submission spotted in $groupName", "I need calendar access to add a reminder. Open Ghostie and allow it.\n${sub.summary}")
            }
        }
    }
}
