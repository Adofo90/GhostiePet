package com.ghostie.pet

import android.app.Notification
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.time.LocalDate
import java.time.LocalDateTime

/**
 * Reads WhatsApp notifications (needs "Notification access"). When a message in a watched group
 * mentions a submission or registration date, adds a calendar event with alerts. It also learns which chat
 * each document came from, to help sort files by subject.
 * Only messages that arrive while this is running can be seen - history is not readable.
 */
class GroupWatcherService : NotificationListenerService() {
    private val whatsapp = setOf("com.whatsapp", "com.whatsapp.w4b")

    companion object {
        private var lastIgnored = ""
    }

    override fun onListenerConnected() {
        ActivityLog.add(this, "Notification", "Watcher connected")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            handle(sbn)
        } catch (e: Exception) {
            ActivityLog.add(this, "Notification", "Error: ${e.javaClass.simpleName}")
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        if (sbn.packageName !in whatsapp) { handleMoney(sbn); handleOther(sbn); return }
        val s = SettingsStore(this)
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val extras = n.extras
        val title = (extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)
            ?: extras.getCharSequence(Notification.EXTRA_TITLE))?.toString() ?: return
        val groupName = title.replace(Regex("\\s*\\(\\d+ messages?\\)\\s*$"), "").trim()

        val texts = mutableListOf<String>()
        @Suppress("DEPRECATION")
        val msgs = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
        if (msgs != null) {
            for (m in msgs) (m as? Bundle)?.getCharSequence("text")?.toString()?.let { texts.add(it) }
        }
        if (texts.isEmpty()) {
            val t = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()
            if (t != null) texts.addAll(t.lines())
        }

        // "Ghostie calls me": repeated or urgent messages from people/groups the user picked.
        if (s.callEnabled) {
            val items = mutableListOf<CallAlerts.Msg>()
            if (msgs != null) {
                for (m in msgs) {
                    val b = m as? Bundle ?: continue
                    val tx = b.getCharSequence("text")?.toString() ?: continue
                    items.add(CallAlerts.Msg(b.getCharSequence("sender")?.toString() ?: "", tx, b.getLong("time")))
                }
            } else {
                for (tx in texts) items.add(CallAlerts.Msg("", tx, 0L))
            }
            CallAlerts.onMessages(this, s, groupName, items)
        }

        // Learn which chat each document came from, and sort new files soon after they land.
        var sawDocument = false
        for (text in texts) {
            val name = DocNotice.fileName(text) ?: continue
            s.rememberDoc(name, groupName)
            sawDocument = true
        }
        if (sawDocument && s.autoOrganize) AutoOrganizer.request(this)

        if (!s.watchEnabled) return
        val groups = s.watchedGroupList()
        if (groups.isEmpty()) return
        if (groups.none { title.contains(it, ignoreCase = true) }) {
            if (lastIgnored != title) {
                lastIgnored = title
                ActivityLog.add(this, "Notification", "Heard \"$groupName\" - not in your watch list")
            }
            return
        }
        ActivityLog.add(this, "Notification", "Read ${texts.size} message(s) from \"$groupName\"")
        if (s.learnGroups) for (text in texts) SentenceStore.learn(this, text, 1)

        val today = LocalDate.now()
        val now = LocalDateTime.now()
        for (text in texts) {
            if (!s.markSeen((groupName + "|" + text).hashCode())) continue
            if (s.isIgnoredByRule(groupName, text)) {
                ActivityLog.add(this, "Notification", "Ignored a message in \"$groupName\" (your group rule)")
                continue
            }
            try { Student.digestAdd(Student.load(this), groupName, text, System.currentTimeMillis()); Student.save(this) } catch (e: Exception) { }
            if (s.classAlerts) {
                val subj = SubjectMatcher.classify(text, SubjectMatcher.parse(s.subjects))
                ClassChange.detect(text, subj)?.let { ch ->
                    ActivityLog.add(this, "Notification", "Class update in \"$groupName\": ${ch.summary}")
                    Notifier.post(this, "🔔 Class update: ${ch.summary}", "From \"$groupName\":\n\u201C${text.take(200)}\u201D")
                    try {
                        startService(Intent(this, PetOverlayService::class.java).setAction(PetOverlayService.ACTION_SAY).putExtra("text", "🔔 ${ch.summary} ($groupName)"))
                    } catch (e: Exception) { }
                }
            }
            val sub = SubmissionParser.parse(text, today) ?: continue
            if (ReminderMaker.isDuplicate(s, text, sub, this, groupName)) {
                ActivityLog.add(this, "Notification", "Deadline ${sub.deadline} already in your list")
                continue
            }
            ReminderMaker.report(this, "Notification", groupName, sub, ReminderMaker.add(this, s, groupName, text, sub, now), now)
        }
    }

    /** Instagram / Telegram / Discord notifications (only for apps the user switched on): deadlines only. */
    private fun handleOther(sbn: StatusBarNotification) {
        val app = ChatApps.nameFor(sbn.packageName) ?: return
        val s = SettingsStore(this)
        if (!s.otherChatOn(app)) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val extras = n.extras
        val title = (extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE) ?: extras.getCharSequence(Notification.EXTRA_TITLE))?.toString()
        val group = ChatApps.label(app, title)
        val texts = mutableListOf<String>()
        @Suppress("DEPRECATION")
        val msgs = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
        if (msgs != null) for (m in msgs) (m as? Bundle)?.getCharSequence("text")?.toString()?.let { texts.add(it) }
        if (texts.isEmpty()) (extras.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.let { texts.addAll(it.lines()) }
        val today = LocalDate.now()
        val now = LocalDateTime.now()
        for (text in texts) {
            if (!s.markSeen((group + "|" + text).hashCode())) continue
            val sub = SubmissionParser.parse(text, today) ?: continue
            if (ReminderMaker.isDuplicate(s, text, sub, this, group)) continue
            ReminderMaker.report(this, "Notification", group, sub, ReminderMaker.add(this, s, group, text, sub, now), now)
        }
    }

    /** Payment-app notifications ("Paid ₹80 to Canteen"): only the amount, merchant and category are kept. */
    private fun handleMoney(sbn: StatusBarNotification) {
        val s = SettingsStore(this)
        if (!s.moneyAuto) return
        if (!ShieldPolicy.isProtected(sbn.packageName, emptySet(), emptySet(), true)) return
        val ex = sbn.notification.extras
        val text = listOfNotNull(ex.getCharSequence(Notification.EXTRA_TITLE), ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT)).joinToString(". ")
        MoneyParser.parse(text, System.currentTimeMillis(), "notification")?.let { ExpenseStore.add(this, it) }
    }
}
