package com.ghostie.pet

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Rect
import android.graphics.drawable.Drawable
import kotlin.math.PI
import kotlin.math.sin

/**
 * Ghost looks: a colour tint plus an optional drawn accessory (res/drawable/acc_*.xml, drawn in the ghost's own
 * pixel space so hats sit on the head and glasses sit on the eyes). Some unlock as you chat with Ghostie.
 */
object Skins {
    /** [acc] is the drawable name without the "acc_" prefix, or "" for none. */
    data class Skin(val id: String, val label: String, val tint: Int?, val acc: String, val unlockChats: Int)

    private fun c(hex: String) = Color.parseColor(hex)

    val all = listOf(
        Skin("classic", "👻 Classic", null, "", 0),
        Skin("mint", "🌿 Mint", c("#BFF5DA"), "", 0),
        Skin("pink", "🌸 Pink + bow", c("#FFC9E3"), "bow", 0),
        Skin("shades", "😎 Shades", null, "shades", 0),
        Skin("nerd", "🤓 Round glasses", null, "nerd", 0),
        Skin("cap", "🧢 Cap", null, "cap", 0),
        Skin("custom", "🎨 Custom colour", null, "", 0),
        // study & professions
        Skin("grad", "🎓 Graduate", null, "grad", 0),
        Skin("doctor", "🩺 Doctor", null, "doctor", 0),
        Skin("engineer", "👷 Engineer", null, "engineer", 0),
        Skin("scientist", "🔬 Scientist", null, "scientist", 0),
        Skin("artist", "🎨 Artist beret", null, "artist", 0),
        Skin("chef", "👨‍🍳 Chef", null, "chef", 0),
        // seasons & festivals
        Skin("santa", "🎅 Santa hat", null, "santa", 0),
        Skin("witch", "🧙 Witch hat", c("#E7DDFF"), "witch", 0),
        Skin("pumpkin", "🎃 Pumpkin", c("#FFD2A1"), "pumpkin", 0),
        Skin("diya", "🪔 Diwali", c("#FFE9B8"), "diya", 0),
        Skin("holi", "🌈 Holi colours", null, "holi", 0),
        Skin("party", "🥳 Party hat", null, "party", 0),
        Skin("umbrella", "☔ Rainy day", c("#D6ECFF"), "umbrella", 0),
        Skin("winter", "🧣 Winter", c("#E8F4FF"), "winter", 0),
        // characters
        Skin("cat", "🐱 Cat", null, "cat", 0),
        Skin("bunny", "🐰 Bunny", c("#FFF2F8"), "bunny", 0),
        Skin("devil", "😈 Little devil", c("#FFE3E3"), "devil", 0),
        Skin("alien", "👽 Alien", c("#D9F7DA"), "alien", 12),
        Skin("robot", "🤖 Robot", c("#E3E9EF"), "robot", 12),
        // unlockables
        Skin("phones", "🎧 Headphones", null, "phones", 5),
        Skin("flower", "🌼 Flower", c("#FFF3B0"), "flower", 8),
        Skin("hat", "🎩 Top hat", null, "hat", 10),
        Skin("night", "🌙 Night", c("#B9B3FF"), "moon", 25),
        Skin("halo", "😇 Angel halo", null, "halo", 30),
        Skin("ice", "❄️ Ice", c("#BFE6FF"), "snow", 35),
        Skin("lava", "🔥 Lava", c("#FFB4A0"), "flame", 40),
        Skin("crown", "👑 Gold crown", c("#FFE9A6"), "crown", 50),
        // colour themes
        Skin("ocean", "🌊 Ocean", c("#B8E3FF"), "", 0),
        Skin("lavender", "💜 Lavender", c("#E3D4FF"), "", 0),
        Skin("peach", "🍑 Peach", c("#FFD9C2"), "", 0),
        Skin("sunny", "🌞 Sunny", c("#FFF1A8"), "", 0),
        Skin("sparkle", "✨ Sparkle", null, "sparkle", 0),
        Skin("galaxy", "🌌 Galaxy", c("#9B8CD9"), "galaxy", 20),
        Skin("gold", "🏅 Golden", c("#FFE08A"), "gold", 45)
    )

    fun byId(id: String) = all.firstOrNull { it.id == id } ?: all[0]

    fun unlocked(s: Skin, chats: Int) = chats >= s.unlockChats

    fun drawable(ctx: Context, skin: Skin): GhostDrawable {
        val tint = if (skin.id == "custom") (try { Color.parseColor(SettingsStore(ctx).customTint) } catch (e: Exception) { null }) else skin.tint
        val overlay = if (skin.acc.isEmpty()) null else {
            val id = ctx.resources.getIdentifier("acc_" + skin.acc, "drawable", ctx.packageName)
            if (id != 0) ctx.getDrawable(id)?.mutate() else null
        }
        return GhostDrawable(ctx.applicationContext, tint, overlay)
    }

    /**
     * The ghost picture plus its accessory. The ghost is drawn a little smaller, leaving headroom for hats; the
     * accessory drawable's viewport matches that margin exactly. With [waveAmount] > 0 the lower cloth ripples
     * (the bitmap is bent through a mesh), which is what makes the big ghost look alive.
     */
    class GhostDrawable(ctx: Context, tint: Int?, private val overlay: Drawable?) : Drawable() {
        private val bmp: Bitmap = BitmapFactory.decodeResource(ctx.resources, R.drawable.ghost_pet)
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val dst = Rect()
        private val src = Rect(0, 0, bmp.width, bmp.height)

        /** 0 = still. About 0.02 - 0.06 looks good. */
        var waveAmount = 0f
            set(v) { field = v; invalidateSelf() }
        var phase = 0f
            set(v) { field = v; if (waveAmount > 0f) invalidateSelf() }

        private val cols = 8
        private val rows = 14
        private val verts = FloatArray((cols + 1) * (rows + 1) * 2)

        init {
            if (tint != null) paint.colorFilter = PorterDuffColorFilter(tint, PorterDuff.Mode.MULTIPLY)
        }

        override fun onBoundsChange(b: Rect) {
            val w = b.width(); val h = b.height()
            dst.set(b.left + (w * 0.06f).toInt(), b.top + (h * 0.12f).toInt(), b.right - (w * 0.06f).toInt(), b.bottom)
            overlay?.setBounds(b.left, b.top, b.right, b.bottom)
        }

        override fun getIntrinsicWidth() = bmp.width
        override fun getIntrinsicHeight() = bmp.height

        override fun draw(c: Canvas) {
            if (waveAmount <= 0.001f) {
                c.drawBitmap(bmp, src, dst, paint)
            } else {
                var k = 0
                val dw = dst.width().toFloat(); val dh = dst.height().toFloat()
                for (j in 0..rows) {
                    val v = j.toFloat() / rows
                    val hem = v * v * v            // the lower cloth moves most, the head hardly at all
                    for (i in 0..cols) {
                        val u = i.toFloat() / cols
                        val dx = waveAmount * dw * hem * sin(phase + v * 5.2f + u * 1.6f) +
                            waveAmount * 0.5f * dw * v * sin(phase + v * 2f)
                        val dy = waveAmount * 0.35f * dh * hem * sin(phase * 2f + u * 6f)
                        verts[k++] = dst.left + u * dw + dx
                        verts[k++] = dst.top + v * dh + dy
                    }
                }
                c.drawBitmapMesh(bmp, cols, rows, verts, 0, null, 0, paint)
            }
            overlay?.draw(c)
        }

        override fun setAlpha(a: Int) { paint.alpha = a; overlay?.alpha = a }
        override fun setColorFilter(f: ColorFilter?) { /* tint is fixed per skin */ }
        @Deprecated("Deprecated in Java")
        override fun getOpacity() = PixelFormat.TRANSLUCENT

        companion object { const val TAU = (2 * PI).toFloat() }
    }
}
