package com.ghostie.pet

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.Drawable

/** Ghost looks: a colour tint plus an optional emoji accessory. Some unlock as you chat with Ghostie. */
object Skins {
    data class Skin(val id: String, val label: String, val tint: Int?, val accessory: String, val x: Float, val y: Float, val size: Float, val unlockChats: Int)

    val all = listOf(
        Skin("classic", "👻 Classic", null, "", 0f, 0f, 0f, 0),
        Skin("mint", "🌿 Mint", Color.parseColor("#BFF5DA"), "", 0f, 0f, 0f, 0),
        Skin("pink", "🌸 Pink", Color.parseColor("#FFC9E3"), "🎀", 0.64f, 0.13f, 0.22f, 0),
        Skin("shades", "😎 Shades", null, "🕶️", 0.47f, 0.34f, 0.36f, 0),
        Skin("cap", "🧢 Cap", null, "🧢", 0.47f, 0.14f, 0.32f, 0),
        Skin("custom", "🎨 Custom colour", null, "", 0f, 0f, 0f, 0),
        Skin("phones", "🎧 Headphones", null, "🎧", 0.47f, 0.10f, 0.42f, 5),
        Skin("flower", "🌼 Flower", Color.parseColor("#FFF3B0"), "🌼", 0.66f, 0.12f, 0.20f, 8),
        Skin("hat", "🎩 Top hat", null, "🎩", 0.47f, 0.15f, 0.34f, 10),
        Skin("grad", "🎓 Graduate", null, "🎓", 0.47f, 0.13f, 0.36f, 15),
        Skin("pumpkin", "🎃 Pumpkin", Color.parseColor("#FFD2A1"), "🎃", 0.78f, 0.74f, 0.22f, 20),
        Skin("night", "🌙 Night", Color.parseColor("#B9B3FF"), "🌙", 0.80f, 0.14f, 0.22f, 25),
        Skin("halo", "😇 Angel halo", null, "💫", 0.47f, 0.02f, 0.26f, 30),
        Skin("ice", "❄️ Ice", Color.parseColor("#BFE6FF"), "❄️", 0.80f, 0.14f, 0.22f, 35),
        Skin("lava", "🔥 Lava", Color.parseColor("#FFB4A0"), "🔥", 0.84f, 0.72f, 0.24f, 40),
        Skin("crown", "👑 Gold crown", Color.parseColor("#FFE9A6"), "👑", 0.47f, 0.13f, 0.30f, 50)
    )

    fun byId(id: String) = all.firstOrNull { it.id == id } ?: all[0]

    fun unlocked(s: Skin, chats: Int) = chats >= s.unlockChats

    fun drawable(ctx: Context, skin: Skin): Drawable {
        val base = ctx.getDrawable(R.drawable.ghost_pet)!!.mutate()
        val tint = if (skin.id == "custom") (try { Color.parseColor(SettingsStore(ctx).customTint) } catch (e: Exception) { null }) else skin.tint
        if (tint != null) base.colorFilter = PorterDuffColorFilter(tint, PorterDuff.Mode.MULTIPLY)
        return if (skin.accessory.isEmpty()) base else SkinDrawable(base, skin)
    }

    private class SkinDrawable(private val base: Drawable, private val skin: Skin) : Drawable() {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onBoundsChange(b: android.graphics.Rect) { base.bounds = b }
        override fun getIntrinsicWidth() = base.intrinsicWidth
        override fun getIntrinsicHeight() = base.intrinsicHeight

        override fun draw(c: Canvas) {
            base.draw(c)
            val b = bounds
            paint.textSize = b.width() * skin.size
            paint.textAlign = Paint.Align.CENTER
            c.drawText(skin.accessory, b.left + b.width() * skin.x, b.top + b.height() * (skin.y + skin.size * 0.7f), paint)
        }

        override fun setAlpha(a: Int) { base.alpha = a }
        override fun setColorFilter(f: ColorFilter?) { base.colorFilter = f }
        @Deprecated("Deprecated in Java")
        override fun getOpacity() = PixelFormat.TRANSLUCENT
    }
}
