package com.ghostie.pet

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.Drawable

/** Ghost looks: a colour tint plus an optional emoji accessory. Some unlock as you chat with Ghostie. */
object Skins {
    data class Skin(val id: String, val label: String, val tint: Int?, val accessory: String, val x: Float, val y: Float, val size: Float, val unlockChats: Int)

    val all = listOf(
        Skin("classic", "👻 Classic", null, "", 0f, 0f, 0f, 0),
        Skin("mint", "🌿 Mint", Color.parseColor("#BFF5DA"), "", 0f, 0f, 0f, 0),
        Skin("pink", "🌸 Pink", Color.parseColor("#FFC9E3"), "🎀", 0.66f, 0.06f, 0.2f, 0),
        Skin("shades", "😎 Shades", null, "🕶️", 0.58f, 0.27f, 0.34f, 0),
        Skin("cap", "🧢 Cap", null, "🧢", 0.55f, 0.04f, 0.26f, 0),
        Skin("custom", "🎨 Custom colour", null, "", 0f, 0f, 0f, 0),
        Skin("phones", "🎧 Headphones", null, "🎧", 0.57f, 0.22f, 0.4f, 5),
        Skin("flower", "🌼 Flower", Color.parseColor("#FFF3B0"), "🌼", 0.66f, 0.05f, 0.2f, 8),
        Skin("hat", "🎩 Top hat", null, "🎩", 0.55f, 0.03f, 0.26f, 10),
        Skin("grad", "🎓 Graduate", null, "🎓", 0.55f, 0.03f, 0.28f, 15),
        Skin("pumpkin", "🎃 Pumpkin", Color.parseColor("#FFD2A1"), "🎃", 0.85f, 0.85f, 0.22f, 20),
        Skin("night", "🌙 Night", Color.parseColor("#B9B3FF"), "🌙", 0.8f, 0.06f, 0.2f, 25),
        Skin("halo", "😇 Angel halo", null, "💫", 0.55f, -0.03f, 0.22f, 30),
        Skin("ice", "❄️ Ice", Color.parseColor("#BFE6FF"), "❄️", 0.8f, 0.08f, 0.2f, 35),
        Skin("lava", "🔥 Lava", Color.parseColor("#FFB4A0"), "🔥", 0.85f, 0.8f, 0.22f, 40),
        Skin("crown", "👑 Gold crown", Color.parseColor("#FFE9A6"), "👑", 0.55f, -0.01f, 0.24f, 50)
    )

    fun byId(id: String) = all.firstOrNull { it.id == id } ?: all[0]

    fun unlocked(s: Skin, chats: Int) = chats >= s.unlockChats

    fun drawable(ctx: Context, skin: Skin): Drawable {
        val base = ctx.getDrawable(R.drawable.ghost_pet)!!.mutate()
        val tint = if (skin.id == "custom") (try { Color.parseColor(SettingsStore(ctx).customTint) } catch (e: Exception) { null }) else skin.tint
        if (tint != null) base.colorFilter = PorterDuffColorFilter(tint, PorterDuff.Mode.MULTIPLY)
        return if (skin.accessory.isEmpty()) base else SkinDrawable(base, skin)
    }

    private class SkinDrawable(private val base: Drawable, private val skin: Skin) : Drawable() {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // The ghost is drawn a little smaller, leaving headroom for hats. Accessory positions are fractions of the ghost itself.
        override fun onBoundsChange(b: android.graphics.Rect) {
            val w = b.width(); val h = b.height()
            base.setBounds(b.left + (w * 0.06f).toInt(), b.top + (h * 0.12f).toInt(), b.right - (w * 0.06f).toInt(), b.bottom)
        }
        override fun getIntrinsicWidth() = base.intrinsicWidth
        override fun getIntrinsicHeight() = base.intrinsicHeight

        override fun draw(c: Canvas) {
            base.draw(c)
            val b = bounds
            val gw = b.width() * 0.88f
            val gh = b.height() * 0.88f
            paint.textSize = gw * skin.size
            paint.textAlign = Paint.Align.CENTER
            val cx = b.left + b.width() * 0.06f + gw * skin.x
            val cy = b.top + b.height() * 0.12f + gh * skin.y
            c.drawText(skin.accessory, cx, cy + paint.textSize * 0.34f, paint)
        }

        override fun setAlpha(a: Int) { base.alpha = a }
        override fun setColorFilter(f: ColorFilter?) { base.colorFilter = f }
        @Deprecated("Deprecated in Java")
        override fun getOpacity() = PixelFormat.TRANSLUCENT
    }
}
