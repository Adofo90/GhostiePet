package com.ghostie.pet

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Rect
import android.graphics.drawable.Drawable
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.sin

/**
 * Ghost looks: a colour tint plus an optional drawn accessory (res/drawable/acc_*.xml, drawn in the ghost's own
 * pixel space so hats sit on the head and glasses sit on the eyes). Some unlock as you chat with Ghostie.
 */
object Skins {
    /** [acc] is the drawable name without the "acc_" prefix, or "" for none. */
    data class Skin(val id: String, val label: String, val tint: Int?, val acc: String, val unlockChats: Int)

    private fun c(hex: String) = Color.parseColor(hex)

    val all = listOf(
        Skin("classic", "👻 Classic", null, "", 0),
        Skin("mint", "🌿 Mint", c("#BFF5DA"), "", 0),
        Skin("pink", "🌸 Pink + bow", c("#FFC9E3"), "bow", 0),
        Skin("shades", "😎 Shades", null, "shades", 0),
        Skin("nerd", "🤓 Round glasses", null, "nerd", 0),
        Skin("cap", "🧢 Cap", null, "cap", 0),
        Skin("custom", "🎨 Custom colour", null, "", 0),
        // study & professions
        Skin("grad", "🎓 Graduate", null, "grad", 0),
        Skin("doctor", "🩺 Doctor", null, "doctor", 0),
        Skin("engineer", "👷 Engineer", null, "engineer", 0),
        Skin("scientist", "🔬 Scientist", null, "scientist", 0),
        Skin("artist", "🎨 Artist beret", null, "artist", 0),
        Skin("chef", "👨‍🍳 Chef", null, "chef", 0),
        // seasons & festivals
        Skin("santa", "🎅 Santa hat", null, "santa", 0),
        Skin("witch", "🧙 Witch hat", c("#E7DDFF"), "witch", 0),
        Skin("pumpkin", "🎃 Pumpkin", c("#FFD2A1"), "pumpkin", 0),
        Skin("diya", "🪔 Diwali", c("#FFE9B8"), "diya", 0),
        Skin("holi", "🌈 Holi colours", null, "holi", 0),
        Skin("party", "🥳 Party hat", null, "party", 0),
        Skin("umbrella", "☔ Rainy day", c("#D6ECFF"), "umbrella", 0),
        Skin("winter", "🧣 Winter", c("#E8F4FF"), "winter", 0),
        // characters
        Skin("cat", "🐱 Cat", null, "cat", 0),
        Skin("bunny", "🐰 Bunny", c("#FFF2F8"), "bunny", 0),
        Skin("devil", "😈 Little devil", c("#FFE3E3"), "devil", 0),
        Skin("alien", "👽 Alien", c("#D9F7DA"), "alien", 12),
        Skin("robot", "🤖 Robot", c("#E3E9EF"), "robot", 12),
        // unlockables
        Skin("phones", "🎧 Headphones", null, "phones", 5),
        Skin("flower", "🌼 Flower", c("#FFF3B0"), "flower", 8),
        Skin("hat", "🎩 Top hat", null, "hat", 10),
        Skin("night", "🌙 Night", c("#B9B3FF"), "moon", 25),
        Skin("halo", "😇 Angel halo", null, "halo", 30),
        Skin("ice", "❄️ Ice", c("#BFE6FF"), "snow", 35),
        Skin("lava", "🔥 Lava", c("#FFB4A0"), "flame", 40),
        Skin("crown", "👑 Gold crown", c("#FFE9A6"), "crown", 50),
        // colour themes
        Skin("ocean", "🌊 Ocean", c("#B8E3FF"), "", 0),
        Skin("lavender", "💜 Lavender", c("#E3D4FF"), "", 0),
        Skin("peach", "🍑 Peach", c("#FFD9C2"), "", 0),
        Skin("sunny", "🌞 Sunny", c("#FFF1A8"), "", 0),
        Skin("sparkle", "✨ Sparkle", null, "sparkle", 0),
        Skin("galaxy", "🌌 Galaxy", c("#9B8CD9"), "galaxy", 20),
        Skin("gold", "🏅 Golden", c("#FFE08A"), "gold", 45)
    )

    fun byId(id: String) = all.firstOrNull { it.id == id } ?: all[0]

    fun unlocked(s: Skin, chats: Int) = chats >= s.unlockChats

    fun drawable(ctx: Context, skin: Skin): GhostDrawable {
        val tint = if (skin.id == "custom") (try { Color.parseColor(SettingsStore(ctx).customTint) } catch (e: Exception) { null }) else skin.tint
        val overlay = if (skin.acc.isEmpty()) null else {
            val id = ctx.resources.getIdentifier("acc_" + skin.acc, "drawable", ctx.packageName)
            if (id != 0) ctx.getDrawable(id)?.mutate() else null
        }
        return GhostDrawable(ctx.applicationContext, tint, overlay, skin.acc)
    }

    /**
     * The ghost picture plus its accessory. The ghost is drawn a little smaller, leaving headroom for hats; the
     * accessory drawable's viewport matches that margin exactly. With [waveAmount] > 0 the lower cloth ripples
     * (the bitmap is bent through a mesh), which is what makes the big ghost look alive.
     */
    class GhostDrawable(ctx: Context, tint: Int?, private val overlay: Drawable?, acc: String = "") : Drawable() {
        private val rig: Rig = RIGS[acc] ?: DEFAULT_RIG
        private val bmp: Bitmap = BitmapFactory.decodeResource(ctx.resources, R.drawable.ghost_pet)
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val dst = Rect()
        private val src = Rect(0, 0, bmp.width, bmp.height)

        /** 0 = still. About 0.02 - 0.06 looks good. */
        var waveAmount = 0f
            set(v) { field = v; invalidateSelf() }
        var phase = 0f
            set(v) { field = v; if (waveAmount > 0f) invalidateSelf() }

        private val cols = 8
        private val rows = 14
        private val verts = FloatArray((cols + 1) * (rows + 1) * 2)

        init {
            if (tint != null) paint.colorFilter = PorterDuffColorFilter(tint, PorterDuff.Mode.MULTIPLY)
        }

        override fun onBoundsChange(b: Rect) {
            val w = b.width(); val h = b.height()
            dst.set(b.left + (w * 0.06f).toInt(), b.top + (h * 0.12f).toInt(), b.right - (w * 0.06f).toInt(), b.bottom)
            overlay?.setBounds(b.left, b.top, b.right, b.bottom)
        }

        override fun getIntrinsicWidth() = bmp.width
        override fun getIntrinsicHeight() = bmp.height

        override fun draw(c: Canvas) {
            if (waveAmount <= 0.001f) {
                c.drawBitmap(bmp, src, dst, paint)
            } else {
                var k = 0
                val dw = dst.width().toFloat(); val dh = dst.height().toFloat()
                for (j in 0..rows) {
                    val v = j.toFloat() / rows
                    for (i in 0..cols) {
                        val u = i.toFloat() / cols
                        verts[k++] = dst.left + u * dw + dispX(u, v, dw)
                        verts[k++] = dst.top + v * dh + dispY(u, v, dh)
                    }
                }
                c.drawBitmapMesh(bmp, cols, rows, verts, 0, null, 0, paint)
            }
            drawAccessory(c)
        }

        // The cloth's own sway at a point (u,v in 0..1 over the ghost): head hardly moves, the hem moves most.
        private fun dispX(u: Float, v: Float, dw: Float): Float {
            val hem = v * v * v
            return waveAmount * dw * hem * sin(phase + v * 5.2f + u * 1.6f) + waveAmount * 0.5f * dw * v * sin(phase + v * 2f)
        }
        private fun dispY(u: Float, v: Float, dh: Float): Float {
            val hem = v * v * v
            return waveAmount * 0.35f * dh * hem * sin(phase * 2f + u * 6f)
        }

        /**
         * The accessory rides the ghost: it is pinned to its anchor (head, eyes, neck...), follows how the cloth sways at
         * that spot, tilts with it, and adds its own idle motion (ears flick, halo bobs, flames flicker...).
         * It scales with the ghost because it is drawn in the ghost's own coordinates.
         */
        private fun drawAccessory(c: Canvas) {
            val ov = overlay ?: return
            if (waveAmount <= 0.001f) { ov.draw(c); return }
            val b = bounds
            val sc = b.width() / 595.45f
            val ax = b.left + rig.ax * sc; val ay = b.top + rig.ay * sc
            val dw = dst.width().toFloat(); val dh = dst.height().toFloat()
            val u = ((ax - dst.left) / dw).coerceIn(0f, 1f); val v = ((ay - dst.top) / dh).coerceIn(0f, 1f)
            val dx = dispX(u, v, dw) * rig.follow
            val dy = dispY(u, v, dh) * rig.follow
            val lean = Math.toDegrees(atan2((dispX(u, (v + 0.08f).coerceAtMost(1f), dw) - dispX(u, (v - 0.08f).coerceAtLeast(0f), dw)).toDouble(), (0.16f * dh).toDouble())).toFloat() * rig.tilt
            val rot = lean + rig.sway * sin(phase * rig.swayK)
            val bob = rig.bob * sc * sin(phase * rig.bobK)
            val pulse = 1f + rig.pulse * sin(phase * rig.pulseK)
            c.save()
            c.translate(dx, dy + bob)
            c.rotate(rot, ax, ay)
            c.scale(pulse, pulse, ax, ay)
            ov.draw(c)
            c.restore()
        }

        override fun setAlpha(a: Int) { paint.alpha = a; overlay?.alpha = a }
        override fun setColorFilter(f: ColorFilter?) { /* tint is fixed per skin */ }
        @Deprecated("Deprecated in Java")
        override fun getOpacity() = PixelFormat.TRANSLUCENT

        companion object {
            const val TAU = (2 * PI).toFloat()
            /** Integer multipliers (K) keep every loop seamless because the phase wraps at TAU. */
            val DEFAULT_RIG = Rig(300f, 110f, 1f, 0f, 1, 0f, 1, 0f, 1, 0.5f)
            val RIGS: Map<String, Rig> = mapOf(
                // hats ride the head and lean a little
                "cap" to Rig(300f, 100f, 1f, 0f, 1, 2f, 1, 0f, 1, 0.6f),
                "grad" to Rig(300f, 90f, 1f, 0f, 1, 3f, 1, 0f, 1, 0.6f),
                "witch" to Rig(300f, 90f, 1f, 0f, 1, 4f, 1, 0f, 1, 0.6f),
                "santa" to Rig(300f, 90f, 1f, 0f, 1, 4f, 2, 0f, 1, 0.6f),
                "party" to Rig(300f, 90f, 1f, 1.5f, 2, 3f, 2, 0f, 1, 0.6f),
                "chef" to Rig(300f, 90f, 1f, 0f, 1, 2f, 1, 0f, 1, 0.6f),
                "artist" to Rig(300f, 90f, 1f, 0f, 1, 3f, 1, 0f, 1, 0.6f),
                "hat" to Rig(300f, 90f, 1f, 0f, 1, 3f, 1, 0f, 1, 0.6f),
                "engineer" to Rig(300f, 95f, 1f, 0f, 1, 1.5f, 1, 0f, 1, 0.6f),
                "scientist" to Rig(300f, 95f, 1f, 0f, 1, 1.5f, 1, 0f, 1, 0.6f),
                "doctor" to Rig(300f, 95f, 1f, 0f, 1, 1.5f, 1, 0f, 1, 0.6f),
                "flower" to Rig(300f, 90f, 1f, 1f, 2, 5f, 2, 0f, 1, 0.6f),
                "bow" to Rig(350f, 60f, 1f, 0f, 1, 5f, 2, 0f, 1, 0.6f),
                // ears and antennae flick
                "bunny" to Rig(300f, 70f, 1f, 0f, 1, 6f, 2, 0f, 1, 0.6f),
                "cat" to Rig(300f, 70f, 1f, 0f, 1, 4f, 3, 0f, 1, 0.6f),
                "devil" to Rig(300f, 70f, 1f, 2f, 2, 3f, 3, 0f, 1, 0.6f),
                "alien" to Rig(300f, 70f, 1f, 1f, 2, 7f, 1, 0f, 1, 0.6f),
                "robot" to Rig(300f, 80f, 1f, 0f, 1, 3f, 3, 0.02f, 3, 0.6f),
                // floating things bob
                "halo" to Rig(300f, 60f, 1f, 6f, 2, 3f, 1, 0f, 1, 0.5f),
                "crown" to Rig(300f, 70f, 1f, 4f, 2, 2f, 1, 0f, 1, 0.6f),
                "moon" to Rig(300f, 60f, 1f, 4f, 1, 4f, 1, 0.02f, 2, 0.5f),
                "snow" to Rig(300f, 80f, 1f, 5f, 2, 2f, 1, 0f, 1, 0.5f),
                "sparkle" to Rig(300f, 150f, 1f, 2f, 3, 0f, 1, 0.06f, 4, 0f),
                "galaxy" to Rig(300f, 150f, 1f, 0f, 1, 0f, 1, 0.03f, 2, 0f),
                "gold" to Rig(300f, 150f, 1f, 0f, 1, 0f, 1, 0.03f, 2, 0f),
                // flames flicker
                "flame" to Rig(300f, 60f, 1f, 0f, 1, 5f, 6, 0.07f, 6, 0.5f),
                "diya" to Rig(300f, 80f, 1f, 0f, 1, 3f, 6, 0.05f, 6, 0.5f),
                // eyes and face
                "shades" to Rig(310f, 150f, 1f, 0f, 1, 0f, 1, 0f, 1, 0.5f),
                "nerd" to Rig(310f, 150f, 1f, 0f, 1, 0f, 1, 0f, 1, 0.5f),
                "phones" to Rig(300f, 150f, 1f, 1.5f, 4, 0f, 1, 0.015f, 4, 0.5f),
                // body items follow the cloth
                "winter" to Rig(300f, 240f, 0.8f, 2f, 2, 4f, 2, 0f, 1, 0.8f),
                "umbrella" to Rig(300f, 70f, 1f, 2f, 1, 4f, 1, 0f, 1, 0.6f),
                "pumpkin" to Rig(300f, 90f, 1f, 2f, 1, 2f, 1, 0f, 1, 0.6f),
                "holi" to Rig(300f, 150f, 1f, 0f, 1, 2f, 2, 0f, 1, 0.5f)
            )
        }
        class Rig(
            val ax: Float, val ay: Float, val follow: Float,
            val bob: Float, val bobK: Int, val sway: Float, val swayK: Int,
            val pulse: Float, val pulseK: Int, val tilt: Float
        )
    }
}
