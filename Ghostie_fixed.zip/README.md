# Ghostie Android — online-build ready

This is a native Android project for the Ghostie floating companion. It is prepared so you can build an installable APK in the cloud without installing Android Studio.

## Easiest: GitHub Actions (recommended)

1. Create a free GitHub account if you do not already have one.
2. Create a **new empty repository**.
3. Upload the **contents** of this folder to the repository. The `.github/workflows/build-apk.yml` file must be present.
4. Open the repository's **Actions** tab.
5. Select **Build Ghostie APK**.
6. Tap **Run workflow**.
7. Wait for the build to finish.
8. Open the completed workflow run and download the **Ghostie-debug-apk** artifact.
9. Extract the downloaded artifact if necessary; install `app-debug.apk` on your Android phone.

The workflow installs JDK 17, the Android SDK (platform 35) and Gradle 8.9 in the cloud, then builds `assembleDebug`. No Android Studio is required on your computer.

**Important:** `.github/workflows/build-apk.yml`, `build.gradle` and `settings.gradle` must be at the *root* of the repository, not inside a sub-folder. If the Actions tab shows no workflow, the folder was uploaded one level too deep.

## Codemagic alternative

This repository also contains `codemagic.yaml`. Codemagic supports native Android projects and can produce an APK artifact. Connect this GitHub repository in Codemagic, choose the Android/native workflow, and start a build.

## Phone permissions

After installing Ghostie, open it and grant **Display over other apps**. Android may also ask for notification/foreground-service permission depending on the phone and Android version. These permissions are required for a persistent floating overlay on modern Android versions.

## Notes

- The debug APK is suitable for direct installation/testing.
- For Google Play release, create and protect a signing keystore and use a release build.
- Do not put an OpenAI API key into the source code or a public repository. Enter it inside the app instead.

## Chat commands (work offline, no API key needed)

- `organize documents` - copies every document WhatsApp saved into `Documents/Ghostie/<Subject>/` (originals are untouched). Sorting is by file name using the subject list on the Ghostie settings screen. WhatsApp does not record which group a file came from, so this covers all groups. Allow "file access" once when asked.
- `add event maths exam tomorrow 10am` - opens your calendar pre-filled.
- `timer 10 minutes`, `alarm 6:30 am`, `open WhatsApp`, `help`.

## Group reminders

Add your WhatsApp group name(s) in the app (or tell the ghost: `watch group CSE 3A`) and switch on **Notification access** and **Calendar**. When a message in that group mentions a submission date (e.g. "submit DBMS record by 5th Nov"), Ghostie adds a calendar reminder at 9:00 the day before and lists it under **Upcoming submissions** in the app. The ghost also mentions anything due today or tomorrow. Use **Test message** in the app to see what it would detect.

Limits: WhatsApp has no public API, so Ghostie only sees messages that arrive as notifications while it is running (not old chat history, and not groups whose notifications are turned off).

## Catching up when a notification was missed

WhatsApp does not post a notification for the chat you currently have open (or for muted groups), so the live watcher can miss messages. To catch up: in the group tap the three dots > More > Export chat > Without media, then pick **Add Ghostie reminders** in the share sheet. You can share a single message the same way. In the app, **Scan a chat file** does the same for an export saved on the phone. Already-added deadlines are not duplicated.

## Read open chats (optional, fully automatic)

Turn on **Read open chats** in the app's Setup list (Android Accessibility). While one of your watched groups is open in WhatsApp, Ghostie reads the visible messages and adds reminders for submission dates, so nothing is missed when WhatsApp posts no notification. It only observes WhatsApp, only acts on groups you listed, and processes everything on the phone. On Android 13+ you may first need Settings > Apps > Ghostie > ⋮ > Allow restricted settings.

## Personality

Ghostie chats offline: greetings that depend on the time of day, jokes, fun facts, study and stress support, name memory ("my name is ..."), and it asks follow-ups. It bobs, sways, blinks and glances while idle, pops when tapped or when it speaks, and bounces in when it visits. If you add an OpenAI key and turn on AI chat, the same casual personality is used for free-form conversation.

If Android shows a floating accessibility button after you enable "Read open chats", turn it off in Settings > Accessibility > Ghostie chat reader > Shortcut (or the floating button settings). Ghostie doesn't need it.

## Event registrations

Besides submissions, Ghostie also records the last date to register or apply for events ("last date to register for Hackathon is 12 Nov", "apply for the internship before 15/11", "RSVP by 3 Nov"). It adds a calendar reminder the day before (marked 📝) and lists it under **Upcoming deadlines**. Messages that only give the event's own date ("TechFest is on 12 Nov") are ignored.

## New in this version
- **Calling**: say `call Mom` or `call 9876543210`. Allow *Contacts & calls* in the app to dial instantly (otherwise the dialer opens). Emergency numbers always open the dialer only.
- **Alarm titles**: `set an alarm with title resume at 12 pm`.
- **Faster ghost**: hardware-accelerated overlay, no endless animations, quicker replies.
- **Activity log** in the app (what was heard/read/added, Copy button) plus "last notification heard / chat read" lines.
- **Smarter sorting**: uses file name, the WhatsApp chat a file came from, then the text inside PDF/Word/PowerPoint files. New documents are sorted automatically (switch in Documents).
- **Better reminders**: calendar event on the due date (stated time, else 5 pm) with alerts the day before 9 am, optional 2 days before, optional morning-of; Snooze button (+3 h); understands "day after", "kal", "parso", "aaj".
- **Ghost behaviour**: hides during calls, landscape and Do Not Disturb; sleeps 11 pm-6 am (tap the edge ghost to wake it for 10 min); size slider.

## Voice, animation and conversation
- **Ghostie voice**: replies are spoken with your phone's text-to-speech, pitched up (Squeaky / Cute / Normal in Companion), plus synthesized squeaks, pops, giggles and purrs. Both have switches and stay silent on silent/vibrate.
- **Interactive ghost**: it leans toward your finger while you touch it, long-press to pet (hearts + purr), double-tap to spin, drag to carry it (it tilts and squeaks), shake it while dragging to make it dizzy. (Android doesn't let apps see touches outside their own windows, so it can only follow your finger while you touch it.)
- **Conversations continue**: tap the ghost after it pops up and the chat opens with what it just said; quick-reply buttons (Yes / Not yet / Done / Remind me later...) answer it, and typed answers are understood in context.
- **Bigger vocabulary**: 60+ proactive messages (meals, water, posture, eye breaks, mood, riddles, would-you-rather, tips, facts, jokes, weekday lines), many more topics, Hinglish phrases, and it mirrors "I am / I like / I want" sentences.

## Calendar categories, listening, bin and learning
- **Calendar categories** (like the phone's Add event form): `add birthday Tikki on 19 October` (all-day, repeats yearly, reminded the day before and that morning), `add anniversary ...`, `countdown to exams on 5 December` (all-day, reminders a week/day before and that morning, listed under Upcoming), and normal events with options: `add event dbms viva 12 Nov 2pm for 2 hours remind me 30 minutes before`, `every week`, `all day`, `description ...`. Wrong category? Say `make it a birthday` / `make it an event` and Ghostie fixes it and remembers.
- **Listening**: hold the ghost and talk (let go when done), or tap 🎙 in the chat. It listens only while you hold/tap and switches the mic off straight after, preferring on-device recognition, so it costs almost no battery. If in-app listening isn't allowed, it falls back to the phone's own speech dialog. Allow *Microphone* in Setup for the smooth version. Triple-tap the ghost to pet it.
- **The bin**: drag the ghost and a bin appears; drop it in to send the ghost away for an hour (tap the edge ghost to bring it back). In the app, long-press a deadline or a sorted document and drag it to the bin (documents: only Ghostie's copy is deleted).
- **Learning** (on this phone only, no AI key needed): it learns from corrections - moving a document to another subject, "make it a birthday", deadlines you bin (similar ones from that group are ignored), phrases you teach it (`when I say study mode, set timer 25 minutes`, `remember cs means computer science`), and which kinds of messages you answer or ignore. See and erase it under *What Ghostie learned*, or say `what have you learned` / `forget everything`.

## Own sentences
Ghostie now builds new sentences from words it has learned. It reads what you type or say to it, text you paste under *What Ghostie learned → Teach by example*, and (switchable) messages from watched groups and shared chats. It remembers which words follow which and mixes its own sentences into replies and idle messages, with 👍/👎 buttons to teach it what sounds right. Say "say something" or "surprise me" to hear one. It starts after about 25 learned sentences. Links, phone numbers and rude words are never learned; everything stays on the phone, and *Forget learned words* wipes it. It is a small word-chain model, not a large language model, so sentences can be quirky.

**Throwing the ghost**: pick it up (even after holding a moment), drop it on the bin, or flick it fast toward the bin.

## When Ghostie speaks (and listening)
Spoken (if *Ghost speaks aloud* is on and the phone is not on silent/vibrate): when it pops up with a message (check-ins, deadline nudges, water reminders), when it replies in chat or to a voice command, and for its short reactions (petting, dizzy, being thrown in the bin, waking up). It stays quiet during calls, in landscape, in Do Not Disturb, in Quiet time, and while sleeping (11 pm - 6 am).
Listening: hold the ghost until "Speak now", then talk. Let go to finish (a quick press keeps listening until you stop). Small finger wobble no longer cancels it. While listening the service switches to microphone mode so Android doesn't silence the mic; if it hears nothing twice in a row it opens the phone's own voice box.

## UI refresh
The app is split into tabs (Home, Setup, Docs, Brain, More) with a setup-progress banner, a battery/autostart row for Xiaomi/Poco phones, and card icons. The ghost's chat box now matches the app's dark-purple look: message bubbles, a header with a close button, pill-shaped quick replies and round mic/send buttons.

## Ghostie calls me (More tab)
Pick people/groups (one per line, as WhatsApp shows them). Ghostie rings like an incoming call after N messages within M minutes, or on an urgent word. Answer opens WhatsApp, Dismiss silences, dragging the ghost into the bin (or "🗑 Never") mutes that chat; "Unmute chats" resets. Needs Notification access. On Android 14+ use "Allow full screen" if the call screen doesn't pop up over other apps.

## Free AI (More tab)
Pick Groq / Gemini / OpenRouter / OpenAI, paste a key. Nothing is downloaded; needs internet. Tapping Ghostie's quick-reply chips is always answered locally.

## Round 2
- **Notification buttons**: each deadline alert is Ghostie's own notification with Done ✅ / Snooze 1h / 🗑 Never (deletes the event and teaches Ghostie to ignore similar ones). Re-scheduled after a reboot (approximate times).
- **Recent events** (Home): tap to edit name/date/time/category, drag to the bin to delete. In chat, "undo" (or the Undo ↩️ chip) removes the event just added.
- **Widget**: add "Ghostie" from the home-screen widgets list; shows the next 3 deadlines with ✅ and 🗑 buttons.
- **Hindi / Hinglish**: More tab → Language. Commands like "kal shaam 6 baje alarm lagao", "5 minute ka timer", "mom ko call karo" work in either mode.
- **Group rules**: More tab → words to ignore per group. Each deadline shows the original message.
- **Ghost looks**: More tab → Ghost look; some unlock after chatting (10 / 25 / 50 chats).

## More options
- **Ghost looks**: cap, headphones, flower, top hat, graduate, pumpkin, night, angel halo, ice, lava, gold crown, plus a custom colour (hex). Fancy ones unlock by chatting (5 to 50 chats).
- **Tricks**: random dance / wave / yawn / shiver / flip while idle (switch in More). Say "dance", "wave", "yawn", "do a flip". The ghost also reacts when you plug in the charger or the battery gets low.
- **Chat commands**: note / show notes / clear notes; todo X / my todos / done N; remind me to X in 20 minutes; flashlight on/off; calculate 12*(3+4); flip a coin; roll a dice; what time is it; what's the date; battery.

## Sharing the APK
Installed from a shared file? Setup tab → "Open App info" → ⋮ → "Allow restricted settings", then enable Accessibility / Notification access. Opening apps from Ghostie also posts a short "Tap to open" notification, because some phones (e.g. Nothing, stock Android 15) block launches from background services.

## Class changes, Study mode, Moods, Share
- **Class changes**: in watched groups, "class cancelled / rescheduled / room changed / now online" gives a notification and a ghost message (switch in More → Group rules). Alert only, nothing is added to the calendar.
- **Study mode** (Home tab, or say "study 45", "stop studying", "study log"): focus/break timer, optional Do Not Disturb (needs policy access, your choice), optional cover for chosen apps (needs Usage access), daily/weekly focus log and streak. No random ghost visits while focusing.
- **Moods** (More → Personality): Classic, Sweet, Playful, Sassy, Coach. Also steers AI chat if enabled.
- **Share** (More → Share Ghostie): paste your release link once, send it with install steps.

## Learning agent (Brain tab → Ghostie's agent)
- **Learns (on the phone only)**: when you chat and study, which focus length you finish, which groups' reminders you finish / snooze / bin, which hours you ignore the ghost, which suggestions you accept.
- **Suggests, you approve**: at most 2 a day, 3 h apart, never while studying or at night: a deadline for a subject you haven't studied, your usual study hour, keeping a streak, quiet hours. Yes / Not now / Stop these chips. Three declines of a type mutes it for a week.
- **Learns how you talk**: if you say something it didn't understand and then a real command, it offers to remember the first as a shortcut.
- **Plan my week** / "plan my day": a study plan from your deadlines (offline). With AI on, it is rewritten by the cloud model; a short summary of deadlines and habits (never message text) is sent only if the AI switch is on (can be turned off).
- "study dbms 45" logs minutes per subject. "what have you learned about me", "stop suggestions", "forget my habits".

## 🍽️ Food price check (read-only)
Say "cheapest chicken biryani" or "compare paneer pizza and garlic bread". Ghostie opens Zomato, Swiggy and the brand apps (Domino's, Popeyes, EatSure) one by one, searches, reads the prices, and tells you the cheapest option including delivery fees. For several items it finds the cheapest combination (splitting over up to 3 places, each fee counted once).
- It NEVER orders: it only opens the app, taps search, types your item, scrolls and reads. It refuses to touch anything labelled cart/pay/checkout/add/login, and works only while you have asked for a check.
- Setup tab: switch on "Ghostie food price reader" (Accessibility, limited to food apps). Delivery fees are only shown by some apps in search results; otherwise an assumed fee (default ₹40, editable) is used and marked "~".
- Untested on real apps: screen layouts differ and change, so results are best-effort. Failures now say why (e.g. "no search box found").

## 🎨 Look & feel, chat box, tutorial, calls (latest)
- Themes: Midnight purple, Ocean, Forest, Rose, Sunset, Black & white, White & black; pick a theme colour; Glass look (translucent panels, blur behind the chat box on Android 12+). Applies to the app, the chat box and the call screen.
- Chat box: drag the title bar to move it, drag the ◢ corner to resize; size and place are remembered (presets and reset in Look & feel). "Tap the ghost to open chat straight away" skips the big-ghost visit.
- Tutorial: shown once after install/update (can be turned off), reopen from Look & feel. Long explanations under settings are hidden by default ("Show explanations" brings them back; tap a card title to read just that card's).
- Calls: ringing now always stops (40 s limit, closing the call screen stops it, and an alarm failsafe silences it even if the app is gone). New: if a deadline isn't marked Done, Ghostie rings like a call 1 hour before (choose 2 h / 1 h / 30 / 15 min; Done on the call or the reminder cancels it).

## 📂 Files
- Automatic sorting of WhatsApp documents is now OFF by default (switch in the Documents card). "Organize now" still works any time.
- "open file maths notes", "open the DBMS pdf", "open lab record.docx": Ghostie searches Downloads, Documents, Pictures, Ghostie's sorted folders and WhatsApp documents, then opens the best match in your normal viewer (needs the File access permission). Several equally good matches: it opens the newest, or asks for more of the name.

## Simpler screens
Cards are tap-to-open (▸/▾ in the title; the first card of each tab starts open and your choices are remembered). Glass look has an intensity slider. Switches follow the theme colour.

## Glass navigation bars
Look & feel > Navigation bar: Neon glass (glowing arch), Dip bubble, Pop bubble, or the Classic top tabs. Default is Neon glass.

## Simple / Advanced mode
Switch at the top of every screen. Simple (default) shows the essentials; Advanced adds recent events, manual catch-up, learned items, Companion options, Share, group rules, activity log and AI chat.

## Payment apps (Paytm, BharatPe...) won't open
Those apps refuse to run when they find a sideloaded app with powerful permissions (screen-reading Accessibility, all-files access, usage access, call/contacts). Play Protect itself can't be "satisfied" by code. To test, build the **lite** variant: in `gradle.properties` change `ghostie.lite=false` to `ghostie.lite=true`. It drops the two Accessibility services and the all-files / usage-access / call / contacts permissions and installs as a separate app "com.ghostie.pet.lite". Lite loses: reading open WhatsApp chats, food price check, document sorting/open file, study app-blocking and the call-by-name command. If the payment apps work with lite, we know which permissions trigger it.

Food check result is never lost: if you close the chat box during the check, Ghostie sends a notification with the full result and the ghost appears saying "tap me" (tapping opens the chat with the result). Say "show last food result" to see it again.
