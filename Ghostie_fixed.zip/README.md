# Ghostie Android — online-build ready

This is a native Android project for the Ghostie floating companion. It is prepared so you can build an installable APK in the cloud without installing Android Studio.

## Easiest: GitHub Actions (recommended)

1. Create a free GitHub account if you do not already have one.
2. Create a **new empty repository**.
3. Upload the **contents** of this folder to the repository. The `.github/workflows/build-apk.yml` file must be present.
4. Open the repository's **Actions** tab.
5. Select **Build Ghostie APK**.
6. Tap **Run workflow**.
7. Wait for the build to finish.
8. Open the completed workflow run and download the **Ghostie-debug-apk** artifact.
9. Extract the downloaded artifact if necessary; install `app-debug.apk` on your Android phone.

The workflow installs JDK 17, the Android SDK (platform 35) and Gradle 8.9 in the cloud, then builds `assembleDebug`. No Android Studio is required on your computer.

**Important:** `.github/workflows/build-apk.yml`, `build.gradle` and `settings.gradle` must be at the *root* of the repository, not inside a sub-folder. If the Actions tab shows no workflow, the folder was uploaded one level too deep.

## Codemagic alternative

This repository also contains `codemagic.yaml`. Codemagic supports native Android projects and can produce an APK artifact. Connect this GitHub repository in Codemagic, choose the Android/native workflow, and start a build.

## Phone permissions

After installing Ghostie, open it and grant **Display over other apps**. Android may also ask for notification/foreground-service permission depending on the phone and Android version. These permissions are required for a persistent floating overlay on modern Android versions.

## Notes

- The debug APK is suitable for direct installation/testing.
- For Google Play release, create and protect a signing keystore and use a release build.
- Do not put an OpenAI API key into the source code or a public repository. Enter it inside the app instead.

## Chat commands (work offline, no API key needed)

- `organize documents` - copies every document WhatsApp saved into `Documents/Ghostie/<Subject>/` (originals are untouched). Sorting is by file name using the subject list on the Ghostie settings screen. WhatsApp does not record which group a file came from, so this covers all groups. Allow "file access" once when asked.
- `add event maths exam tomorrow 10am` - opens your calendar pre-filled.
- `timer 10 minutes`, `alarm 6:30 am`, `open WhatsApp`, `help`.

## Group reminders

Add your WhatsApp group name(s) in the app (or tell the ghost: `watch group CSE 3A`) and switch on **Notification access** and **Calendar**. When a message in that group mentions a submission date (e.g. "submit DBMS record by 5th Nov"), Ghostie adds a calendar reminder at 9:00 the day before and lists it under **Upcoming submissions** in the app. The ghost also mentions anything due today or tomorrow. Use **Test message** in the app to see what it would detect.

Limits: WhatsApp has no public API, so Ghostie only sees messages that arrive as notifications while it is running (not old chat history, and not groups whose notifications are turned off).

## Catching up when a notification was missed

WhatsApp does not post a notification for the chat you currently have open (or for muted groups), so the live watcher can miss messages. To catch up: in the group tap the three dots > More > Export chat > Without media, then pick **Add Ghostie reminders** in the share sheet. You can share a single message the same way. In the app, **Scan a chat file** does the same for an export saved on the phone. Already-added deadlines are not duplicated.

## Read open chats (optional, fully automatic)

Turn on **Read open chats** in the app's Setup list (Android Accessibility). While one of your watched groups is open in WhatsApp, Ghostie reads the visible messages and adds reminders for submission dates, so nothing is missed when WhatsApp posts no notification. It only observes WhatsApp, only acts on groups you listed, and processes everything on the phone. On Android 13+ you may first need Settings > Apps > Ghostie > ⋮ > Allow restricted settings.

## Personality

Ghostie chats offline: greetings that depend on the time of day, jokes, fun facts, study and stress support, name memory ("my name is ..."), and it asks follow-ups. It bobs, sways, blinks and glances while idle, pops when tapped or when it speaks, and bounces in when it visits. If you add an OpenAI key and turn on AI chat, the same casual personality is used for free-form conversation.

If Android shows a floating accessibility button after you enable "Read open chats", turn it off in Settings > Accessibility > Ghostie chat reader > Shortcut (or the floating button settings). Ghostie doesn't need it.

## Event registrations

Besides submissions, Ghostie also records the last date to register or apply for events ("last date to register for Hackathon is 12 Nov", "apply for the internship before 15/11", "RSVP by 3 Nov"). It adds a calendar reminder the day before (marked 📝) and lists it under **Upcoming deadlines**. Messages that only give the event's own date ("TechFest is on 12 Nov") are ignored.
